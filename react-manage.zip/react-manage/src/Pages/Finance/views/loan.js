/*
 * @Author: miccy 
 * @Date: 2018-01-18 17:41:29 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 10:08:48
 * 财务借款管理
 */
import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import TwoDecimals from '../../../Common/twoDecimals'
import { Card, Table, Button } from 'antd'
import { handleStartTime, handleEndTime, toMoney } from '../../../Util/reactUtil'
import { requestGet, requestAdd } from '../../../Util/Request'
import { actionAdd, actionEdit, actionCancel, actionChangePage, actionClearSearch, actionSearch, actionSave, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'
import { getFetch } from '../../../Config/request';
const addTitle = '新建借款',
  editTitle = '查看借款',
  newItem = {}

const pagingUrl = '/system/loan/paging', //获取列表
  addUrl = '/system/loan/add', //添加
  getSystemCapitalUrl = '/system/appropriation/getsystemcapital' //获取系统资金账户信息

const statusOptions = [
  { label: '申请借款', value: '1' },
  { label: '同意借款', value: '2' },
  { label: '拒绝借款', value: '3' }
]
class Loan extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({ params, pagingUrl, context: this }).then(() => {
        this.Request.getSystemCapital()
      })
    },
    getSystemCapital: (params) => {
      getFetch(getSystemCapitalUrl, params).then(res => {
        if (res.status == 0 && res.model) {
          this.setState({
            systemCapital: res.model
          })
        }
      })
    },
    // 添加数据
    add: (params) => {
      requestAdd({ params, addUrl, context: this })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.formItems = this.Util.getFormItems()
      actionAdd({ addTitle, context: this })
    },
    // 点击查看按钮
    edit: (record, index) => {
      this.formItems = this.Util.getViewFormItems()
      actionEdit({ record, editTitle, context: this })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      delete queryParams.createtime
      actionSearch({ value: queryParams, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      if (this.state.editId) {
        this.setState({
          modalVis: false,
          editId: null
        })
      } else {
        actionSave({ context: this, values })
      }
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
  }
  Util = {
    getFormItems: (() => {
      let formItems;
      return () => {
        if (formItems) {
          return formItems
        } else {
          return formItems = [
            {
              render: TwoDecimals,
              type: EditType.InputNum,
              label: '借款金额',
              key: 'amount',
              config: {
                rules: [
                  { required: true, message: '请输入借款金额' },
                  {
                    validator: (rule, value, callback) => {
                      if (value && value <= 0) {
                        callback('借款金额不得小于等于0');
                      }
                      callback();
                    }
                  }
                ],
              },
              isInputNum: true
            }, {
              type: EditType.InputStr,
              label: '借款原因',
              key: 'whatfor',
              config: {
                rules: [
                  { required: true, message: '请输入借款原因' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '备注',
              key: 'note'
            },
            {
              type: EditType.Select,
              label: '借款货币类型',
              key: 'channelId',
              config: {
                rules: [
                  { required: true, message: '请选择打款货币类型' }
                ]
              },
              itemConfig: {
                options: [
                  { label: '积分', value: 6 },
                  { label: '余额', value: 8 }
                ]
              }
            },
            {
              type: EditType.InputStr,
              label: '支付密码',
              key: 'payPassword',
              config: {
                rules: [
                  { required: true, message: '请输入支付密码' }
                ]
              },
              itemConfig: {
                type: 'password',
                autoComplete: 'false'
              }
            }
          ]
        }
      }

    })(),
    getViewFormItems: (() => {
      let formItems
      return () => {
        if (formItems) {
          return formItems
        } else {
          return formItems = [
            {
              render: TwoDecimals,
              type: EditType.InputNum,
              label: '借款金额',
              key: 'amount',
              config: {
                rules: [{ required: true, message: '请输入借款金额' }]
              },
              itemConfig: {
                readOnly: true
              },
              isInputNum: true
            }, {
              type: EditType.InputStr,
              label: '借款原因',
              key: 'whatfor',
              config: {
                rules: [
                  { required: true, message: '请输入借款原因' }
                ]
              },
              itemConfig: {
                readOnly: true
              },
            }, {
              type: EditType.InputStr,
              label: '备注',
              key: 'note',
              itemConfig: {
                readOnly: true
              }
            }, {
              type: EditType.DatePicker,
              label: '创建时间',
              key: 'createTime',
              itemConfig: {
                disabled: true,
                format: 'YYYY-MM-DD HH:mm:ss'
              }
            }, {
              type: EditType.InputStr,
              label: '平台唯一订单号',
              key: 'orderNo',
              itemConfig: {
                readOnly: true
              }
            }, {
              type: EditType.Select,
              label: '状态',
              key: 'status',
              itemConfig: {
                disabled: true,
                options: statusOptions
              }
            }
          ]
        }
      }
    })()
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
      systemCapital: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '平台唯一订单号',
          id: 'orderNo',
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime',
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
        }
      }, {
        title: '操作人',
        dataIndex: 'adminName',
        key: 'adminName'
      }, {
        title: '借款用户',
        dataIndex: 'userId',
        key: 'userId',
        render: value => '系统账户'
      }, {
        title: '平台唯一订单号',
        dataIndex: 'orderNo',
        key: 'orderNo',
      }, {
        title: '借款金额',
        dataIndex: 'amount',
        key: 'amount',
        render: value => toMoney(value)
      }, {
        title: '借款原因',
        dataIndex: 'whatfor',
        key: 'whatfor',
      }, {
        title: '借款货币类型',
        dataIndex: 'channelId',
        key: 'channelId',
        render: value => {
          if (value === 6) {
            return '积分';
          } else if (value === 8) {
            return '余额';
          }
          return value;
        }
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => {
          let option = statusOptions.filter(item => item.value == value)
          return !is.empty(option) && option[0].label
        }
      }, {
        title: '操作时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        // width: 250,
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>查看</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = this.Util.getFormItems()
    //新建面板表单的初始内容
    this.newItem = newItem
  }
  render() {
    const { dataSource, title, modalVis, modal, current, totalModels, pageSize, systemCapital } = this.state
    const { add, search, clearSearch, save, cancel, changePage, onShowSizeChange } = this.Action
    return (
      <div>
        <Card>
          <p style={{ fontSize: 30, fontWeight: 'bold', color: '#108ee9' }}>
            当前系统账户总余额：{parseFloat(isNaN(systemCapital.totalResidual) ? 0 : systemCapital.totalResidual / 100).toFixed(2) + '元'}</p>
          <p style={{ fontSize: 30, fontWeight: 'bold', color: '#108ee9' }}>
            当前系统账户总积分：{parseFloat(isNaN(systemCapital.totalIntegral) ? 0 : systemCapital.totalIntegral / 100).toFixed(2)}</p>
        </Card>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增借款</Button>
        </Card>
        <Table
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange,
            showTotal: actionShowTotal,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default Loan