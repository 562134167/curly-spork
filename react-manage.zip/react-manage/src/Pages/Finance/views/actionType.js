/*
 * @Author: miccy 
 * @Date: 2018-04-09 10:38:19 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2018-04-25 15:21:49
 * 打款操作类型
 */
import React, { Component } from 'react'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
// import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Button } from 'antd'
import { formateEditData } from '../../../Util/reactUtil'
// import { hasAttr } from '../../../Util'
// import { fetch, getFetch } from '../../../Config/request'
import { requestGet, requestAdd, requestUpdate } from '../../../Util/Request'
import { actionAdd, actionEdit, actionCancel, actionChangePage, actionEditItems, actionSave, initGetParams, actionOnShowSizeChange } from '../../../Util/Action'
const addTitle = '新建操作类型'
const editTitle = '编辑操作类型'

const newItem = {
    status: 1,
    sort: 1
}
const pagingUrl = '/system/appropriation/pagingtype', //获取列表
    addUrl = '/system/appropriation/addtype', //添加
    updateUrl = '/system/appropriation/updatetype'; //修改
// const updatePropertyUrl = '/system/feelingsetting/updateproperty' //批量修改
class ActionType extends Component {
    constructor(props) {
        super(props)

        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({ params, pagingUrl, context: this })
        },
        // 添加数据
        add: (params) => {
            requestAdd({ params, addUrl, context: this })
        },
        // 修改数据
        edit: (params) => {
            requestUpdate({ params, updateUrl, context: this })
        },
        // 批量更新属性
        // editItems: (params) => {
        //     requestUpdateProperty({ params, updatePropertyUrl, context: this })
        // }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        // 点击新建按钮
        add: () => {
            actionAdd({ addTitle, context: this })
        },
        // 点击修改按钮
        edit: (record, index) => {
            actionEdit({ record, editTitle, context: this })
        },
        // 保存模态框表单数据（新建/编辑）
        save: (values) => {
            actionSave({ context: this, values })
        },
        cancel: () => {
            actionCancel({ context: this })
        },
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this })
        },
        // 点击批量操作按钮
        editItems: ({ name, value }) => {
            actionEditItems({ context: this, name, value })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this })
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        const { edit } = this.Action
        this.state = {
            title: addTitle,
            dataSource: [],
            modalVis: false,
            modal: {},
            editId: null,
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 20,
        }

        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
            },
            {
                title: '操作类型名称',
                dataIndex: 'name',
                key: 'name',
            },
            {
                title: '排序',
                dataIndex: 'sort',
                key: 'sort'
            }, {
                title: '状态',
                dataIndex: 'status',
                key: 'status',
                render: value => value == 1 ? '启用' : '禁用'
            }, {
                title: '操作',
                dataIndex: 'actions',
                key: 'actions',
                width: 250,
                render: (text, record, index) => (
                    <span>
                        <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
                    </span>
                )
            }
        ]
        // 编辑面板内容
        this.formItems = [
            {
                type: EditType.InputStr,
                label: '操作类型名称',
                key: 'name',
                config: {
                    rules: [
                        { required: true, message: '请输入操作类型名称' },
                        {
                            validator: (rule, value, callback) => {
                                if (value && value.length > 20) {
                                    callback('操作类型名称不得多于20个字！');
                                }
                                callback();
                            }
                        }
                    ]
                }
            }, {
                type: EditType.InputNum,
                label: '排序',
                key: 'sort',
                config: {
                    rules: [
                        { required: true, message: '请输入排序' }
                    ]
                }
            }, {
                type: EditType.Select,
                label: '状态',
                key: 'status',
                itemConfig: {
                    options: [
                        { value: 1, label: '启用' },
                        { value: 0, label: '禁用' },
                    ]
                },
                config: {
                    rules: [
                        { required: true, message: '请选择状态' }
                    ]
                },
            },
        ]
        //新建面板表单的初始内容
        this.newItem = formateEditData(newItem, this.formItems)
        for (let i in this.newItem) {
            this.newItem[i] = {
                value: this.newItem[i]
            }
        }
    }
    render() {
        const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, pageSize } = this.state
        const { add, save, cancel, changePage, onShowSizeChange } = this.Action
        return (
            <div>
                <Card>
                    <Button type="primary" onClick={add} className="action-item">新增</Button>
                    {/* <DropdownBtn
                        className="action-item"
                        mainLabel="批量操作"
                        keyName="status"
                        items={[{ label: '批量启用', value: '1' },
                        { label: '批量禁用', value: '0' }]}
                        onClick={(obj) => { editItems(obj) }}
                    /> */}
                </Card>
                <Table
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange
                    }}
                />
                <EditPanel
                    title={title}
                    modalVis={modalVis}
                    formItems={this.formItems}
                    modal={modal}
                    onSave={save}
                    onCancel={cancel}
                />
            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: initGetParams
        })
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
    }
}
export default ActionType
