/*
 * @Author: miccy 
 * @Date: 2018-01-18 17:41:29 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 17:30:10
 * 全部打款记录
 */
import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Table, Button, message } from 'antd'
import { toMoney } from '../../../Util/reactUtil'
import { getQueryObj, arrayToObject } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import { requestGet } from '../../../Util/Request'
import { actionAdd, actionSearch, actionClearSearch, actionCancel, actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'
const confirmTitle = '确认打款'
const newItem = {}
const pagingUrl = '/system/appropriation/paginginfo', //获取列表
  confirmUrl = '/system/appropriation/confirm', //确定打款
  getRecordUrl = '/system/appropriation/getrecord',//获取本次打款记录的总金额
  getTypeListUrl = '/system/appropriation/gettypelist'

class AppropriationInfo extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({ params: { ...params, recordId: this.queryObj.id }, pagingUrl, context: this }).then(res => {
        if (res.status == 0) {
          !this.state.typeOptions.length && this.Request.getType();
          this.queryObj.id && this.Request.getRecord({ id: this.queryObj.id })
        }
      })
    },
    getType: () => {
      getFetch(getTypeListUrl).then(res => {
        if (res.status == 0) {
          const { typeOptions, typeOptionsEnabled } = this.state
          res.models.forEach(item => {
            typeOptions.push({
              label: item.name,
              value: item.id,
              status: item.status
            })
            if (item.status === '1') {
              typeOptionsEnabled.push({
                label: item.name,
                value: item.id
              })
            }
          })
          this.setState({
            typeEnum: arrayToObject({ array: res.models, keyName: 'id', valueName: 'name' }),
            typeOptions
          })
        }
      })
    },
    // 确认打款
    confirm: (params) => {
      return fetch(confirmUrl, params).then(res => {
        if (res.status == 0) {
          this.props.history.replace('/finance/appropriationRecord')
        }
      })
    },
    // 获取本次打款记录的总金额
    getRecord: (params) => {
      getFetch(getRecordUrl, params).then(res => {
        if (res.status == 0) {
          this.setState({
            recordAmount: res.model.totalAmount
          })
        }
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const mobileRegx = /^1\d{10}$/gi
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      if (!is.undefined(queryParams.createTime) && !is.undefined(queryParams.createTime[0])) {
        queryParams.startTime = queryParams.createTime[0].format('x')
        queryParams.endTime = queryParams.createTime[1].format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      delete queryParams.createTime
      actionSearch({ value: queryParams, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    // 点击新建按钮
    confirm: () => {
      actionAdd({ addTitle: confirmTitle, context: this })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      this.Request.confirm({
        ...values,
        recordId: this.queryObj.id
      })
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
  }

  Util = {
    getTotalAmount: (dataSource) => {
      let totalAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (item.capitalBalance) {
          totalAmount += item.capitalBalance
        }
      })
      return totalAmount
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.state = {
      title: confirmTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
      totalAmount: 0,
      recordAmount: 0, //本次打款记录的总金额
      typeOptions: [],
      typeOptionsEnabled: [],
      typeEnum: {}
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [{
        type: SearchType.String,
        label: '手机号码',
        id: 'mobilePhone'
      }, {
        type: SearchType.DateRange,
        label: '时间段',
        id: 'createTime',
        config: {
          showTime: true,
          format: "YYYY-MM-DD HH:mm:ss",
        }
      }, {
        type: SearchType.Select,
        label: '打款操作类型',
        id: 'type',
        dataSource: this.state.typeOptions
      }, {
        type: SearchType.Select,
        label: '打款货币类型',
        id: 'channelId',
        dataSource: [{ label: '余额', value: 8 }, { label: '积分', value: 6 }]
      }]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
        }
      }, {
        title: '收款方手机号码',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone'
      }, {
        title: '收款方真实姓名',
        dataIndex: 'realName',
        key: 'realName'
      }, {
        title: '打款',
        dataIndex: 'capitalBalance',
        key: 'capitalBalance',
        render: (value, record) => {
          if (record.channelId == 6) {
            return toMoney(record.amount, '积分')
          } else if (record.channelId == 8) {
            return toMoney(value)
          }
          return value
        }
      }, {
        title: '打款操作类型',
        dataIndex: 'type',
        key: 'type',
        render: value => this.state.typeEnum[value] || value
      }, {
        title: '产品类型',
        dataIndex: 'channelId',
        key: 'channelId',
        render: value => {
          if (value == 6) {
            return '积分'
          } else if (value == 8) {
            return '余额'
          }
          return value;
        }
      }, {
        title: '打款前',
        dataIndex: 'preBalance',
        key: 'preBalance',
        render: (value, record) => {
          if (record.channelId == 6) {
            return toMoney(value, '积分');
          } else if (record.channelId == 8) {
            return toMoney(value);
          }
          return toMoney(value, '');
        }
      }, {
        title: '打款后',
        dataIndex: 'afterBalance',
        key: 'afterBalance',
        render: (value, record) => {
          if (record.channelId == 6) {
            return toMoney(value, '积分');
          } else if (record.channelId == 8) {
            return toMoney(value);
          }
          return toMoney(value, '');
        }
      }, {
        title: '备注（喊话内容）',
        dataIndex: 'note',
        key: 'note'
      }
    ]
    // 编辑面板内容
    this.formItems = [{
      type: EditType.InputStr,
      label: '支付密码',
      key: 'payPassword',
      config: {
        rules: [
          { required: true, message: '请输入支付密码' }
        ]
      },
      itemConfig: {
        type: 'password'
      }
    }, {
      type: EditType.Select,
      label: '打款操作类型',
      key: 'typeId',
      config: {
        rules: [
          { required: true, message: '请选择打款操作类型' }
        ]
      },
      itemConfig: {
        options: this.state.typeOptionsEnabled
      }
    }
    ]
    //新建面板表单的初始内容
    this.newItem = newItem
    //将url的查询参数转换成查询对象
    this.queryObj = getQueryObj(this.props.location.search) || {}
    if (this.queryObj.status !== 1) {
      this.columns.push({
        title: '订单号',
        dataIndex: 'orderNo',
        key: 'orderNo'
      }, {
          title: '打款时间',
          dataIndex: 'createTime',
          key: 'createTime',
          render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        })
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, current, totalModels, pageSize, totalAmount, recordAmount } = this.state
    const { confirm, search, clearSearch, save, cancel, changePage, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        {(this.queryObj.status == 1) ? (<Card>
          <Button type="primary" onClick={confirm} className="action-item">确认打款</Button>
        </Card>) : null}
        <Card>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页总打款金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}</p>
          {(this.queryObj.id !== undefined) ? <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            本次打款记录总金额：{parseFloat(recordAmount / 100).toFixed(2) + '元'}</p> : null}
        </Card>
        <Table
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange,
            showTotal: actionShowTotal,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, dataSource } = this.state
    const { get } = this.Request
    const { getTotalAmount } = this.Util
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    // 当前页的数据发生变化时，计算当前页的总金额
    if (nextState.dataSource !== dataSource) {
      this.setState({
        totalAmount: getTotalAmount(nextState.dataSource)
      })
    }
  }
}
export default AppropriationInfo