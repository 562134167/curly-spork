/*
 * @Author: miccy 
 * @Date: 2018-01-30 14:39:21 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-20 17:42:31
 * 财务单笔转账
 */
import React, { Component } from 'react'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, message, Button, Card } from 'antd'
import { formatData, flattenObj, toMoney } from '../../../Util/reactUtil'
// import { getQueryObj } from '../../../Util'
import { getFetch } from '../../../Config/request'
import { requestGet, requestAdd } from '../../../Util/Request'
import { actionEdit, actionCancel, actionChangePage, actionClearSearch, actionSearch, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'
import TwoDecimals from '../../../Common/twoDecimals'
const title = '打款给用户'

const pagingUrl = '/system/capital/paging',
  addUrl = '/system/appropriation/transfer',
  getTypeListUrl = '/system/appropriation/gettypelist'

class Transfer extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({
        params, pagingUrl, context: this, successCallback: (res) => {
          if (res && is.array(res.models)) {
            const { models, totalModels, totalPages } = res
            const dataSource = formatData(flattenObj(models, ['capital']))
            this.setState({
              dataSource,
              totalModels,
              totalPages,
              current: params.pageIndex
            })
            !this.state.typeOptions.length && this.Request.getType();
          }
          return res
        }
      })
    },
    getType: () => {
      getFetch(getTypeListUrl).then(res => {
        if (res.status == 0) {
          const { typeOptions } = this.state
          res.models.forEach(item => {
            if (item.status === '1') {
              typeOptions.push({
                label: item.name,
                value: item.id,
              })
            }
          })
          this.setState({
            // typeEnum: arrayToObject({ array: res.models, keyName: 'id', valueName: 'name' }),
            typeOptions
          })
        }
      })
    },
    // 打款
    pay: (params) => {
      requestAdd({ params, addUrl, context: this })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const mobileRegx = /^1\d{10}$/gi
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      actionSearch({ value: queryParams, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    // 点击修改按钮
    edit: (record, index) => {
      actionEdit({ record, editTitle: title, context: this })
      this.setState({
        editId: record.userId
      })
    },
    save: (values) => {
      const { editId } = this.state
      const { pay } = this.Request
      // 把保存的数值发送到服务器
      pay({
        userId: editId,
        ...values
      })

    },
    cancel: () => {
      actionCancel({ context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
  }

  Util = {
    getTotalAmount: (dataSource) => {
      let totalAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (item.totalResidual) {
          totalAmount += item.totalResidual
        }
      })
      return totalAmount
    },
    getSelectedAmount: (dataSource, selectedRowKeys) => {
      const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
      if (!tempSelectedRowKeys.length) {
        return 0
      }
      const selectedString = tempSelectedRowKeys.join(',')
      let selectedAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (selectedString.indexOf(item.id) > -1 && item.totalResidual) {
          selectedAmount += item.totalResidual
        }
      })
      return selectedAmount
    }
  }

  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    const { edit } = this.Action;
    this.state = {
      dataSource: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      editId: null,
      modalVis: false,
      modal: null,
      title: title,
      pageSize: 50,
      selectedRowKeys: [],
      totalAmount: 0,
      selectedAmount: 0,
      typeOptions: []
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone',
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
        }
      },
      {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName',
      },
      {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile',
      }, {
        title: '可用积分',
        dataIndex: 'totalIntegral',
        key: 'totalIntegral',
        render: value => toMoney(value, '')
      }, {
        title: '可用余额',
        dataIndex: 'totalResidual',
        key: 'totalResidual',
        render: value => toMoney(value)
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <Button type="primary" className="action-item" onClick={() => edit(record, index)}> 打款</Button>
        )
      }
    ];
    this.formItems = [
      {
        render: TwoDecimals,
        type: EditType.InputNum,
        key: 'money',
        label: '打款资金',
        config: {
          rules: [
            { required: true, message: '请填写要打款的金额数目' },
            {
              validator: (rule, value, callback) => {
                if (value && value <= 0) {
                  callback('打款的金额不得小于等于0');
                }
                callback();
              }
            }
          ],
        },
        isInputNum: true
      }, {
        type: EditType.InputStr,
        key: 'note',
        label: '备注(喊话内容)'
      }, {
        type: EditType.InputStr,
        label: '支付密码',
        key: 'payPassword',
        config: {
          rules: [
            { required: true, message: '请输入支付密码' }
          ]
        },
        itemConfig: {
          type: 'password'
        }
      },
      {
        type: EditType.Select,
        label: '打款货币类型',
        key: 'channelId',
        config: {
          rules: [
            { required: true, message: '请选择打款货币类型' }
          ]
        },
        itemConfig: {
          options: [
            { label: '积分', value: 6 },
            { label: '余额', value: 8 }
          ]
        }
      },
      {
        type: EditType.Select,
        label: '打款操作类型',
        key: 'typeId',
        config: {
          rules: [
            { required: true, message: '请选择打款操作类型' }
          ]
        },
        itemConfig: {
          options: this.state.typeOptions
        }
      }
    ]
  }
  render() {
    const { dataSource, current, totalModels, title, modalVis, modal, pageSize, totalAmount, selectedAmount, selectedRowKeys } = this.state
    const { changePage, search, clearSearch, save, cancel } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页总金额：{parseFloat(totalAmount / 100).toFixed(2)}，已选中的项的总金额：{parseFloat(selectedAmount / 100).toFixed(2)}</p>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: actionShowTotal,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, selectedRowKeys, dataSource } = this.state
    const { get } = this.Request
    const { getSelectedAmount, getTotalAmount } = this.Util
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    // 选中的项发生变化时，计算已选中的项的总金额
    if (nextState.selectedRowKeys !== selectedRowKeys) {
      this.setState({
        selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
      })
    }
    // 当前页的数据发生变化时，计算当前页的总金额
    if (nextState.dataSource !== dataSource) {
      this.setState({
        totalAmount: getTotalAmount(nextState.dataSource)
      })
    }
  }
}

export default Transfer
