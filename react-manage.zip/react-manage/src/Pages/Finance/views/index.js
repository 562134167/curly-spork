import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
// import './index.less'

const loadLoan = (cd) => {
  return import('./loan.js')
}
const loadAppropriationRecord = (cd) => {
  return import('./appropriationRecord.js')
}
const loadAppropriationInfo = (cd) => {
  return import('./appropriationInfo.js')
}
const loadTransfer = (cd) => {
  return import('./transfer.js')
}
const loadActionType = (cd) => {
  return import('./actionType.js')
}
const Loan = getComponent(loadLoan)
const AppropriationRecord = getComponent(loadAppropriationRecord)
const AppropriationInfo = getComponent(loadAppropriationInfo)
const Transfer = getComponent(loadTransfer)
const ActionType = getComponent(loadActionType)
export default class Finance extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/finance"
          exact render={() => <Redirect to="/finance/loan" />}
        />
        <Route path='/finance/loan' render={(props) => <Loan {...props} />} />
        <Route path='/finance/appropriationRecord' render={(props) => <AppropriationRecord {...props} />} />
        <Route path='/finance/appropriationInfo' render={(props) => <AppropriationInfo {...props} />} />
        <Route path='/finance/transfer' render={(props) => <Transfer {...props} />} />
        <Route path='/finance/actionType' render={(props) => <ActionType {...props} />} />
      </Switch>
    )
  }
}