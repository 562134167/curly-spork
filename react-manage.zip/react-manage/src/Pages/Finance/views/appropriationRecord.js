/*
 * @Author: miccy 
 * @Date: 2018-01-18 17:41:29 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 17:30:23
 * 打款记录
 */
import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Table, Button } from 'antd'
import { handleStartTime, handleEndTime, toMoney } from '../../../Util/reactUtil'
import { hasAttr, arrayToObject } from '../../../Util'
import { getFetch } from '../../../Config/request'
import { requestGet, requestAdd } from '../../../Util/Request'
import { actionAdd, actionCancel, actionChangePage, actionClearSearch, actionSearch, actionSave, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'
const addTitle = '导入数据'
// const editTitle = '查看借款'
const newItem = {}
const pagingUrl = '/system/appropriation/pagingrecord' //获取列表
const addUrl = '/system/appropriation/add' //添加
const uploadFileUrl = '/system/file/uploadexcel',
  getTypeListUrl = '/system/appropriation/gettypelist'

class AppropriationRecord extends Component {
  constructor(props) {
    super(props)
    // 绑定作用域
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({ params, pagingUrl, context: this }).then(res => {
        if (res.status == 0) {
          !this.state.typeOptions.length && this.Request.getType();
        }
      })
    },
    getType: () => {
      getFetch(getTypeListUrl).then(res => {
        if (res.status == 0) {
          const { typeOptions } = this.state
          res.models.forEach(item => {
            typeOptions.push({
              label: item.name,
              value: item.id
            })
          })
          this.setState({
            typeEnum: arrayToObject({ array: res.models, keyName: 'id', valueName: 'name' }),
            typeOptions
          })
        }
      })
    },
    // 添加数据
    add: (params) => {
      requestAdd({ params, addUrl, context: this }).then(res => {
        if (res.status == 0) {
          this.props.history.push(`/finance/appropriationInfo?id=${res.model}&status=1`)
        }
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      actionAdd({ addTitle, context: this })
    },
    // 查看批量转账的列表
    view: (record) => {
      this.props.history.push(`/finance/appropriationInfo?id=${record.id}&status=${record.status}`)
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      delete queryParams.createtime
      actionSearch({ value: queryParams, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      actionSave({ context: this, values, handleChangedData: this.Util.handleChangedData })
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
  }
  Util = {
    //处理表单的保存内容的key、value以匹配后台的格式
    handleChangedData: (obj) => {
      if (is.object(obj)) {
        const filePath = hasAttr(obj, ['filePath', 0, 'response', 'model'])
        if (filePath) {
          obj.filePath = filePath
        }
      }
      return obj
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { view } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      // selectedRowKeys: [],
      current: 1,
      totalModels: null,
      // totalPages: null,
      getDataParams: {},
      pageSize: 50,
      typeOptions: [],
      typeEnum: {}
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [{
        type: SearchType.DateRange,
        label: '时间段',
        id: 'createtime',
      }, {
        type: SearchType.String,
        label: '标题',
        id: 'title'
      }, {
        type: SearchType.Select,
        label: '打款操作类型',
        id: 'type',
        dataSource: this.state.typeOptions
      }, {
        type: SearchType.Select,
        label: '打款货币类型',
        id: 'channelId',
        dataSource: [{ label: '余额', value: 8 }, { label: '积分', value: 6 }]
      }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
        }
      }, {
        title: '标题',
        dataIndex: 'title',
        key: 'title',
      },
      {
        title: '描述',
        dataIndex: 'content',
        key: 'content',
      }, {
        title: '导入表格的总金额',
        dataIndex: 'totalAmount',
        key: 'totalAmount',
        render: value => toMoney(value)
      },
      {
        title: '打款操作类型',
        dataIndex: 'type',
        key: 'type',
        render: value => this.state.typeEnum[value] || value
      },
      {
        title: '打款货币类型',
        dataIndex: 'channelId',
        key: 'channelId',
        render: value => {
          if (value == 6) {
            return '积分'
          } else if (value == 8) {
            return '余额'
          }
          return value;
        }
      },
      {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => {
          if (value == 1) {
            return '导入成功'
          } else if (value == 2) {
            return '批量打款成功'
          }
        }
      }, {
        title: '操作时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        // width: 250,
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { view(record, index) }}>查看</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '标题',
        key: 'title',
        config: {
          rules: [
            { required: true, message: '请输入标题' },
            {
              validator: (rule, value, callback) => {
                if (value && value.length > 255) {
                  callback('标题的字数不得多于255个');
                }
                callback();
              }
            }
          ]
        },
      }, {
        type: EditType.InputStr,
        label: '描述',
        key: 'content',
        config: {
          rules: [
            { required: true, message: '请输入描述' },
            {
              validator: (rule, value, callback) => {
                if (value && value.length > 255) {
                  callback('描述的字数不得多于255个');
                }
                callback();
              }
            }
          ]
        },
      },
      {
        type: EditType.Select,
        label: '打款货币类型',
        key: 'channelId',
        config: {
          rules: [
            { required: true, message: '请选择打款货币类型' }
          ]
        },
        itemConfig: {
          options: [
            { label: '积分', value: 6 },
            { label: '余额', value: 8 }
          ]
        }
      }, {
        type: EditType.Image,
        label: 'excel文件',
        key: 'filePath',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            console.log(e);
            if (Array.isArray(e)) {
              return e;
            }
            return e && e.fileList;
          },
          rules: [
            { required: true, message: '请上传excel文件' }
          ]
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          tip: '上传excel文件',
          accept: '.xls, .xlsx',
          name: 'files',
          listType: 'text',
        },
        isImageAutoHandle: false,
        isShowbtn: (props) => {
          if (props.form.getFieldValue('filePath') && props.form.getFieldValue('filePath').length) {
            return false
          }
          return true
        }
      }
    ]
    //新建面板表单的初始内容
    this.newItem = newItem
  }
  render() {
    const { dataSource, title, modalVis, modal, current, totalModels, pageSize } = this.state
    const { add, search, clearSearch, save, cancel, changePage, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">导入数据</Button>
        </Card>
        <Table
          // rowSelection={{
          //   selectedRowKeys: selectedRowKeys,
          //   onChange: (selectedRowKeys, selectedRows) => {
          //     this.setState({
          //       selectedRowKeys
          //     })
          //   },
          // }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange,
            showTotal: actionShowTotal,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    // console.log(nextState.selectedRowKeys)
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default AppropriationRecord