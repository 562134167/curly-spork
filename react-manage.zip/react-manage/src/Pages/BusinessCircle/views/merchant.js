import React, { Component } from 'react'
import { connect } from 'react-redux'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Table, Popconfirm, Button } from 'antd'
import { formatData, formateEditData, formatParentIdOptions } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import EditableTag from './component/EditableTag'
const addTitle = '新建商户',
  editTitle = '编辑商户',
  initGetParams = {
    // keyword: '',
    pageIndex: 1,
    pageSize: 20
  },
  newItem = {
    isRecommend: 0,
    status: "1",
    createTime: new Date().getTime()
  };

const pagingUrl = '/system/merchant/infos', //获取列表
  addUrl = '/system/merchant/addinfo', //添加
  updateUrl = '/system/merchant/updateinfo', //修改
  //  updatePropertyUrl = '/system/officialaccounts/updateproperty', //批量修改
  removeUrl = '/system/merchant/deleteinfo', //删除
  removeItemsUrl = '/system/merchant/deleteinfos', //批量删除
  uploadFileUrl = '/system/file/upload' //上传图片
class Merchant extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeItemsUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle,
        fileList: []
      })
    },
    addRecommend: (record, index) => {
      this.Request.addRecommend({
        id: record.id
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems, this.Util.handleEditData)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }

      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state

      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            delete values.createTime
            const temp = this.Util.handleChangedData({ id: dataSource[i].id, ...values })
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = this.Util.handleChangedData(values);
        add(temp)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
  }
  // 方法对象
  Util = {
    // 处理传入表单的编辑内容的key、value以匹配组件的格式要求
    handleEditData: (obj) => {
      // const { getFileList } = this.Util
      if (is.object(obj)) {
        // obj.bgImage = (obj.bgImage && obj.bgImage.trim() && getFileList(obj.bgImage.trim())) || []
        // obj.merIcon = (obj.merIcon && obj.merIcon.trim() && getFileList(obj.merIcon.trim())) || []
        if (obj.label) {
          let label = obj.label || '';
          label = label.replace('[', '')
          label = label.replace(']', '')
          label = label.split(',')
          obj.label = label
        }

      }
      return obj
    },
    //处理表单的保存内容的key、value以匹配后台的格式
    handleChangedData: (obj) => {
      if (is.object(obj)) {
        obj.label = obj.label && obj.label.join(',')
      }
      return obj
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }// 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '商户名',
          id: 'merName',
          type: SearchType.String,
        }, {
          label: '商户号',
          id: 'merNumber',
          type: SearchType.String,
        },
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '商户名',
        dataIndex: 'merName',
        key: 'merName'
      }, {
        title: '商户号',
        dataIndex: 'merNumber',
        key: 'merNumber'
      }, {
        title: '手机号',
        dataIndex: 'phone',
        key: 'phone',
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => {
          if (value == 1) {
            return '审核通过'
          } else if (value == 2) {
            return '审核不通过'
          } else if (value == 0) {
            return '未审核'
          }
          return value
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '商户名称',
        key: 'merName',
        config: {
          rules: [
            { required: true, message: '请输入商户名称' },
            {
              validator: (rule, value, callback) => {
                if (value && value.length > 11) {
                  callback('商户名称的字数不得多于11');
                }
                callback();
              }
            }
          ]
        },
      }, {
        type: EditType.InputStr,
        label: '电话号码',
        key: 'phone',
        config: {
          rules: [
            { required: true, message: '请输入用户电话号码' },
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '手机号码',
        key: 'mobilePhone',
        config: {
          rules: [
            { required: true, message: '请输入用户手机号码' },
            {
              validator: (rule, value, callback) => {
                if (value && !(/^1\d{10}$/gi.test(value))) {
                  callback('手机号码格式不正确');
                }
                callback();
              }
            }
          ]
        }
      }, {
        type: EditType.Image,
        label: '商户背景图',
        key: 'bgImage',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            if (Array.isArray(e)) {
              return e;
            }
            return e && e.fileList;
          },
          rules: [
            { required: true, message: '请上传商户背景图' }
          ]
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          tip: '上传商户背景图',
          accept: '.jpg, .png, .bmp, .jpeg',
          name: 'files'
        },
        isShowbtn: (props) => {
          if (props.form.getFieldValue('bgImage') && props.form.getFieldValue('bgImage').length) {
            return false
          }
          return true
        }
      }, {
        type: EditType.Image,
        label: '商户logo',
        key: 'merIcon',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            if (Array.isArray(e)) {
              return e;
            }
            return e && e.fileList;
          },
          rules: [
            { required: true, message: '请上传商户logo' }
          ]
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          tip: '上传商户logo',
          accept: '.jpg, .png, .bmp, .jpeg',
          name: 'files'
        },
        isShowbtn: (props) => {
          if (props.form.getFieldValue('merIcon') && props.form.getFieldValue('merIcon').length) {
            return false
          }
          return true
        }
      }, {
        type: EditType.InputStr,
        label: '商户描述',
        key: 'merDesc',
        config: {
          rules: [
            { required: true, message: '请输入商户描述' }
          ]
        }
      }, {
        type: EditType.Select,
        label: '行业分类',
        key: 'industryType',
        itemConfig: {
          options: formatParentIdOptions({ options: this.props.industryTypeOptions, hasDefaultOption: false, valueKey: 'value' })
        },
        config: {
          rules: [
            { required: true, message: '请选择行业分类' }
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '商户地址',
        key: 'merAddress',
        config: {
          rules: [
            { required: true, message: '请输入商户地址' }
          ]
        }
      }, {
        label: '商户标签',
        key: 'label',
        render: EditableTag,
        config: {
          rules: [
            { required: true, message: '请输入商户标签' }
          ]
        }
      }, {
        type: EditType.InputNum,
        label: '人均消费',
        key: 'averageCoum',
        config: {
          rules: [
            { required: true, message: '请输入人均消费' }
          ]
        }
      }, {
        type: EditType.InputNum,
        label: '人气排行',
        key: 'popularity',
        config: {
          rules: [
            { required: true, message: '请输入人气排行' }
          ]
        }
      }, {
        type: EditType.Select,
        label: '商户类型',
        key: 'merType',
        options: [
          { value: 1, label: '线上' },
          { value: 2, label: '线下' },
        ],
        config: {
          rules: [
            { required: true, message: '请选择审核状态' }
          ]
        },
      }, {
        type: EditType.DatePicker,
        label: '创建时间',
        key: 'createTime',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.Select,
        label: '审核状态',
        key: 'status',
        options: [
          { value: 0, label: '未审核' },
          { value: 1, label: '审核通过' },
          { value: 2, label: '审核不通过' },
        ],
        isSelectNum: true,
        config: {
          rules: [
            { required: true, message: '请选择审核状态' }
          ]
        },
      },
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems, this.Util.handleEditData)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, search, clearSearch, save, cancel, changePage, removeItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    industryTypeOptions: hasAttr(state.index.dictList.filter((item, index) => item.value === 'IndustryType'), [0, 'items']) || [],
  }
}
export default connect(mapStateToProps)(Merchant)