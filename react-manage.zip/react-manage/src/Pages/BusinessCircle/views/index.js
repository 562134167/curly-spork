/*
 * @Author: miccy 
 * @Date: 2017-12-18 16:02:45 
 * @Last Modified by: miccy
 * @Last Modified time: 2017-12-22 15:41:40
 * 商圈路由管理
 */
import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
const loadCommodity = (cb) => {
  return import('./commodity.js')
}
const loadMerchant = (cb) => {
  return import('./merchant.js')
}
const loadGuessLike = (cb) => {
  return import('./guessLike.js')
}
const loadHomeAdvert = (cb) => {
  return import('./homeAdvert.js')
}
const loadCoupous = (cb) => {
  return import('./coupous.js')
}
const loadRedPackage = (cb) => {
  return import('./redPackage.js')
}
const loadMember = (cb) => {
  return import('./member.js')
}
const loadMerchantFans = (cb) => {
  return import('./merchantFans.js')
}
const loadCommodityFans = (cb) => {
  return import('./commodityFans.js')
}
const loadEntranceType = (cb) => {
  return import('./entranceType.js')
}
const Commodity = getComponent(loadCommodity)
const Merchant = getComponent(loadMerchant)
const GuessLike = getComponent(loadGuessLike)
const HomeAdvert = getComponent(loadHomeAdvert)
const Coupous = getComponent(loadCoupous)
const RedPackage = getComponent(loadRedPackage)
const Member = getComponent(loadMember)
const MerchantFans = getComponent(loadMerchantFans)
const CommodityFans = getComponent(loadCommodityFans)
const EntranceType = getComponent(loadEntranceType)


export default class BusinessCircle extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/businessCircle"
          exact render={() => <Redirect to="/businessCircle/commodity" />}
        />
        <Route path="/businessCircle/commodity" render={(props) => <Commodity {...props} />} />
        <Route path="/businessCircle/merchant" render={(props) => <Merchant {...props} />} />
        <Route path="/businessCircle/guessLike" render={(props) => <GuessLike {...props} />} />
        <Route path="/businessCircle/homeAdvert" render={(props) => <HomeAdvert {...props} />} />
        <Route path="/businessCircle/coupous" render={(props) => <Coupous {...props} />} />
        <Route path="/businessCircle/redPackage" render={(props) => <RedPackage {...props} />} />
        <Route path="/businessCircle/member" render={(props) => <Member {...props} />} />
        <Route path="/businessCircle/merchantFans" render={(props) => <MerchantFans {...props} />} />
        <Route path="/businessCircle/commodityFans" render={(props) => <CommodityFans {...props} />} />
        <Route path="/businessCircle/entrance" render={(props) => <EntranceType {...props} />} />
      </Switch>
    )
  }
}