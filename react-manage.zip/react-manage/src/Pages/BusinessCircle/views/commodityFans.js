/*
 * @Author: miccy 
 * @Date: 2017-12-20 15:00:05 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-20 15:12:03
 * 关注商品的粉丝
 */

import React, { Component } from 'react'
import is from 'is_js'
import moment from 'moment'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Table } from 'antd'
import { formatData } from '../../../Util/reactUtil'
import { getFetch } from '../../../Config/request'
const initGetParams = {
  pageIndex: 1,
  pageSize: 20
}

const pagingUrl = '/system/fans/commodityinfos' //获取列表
class CommodityFans extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state

      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 当前所在页发生变化
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        getDataParams: params
      })
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.state = {
      dataSource: [],
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '用户名',
          id: 'userName',
          type: SearchType.String,
        }, {
          label: '商品名',
          id: 'commodityName',
          type: SearchType.String,
        },
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '商品名',
        dataIndex: 'commodityName',
        key: 'commodityName'
      },
      {
        title: '商户名',
        dataIndex: 'merchantName',
        key: 'merchantName',
      }, {
        title: '用户名',
        dataIndex: 'userName',
        key: 'userName',
      }, {
        title: '手机号码',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone',
      }, {
        title: '关注时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => {
          return is.undefined(value) ? '' : moment(value).format('YYYY-MM-DD HH:mm:ss')
        }
      }
    ]
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels } = this.state
    const { changePage, search, clearSearch } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default CommodityFans