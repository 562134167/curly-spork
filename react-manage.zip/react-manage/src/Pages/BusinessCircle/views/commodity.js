import React, { Component } from 'react'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import Editor from '../../../Common/Editor'
import { Card, Table, Popconfirm, Button } from 'antd'
import { formatData, formateEditData, formatParentIdOptions } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import EditableTag from './component/EditableTag'
import TwoDecimals from '../../../Common/twoDecimals'

const addTitle = '新建商品',
  editTitle = '编辑商品',
  initGetParams = {
    // keyword: '',
    pageIndex: 1,
    pageSize: 20
  },
  newItem = {
    commodityType: 1,
    isLogistics: 1,
    status: '0',
    createTime: new Date().getTime(),
    sort: 1,
    // merchantId: 36
  };

const pagingUrl = '/system/commodity/infos', //获取列表
  addUrl = '/system/commodity/addCommodity', //添加
  updateUrl = '/system/commodity/updateCommodity', //修改
  //  updatePropertyUrl = '/system/officialaccounts/updateproperty', //批量修改
  removeUrl = '/system/commodity/deleteCommodity', //删除
  removeItemsUrl = '/system/commodity/batchDeleteCommodity', //批量删除
  uploadFileUrl = '/system/file/upload', //上传图片
  getMerchantUrl = '/system/merchant/queryNumber', //获取商户号id
  getModularUrl = '/system/entrance/modelInfo'; //获取商户号id

class Commodity extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {

      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    getMerchant: (params) => {
      return getFetch(getMerchantUrl, params).then(res => {
        if (res && res.models) {
          this.setState({
            merchantOptions: res.models
          })
        }
      })
    },
    getModular: (params) => {
      return getFetch(getModularUrl, params).then(res => {
        if (res && res.models) {
          this.setState({
            modularOptions: res.models
          })
        }
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeItemsUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle,
        fileList: []
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems, this.Util.handleEditData)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }

      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state

      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            delete values.createTime
            const temp = this.Util.handleChangedData({ id: dataSource[i].id, ...values })
            // console.log(temp)
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = this.Util.handleChangedData(values);
        // console.log(temp)
        add(temp)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
  }
  // 方法对象
  Util = {
    // 处理传入表单的编辑内容的key、value以匹配组件的格式要求
    handleEditData: (obj) => {
      // const { getFileList } = this.Util
      if (is.object(obj)) {
        // obj.commodityImage = (obj.commodityImage && obj.commodityImage.trim() && getFileList(obj.commodityImage.trim())) || []
        if (obj.label) {
          let label = obj.label || '';
          label = label.replace('[', '')
          label = label.replace(']', '')
          label = label.split(',')
          obj.label = label
        }

      }
      return obj
    },
    //处理表单的保存内容的key、value以匹配后台的格式
    handleChangedData: (obj) => {
      if (is.object(obj)) {
        // if (is.array(obj.commodityImage)) {
        //   obj.commodityImage = this.Util.getUrl(obj.commodityImage)
        // }
        obj.label = obj.label && obj.label.join(',')
      }
      return obj
    },
    // 更新模态框表单的配置
    updateFormItem: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
        fn(formItem)
      }
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      merchantOptions: [],
      modularOptions: []
    }// 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '所属商户',
          id: 'merchantName',
          type: SearchType.String,
        },
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: 'id',
        dataIndex: 'id',
        key: 'id',
        width: 50,
      },
      {
        title: '所属商户',
        dataIndex: 'merchantId',
        key: 'merchantId',
        render: value => {
          const options = this.state.merchantOptions.filter(item => item.merchantId == value)
          if (options && options[0]) {
            return options[0].merchantName
          }
          return value
        }
      },
      {
        title: '商品标题',
        dataIndex: 'commodityTitle',
        key: 'commodityTitle',
        width: 200,
      }, {
        title: '商品图片',
        dataIndex: 'commodityImage',
        key: 'commodityImage',
        render: value => {
          if (value) {
            return <img style={{ width: 80 }} src={value.split(',')[0]} />
          }
          return;
        }
      }, {
        title: '商品名称',
        dataIndex: 'commodityName',
        key: 'commodityName'
      }, {
        title: '商品描述',
        dataIndex: 'commodityDesc',
        key: 'commodityDesc',
        width: 200,
      }, {
        title: '现价',
        dataIndex: 'commodityDiscount',
        key: 'commodityDiscount',
        render: value => value ? value / 100 : 0
      }, {
        title: '原价格',
        dataIndex: 'commodityValue',
        key: 'commodityValue',
        render: value => value ? value / 100 : 0
      }, {
        title: '是否推荐',
        dataIndex: 'isRecommend',
        key: 'isRecommend',
        render: value => value == 1 ? '推荐' : '不推荐'
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '显示在精品页' : '不显示在精品页'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.Select,
        label: '所属商户',
        key: 'merchantId',
        config: {
          rules: [{ required: true, message: '请选择所属商户' }]
        },
        itemConfig: {
          options: this.state.merchantOptions
        }
      },
      {
        type: EditType.InputStr,
        label: '商品标题',
        key: 'commodityTitle',
        config: {
          rules: [{ required: true, message: '请输入商品标题' }]
        }
      }, {
        type: EditType.InputStr,
        label: '商品名称',
        key: 'commodityName',
        config: {
          rules: [{ required: true, message: '请输入商品名称' }]
        }
      }, {
        type: EditType.InputStr,
        label: '商品描述',
        key: 'commodityDesc',
        config: {
          rules: [{ required: true, message: '请输入商品描述' }]
        }
      }, {
        type: EditType.InputNum,
        label: '商品总数',
        key: 'commoditySum',
        config: {
          rules: [{ required: true, message: '请输入商品总数' }]
        }
      }, {
        type: EditType.InputNum,
        label: '商品剩余量',
        key: 'commodityBalance',
        // config: {
        //   rules: [{ required: true, message: '请输入商品剩余量' }]
        // }
      }, {
        render: TwoDecimals,
        type: EditType.InputNum,
        label: '商品原价格',
        key: 'commodityValue',
        config: {
          rules: [{ required: true, message: '请输入商品原价格' }]
        },
        isInputNum: true
      }, {
        render: TwoDecimals,
        type: EditType.InputNum,
        label: '商品现价',
        key: 'commodityDiscount',
        config: {
          rules: [{ required: true, message: '商品现价' }]
        },
        isInputNum: true
      }, {
        type: EditType.InputStr,
        label: '商品评分',
        key: 'score',
        config: {
          rules: [{ required: true, message: '请输入商品评分' }]
        }
      }, {
        type: EditType.InputNum,
        label: '排序',
        key: 'sort',
        config: {
          rules: [
            { required: true, message: '请输入商品的排序' }
          ]
        }
      }, {
        type: EditType.Select,
        label: '状态',
        key: 'status',
        itemConfig: {
          options: [
            { value: 1, label: '显示在精品页' },
            { value: 0, label: '不显示在精品页' },
          ]
        },
        config: {
          rules: [
            { required: true, message: '请选择状态' }
          ]
        },
      }, {
        type: EditType.Select,
        label: '所属模块',
        key: 'modular',
        itemConfig: {
          options: this.state.modularOptions
        },
        config: {
          rules: [
            { required: true, message: '请选择所属模块' }
          ]
        },
      }, {
        label: '商品详情',
        key: 'commodityDetails',
        render: Editor,
        config: {
          rules: [
            { required: true, message: '请输入商品详情' }
          ]
        }
      }, {
        label: '商品标签',
        key: 'label',
        render: EditableTag,
        config: {
          rules: [
            { required: true, message: '请输入商品标签' }
          ]
        }
      }, {
        type: EditType.Image,
        label: '商品图片',
        key: 'commodityImage',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            if (Array.isArray(e)) {
              return e;
            }
            return e && e.fileList;
          },
          rules: [
            { required: true, message: '请上传商品图片' }
          ]
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          tip: '上传商品图片',
          accept: '.jpg, .png, .bmp, .jpeg',
          name: 'files'
        },
        isShowbtn: (props) => {
          if (props.form.getFieldValue('commodityImage') && props.form.getFieldValue('commodityImage').length >= 5) {
            return false
          }
          return true
        }
      }, {
        type: EditType.Select,
        label: '商品类型',
        key: 'commodityType',
        config: {
          rules: [{ required: true, message: '请选择商品类型' }]
        },
        itemConfig: {
          options: [
            { label: '普通', value: '1' },
            { label: '旅游', value: '2' }
          ]
        }
      }, {
        type: EditType.Select,
        label: '是否包邮',
        key: 'isLogistics',
        config: {
          rules: [{ required: true, message: '请选择是否包邮' }]
        },
        itemConfig: {
          options: [
            { label: '包邮', value: 1 },
            { label: '不包邮', value: 0 },
          ]
        },
        isSelectNum: true
      }, {
        type: EditType.Select,
        label: '是否推荐',
        key: 'isRecommend',
        config: {
          rules: [{ required: true, message: '请选择是否推荐' }]
        },
        itemConfig: {
          options: [
            { label: '推荐', value: 1 },
            { label: '不推荐', value: 0 },
          ]
        },
        isSelectNum: true
      }, {
        type: EditType.DatePicker,
        label: '创建时间',
        key: 'createTime',
        itemConfig: {
          disabled: true
        }
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems, this.Util.handleEditData)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, search, clearSearch, save, cancel, changePage, removeItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
    this.Request.getMerchant()
    this.Request.getModular()
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, merchantOptions, modularOptions } = this.state
    const { get } = this.Request
    const { updateFormItem } = this.Util
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    // 监听所属商户下拉框
    updateFormItem(merchantOptions, nextState.merchantOptions, 'merchantId', (formItem) => {
      if (hasAttr(formItem, ['itemConfig', 'options'])) {
        formItem.itemConfig.options = formatParentIdOptions({
          options: nextState.merchantOptions,
          hasDefaultOption: false,
          valueKey: 'merchantId',
          labelKey: 'merchantName'
        })
      }
    })
    // 监听所属分类下拉框
    updateFormItem(modularOptions, nextState.modularOptions, 'modular', (formItem) => {
      if (hasAttr(formItem, ['itemConfig', 'options'])) {
        formItem.itemConfig.options = formatParentIdOptions({
          options: nextState.modularOptions,
          // hasDefaultOption: false,
          valueKey: 'key',
          labelKey: 'value'
        })
      }
    })
  }
}
export default Commodity