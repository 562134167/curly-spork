/*
 * @Author: miccy 
 * @Date: 2017-12-20 15:22:25 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-20 15:11:00
 * 根据用户名获得该用户关注该商户的所有商品
 */


import React, { Component } from 'react'
import is from 'is_js'
import moment from 'moment'
import { Table, Modal, Button } from 'antd'
import { formatData } from '../../../../Util/reactUtil'
import { getFetch } from '../../../../Config/request'
const initGetParams = {
  pageIndex: 1,
  pageSize: 20
}

const pagingUrl = '/system/fans/commodityinfos' //获取列表
class CommodityModal extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels, totalPages } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            totalPages,
            current: params.pageIndex
          })
        }
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {

    // 当前所在页发生变化
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        getDataParams: params
      })
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    this.state = {
      dataSource: [],
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      totalPages: null,
      getDataParams: {},
    }
    // 表头设置
    this.columns = [
      {
        title: '商品名',
        dataIndex: 'commodityName',
        key: 'commodityName'
      },
      {
        title: '商户名',
        dataIndex: 'merchantName',
        key: 'merchantName',
      }, {
        title: '用户名',
        dataIndex: 'userName',
        key: 'userName',
      }, {
        title: '手机号码',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone',
      }, {
        title: '关注时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => {
          return is.undefined(value) ? '' : moment(value).format('YYYY-MM-DD HH:mm:ss')
        }
      }
    ]
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels } = this.state
    const { changePage } = this.Action
    const { modal, modalVis, cancel } = this.props
    return (
      <Modal
        title={modal.userName + "关注的商品"}
        visible={modalVis}
        onCancel={cancel}
        footer={<Button onClick={cancel}>关闭</Button>}
      >
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
      </Modal>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, userName: this.props.modal.userName }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    if (nextProps.modal !== this.props.modal) {
      this.setState({
        getDataParams: { ...getDataParams, userName: nextProps.modal.userName }
      })
    }
  }
}
export default CommodityModal