import React, { Component } from 'react'
import { Tag, Input, Tooltip, Button } from 'antd';

export default class EditableTag extends Component {
  constructor(props) {
    super(props)
    const value = this.props.value || []
    this.state = {
      tags: value,
      inputVisible: false,
      inputValue: '',
    }
  }

  Action = {
    handleClose: (removedTag) => {
      const tags = this.state.tags.filter(tag => tag !== removedTag);
      this.Action.triggerChange(tags)
    },
    handleInputChange: (e) => {
      let value = e.target.value
      this.setState({ inputValue: value });
    },
    handleInputConfirm: () => {
      const state = this.state;
      const inputValue = state.inputValue;
      let tags = state.tags;
      if (inputValue && tags.indexOf(inputValue) === -1) {
        tags = [...tags, inputValue];
      }
      this.Action.triggerChange(tags)
      this.setState({
        inputVisible: false,
        inputValue: '',
      });
    },
    showInput: () => {
      // if (this.state.tags.length >= 3) {
      //   return;
      // }
      this.setState({ inputVisible: true }, () => this.input.focus());
    },
    triggerChange: (changedValue) => {
      const { onChange } = this.props
      if (onChange) {
        onChange(changedValue)
      }
    }
  }
  saveInputRef = input => this.input = input
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      this.setState({
        tags: nextProps.value || []
      })
    }
  }

  render() {
    const { tags, inputVisible, inputValue } = this.state;
    const { handleClose, handleInputChange, handleInputConfirm, showInput } = this.Action
    return (
      <div>
        {tags.map((tag, index) => {
          const isLongTag = tag.length > 20;
          const tagElem = (
            <Tag key={tag} closable={true} afterClose={() => handleClose(tag)}>
              {isLongTag ? `${tag.slice(0, 20)}...` : tag}
            </Tag>
          );
          return isLongTag ? <Tooltip title={tag}>{tagElem}</Tooltip> : tagElem;
        })}
        {inputVisible && (
          <Input
            ref={this.saveInputRef}
            type="text" size="small"
            style={{ width: 78 }}
            value={inputValue}
            onChange={handleInputChange}
            onBlur={handleInputConfirm}
            onPressEnter={handleInputConfirm}
          />
        )}
        {!inputVisible && tags.length < 3 && <Button size="small" type="dashed" onClick={showInput}>+ 新增标签</Button>}
      </div>
    );
  }
}
