/*
 * @Author: miccy 
 * @Date: 2017-12-20 14:35:42 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-20 15:17:29
 * 会员卡管理
 */

import React, { Component } from 'react'
import is from 'is_js'
import moment from 'moment'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Table, Popconfirm, Button } from 'antd'
import { formatData, formateEditData, formatParentIdOptions, toMoney } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import TwoDecimals from '../../../Common/twoDecimals'
const addTitle = '新增会员卡',
  editTitle = '编辑会员卡',
  initGetParams = {
    pageIndex: 1,
    pageSize: 20
  }
  ,
  newItem = {
    startTime: new Date().getTime(),
    endTime: moment().set('month', moment().month() + 1).format('x'),
    sort: 0,
    isFirst: '0'
  };

const pagingUrl = '/system/voucher/infos', //获取列表
  addUrl = '/system/voucher/addMemberVoucher', //添加
  updateUrl = '/system/voucher/updateVoucher', //修改
  removeUrl = '/system/voucher/deleteVoucher', //删除
  removeItemsUrl = '/system/voucher/batchDelVoucher', //批量删除
  getMerchantUrl = '/system/merchant/queryNumber', //获取商户号id
  uploadFileUrl = '/system/file/upload', //上传图片
  getModularUrl = '/system/entrance/modelInfo'; //获取所属模块
class Member extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, { voucherType: 3, ...params }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 获取商户下拉数据
    getMerchant: (params) => {
      return getFetch(getMerchantUrl, params).then(res => {
        if (res && res.models) {
          this.setState({
            merchantOptions: formatParentIdOptions({
              options: res.models,
              hasDefaultOption: false,
              valueKey: 'merchantId',
              labelKey: 'merchantName'
            })
          })
        }
      })
    },
    getModular: (params) => {
      return getFetch(getModularUrl, params).then(res => {
        if (res && res.models) {
          this.setState({
            modularOptions: res.models
          })
        }
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量删除数据
    deleteItems: (params) => {
      return fetch(removeItemsUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle,
        fileList: []
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      // this.formItems = this.Util.getEditFormItem()
      const obj = formateEditData(record, this.formItems)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            delete values.createTime
            const temp = { id: dataSource[i].id, ...values }
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = values
        add(temp)
      }
    },
    // 模态框取消
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    // 当前所在页发生变化
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
  }
  // 方法对象
  Util = {
    // 更新模态框表单的配置
    updateFormItem: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
        fn(formItem)
      }
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      merchantOptions: [],
      modularOptions: []
    }
    // 表头设置
    this.columns = [
      {
        title: '所属商户',
        dataIndex: 'merchantId',
        key: 'merchantId',
        render: value => {
          const options = this.state.merchantOptions.filter(item => item.value == value)
          if (options && options[0]) {
            return options[0].label
          }
          return value
        }
      }, {
        title: '会员卡名称',
        dataIndex: 'voucherName',
        key: 'voucherName',
      }, {
        title: '发行数量',
        dataIndex: 'voucherSum',
        key: 'voucherSum',
      }, {
        title: '金额',
        dataIndex: 'totalAmount',
        key: 'totalAmount',
        render: value => toMoney(value)
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.Select,
        label: '所属商户',
        key: 'merchantId',
        config: {
          rules: [{ required: true, message: '请选择所属商户' }]
        },
        itemConfig: {
          options: this.state.merchantOptions,
        }
      }, {
        type: EditType.InputStr,
        label: '会员卡名称',
        key: 'voucherName',
        config: {
          rules: [{ required: true, message: '请输入会员卡名称' }]
        }
      }, {
        type: EditType.InputStr,
        label: '会员卡使用条件',
        key: 'voucherDesc',
        config: {
          rules: [{ required: true, message: '请输入会员卡使用条件' }]
        },
        itemConfig: {
          autosize: { minRows: 1, maxRows: 6 },
        }
      }, {
        type: EditType.Textarea,
        label: '会员卡详情',
        key: 'voucherDetails',
        config: {
          rules: [{ required: true, message: '请输入会员卡详情' }]
        },
        itemConfig: {
          autosize: { minRows: 3, maxRows: 7 },
        }
      }, {
        type: EditType.Image,
        label: '背景图',
        key: 'bgImage',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            if (Array.isArray(e)) {
              return e;
            }
            return e && e.fileList;
          },
          rules: [
            { required: true, message: '请上传背景图' }
          ]
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          tip: '上传背景图',
          accept: '.jpg, .png, .bmp, .jpeg',
          name: 'files'
        },
        isShowbtn: (props) => {
          if (props.form.getFieldValue('bgImage') && props.form.getFieldValue('bgImage').length) {
            return false
          }
          return true
        }
      }, {
        type: EditType.InputNum,
        label: '发行数量',
        key: 'voucherSum',
        config: {
          rules: [{ required: true, message: '请输入发行数量' }]
        }
      }, {
        render: TwoDecimals,
        type: EditType.InputNum,
        label: '金额',
        key: 'totalAmount',
        config: {
          rules: [{ required: true, message: '请输入金额' }]
        },
        isInputNum: true
      }, {
        type: EditType.InputStr,
        label: '等级',
        key: 'grade',
        config: {
          rules: [{ required: true, message: '请输入等级' }]
        }
      }, {
        type: EditType.InputStr,
        label: '等级名称',
        key: 'gradeName',
        config: {
          rules: [{ required: true, message: '请输入等级名称' }]
        }
      }, {
        type: EditType.DatePicker,
        label: '开始时间',
        key: 'startTime',
        config: {
          rules: [{ required: true, message: '请选择开始时间' }]
        },
        itemConfig: {
          showTime: true,
          format: 'YYYY-MM-DD HH:mm:ss'
        }
      }, {
        type: EditType.DatePicker,
        label: '结束时间',
        key: 'endTime',
        config: {
          rules: [{ required: true, message: '请选择结束时间' }]
        },
        itemConfig: {
          showTime: true,
          format: 'YYYY-MM-DD HH:mm:ss'
        }
      }, {
        type: EditType.InputNum,
        label: '排序',
        key: 'sort',
        config: {
          rules: [
            { required: true, message: '请输入会员卡的排序' }
          ]
        }
      }, {
        type: EditType.Select,
        label: '是否显示在精品页',
        key: 'isFirst',
        itemConfig: {
          options: [
            { value: 1, label: '是' },
            { value: 0, label: '不是' },
          ]
        },
        config: {
          rules: [
            { required: true, message: '请选择是否显示在精品页' }
          ]
        },
      }, {
        type: EditType.Select,
        label: '所属模块',
        key: 'modular',
        itemConfig: {
          options: this.state.modularOptions
        },
        config: {
          rules: [
            { required: true, message: '请选择所属模块' }
          ]
        },
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, save, cancel, changePage, removeItems } = this.Action
    return (
      <div>
        <Card>
          <Button type="primary" onClick={add} className="action-item" disabled={totalModels >= 20}>新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
    this.Request.getMerchant()
    this.Request.getModular()
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, merchantOptions, modularOptions } = this.state
    const { get } = this.Request
    const { updateFormItem } = this.Util
    // console.log(nextState.selectedRowKeys)
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    // 监听所属商户下拉框
    updateFormItem(merchantOptions, nextState.merchantOptions, 'merchantId', (formItem) => {
      if (hasAttr(formItem, ['itemConfig', 'options'])) {
        formItem.itemConfig.options = nextState.merchantOptions
      }
    })
    // 监听所属分类下拉框
    updateFormItem(modularOptions, nextState.modularOptions, 'modular', (formItem) => {
      if (hasAttr(formItem, ['itemConfig', 'options'])) {
        formItem.itemConfig.options = formatParentIdOptions({
          options: nextState.modularOptions,
          // hasDefaultOption: false,
          valueKey: 'key',
          labelKey: 'value'
        })
      }
    })
  }
}
export default Member