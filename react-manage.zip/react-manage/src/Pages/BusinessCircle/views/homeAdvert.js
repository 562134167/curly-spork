import React, { Component } from 'react'
import is from 'is_js'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
const addTitle = '新建公众号',
  editTitle = '编辑公众号',
  initGetParams = {
    pageIndex: 1,
    pageSize: 20
  },
  newItem = {
    status: 1
  }
const pagingUrl = '/system/popup/paging', //获取列表
  addUrl = '/system/popup/add', //添加
  updateUrl = '/system/popup/update', //修改
  updatePropertyUrl = '/system/popup/updateproperty', //批量修改
  removeUrl = '/system/popup/remove', //删除
  removeItemsUrl = '/system/popup/removelist', //批量删除
  uploadFileUrl = '/system/file/upload' //上传图片
class HomeAdvert extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeItemsUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      if (this.state.totalModels > 10) {
        message.error('商圈首页轮播图不得多于10张，请删除其他轮播图再添加！')
        return;
      }
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle,
        fileList: []
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }

      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            const temp = { ...dataSource[i], ...values }
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = values
        add(temp)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
  }

  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }
    // 表头设置
    this.columns = [
      {
        title: '广告链接',
        dataIndex: 'link',
        key: 'link'
      }, {
        title: '广告图片',
        dataIndex: 'image',
        key: 'image',
        render: value => {
          if (value) {
            return <img style={{ width: 80 }} src={value} />
          }
          return;
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '广告链接',
        key: 'link',
      }, {
        type: EditType.Image,
        label: '广告图片',
        key: 'image',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            if (Array.isArray(e)) {
              return e;
            }
            return e && e.fileList;
          },
          rules: [
            { required: true, message: '请上传广告图片' }
          ]
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          tip: '广告图片',
          accept: '.jpg, .png, .bmp, .jpeg',
          name: 'files'
        },
        isShowbtn: (props) => {
          if (props.form.getFieldValue('image') && props.form.getFieldValue('image').length) {
            return false
          }
          return true
        }
      },
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, save, cancel, changePage, removeItems } = this.Action
    return (
      <div>
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default HomeAdvert