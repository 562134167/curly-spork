import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
const addTitle = '新建广告信息'
const editTitle = '编辑广告信息'
const initGetParams = {
  // keyword: '',
  pageIndex: 1,
  pageSize: 20
}

const newItem = {
  status: 1,
  num: 1,
  hits: 0,
  startTime: new Date().getTime(),
  endTime: moment().set('year', moment().year() + 2).format('x')
}
const pagingUrl = '/system/advertinfo/paging', //获取列表
  addUrl = '/system/advertinfo/add', //添加
  updateUrl = '/system/advertinfo/update', //修改
  updatePropertyUrl = '/system/advertinfo/updateproperty', //批量修改
  removeUrl = '/system/advertinfo/remove', //删除
  removeItemsUrl = '/system/advertinfo/removelist', //批量删除
  getAdvertPosUrl = '/system/advertposition/getlist', //获取全部广告位
  uploadFileUrl = '/system/file/upload' //上传图片
class AdvertInfo extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {

      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels, totalPages } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            totalPages,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 获取广告位列表
    getAdvertPos: (params) => {
      return getFetch(getAdvertPosUrl, params).then(res => {
        if (res && is.array(res.models)) {
          this.setState({
            advertPosOptions: this.Util.getAdvertPosOptions(res.models)
          })
        }
        return res
      })
    },
    // 添加数据
    add: (params) => {

      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {

      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {

      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {

      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {

      return fetch(removeItemsUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle,
        fileList: []
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }

      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            const temp = { ...dataSource[i], ...values }
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = values
        add(temp)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
  }
  // 方法对象
  Util = {
    // 更新模态框表单的配置
    updateFormItem: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
        fn(formItem)
      }
    },
    getAdvertPosOptions: (arr) => {
      const options = []
      for (let i = -1; arr[++i];) {
        const option = {
          value: arr[i].id,
          label: `${arr[i].title}(宽:${arr[i].width},高:${arr[i].height})`
        }
        options.push(option)
      }
      return options
    },

  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      totalPages: null,
      getDataParams: {},
      advertPosOptions: []
    }// 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '广告标题',
          id: 'keyword',
          type: SearchType.String,
        },
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '广告位',
        dataIndex: 'positionId',
        key: 'positionId',
        render: value => {
          const options = this.state.advertPosOptions.filter(item => item.value == value)
          if (options && options[0]) {
            return options[0].label
          }
          return value
        }
      }, {
        title: '广告标题',
        dataIndex: 'title',
        key: 'title'
      }, {
        title: '广告图片',
        dataIndex: 'image',
        key: 'image',
        render: value => {
          if (value) {
            return <img style={{ width: 80 }} src={value} />
          }
          return;
        }
      }, {
        title: '排序',
        dataIndex: 'num',
        key: 'num'
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '广告标题',
        key: 'title',
        config: {
          rules: [{ required: true, message: '请输入广告标题' }]
        }
      }, {
        type: EditType.Select,
        label: '广告位',
        key: 'positionId',
        config: {
          rules: [{ required: true, message: '请输入广告位' }]
        },
        itemConfig: {
          options: this.state.advertPosOptions
        }
      }, {
        type: EditType.Image,
        label: '广告图片',
        key: 'image',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            if (Array.isArray(e)) {
              return e;
            }
            return e && e.fileList;
          },
          rules: [
            { required: true, message: '请上传广告图片' }
          ]
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          tip: '广告图片',
          accept: '.jpg, .png, .bmp, .jpeg',
          name: 'files',
          beforeUpload: (file) => {
            const isLt2M = file.size / 1024 / 1024 < 2;
            if (!isLt2M) {
              message.error('图片大小不得大于2M!');
            }
            return isLt2M;
          }
        },
        isShowbtn: (props) => {
          if (props.form.getFieldValue('image') && props.form.getFieldValue('image').length) {
            return false
          }
          return true
        }
      }, {
        type: EditType.InputStr,
        label: '超链接/JSON',
        key: 'url'
      }, {
        type: EditType.InputNum,
        label: '排序',
        key: 'num',
        config: {
          rules: [{ required: true, message: '请输入排序' }]
        }
      }, {
        type: EditType.InputNum,
        label: '点击数',
        key: 'hits',
        config: {
          rules: [{ required: true, message: '请输入点击数' }]
        }
      }, {
        type: EditType.DatePicker,
        label: '开始时间',
        key: 'startTime',
        itemConfig: {
          showTime: true,
          format: 'YYYY-MM-DD HH:mm:ss'
        },
        config: {
          rules: [{ required: true, message: '请输入开始时间' }]
        }
      }, {
        type: EditType.DatePicker,
        label: '结束时间',
        key: 'endTime',
        itemConfig: {
          showTime: true,
          format: 'YYYY-MM-DD HH:mm:ss'
        },
        config: {
          rules: [{ required: true, message: '请输入结束时间' }]
        }
      }, {
        type: EditType.Select,
        label: '状态',
        key: 'status',
        itemConfig: {
          options: [
            { value: 1, label: '正常' },
            { value: 0, label: '不正常' },
          ]
        },
        config: {
          rules: [{ required: true, message: '请输入状态' }]
        }
      },
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, search, clearSearch, save, cancel, changePage, editItems, removeItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: '1' },
            { label: '批量禁用', value: '0' }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
    this.Request.getAdvertPos()
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, advertPosOptions } = this.state
    const { get } = this.Request
    const { updateFormItem } = this.Util
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    // 监听广告位下拉框
    updateFormItem(advertPosOptions, nextState.advertPosOptions, 'positionId', (formItem) => {
      if (hasAttr(formItem, ['itemConfig', 'options'])) {
        formItem.itemConfig.options = nextState.advertPosOptions
      }
    })
  }
}
export default AdvertInfo