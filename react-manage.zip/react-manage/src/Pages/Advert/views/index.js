/*
 * @Author: miccy 
 * @Date: 2017-12-20 16:14:21 
 * @Last Modified by: miccy
 * @Last Modified time: 2017-12-20 19:49:42
 * 广告管理路由
 */

import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
const loadImageAdvert = (cb) => {
  return import('./imageAdvert.js')
}
const loadAdvertPos = (cb) => {
  return import('./advertPos.js')
}
const loadAdvertInfo = (cb) => {
  return import('./advertInfo.js')
}
const ImageAdvert = getComponent(loadImageAdvert)
const AdvertPos = getComponent(loadAdvertPos)
const AdvertInfo = getComponent(loadAdvertInfo)

export default class Advert extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/advert"
          exact render={() => <Redirect to="/advert/imageAdvert" />}
        />
        <Route path="/advert/imageAdvert" render={(props) => <ImageAdvert {...props} />} />
        <Route path="/advert/advertPos" render={(props) => <AdvertPos {...props} />} />
        <Route path="/advert/advertInfo" render={(props) => <AdvertInfo {...props} />} />

      </Switch>
    )
  }
}