import * as actionType from './constants'
import { action as indexAction } from '../index'
// import { push } from 'react-router-redux'
import { fetch } from '../../Config/request'
export const login = (username, password) => {
  return {
    type: actionType.LOGIN,
    username,
    password
  }
}
export const loginSuccess = () => {
  return {
    type: actionType.LOGIN_SUCCESS
  }
}
export const loginFail = () => {
  return {
    type: actionType.LOGIN_FAIL
  }
}
export const fetchLogin = (values, successFunc, failFunc) => (dispatch, getState) => {
  dispatch(indexAction.showLoading('正在登录中...'));
  /*return fetch(`/some/API/${postTitle}.json`)
    .then(response => response.json())
    .then(json => dispatch(receivePosts(postTitle, json)));*/
  return fetch('/system/login', values)
    .then((res) => {
      if (res.status === 1) {
        // dispatch(loginFail())
        if (failFunc) {
          failFunc()
        }
        return;
      }
      return res;
    })
    .then((res) => {
      if (res) {
        dispatch(loginSuccess())
        dispatch(indexAction.hideLoading())
        if (successFunc) {
          successFunc(res)
        }
        return res
      }

    });
};