import React, { Component } from 'react'
import { connect } from 'react-redux'
// import { Link } from 'react-router-dom'
import { Form, Icon, Input, Button } from 'antd'
import { showLoading, hideLoading } from '../../action'
import { fetchLogin } from '../action'
import { setStore } from '../../../Util'
import imageBg from './images/bg2.jpg'
import './style.less'
import { getFetch } from '../../../Config/request'
import Code from './component/Code'
const FormItem = Form.Item

const styles = {
  container: {
    display: 'flex',
    height: '100vh',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    background: `url(${imageBg})`,
    backgroundSize: '100% 100%',
  },
  loginForm: {
    maxWidth: '400px',
    width: '100%',
    backgroundColor: 'rgba(255,255,255,.2)',
    padding: '30px 15px 15px',
    borderRadius: '8px',
  },
  title: {
    textAlign: 'center',
    marginBottom: '20px',
    color: '#fff',
    letterSpacing: '2px',
    fontWeight: 'bold'
  },
  loginForget: {
    float: 'right'
  },
  loginBtn: {
    width: '100%'
  }
}
const getImageUrl = '/common/validatecode'
class Login extends Component {
  constructor(props) {
    super(props)
    this.state = {
      imageCode: ''
    }
    this.getImageCode = this.getImageCode.bind(this)
  }
  Request = {
    getImage: (params) => {
      return getFetch(getImageUrl, params).then(res => {
        this.setState({
          imageCode: res
        })
      })
    }
  }
  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      <div style={styles.container}>
        <h1 style={styles.title}>聚管家后台管理系统</h1>
        <Form onSubmit={this.handleSubmit} style={styles.loginForm} className="login-form">
          <FormItem>
            {getFieldDecorator('username', {
              rules: [{ required: true, message: '请输入用户名!' }],
            })(
              <Input prefix={<Icon type="user" style={{ fontSize: 13 }} />} placeholder="用户名" />
            )}
          </FormItem>
          <FormItem>
            {getFieldDecorator('password', {
              rules: [{ required: true, message: '请输入您的密码!' }],
            })(
              <Input prefix={<Icon type="lock" style={{ fontSize: 13 }} />} type="password" placeholder="密码" />
            )}
          </FormItem>
          <FormItem>
            {getFieldDecorator('code', {
              rules: [{ required: true, message: '请输入验证码!' }],
            })(
              // <div className="input-wrapper code-wrapper">
              //   <Input placeholder="验证码" />
              //   <a onClick={this.getImageCode}>
              //     <img src={this.state.imageCode} alt="验证码" />
              //   </a>
              // </div>
              <Code getImageCode={this.getImageCode} imageCode={this.state.imageCode} />
            )}
          </FormItem>
          <FormItem>
            <Button type="primary" htmlType="submit" style={styles.loginBtn}>
              登录
          </Button>
          </FormItem>
        </Form>
      </div>
    )
  }
  // 发送请求获取验证码图片
  getImageCode = (e) => {
    e.preventDefault()
    this.Request.getImage({ t: new Date().getTime() })
  }
  handleSubmit = async (e) => {
    e.preventDefault()
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.fetchLogin(values).then(res => {
          // console.log(res);
          if (!res || res.status == 1) {
            this.Request.getImage({ t: new Date().getTime() })
            this.props.form.setFieldsValue({ 'code': '' })
          }
        }, err => {
          console.log(err);
        })
      }
    });
  }
  componentDidMount() {
    this.Request.getImage({ t: new Date().getTime() })
  }

  // componentWillReceiveProps(nextProps) {
  // console.log(nextProps);
  // if (nextProps.loading === false && this.props.loading === true && nextProps.isLogin === false && isGettingImage === false) {
  //   this.props.form.setFieldsValue({ code: '' })
  //   isGettingImage = true;
  //   this.Request.getImage({ t: new Date().getTime() })
  // }
  // }

}
const WrappedLogin = Form.create()(Login)

const mapStateToProps = (state, ownProps) => {
  return {
    loading: state.index.loading,
    isLogin: state.login.isLogin
  }
}
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    showLoading: () => {
      dispatch(showLoading('正在登录中...'))
    },
    hideLoading: () => {
      dispatch(hideLoading())
    },
    fetchLogin: (values) => {
      return dispatch(fetchLogin(values, (res) => {
        setStore('user', res.model)
        ownProps.history.replace('/home')
      }))
    }
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(WrappedLogin);