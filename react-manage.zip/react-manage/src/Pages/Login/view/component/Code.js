import React, { PureComponent } from 'react'
import { Input } from 'antd'
import is from 'is_js'
export default class Code extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value
    this.state = {
      value: value
    }
  }
  Action = {
    onInputChange: (e) => {
      const value = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(changedValue)
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value
      if (!is.undefined(value)) {
        this.setState({ value })
      }
    }
  }

  render() {
    const { onInputChange } = this.Action
    const { value } = this.state
    const { getImageCode, imageCode } = this.props
    return (
      <div className="input-wrapper code-wrapper">
        <Input value={value} onChange={onInputChange} placeholder="验证码" />
        <a onClick={getImageCode}>
          <img src={imageCode} alt="验证码" />
        </a>
      </div>
    )
  }
}