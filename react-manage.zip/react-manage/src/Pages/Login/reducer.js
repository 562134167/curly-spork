import * as actionType from './constants' //引入action类型常量名
// 初始化state数据
const initialState = {
  isLogin: false
}
export default function login(state = initialState, action) {
  switch (action.type) {
    case actionType.LOGIN_SUCCESS:
      return { ...state, isLogin: true };
    case actionType.LOGIN_FAIL:
      return { ...state, isLogin: false };
    default:
      return state
  }
}