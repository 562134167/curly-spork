import view from './view';
// import './style.less';
import * as action from './action';
import reducer from './reducer';
export { view, action, reducer }