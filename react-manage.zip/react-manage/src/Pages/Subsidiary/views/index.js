import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
const loadList = (cb) => {
  return import('./list.js')
}
const loadTransfer = (cb) => {
  return import('./transfer.js')
}
const loadTransferSub = (cb) => {
  return import('./transferSub.js')
}
const loadPay = (cb) => {
  return import('./pay.js')
}
const List = getComponent(loadList)
const Transfer = getComponent(loadTransfer)
const TransferSub = getComponent(loadTransferSub)
const Pay = getComponent(loadPay)
export default class Subsidiary extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/subsidiary"
          exact render={() => <Redirect to="/subsidiary/list" />}
        />
        <Route path="/subsidiary/list" render={(props) => <List {...props} />} />
        <Route path="/subsidiary/transferSub" render={(props) => <TransferSub {...props} />} />
        <Route path="/subsidiary/transfer" render={(props) => <Transfer {...props} />} />
        <Route path="/subsidiary/pay" render={(props) => <Pay {...props} />} />
      </Switch>
    )
  }
}