/*
 * @Author: miccy 
 * @Date: 2018-02-05 16:40:57 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:10:45
 * 子公司打款给员工所有记录
 */
import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Table, message } from 'antd'
import { handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { requestGet } from '../../../Util/Request'
import { actionChangePage, actionClearSearch, actionSearch, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'

// 消费类型下拉框选项
const transferStatusOptions = [
  { label: '转账成功', value: 1 },
  { label: '转账失败', value: 2 },
]
const statusOptions = [
  { label: '成功', value: 1 },
  { label: '失败', value: 2 },
]
const pagingUrl = '/system/subsidiary/pagingtransfersub'


export default class TransferSub extends Component {
  constructor(props) {
    super(props)
   
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return requestGet({ params, pagingUrl, context: this })
    },

  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 搜索面板点击查询
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.toMobilePhone && (!mobileRegx.test(queryParams.toMobilePhone))) {
        message.error('请输入正确的转入手机号码')
        return;
      }
      delete queryParams.createtime
      actionSearch({ value: queryParams, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    // const { view, unfreeze } = this.Action
    this.state = {
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      totalPages: null,
      getDataParams: {},
      pageSize: 20,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '收款手机号码',
          id: 'toMobilePhone',
        }, {
          type: SearchType.String,
          label: '公司全称',
          id: 'userNick'
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        fixed: 'left',
        width: 50,
        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 10) + (index - 0 + 1)
      }, {
        title: '公司全称',
        dataIndex: 'fromRealName',
        key: 'fromRealName',
        fixed: 'left',
        width: 100,
      }, {
        title: '收款用户名',
        dataIndex: 'toRealName',
        key: 'toRealName',
        fixed: 'left',
        width: 100,
      }, {
        title: '收款手机号',
        dataIndex: 'toMobilePhone',
        key: 'toMobilePhone'
      }, {
        title: '金额',
        dataIndex: 'amount',
        key: 'amount',
        render: value => toMoney(value)
      }, {
        title: '流水号',
        dataIndex: 'serialNumber',
        key: 'serialNumber',
      }, {
        title: '打款用途',
        dataIndex: 'desc',
        key: 'desc',
        width: 200,
      }, {
        title: '转账状态',
        dataIndex: 'transferStatus',
        key: 'transferStatus',
        render: value => {
          const option = transferStatusOptions.filter(item => item.value == value)
          return hasAttr(option, [0, 'label'])
        }
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => {
          const option = statusOptions.filter(item => item.value == value)
          return hasAttr(option, [0, 'label'])
        }
      }, {
        title: '转账时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }
    ];
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels, pageSize } = this.state
    const { changePage, search, clearSearch, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          scroll={{ x: 900 }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            showSizeChanger: true,
            showTotal: actionShowTotal,
            onShowSizeChange: onShowSizeChange
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
