/*
 * @Author: miccy 
 * @Date: 2018-02-08 11:58:13 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:10:47
 * 给子公司打款
 */
import React, { Component } from 'react'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, Button } from 'antd'
import { toMoney } from '../../../Util/reactUtil'
import { requestGet, requestAdd } from '../../../Util/Request'
import { actionSearch, actionClearSearch, actionCancel, actionChangePage, actionEdit, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'
import TwoDecimals from '../../../Common/twoDecimals'

const payTitle = '给子公司打款'

const pagingUrl = '/system/subsidiary/paging', //获取列表
  payUrl = '/system/subsidiary/transfer' //给子公司转账
class Pay extends Component {
  constructor(props) {
    super(props)
   
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({ params, pagingUrl, context: this })
    },

    //给子公司打款
    pay: (params) => {
      requestAdd({ params, addUrl: payUrl, context: this })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 查
    search: (value) => {
      actionSearch({ value, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    // 保存模态框表单数据（打款）
    save: (values) => {
      const { editId } = this.state
      const { pay } = this.Request
      const temp = { userId: editId, ...values }
      pay(temp)
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    // 给子公司打款
    pay: (record, index) => {
      this.formItems = this.Util.getPayFormItem()
      actionEdit({ record, editTitle: payTitle, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { pay } = this.Action
    this.state = {
      title: payTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '公司全称',
          id: 'userNick'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '公司全称',
        dataIndex: 'userNick',
        key: 'userNick'
      }, {
        title: '用户名',
        dataIndex: 'username',
        key: 'username',
      }, {
        title: '可用余额',
        dataIndex: 'totalResidual',
        key: 'totalResidual',
        render: value => toMoney(value)
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '启用' : '禁用'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => pay(record)}>打款</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = this.Util.getPayFormItem()
    //新建面板表单的初始内容
    this.newItem = {}
  }
  Util = {
    getPayFormItem: () => {
      return [
        {
          render: TwoDecimals,
          type: EditType.InputNum,
          key: 'money',
          label: '打款资金',
          config: {
            rules: [
              { required: true, message: '请填写要打款的金额数目' },
              {
                validator: (rule, value, callback) => {
                  if (value && value <= 0) {
                    callback('打款的金额不得小于等于0');
                  }
                  callback();
                }
              }
            ],
          },
          isInputNum: true
        }, {
          type: EditType.InputStr,
          key: 'note',
          label: '打款用途'
        }, {
          type: EditType.InputStr,
          label: '支付密码',
          key: 'payPassword',
          config: {
            rules: [
              { required: true, message: '请输入支付密码' }
            ]
          },
          itemConfig: {
            type: 'password'
          }
        }
      ]
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, pageSize } = this.state
    const { search, clearSearch, save, cancel, changePage, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange,
            showTotal: actionShowTotal
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default Pay