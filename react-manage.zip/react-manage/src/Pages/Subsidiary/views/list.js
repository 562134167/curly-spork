/*
 * @Author: miccy 
 * @Date: 2018-02-08 11:50:23 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-03-23 11:53:50
 * 子公司列表
 */
import React, { Component } from 'react'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Button } from 'antd'
import { toMoney } from '../../../Util/reactUtil'
import { fetch } from '../../../Config/request'
import { requestGet, requestAdd, requestUpdate, requestUpdateProperty } from '../../../Util/Request'
import { actionAdd, actionEdit, actionSave, actionCancel, actionChangePage, actionClearSearch, actionEditItems, actionSearch, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'


const addTitle = '新建子公司',
  editTitle = '编辑子公司'

const pagingUrl = '/system/subsidiary/paging', //获取列表
  addUrl = '/system/subsidiary/add', //添加
  updateUrl = '/system/subsidiary/update', //修改
  updatePropertyUrl = '/system/subsidiary/updateproperty', //批量修改
  resetPwdUrl = '/system/subsidiary/resetpassword',//重置登录密码
  resetPayPwdUrl = '/system/subsidiary/resetpaypassword'//重置支付密码

class List extends Component {
  constructor(props) {
    super(props)
   
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({ params, pagingUrl, context: this })
    },
    // 添加数据
    add: (params) => {
      requestAdd({ params, addUrl, context: this })
    },
    // 修改数据
    edit: (params) => {
      requestUpdate({ params, updateUrl, context: this })
    },
    // 批量更新属性
    editItems: (params) => {
      requestUpdateProperty({ params, updatePropertyUrl, context: this })
    },
    // 重置登录密码
    resetPwd: (params) => {
      return fetch(resetPwdUrl, params)
    },
    // 重置支付密码
    resetPayPwd: (params) => {
      return fetch(resetPayPwdUrl, params)
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      actionAdd({ addTitle, context: this })
    },
    // 点击修改按钮
    edit: (record, index) => {
      actionEdit({ record, editTitle, context: this })
    },
    // 查
    search: (value) => {
      actionSearch({ value, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      actionSave({ context: this, values })
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      actionEditItems({ context: this, name, value })
    },
    // 重置密码
    reset: (record, index) => {
      this.Request.resetPwd({ id: record.id })
    },
    // 重置支付密码
    resetPay: (record, index) => {
      this.Request.resetPayPwd({ id: record.id })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, reset, resetPay } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '公司全称',
          id: 'userNick'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '公司全称',
        dataIndex: 'userNick',
        key: 'userNick'
      }, {
        title: '用户名',
        dataIndex: 'username',
        key: 'username',
      }, {
        title: '可用余额',
        dataIndex: 'totalResidual',
        key: 'totalResidual',
        render: value => toMoney(value)
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '启用' : '禁用'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Button type="primary" ghost className="action-item" onClick={() => edit(record)}>修改</Button>
            <Button type="primary" ghost className="action-item" onClick={() => reset(record)}>重置登录密码</Button>
            <Button type="primary" ghost className="action-item" onClick={() => resetPay(record)}>重置支付密码</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = this.Util.getFormItem()
    //新建面板表单的初始内容
    this.newItem = {}
  }
  Util = {
    getFormItem: () => {
      return [
        {
          type: EditType.InputStr,
          label: '公司名称（全称）',
          key: 'userNick',
          config: {
            rules: [{ required: true, message: '请输入公司名称' }]
          }
        }, {
          type: EditType.InputStr,
          label: '用户名（英文）',
          key: 'username',
          config: {
            rules: [
              { required: true, message: '请选择用户名' }
            ]
          },
        }
      ]
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, pageSize } = this.state
    const { add, search, clearSearch, save, cancel, changePage, editItems, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: '1' },
            { label: '批量禁用', value: '0' }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange,
            showTotal: actionShowTotal
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default List