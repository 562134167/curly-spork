import * as actionType from './constants';



// 请求拦截
// export const startRequest = () => (dispatch,getState)=> {

// }

export const showLoading = (tip) => {
  return {
    type: actionType.SHOW_LOADING,
    tip
  }
}
export const hideLoading = () => {
  return {
    type: actionType.HIDE_LOADING
  }
}
export const setDictList = (list) => {
  return {
    type: actionType.SET_DICT_LIST,
    list
  }
}