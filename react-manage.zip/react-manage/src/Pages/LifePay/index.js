/*
 * @Author: miccy 
 * @Date: 2018-03-09 17:00:50 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-24 16:49:15
 * 生活缴费列表
 */


import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../Common/searchPanel'
import * as SearchType from '../../Common/searchTypes'
import EditPanel from '../../Common/editPanel'
import * as EditType from '../../Common/editType'
import { Table, Card, message, Button } from 'antd'
import { handleEndTime, handleStartTime, formatParentIdOptions, formatData, toMoney } from '../../Util/reactUtil'
import { requestGet } from '../../Util/Request'
import { fetch } from '../../Config/request'
import { actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal, actionSearch, actionClearSearch } from '../../Util/Action'

const pagingUrl = '/system/life/paginghydropower', //获取列表
    getChannelListUrl = '/common/getchannellist',
    // refundUrl = '',
    redoUrl = 'system/life/updatestatus';//手动更新订单状态

const payStatusOptions = [
    { label: '待支付', value: 0 },
    { label: '支付成功', value: 1 },
    { label: '缴费单位处理中', value: 2 },
    { label: '缴费金额到账', value: 3 },
    { label: '交易关闭', value: 4 },
]

class LifePay extends Component {
    constructor(props) {
        super(props)

        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({
                params, pagingUrl, context: this, successCallback: (res) => {
                    const { models, totalModels } = res
                    const dataSource = formatData(models, 'lifePayRecord.id')
                    this.setState({
                        dataSource,
                        totalModels,
                        current: params.pageIndex,
                        pageSize: params.pageSize,
                        selectedRowKeys: []
                    })
                }
            }).then(res => {
                if (!this.state.channelList.length) {
                    this.Request.getChannelList();
                }
            })
        },
        getChannelList: (params) => {
            requestGet({
                params, pagingUrl: getChannelListUrl, context: this, successCallback: res => {
                    if (res.status == 0) {
                        this.setState({
                            channelList: formatParentIdOptions({ options: res.models, hasDefaultOption: false, valueKey: 'channelId', labelKey: 'remarks' })
                        })
                    }
                }
            })
        }
        ,
        // refund: (params) => {
        //     fetch(refundUrl, params).then(res => {
        //         if (res.status == 0) {
        //             this.Request.get(this.state.getDataParams);
        //         }
        //     })
        // },
        redo: (params) => {
            fetch(redoUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams);
                }
            })
        }
    }

    Util = {
        handleSearchValues: (values) => {
            const queryParams = Object.assign({}, values)
            const mobileRegx = /^1\d{10}$/gi
            // 搜索创建时间
            if (!is.undefined(queryParams.createTime) && !is.undefined(queryParams.createTime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createTime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createTime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }
            delete queryParams.createTime

            // 搜索到账时间
            if (!is.undefined(queryParams.finishedTime) && !is.undefined(queryParams.finishedTime[0])) {
                queryParams.finishStartTime = handleStartTime(queryParams.finishedTime[0]).format('x')
                queryParams.finishEndTime = handleEndTime(queryParams.finishedTime[1]).format('x')
            } else {
                queryParams.finishStartTime = undefined
                queryParams.finishEndTime = undefined
            }
            delete queryParams.finishedTime

            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }

            return queryParams
        },
        getTotalAmount: (dataSource) => {
            let totalAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (item.lifePayRecord.payAmount) {
                    totalAmount += item.lifePayRecord.payAmount
                }
            })
            return totalAmount
        },
        getSelectedAmount: (dataSource, selectedRowKeys) => {
            const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
            if (!tempSelectedRowKeys.length) {
                return 0
            }
            const selectedString = tempSelectedRowKeys.join(',')
            let selectedAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (selectedString.indexOf(item.lifePayRecord.id) > -1 && item.lifePayRecord.payAmount) {
                    selectedAmount += item.lifePayRecord.payAmount
                }
            })
            return selectedAmount
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {

        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this })
        },
        search: (values) => {
            const tmp = this.Util.handleSearchValues(values);
            if (tmp) {
                actionSearch({ value: tmp, context: this })
            }
        },
        clearSearch: () => {
            actionClearSearch({ context: this })
        }
        ,
        // refund: (id) => {
        //     this.Request.refund({ id })
        // },
        redo: (id) => {
            this.setState({
                editId: id,
                payModalVis: true
            })
        },
        savePay: (values) => {
            this.Request.redo({ id: this.state.editId, ...values });
        },
        cancelPay: () => {
            this.setState({
                payModalVis: false
            })
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        const { redo } = this.Action

        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            totalAmount: 0,
            selectedAmount: 0,
            channelList: [],
            editId: null,
            payModalVis: false
        }

        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '收款账户',
                    id: 'payAccount'
                },
                {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone'
                },
                {
                    type: SearchType.Select,
                    label: '订单状态',
                    id: 'payStatus',
                    dataSource: payStatusOptions
                },
                {
                    type: SearchType.String,
                    label: '缴费公司订单号',
                    id: 'channelOrderNo'
                }, {
                    type: SearchType.String,
                    label: '平台唯一订单号',
                    id: 'serialNumber'
                },
                {
                    type: SearchType.DateRange,
                    label: '创建时间',
                    id: 'createTime'
                },
                {
                    type: SearchType.DateRange,
                    label: '到账时间',
                    id: 'finishedTime'
                }
            ]
        }

        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            }, {
                title: '手机号码',
                dataIndex: 'mobilePhone',
                key: 'mobilePhone'
            }, {
                title: '平台唯一订单号',
                dataIndex: 'lifePayRecord.serialNumber',
                key: 'lifePayRecord.serialNumber'
            }, {
                title: '缴费公司订单号',
                dataIndex: 'lifePayRecord.channelOrderNo',
                key: 'lifePayRecord.channelOrderNo'
            }, {
                title: '缴费类型',
                dataIndex: 'lifePayRecord.paymentType',
                key: 'lifePayRecord.paymentType',
                render: value => {
                    if (value == 100) {
                        return '水费';
                    } else if (value == 200) {
                        return '电费';
                    } else if (value == 300) {
                        return '煤气费';
                    }
                }
            }, {
                title: '户主姓名',
                dataIndex: 'lifePayRecord.name',
                key: 'lifePayRecord.name'
            }, {
                title: '用户缴费编号',
                dataIndex: 'lifePayRecord.payAccount',
                key: 'lifePayRecord.payAccount'
            }, {
                title: '金额',
                dataIndex: 'lifePayRecord.payAmount',
                key: 'lifePayRecord.payAmount',
                render: value => toMoney(value)
            }, {
                title: '付款渠道',
                dataIndex: 'lifePayRecord.channelId',
                key: 'lifePayRecord.channelId',
                render: value => {
                    const result = this.state.channelList.filter(item => item.value == value);
                    return result[0] && result[0].label;
                }
            }, {
                title: '订单状态',
                dataIndex: 'lifePayRecord.payStatus',
                key: 'lifePayRecord.payStatus',
                render: value => {
                    const result = payStatusOptions.filter(item => item.value == value);
                    return result[0] && result[0].label;
                }
            }, {
                title: '创建时间',
                dataIndex: 'lifePayRecord.createTime',
                key: 'lifePayRecord.createTime',
                render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
            }, {
                title: '支付时间',
                dataIndex: 'lifePayRecord.payTime',
                key: 'lifePayRecord.payTime',
                render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
            }, {
                title: '到账时间',
                dataIndex: 'lifePayRecord.updateTime',
                key: 'lifePayRecord.updateTime',
                render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
            }
            , {
                title: '操作',
                dataIndex: 'action',
                key: 'action',
                render: (text, record, index) => (
                    (record.lifePayRecord.payStatus === 1 || record.lifePayRecord.payStatus === 2) ?
                        (<span>
                            <Button type="primary" className="action-item" onClick={() => { redo(record.lifePayRecord.id) }}>重新发起支付</Button>
                        </span>) : null
                )
            }
        ]

        this.payFormItems = [{
            type: EditType.InputStr,
            label: '支付密码',
            key: 'payPassword',
            config: {
                rules: [
                    { required: true, message: '请输入支付密码' }
                ]
            },
            itemConfig: {
                type: 'password'
            }
        }]

    }
    render() {
        const { dataSource, current, totalModels, pageSize, selectedRowKeys, totalAmount, selectedAmount, payModalVis } = this.state
        const { changePage, onShowSizeChange, search, clearSearch, savePay, cancelPay } = this.Action
        return (
            <div>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Card>
                    <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
                        当前页总金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的总金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
                </Card>
                <Table
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    scroll={{ x: 1500 }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal,
                        pageSizeOptions: ['50', '100', '200'],
                    }}
                />
                <EditPanel
                    title='重新发起回调'
                    modalVis={payModalVis}
                    formItems={this.payFormItems}
                    onSave={savePay}
                    onCancel={cancelPay}
                />
            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
        })
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams, selectedRowKeys, dataSource } = this.state
        const { get } = this.Request
        const { getSelectedAmount, getTotalAmount } = this.Util
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
        // 选中的项发生变化时，计算已选中的项的总金额
        if (nextState.selectedRowKeys !== selectedRowKeys) {
            this.setState({
                selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
            })
        }
        // 当前页的数据发生变化时，计算当前页的总金额
        if (nextState.dataSource !== dataSource) {
            this.setState({
                totalAmount: getTotalAmount(nextState.dataSource)
            })
        }
    }
}
export default LifePay


