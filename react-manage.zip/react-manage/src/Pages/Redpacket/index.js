/*
 * @Author: miccy 
 * @Date: 2018-02-07 11:30:11 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:10:48
 * 红包列表
 */

import React, { Component } from 'react'
// import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../Common/searchPanel'
import * as SearchType from '../../Common/searchTypes'
import { Table, message } from 'antd'
import { formatParentIdOptions, handleStartTime, handleEndTime, toMoney } from '../../Util/reactUtil'
import { hasAttr } from '../../Util'
import { requestGet } from '../../Util/Request'
import { getFetch } from '../../Config/request'
import { actionChangePage, actionClearSearch, actionSearch, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../Util/Action'

const pagingUrl = '/system/redPacket/list', //获取列表
  getTypeUrl = '/system/redPacket/type',//获取红包类型
  getWayUrl = '/system/redPacket/way' //获取红包收入支出退款类型

class Redpacket extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({ params, pagingUrl, context: this }).then(res => {
        if (res.status == 0 && !this.state.typeOptions.length) {
          this.Request.getType()
          this.Request.getWay()
        }
      })
    },

    // 获取红包类型
    getType: (params) => {
      getFetch(getTypeUrl, params).then(res => {
        if (res && res.model && is.array(res.model.redPacketTypeList)) {
          this.setState({
            typeOptions: formatParentIdOptions({
              options: res.model.redPacketTypeList,
              valueKey: 'type',
              labelKey: 'value',
              hasDefaultOption: false
            })
          })
        }
      })
    },

    // 获取收入支出退款类型
    getWay: (params) => {
      getFetch(getWayUrl, params).then(res => {
        if (res && res.model && is.array(res.model.redPacketWayList)) {
          this.setState({
            wayOptions: formatParentIdOptions({
              options: res.model.redPacketWayList,
              valueKey: 'way',
              labelKey: 'value',
              hasDefaultOption: false
            })
          })
        }
      })

    },
  }

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {

    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (value.mobilePhone && (!mobileRegx.test(value.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      delete queryParams.createtime
      actionSearch({ value: queryParams, context: this })
    },

    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },

    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
  }

  Util = {
    // 更新模态框表单的配置
    updateMetaData: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const metadata = this.metadata.conditions.filter((item, index) => item.id === keyValue)[0]
        fn(metadata)
      }
    },
  }

  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.state = {
      dataSource: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
      typeOptions: [],//存储红包类型的枚举
      wayOptions: [],//存储收入支出退款类型的枚举
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [{
        type: SearchType.Select,
        label: '红包类型',
        id: 'type',
        dataSource: this.state.typeOptions
      }, {
        type: SearchType.Select,
        label: '收入支出退款类型',
        id: 'way',
        dataSource: this.state.wayOptions
      }, {
        type: SearchType.String,
        label: '订单号',
        id: 'serialNumber'
      }, {
        type: SearchType.String,
        label: '手机号码',
        id: 'userMobile'
      }, {
        type: SearchType.DateRange,
        label: '时间段',
        id: 'createtime'
      }]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName',
      }, {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile',
      }, {
        title: '金额',
        dataIndex: 'amount',
        key: 'amount',
        render: value => toMoney(value)
      }, {
        title: '订单号',
        dataIndex: 'serialNumber',
        key: 'serialNumber',
      }, {
        title: '关联订单号',
        dataIndex: 'relevancySerialNumber',
        key: 'relevancySerialNumber',
      }, {
        title: '红包类型',
        dataIndex: 'typeStr',
        key: 'typeStr',
      }, {
        title: '收入支出退款类型',
        dataIndex: 'wayStr',
        key: 'wayStr',
      }, {
        title: '操作时间',
        dataIndex: 'createTimeStr',
        key: 'createTimeStr'
      }
    ]

  }
  render() {
    const { dataSource, current, totalModels, pageSize } = this.state
    const { search, clearSearch, changePage, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange,
            showTotal: actionShowTotal
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, typeOptions, wayOptions } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    const { updateMetaData } = this.Util
    // 监听红包类型下拉框
    updateMetaData(typeOptions, nextState.typeOptions, 'type', (metadata) => {
      if (hasAttr(metadata, 'dataSource')) {
        metadata.dataSource = nextState.typeOptions
      }
    })
    // 监听收入支出退款类型下拉框
    updateMetaData(wayOptions, nextState.wayOptions, 'way', (metadata) => {
      if (hasAttr(metadata, 'dataSource')) {
        metadata.dataSource = nextState.wayOptions
      }
    })
  }
}
export default Redpacket