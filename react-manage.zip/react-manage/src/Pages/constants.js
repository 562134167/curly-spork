export const SHOW_LOADING = 'SHOW_LOADING ';
export const HIDE_LOADING  = 'HIDE_LOADING ';
export const SET_DICT_LIST = 'SET_DICT_LIST';