/*
 * @Author: miccy 
 * @Date: 2018-02-07 11:30:11 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:10:48
 * 红包列表
 */

import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../Common/searchPanel'
import * as SearchType from '../../Common/searchTypes'
import { Table, message } from 'antd'
import { formatParentIdOptions, handleStartTime, handleEndTime, toMoney ,formatData} from '../../Util/reactUtil'
import { hasAttr ,arrayToObject} from '../../Util'
import { requestGet } from '../../Util/Request'
import { getFetch } from '../../Config/request'
import { actionChangePage, actionClearSearch, actionSearch, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../Util/Action'

const pagingUrl = '/train/order/paging', //获取列表
	  getChannelListUrl = '/common/getchannellist',
  	  getTypeUrl = '/common/getEnumeByClassName'//获取后台订单状态

class Redpacket extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      getFetch(pagingUrl,params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels, totalPages } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            totalPages,
            current: params.pageIndex,
            pageSize: params.pageSize,
            selectedRowKeys: []
          })
          // 判断下拉列表的数据源是否有数据，无则请求获取数据源
          const { StatusOptions , channelListOptions } = this.state
          !StatusOptions.length && this.Request.getType();
          !channelListOptions.length && this.Request.getChannelList();
        }
        return res
      })
    },

    // 后台订单状态
    getType: (params) => {
      getFetch(getTypeUrl, { ...params, className: 'train.TrainOrderShowStatusEnums' }).then(res => {
        if (res) {
          const {StatusOptions } = this.state
          res.models.forEach(item => {
           StatusOptions.push({
              label: item.value,
              value: item.key
            })
          })
          this.setState({
            StatusEnum: arrayToObject({ array: res.models, keyName: 'key', valueName: 'value' }),
            StatusOptions
          })
        }
      })
    },
    getChannelList: (params) => {
            getFetch(getChannelListUrl).then(res => {
                if (res && res.status == 0) {
                    const { channelListOptions } = this.state
                    res.models.forEach(item => {
                        channelListOptions.push({
                            label: item.remarks,
                            value: item.channelId
                        })
                    })
                    this.setState({
                        channelEnum: arrayToObject({ array: res.models, keyName: 'channelId', valueName: 'remarks' }),
                        channelListOptions
                    })
                }
            })
    },

  }

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {

    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (value.mobilePhone && (!mobileRegx.test(value.mobilePhone))) {
        message.error('请输入正确的乘客手机号')
        return;
      }
      if (value.registerMobilePhone && (!mobileRegx.test(value.registerMobilePhone))) {
        message.error('请输入正确的注册手机号')
        return;
      }
      delete queryParams.createtime
      actionSearch({ value: queryParams, context: this })
    },

    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },

    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
  }

  Util = {
    // 更新模态框表单的配置
    updateMetaData: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const metadata = this.metadata.conditions.filter((item, index) => item.id === keyValue)[0]
        fn(metadata)
      }
    },
  }

  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.state = {
      dataSource: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
      StatusOptions: [],//存储后台订单状态
      StatusEnum: {},
      channelListOptions: [],
      channelEnum: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [{
        type: SearchType.String,
        label: '注册手机号',
        id: 'registerMobilePhone'
      },{
        type: SearchType.String,
        label: '乘客手机号',
        id: 'mobilePhone',
      },{
        type: SearchType.String,
        label: '列车车次',
        id: 'checi',
      }, {
        type: SearchType.Select,
        label: '支付方式',
        id: 'channelId',
        dataSource: this.state.channelListOptions
      }, {
        type: SearchType.Select,
        label: '管理台订单状态',
        id: 'ticketStatus',
        dataSource: this.state.StatusOptions
      }, {
        type: SearchType.String,
        label: '乘客身份证',
        id: 'passportseno'
      }, {
        type: SearchType.String,
        label: '平台订单号',
        id: 'orderNo'
      }, {
        type: SearchType.DateRange,
        label: '时间段',
        id: 'createtime'
      }]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
        }
      }, {
        title: '姓名',
        dataIndex: 'userName',
        key: 'userName',
      }, {
        title: '注册手机号',
        dataIndex: 'registerMobilePhone',
        key: 'registerMobilePhone',
      }, {
        title: '订单金额',
        dataIndex: 'price',
        key: 'price',
        render: value => toMoney(value)
      },{
        title: '支付方式',
        dataIndex: 'channelId',
        key: 'channelId',
        render: (value, record) => this.state.channelEnum[value] || '未知'
      }, {
        title: '管理台订单状态',
        dataIndex: 'ticketStatusName',
        key: 'ticketStatusName',
      }, {
        title: '乘客姓名',
        dataIndex: 'passengersename',
        key: 'passengersename',
      }, {
        title: '乘客手机号',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone',
      }, {
        title: '乘客身份证',
        dataIndex: 'passportseno',
        key: 'passportseno',
      }, {
        title: '车次',
        dataIndex: 'checi',
        key: 'checi'
      }, {
        title: '车座位',
        dataIndex: 'cxin',
        key: 'cxin'
      }, {
        title: '车次发出时间',
        dataIndex: 'startTime',
        key: 'startTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
      }, {
        title: '车次到达时间',
        dataIndex: 'endTime',
        key: 'endTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
      }, {
        title: '车次历时时间',
        dataIndex: 'runtime',
        key: 'runtime',
        render: value => value + '小时',
      }, {
        title: '订单号',
        dataIndex: 'orderNo',
        key: 'orderNo'
      }, {
        title: '订单创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
      }, {
        title: '退款金额',
        dataIndex: 'refundAmount',
        key: 'refundAmount',
        render: value => toMoney(value),
      }, {
        title: '退款费率',
        dataIndex: 'reate',
        key: 'reate'
      }, {
        title: '退款手续费',
        dataIndex: 'poundage',
        key: 'poundage',
        render: value => toMoney(value),
      }
    ]

  }
  render() {
    const { dataSource, current, totalModels, pageSize } = this.state
    const { search, clearSearch, changePage, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange,
            showTotal: actionShowTotal
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, typeOptions, wayOptions } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default Redpacket