import React, { PureComponent } from 'react';
import is from 'is_js'
import { Form, Modal, Input, InputNumber, Select, DatePicker, Checkbox, Radio, Switch, TimePicker, Upload, Icon, Button } from 'antd';
import * as EditType from './../../../../Common/editType';
import { EditFormItemLayout } from '../../../../Common/uiSetting';
import { toString, toNumber, formatFormData } from '../../../../Util/reactUtil'
import KeyPanel from '../../../BusinessManage/views/component/keyPanel'
import '../index.less'
const { RangePicker, MonthPicker } = DatePicker;
const CheckboxGroup = Checkbox.Group;
const RadioGroup = Radio.Group;
const FormItem = Form.Item;
class EditForm extends PureComponent {
    render() {
        const { getFieldDecorator } = this.props.form;
        return (
            <Form>
                {
                    this.props.formItems.map((item, i) => (
                        getFormItem(this.props, item, getFieldDecorator, i)
                    ))
                }
            </Form>
        )
    }
    componentWillReceiveProps(nextProps, nextState) {
        /*         console.log(this.props.form.getFieldsValue())
                console.log(nextProps.form.getFieldsValue()); */
    }
}
/**
 *根据传入的配置，生成编辑面板
 *如果传入render，则默认由用户自己实现FormItem的实现
 *否则必须传入生成FormItem的类型，传入的类型必须在EditType里有声明的，否则报错
 *item类型：Object
*/
const getFormItem = (props, item, getFieldDecorator, index) => {
    if (item.render) {
        const RenderComponent = item.render
        return (
            <FormItem {...EditFormItemLayout} label={item.label} key={index}>
                {getFieldDecorator(item.key, item.config)(<RenderComponent {...props} item={item} />)}
            </FormItem>
        )
    }
    return (
        <FormItem {...EditFormItemLayout} label={item.label} key={index}>
            {getFieldDecorator(item.key, item.config)(renderItem(props, item))}
        </FormItem>
    )

}
// const grop = () => {

// }

const renderItem = (props, item) => {
    // console.log({...item.itemConfig.modalVis})
    switch (item.type) {
        case EditType.InputStr:
            return (
                <Input {...item.itemConfig} />
            )
        case EditType.InputNum:
            return (
                <InputNumber {...item.itemConfig} style={{ width: '100%' }} />
            )
        case EditType.Textarea:
            return (
                <Input type="textarea" {...item.itemConfig} />
            )
        case EditType.Select:
            // ant design2.X 不支持Number类型的值
            for (let i in item.options) {
                let option = item.options[i]
                if (!is.string(option.value)) {
                    option.value = toString(option.value)
                }
            }
            return (
                <Select {...item.itemConfig}>
                    {item.options.map((o, i) => (<Select.Option key={i} value={o.value}>{o.label}</Select.Option>))}
                </Select>
            )
        case EditType.DatePicker:
            return (
                <DatePicker {...item.itemConfig} />
            )
        case EditType.RangePicker:
            return (
                <RangePicker
                    {...item.itemConfig}
                />
            )
        case EditType.MonthPicker:
            return (
                <MonthPicker {...item.itemConfig} />
            )
        case EditType.TimePicker:
            return (
                <TimePicker {...item.itemConfig} />
            )
        case EditType.Checkbox:
            return (
                <Checkbox {...item.itemConfig}>{item.itemConfig && item.itemConfig.label}</Checkbox>
            )
        case EditType.CheckboxGroup:
            return (
                <CheckboxGroup {...item.itemConfig} />
            )
        case EditType.Radio:
            return (
                <Radio  {...item.itemConfig} />
            )
        case EditType.RadioGroup:
            return (
                <RadioGroup {...item.itemConfig} >
                    {
                        is.array(item.options) && item.options.map((o, index) => (
                            <Radio value={o.value} key={index}> {o.label}</Radio>
                        ))
                    }
                </RadioGroup>
            )
        case EditType.Switch:
            return (
                <Switch {...item.itemConfig} />
            )
        case EditType.Image:
            return (
                <div>
                    <Upload
                        withCredentials={true}
                        {...item.itemConfig}
                    >
                        {<div>
                            <Icon type="plus" />
                            <div className="ant-upload-text">上传图片</div>
                        </div>}
                    </Upload>
                </div>
            )
        default:
            throw new Error('未知的编辑表单项类型');
    }
}

const EditFormWrapper = Form.create({
    mapPropsToFields(props) { return { ...props.modal } }
})(EditForm);
/**
 * 组件传入props说明
 * @prop {Boolean} modalVis 模态框是否可见
 * @prop {String | ReactNode} title 模态框的窗口标题
 * @prop {Object} modal 模态框表单数据对象，用以填充表单域
 * @prop {Function} onSave 保存模态框表单修改/新建执行的函数
 * @prop {Function} onCancel 取消模态框表单修改/新建执行的函数
 * @prop {Array} formItems 动态生成模态框表单的配置，根据配置生成当前页面的表单
 * @prop {String} className 指定当前模态框的类名，用于添加样式
 * @prop {Object} modalConfig 其他模态框设置，可根据ant design提供的modal API进行进一步设置
 * 
 * formItems 数组传入说明
 *  [
 *     @param {Object} formItems[0]  
      {
        @param {Function} render 生成表单项的render函数，自定义实现表单项。如果有此函数，则忽略type、label、itemConfig
        
        render: () => {
            return (
                <div></div>
            )
        }
        @param {String} type 生成表单项的类型，可选类型可参照'./editType.js',如果没有符合的选项，可自己实现表单项的render
        type: EditType.InputStr,
        @param {String} label 生成表单项的标签文本
        label: '全称',
        @param {String} key 当前表单项取值所对应的key，表单也可从传入的modal[key]中获取到当前项的值
        key: 'fullname',
        @param {Object} config 对ant design表单项的配置，设置规则参照ant design中Form.Item的API
        config: {
          rules: [
            { required: true, message: '请输入全称', type: 'string' },
          ]
        }
        @param {Object} itemConfig 对输入域的配置，可参照ant design中数据输入组件的API（eg：如果当前type为EditType.InputStr,则可参照ant design中input组件的API）
        itemConfig: { disabled: true, format: 'YYYY-MM-DD HH:mm:ss' }
        
      } 
    ]     
 */
class InformPanel extends PureComponent {
    // console.log(this.props.formItems,item)
    render() {

        const { modalVis, title, modal, onSave, onCancel, className, formItems, modalConfig, onDisplay, formItems1, onSavePanel, modalVis1 } = this.props;
        // console.log(formItems.concat(formItems1))

        return (
            <div>
                <Modal title='审核'
                    okText='审核通过'
                    cancelText='审核不通过'
                    visible={modalVis1}
                    onOk={() => { this.refs.editForm.validateFieldsAndScroll((err, values) => { if (!err) { onSave(formatFormData(values, formItems)); } }) }}
                    onCancel={onCancel}
                >
                    <EditFormWrapper ref='editForm' modal={modal} formItems={formItems} />
                    <KeyPanel modalVis={modalVis} onCancel={onCancel} formItems1={formItems1} serve={onSavePanel} />
                </Modal>

            </div>
        )

    }
    componentWillReceiveProps(nextProps) {
        /* for (let key in nextProps) {
            console.log(key, nextProps[key] == this.props[key])
        } */
    }

}

export default InformPanel;