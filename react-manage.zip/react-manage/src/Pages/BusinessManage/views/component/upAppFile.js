import React, { Component } from 'react';
import { Upload, Button, Icon } from 'antd'

export default class UpAppFile extends Component {
    render() {
        return (

            //   console.log(this.props),
            <div>
                <Upload
                    withCredentials={true}
                    type='file'
                    name='file'
                    action='//jsonplaceholder.typicode.com/posts/'
                    multiple={true}
                    defaultFileList={this.props.item.itemConfig.fileList}
                    accept=".jpg,.png,.doc"
                >
                    <Button><Icon type='inbox' />上传</Button>
                </Upload>
            </div>
        )
    }
}