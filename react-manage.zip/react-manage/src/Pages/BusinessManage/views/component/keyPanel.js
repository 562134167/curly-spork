import React, { PureComponent } from 'react';
import { Form, Modal, Input, InputNumber, Select, DatePicker, Checkbox, Radio, Switch,   Button } from 'antd';
import * as EditType from './../../../../Common/editType';
import { EditFormItemLayout } from '../../../../Common/uiSetting';
import { toString, toNumber, formatFormData, formatData } from '../../../../Util/reactUtil'
import '../index.less'
const { RangePicker, MonthPicker } = DatePicker;
const CheckboxGroup = Checkbox.Group;
const RadioGroup = Radio.Group;
const FormItem = Form.Item;

class EditForm extends PureComponent {
    //初始数据
    render() {
        const { getFieldDecorator } = this.props.form;
        return (
            <Form>
                {
                    this.props.formItems1.map((item, i) => (
                        getFormItem(this.props, item, getFieldDecorator, i)
                    ))
                }
            </Form>
        )
    }
    componentWillReceiveProps(nextProps, nextState) {
        /*         console.log(this.props.form.getFieldsValue())
                console.log(nextProps.form.getFieldsValue()); */
    }
}
/**
 *根据传入的配置，生成配置密钥面板
 *否则必须传入生成FormItem的类型，传入的类型必须在EditType里有声明的，否则报错
 *item类型：Object
*/
const getFormItem = (props, item,getFieldDecorator, index) => {
    // console.log(item)
    if (item.render) {
        const RenderComponent = item.render
        return (
            <FormItem {...EditFormItemLayout} label={item.label} key={index}>
                {getFieldDecorator(item.key, item.config)(<RenderComponent {...props} item={item}/>)}
            </FormItem>
        )
    }
    return (
        <FormItem className='itemFrom' {...EditFormItemLayout} label={item.label} key={index}>
            {getFieldDecorator(item.key, item.config)(renderItem(item))}
        </FormItem>
    )

}

const renderItem = ( item) => {
    console.log(item.options)
    switch (item.type) {
        case EditType.InputStr:
            return (
                <Input className='bothInp' {...item.itemConfig}></Input>
            )
        case EditType.InputNum:
            return (
                <InputNumber  {...item.itemConfig}  />
            )
        default:
            return (
                <Input className='bothNum' {...item.itemConfig}></Input>
            )
        }
}

const EditFormWrapper = Form.create({
    mapPropsToFields(props) { return { ...props.modal } }
})(EditForm);
/**
 * 组件传入props说明
 * formItems 数组传入说明
 *  [
 *     @param {Object} formItems[0]  
      {
        @param {Function} render 生成表单项的render函数，自定义实现表单项。如果有此函数，则忽略type、label、itemConfig
        
        render: () => {
            return (
                <div></div>
            )
        }
        @param {String} type 生成表单项的类型，可选类型可参照'./editType.js',如果没有符合的选项，可自己实现表单项的render
        type: EditType.InputStr,
        @param {String} label 生成表单项的标签文本
        label: '全称',
        @param {String} key 当前表单项取值所对应的key，表单也可从传入的modal[key]中获取到当前项的值
        key: 'fullname',
        @param {Object} config 对ant design表单项的配置，设置规则参照ant design中Form.Item的API
        config: {
          rules: [
            { required: true, message: '请输入全称', type: 'string' },
          ]
        }
        @param {Object} itemConfig 对输入域的配置，可参照ant design中数据输入组件的API（eg：如果当前type为EditType.InputStr,则可参照ant design中input组件的API）
        itemConfig: { disabled: true, format: 'YYYY-MM-DD HH:mm:ss' }
      } 
    ]     
 */
class KeyPanel extends PureComponent {
    state={
        val:''
    }
    outInp=(values)=>{
        console.log(1212)
         this.setState({
             val:values
         })
    }
    
    render() {
        const { modalVis, title, modal, onSave, onCancel, formItems1, className, modalConfig,serve} = this.props;

        return (
            <div>
                <Modal
                className='modalWid' 
                title='输入密钥'
                visible={modalVis}
                okText='确认'
                cancelText='不报存'
                onOk={()=>{this.refs.editForm.validateFieldsAndScroll((err,values1)=>{serve(values1,formItems1)})}}
                onCancel={onCancel}
                >
                <span className='busiName'>商户</span><span className='sceKey'>密钥</span>
                <EditFormWrapper ref='editForm' modal={modal} formItems1={formItems1} />
            </Modal>
               
                {/* <Button onClick={}>存值</Button> */}
            </div>
        )

    }
    componentWillReceiveProps(nextProps) {
        /* for (let key in nextProps) {
            console.log(key, nextProps[key] == this.props[key])
        } */
    }

}

export default KeyPanel;