import React, { Component } from 'react'
import moment from 'moment'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Icon, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
const editTitle = '查看'
const initGetParams = {
  // keyword: '',
  pageIndex: 1,
  // pageSize: 20
}
const newItem = {
  createtime: {
    value: moment()
  }
}
const pagingUrl = '/system/helppay/paging',
  addUrl = '/system/helppay/add',
  updateUrl = '/system/helppay/update',
  removeUrl = '/system/helppay/remove',
  removeListUrl = '/system/helppay/removelist',
  updatePropertyUrl = '/system/helppay/updateproperty';

export default class BusinessReport extends Component {
  constructor(props) {
    super(props)
    
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        const { models, totalModels } = res
        const dataSource = formatData(models)
        this.setState({
          dataSource,
          totalModels,
          current: params.pageIndex
        })
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeListUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params, { arrayFormat: 'indices' }).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
  }
  // 点击按钮的操作（修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {

    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      console.log(record)
      const obj = formateEditData(record, this.formItems)
      for (let i in record) {
        modal[i] = {
          value: obj[i]
        }
      }
      console.log(modal)
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      this.onInit()
      const { getDataParams, dataSource, length } = this.state
      const arr1 = []
      // const arr2 = Object.assign([],dataSource)
      console.log(value, dataSource)
      //转化时间格式
      // const dat=moment(value.createtime._d).format('YYYY-MM-DD')
      // for(let i in dataSource){
      //   const Num = Number(value.merchantType) - 1
      //   const Val = this.metadata.conditions[0].dataSource[Num].label
      //   if(Val==dataSource[i].merchantType&&dat==dataSource[i].createtime&&value.merchantName==dataSource[i].merchantName){
      //     arr1.push(dataSource[i])
      //   }
      // }
      const params = { ...getDataParams, ...value }
      this.setState({
        getDataParams: params,
        dataSource: arr1,
        length: arr1.length
      })
    },

    // 清空查找条件
    clearSearch: (params) => {
      this.onInit()
      const { dataSource } = this.state
      this.setState({
        getDataParams: initGetParams,
        dataSource: dataSource
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId == 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            // edit({
            //   ...dataSource[i],
            //   ...values,
            // })
            console.log(`edit`, { ...dataSource[i], ...values })
            break;
          }
        }
      } else {
        // 新增状态下的保存
        // add(values)
        console.log(`add`, values)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击导出操作按钮
    derivationItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要导出的数据')
        return;
      }
      // window.location.href()
      // this.Request.editItems({
      //   name,
      //   value,
      //   ids: selectedRowKeys
      // })
      console.log(`editItems`, { name, value, ids: selectedRowKeys })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit } = this.Action
    const { get } = this.Request
    this.state = {
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      length: 0
    }// 搜索面板元数据
    this.metadata = {
      // orders: [
      //   { value: 'num', label: '排序号' },
      // ],
      conditions: [
        {
          type: SearchType.Select,
          label: '商户行业类型',
          id: 'merchantType',
          dataSource: [
            { value: 1, label: '商户类一' },
            { value: 2, label: '商户类二' },
            { value: 3, label: '商户类三' }
          ]
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime',
        }, {
          type: SearchType.String,
          label: '商户名称',
          id: 'merchantName',
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'trxNo',
        key: 'trxNo',
        // render: text => <a href="#">{text}</a>,
      }, {
        title: '公司名称',
        dataIndex: 'merchantOrderNo',
        key: 'merchantOrderNo',
        // render: text => <a href="#">{text}</a>,
      }, {
        title: '商户行业类型',
        dataIndex: 'merchantType',
        key: 'merchantType',
        // render: text => <a href="#">{text}</a>,
      }, {
        title: '商户名称',
        dataIndex: 'merchantName',
        key: 'merchantName'
      }, {
        title: '审核时间',
        dataIndex: 'createtime',
        key: 'createtime'
      }, {
        title: '审核状态',
        dataIndex: 'status',
        key: 'status',
        render: (text, record, index) => (
          text === true ? '审核通过' : '审核不通过'
        )
      }, {
        title: '操作',
        dataIndex: 'protocol',
        key: 'protocol',
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>查看</Button>
          </span>
        )
      }
    ];
    //查看面板数据
    this.formItems = [
      {
        type: EditType.InputNum,
        label: '序号',
        key: 'trxNo',
      }, {
        type: EditType.InputNum,
        label: '公司名称',
        key: 'merchantOrderNo'
      }, {
        type: EditType.InputStr,
        label: '商户行业类型',
        key: 'merchantType'
      }, {
        type: EditType.InputStr,
        label: '商户行业类型',
        key: 'merchantName'
      }, {
        type: EditType.InputStr,
        label: '审核时间',
        key: 'createtime'
      }, {
        type: EditType.Select,
        label: '审核状态',
        key: 'isSettlement',
        options: [
          { value: 100, label: '审核通过' },
          { value: 101, label: '审核未通过' }
        ],
        isNum: true
      },
    ]
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, totalPages } = this.state
    const { search, clearSearch, save, cancel, changePage, derivationItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <p style={{ fontSize: 20 }}>当前筛选后的数据数量：{this.state.length}</p>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, selectedRowKeys } = this.state
    // const { get } = this.Request
    console.log(nextState.selectedRowKeys)
    if (nextState.getDataParams !== getDataParams) {
      // get(nextState.getDataParams)
      console.log(`get`, nextState.getDataParams)
    }
  }
}