import React, { Component } from 'react'
import { connect } from 'react-redux'
// import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions, formatFormData } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
const editTitle = '编辑商户',
  initGetParams = {
    pageIndex: 1,
  }

const pagingUrl = '/system/merchant/paging',
  updateUrl = '/system/merchant/update',
  updatePropertyUrl = '/system/merchant/updateproperty',
  uploadFileUrl = '/system/file/upload'
class FileManage extends Component {
  constructor(props) {
    super(props)
   
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击修改按钮
    edit: (record, index) => {
      if (record.assStatus == 0) {
        this.formItems = this.Util.getUndoFormItem()
      } else {
        this.formItems = this.Util.getDisabledFormItem()
      }
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        modalVis: true,
        modal: modal,
        title: editTitle,
        editId: record.assStatus == 0 ? obj.id : null,
      })
    },
    // 查
    search: (value) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...value }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    editStatus: (type, context) => {
      context.refs.editForm.validateFieldsAndScroll((err, values) => {
        if (!err) {
          this.Action.save(formatFormData(values, this.formItems));
        }
      })
      this.Request.editItems({
        name: 'assStatus',
        value: type === 'cancel' ? 2 : 1,
        ids: [this.state.editId]
      }).then(res => {
        this.setState({
          modalVis: false
        })
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      for (let i in dataSource) {
        if (dataSource[i].id === editId) {
          const temp = { ...dataSource[i], ...values }
          edit(temp)
          break;
        }
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    }
  }
  RenderFunc = {
    // 模态框底部的渲染函数
    renderFooter: (context) => {
      const { editId } = this.state
      const { editStatus, cancel } = this.Action
      if (editId || editId == 0) {
        return (
          <div>
            <Button onClick={() => { editStatus('ok', context) }} type="primary">审核通过</Button>
            <Button onClick={() => { editStatus('cancel', context) }}>审核不通过</Button>
          </div>
        )
      } else {
        return (
          <div>
            <Button onClick={cancel} type="primary">确定</Button>
          </div>
        )
      }
    }
  }
  Util = {
    // 更新模态框表单的配置
    updateFormItem: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
        fn(formItem)
      }
    },
    // 处理传入表单的编辑内容的key、value以匹配组件的格式要求
    // handleEditData: (obj) => {
    //   const { getFileList } = this.Util
    //   if (is.object(obj)) {
    //     if (!is.undefined(obj.merBusiLicUrl)) {
    //       obj.merBusiLicUrl = getFileList(obj.merBusiLicUrl)
    //     }
    //     if (!is.undefined(obj.merIdCardCopyUrl)) {
    //       obj.merIdCardCopyUrl = getFileList(obj.merIdCardCopyUrl)
    //     }
    //     if (!is.undefined(obj.merAgreementUrl)) {
    //       obj.merAgreementUrl = getFileList(obj.merAgreementUrl)
    //     }
    //     if (!is.undefined(obj.userImages)) {
    //       obj.userImages = getFileList(obj.userImages)
    //     }
    //   }
    //   return obj
    // },
    //处理表单的保存内容的key、value以匹配后台的格式
    // handleChangedData: (obj) => {
    //   if (is.object(obj)) {
    //     if (is.array(obj.userImages)) {
    //       obj.userImages = this.Util.getUrl(obj.userImages)
    //     }
    //     if (is.array(obj.merBusiLicUrl)) {
    //       obj.merBusiLicUrl = this.Util.getUrl(obj.merBusiLicUrl)
    //     }
    //     if (is.array(obj.merIdCardCopyUrl)) {
    //       obj.merIdCardCopyUrl = this.Util.getUrl(obj.merIdCardCopyUrl)
    //     }
    //     if (is.array(obj.merAgreementUrl)) {
    //       obj.merAgreementUrl = this.Util.getUrl(obj.merAgreementUrl)
    //     }
    //   }
    //   return obj
    // },
    getUndoFormItem: (() => {
      let merchantFormItem;
      return () => {
        if (merchantFormItem) {
          return merchantFormItem
        } else {
          return merchantFormItem = [
            {
              type: EditType.Select,
              label: '账号类型',
              key: 'merAccType',
              options: [
                { value: 1, label: '对公' },
                { value: 2, label: '对私' },
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择账号类型' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '公司编码',
              key: 'merCode',
              config: {
                rules: [
                  { required: true, message: '请输入公司编码' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司名称',
              key: 'merName',
              config: {
                rules: [
                  { required: true, message: '请输入公司名称' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '企业邮箱',
              key: 'merEmail',
              config: {
                rules: [
                  { pattern: /^\w+((-\w+)|(\.\w+))*@\w+((\.|-)\w+)*\.\w+$/, message: '企业邮箱格式不正确' },
                  { required: true, message: '请输入企业邮箱' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司地址',
              key: 'merAddr',
              config: {
                rules: [
                  { required: true, message: '请输入公司地址' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司网址',
              key: 'merWebsite',
              config: {
                rules: [
                  { required: true, message: '请输入公司网址' }
                ]
              }
            }, {
              type: EditType.Textarea,
              label: '公司简介',
              key: 'merIntroduct',
              config: {
                rules: [
                  { required: true, message: '请输入公司简介' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '营业执照号',
              key: 'merBusiLicNo',
              config: {
                rules: [
                  { required: true, message: '请输入营业执照号' }
                ]
              }
            }, {
              type: EditType.Image,
              label: '营业执照',
              key: 'merBusiLicUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传营业执照' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传营业执照',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merBusiLicUrl') && props.form.getFieldValue('merBusiLicUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '企业法人',
              key: 'merLegalPerson',
              config: {
                rules: [{ required: true, message: '请输入企业法人' }]
              }
            }, {
              type: EditType.InputStr,
              label: '法人身份证号码',
              key: 'merIdCard',
              config: {
                rules: [
                  { required: true, message: '请输入法人身份证号码' },
                  { pattern: /\d{18}|\d{15}/, message: '身份证号码格式错误' }
                ],
              }
            }, {
              type: EditType.Image,
              label: '法人身份证复印件',
              key: 'merIdCardCopyUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传法人身份证复印件' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '身份证复印件',
                accept: '.jpg',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merIdCardCopyUrl') && props.form.getFieldValue('merIdCardCopyUrl').length >= 2) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.Image,
              label: '协议上传',
              key: 'merAgreementUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传协议上传' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传协议',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merAgreementUrl') && props.form.getFieldValue('merAgreementUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '公司银行开户名',
              key: 'bankAccountName',
              config: {
                rules: [
                  { required: true, message: '请输入公司银行开户名' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '开户银行名称',
              key: 'bankBankName',
              config: {
                rules: [{ required: true, message: '请输入开户银行名称' }]
              }
            }, {
              type: EditType.InputNum,
              label: '开户账号',
              key: 'bankBankNumber',
              rules: [
                { required: true, message: '请输入开户账号' }
              ]
            }, {
              type: EditType.Select,
              label: '商户行业类型',
              key: 'bankType',
              config: {
                rules: [
                  { required: true, message: '请输入商户行业类型' }
                ]
              },
              itemConfig: {
                options: formatParentIdOptions({
                  options: this.props.industryTypeOptions,
                  hasDefaultOption: false,
                  valueKey: 'value'
                })
              }
            }, {
              type: EditType.Select,
              label: '状态',
              key: 'status',
              options: [
                { value: 1, label: '正常' },
                { value: 2, label: '不正常' },
              ],
              config: {
                rules: [
                  { required: true, message: '请选择状态' }
                ]
              },
            },
          ]
        }
      }
    })(),
    getDisabledFormItem: (() => {
      let formItem;
      return () => {
        if (formItem) {
          return formItem
        } else {
          formItem = Object.assign([], this.Util.getUndoFormItem())
          for (let i in formItem) {
            if (hasAttr(formItem[i], 'itemConfig')) {
              formItem[i].itemConfig.disabled = true
            } else {
              formItem[i].itemConfig = {
                disabled: true
              }
            }
          }
          return formItem
        }
      }
    })()
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit } = this.Action
    // const { get } = this.Request
    this.state = {
      title: editTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      editId: null,
      totalModels: null,
      getDataParams: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.Select,
          label: '审核状态',
          id: 'assStatus',
          dataSource: [
            { value: 0, label: '未审核' },
            { value: 2, label: '审核不通过' },
          ]
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '公司名称',
        dataIndex: 'merName',
        key: 'merName',
      }, {
        title: '企业法人',
        dataIndex: 'merLegalPerson',
        key: 'merLegalPerson',
      }, {
        title: '公司编码',
        dataIndex: 'merCode',
        key: 'merCode',
      }, {
        title: '审核状态',
        dataIndex: 'assStatus',
        key: 'assStatus',
        render: value => {
          if (value == 0) {
            return '未审核'
          } else if (value == 1) {
            return '审核通过'
          } else if (value == 2) {
            return '审核不通过'
          }
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>查看</Button>
          </span>
        )
      }
    ];
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { search, clearSearch, cancel, changePage, editItems } = this.Action
    return (
      <div className="file-manage">
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="assStatus"
            items={[{ label: '审核通过', value: 1 },
            { label: '审核不通过', value: 2 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          footer={(context) => this.RenderFunc.renderFooter(context)}
          onCancel={cancel}
          className="file-manage-modal"
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    industryTypeOptions: hasAttr(state.index.dictList.filter((item, index) => item.value === 'IndustryType'), [0, 'items']) || [],
  }
}
export default connect(mapStateToProps)(FileManage)