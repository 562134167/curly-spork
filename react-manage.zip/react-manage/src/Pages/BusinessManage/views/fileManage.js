import React, { Component } from 'react'
import { connect } from 'react-redux'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions, handleEndTime, handleStartTime } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
const addTitle = '新建商户'
const editTitle = '编辑商户'
const editUserinfoTitle = '编辑用户信息'
const initGetParams = {
  // keyword: '',
  pageIndex: 1,
  // pageSize: 20
}
const newItem = {
  userType: 1,
  fromType: 1,
  merType: 1,
  merAccType: 1,
  assStatus: 0,
  status: 1
}
const pagingUrl = '/system/merchant/paging',
  userinfoPagingUrl = '/system/userinfo/paging',
  addUrl = '/system/merchant/add',
  updateUrl = '/system/merchant/update',
  userinfoUpdateUrl = '/system/userinfo/update',
  removeUrl = '/system/merchant/remove',
  removeListUrl = '/system/merchant/removelist',
  updatePropertyUrl = '/system/merchant/updateproperty',
  uploadFileUrl = '/system/file/upload',
  resetPwdUrl = 'system/userinfo/resetpassword',
  resetPayPwdUrl = 'system/userinfo/resetpaypassword'
class FileManage extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, { ...params, ...{ type: '1' } }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 获取用户信息
    getUserinfo: (params) => {
      return getFetch(userinfoPagingUrl, params).then(res => {
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        if (res.status == 0) {
          this.setState({
            modalVis: false
          })
          this.Request.get(this.state.getDataParams)
        }
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          console.log(selectedRowKeys[i])
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeListUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改用户信息数据
    editUserInfo: (params) => {
      return fetch(userinfoUpdateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    resetPwd: (params) => {
      return fetch(resetPwdUrl, params).then(res => {
        if (res.status == 0) {
          message.success('重置登录密码成功')
        } else {
          message.error('重置登录密码失败，请稍后重试')
        }
        return res
      })
    },
    resetPayPwd: (params) => {
      return fetch(resetPayPwdUrl, params).then(res => {
        if (res.status == 0) {
          message.success('重置支付密码成功')
        } else {
          message.error('重置支付密码失败，请稍后重试')
        }
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.formItems = this.Util.getNewItemFormItem()
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle
      })
    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
    // 点击修改按钮
    edit: (record, index) => {
      this.formItems = this.Util.getMerchantFormItem()
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }
      }
      console.log(modal)
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 修改用户信息
    editUserinfo: (record, index) => {
      this.formItems = this.Util.getUserinfoFormItem()
      this.Request.getUserinfo({ id: record.userId }).then(res => {
        if (res && is.array(res.models)) {
          let modal = {}
          const obj = formateEditData(res.models[0], this.formItems)
          for (let i in obj) {
            modal[i] = {
              value: obj[i]
            }
          }
          this.setState({
            editId: obj.id,
            modalVis: true,
            modal: modal,
            title: editUserinfoTitle
          })
        }
      })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }

      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId == 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            const temp = { ...dataSource[i], ...values }
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = values
        add(temp)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    },
    // 重置登录密码
    resetPwd: (record, index) => {
      this.Request.resetPwd({
        id: record.userId
      })
    },
    // 重置支付密码
    resetPayPwd: (record, index) => {
      this.Request.resetPayPwd({
        id: record.userId
      })
    }
  }
  Util = {
    getMerchantFormItem: (() => {
      let merchantFormItem;
      return () => {
        if (merchantFormItem) {
          return merchantFormItem
        } else {
          return merchantFormItem = [
            {
              type: EditType.Select,
              label: '账号类型',
              key: 'merAccType',
              options: [
                { value: 1, label: '对公' },
                { value: 2, label: '对私' },
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择账号类型' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '公司编码',
              key: 'merCode',
              config: {
                rules: [
                  { required: true, message: '请输入公司编码' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司名称',
              key: 'merName',
              config: {
                rules: [
                  { required: true, message: '请输入公司名称' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '企业邮箱',
              key: 'merEmail',
              config: {
                rules: [
                  { pattern: /^\w+((-\w+)|(\.\w+))*@\w+((\.|-)\w+)*\.\w+$/, message: '企业邮箱格式不正确' },
                  { required: true, message: '请输入企业邮箱' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司地址',
              key: 'merAddr',
              config: {
                rules: [
                  { required: true, message: '请输入公司地址' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司网址',
              key: 'merWebsite',
              config: {
                rules: [
                  { required: true, message: '请输入公司网址' }
                ]
              }
            }, {
              type: EditType.Textarea,
              label: '公司简介',
              key: 'merIntroduct',
              config: {
                rules: [
                  { required: true, message: '请输入公司简介' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '营业执照号',
              key: 'merBusiLicNo',
              config: {
                rules: [
                  { required: true, message: '请输入营业执照号' }
                ]
              }
            }, {
              type: EditType.Image,
              label: '营业执照',
              key: 'merBusiLicUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传营业执照' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传营业执照',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merBusiLicUrl') && props.form.getFieldValue('merBusiLicUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '企业法人',
              key: 'merLegalPerson',
              config: {
                rules: [{ required: true, message: '请输入企业法人' }]
              }
            }, {
              type: EditType.InputStr,
              label: '法人身份证号码',
              key: 'merIdCard',
              config: {
                rules: [
                  { required: true, message: '请输入法人身份证号码' },
                  { pattern: /\d{18}|\d{15}/, message: '身份证号码格式错误' }
                ],
              }
            }, {
              type: EditType.Image,
              label: '法人身份证复印件',
              key: 'merIdCardCopyUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传法人身份证复印件' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '身份证复印件',
                accept: '.jpg',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merIdCardCopyUrl') && props.form.getFieldValue('merIdCardCopyUrl').length >= 2) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.Image,
              label: '协议上传',
              key: 'merAgreementUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传协议上传' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传协议',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merAgreementUrl') && props.form.getFieldValue('merAgreementUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '公司银行开户名',
              key: 'bankAccountName',
              config: {
                rules: [
                  { required: true, message: '请输入公司银行开户名' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '开户银行名称',
              key: 'bankBankName',
              config: {
                rules: [{ required: true, message: '请输入开户银行名称' }]
              }
            }, {
              type: EditType.InputNum,
              label: '开户账号',
              key: 'bankBankNumber',
              rules: [
                { required: true, message: '请输入开户账号' }
              ]
            }, {
              type: EditType.Select,
              label: '商户行业类型',
              key: 'bankType',
              config: {
                rules: [
                  { required: true, message: '请输入商户行业类型' }
                ]
              },
              itemConfig: {
                options: formatParentIdOptions({
                  options: this.props.industryTypeOptions,
                  hasDefaultOption: false,
                  valueKey: 'value'
                })
              }
            }, {
              type: EditType.Select,
              label: '审核状态',
              key: 'assStatus',
              options: [
                { value: 0, label: '未审核' },
                { value: 1, label: '审核通过' },
                { value: 2, label: '审核不通过' },
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择审核状态' }
                ]
              },
            }, {
              type: EditType.Select,
              label: '状态',
              key: 'status',
              options: [
                { value: 1, label: '正常' },
                { value: 2, label: '不正常' },
              ],
              config: {
                rules: [
                  { required: true, message: '请选择状态' }
                ]
              },
            },
          ]
        }
      }
    })(),
    getUserinfoFormItem: (() => {
      let userInfoFormItem;
      return () => {
        if (userInfoFormItem) {
          return userInfoFormItem
        }
        return userInfoFormItem = [
          {
            type: EditType.InputStr,
            label: '用户名',
            key: 'userName',
            config: {
              rules: [{ required: true, message: '请输入用户名' }]
            }
          }, {
            type: EditType.InputStr,
            label: '用户手机号码',
            key: 'userMobile',
            config: {
              rules: [
                { required: true, message: '请输入用户手机号码' },
                {
                  pattern: /^1\d{10}$/gi, message: '手机号码格式不正确', transform(value) {
                    return Number(value);
                  }
                }
              ]
            }
          }, {
            type: EditType.InputStr,
            label: '身份证号码',
            key: 'userIdCard',
            config: {
              rules: [
                { required: true, message: '请输入身份证号码' },
                { pattern: /\d{18}|\d{15}/, message: '身份证号码格式错误' }
              ]
            }
          }, {
            type: EditType.InputStr,
            label: '真实姓名',
            key: 'userRealName',
            config: {
              rules: [{ required: true, message: '请输入真实姓名' }]
            }
          }, {
            type: EditType.InputStr,
            label: '用户昵称',
            key: 'userNick',
            config: {
              rules: [{ required: true, message: '请输入用户昵称' }]
            },
          }, {
            type: EditType.Image,
            label: '用户头像',
            key: 'userImages',
            config: {
              valuePropName: 'fileList',
              getValueFromEvent: (e) => {
                if (Array.isArray(e)) {
                  return e;
                }
                return e && e.fileList;
              },
              rules: [
                { required: true, message: '请上传用户头像' }
              ]
            },
            itemConfig: {
              action: window.baseUrl + uploadFileUrl,
              tip: '上传用户头像',
              accept: '.jpg, .png, .bmp, .jpeg',
              name: 'files'
            },
            isShowbtn: (props) => {
              if (props.form.getFieldValue('userImages') && props.form.getFieldValue('userImages').length) {
                return false
              }
              return true
            }
          }, {
            type: EditType.InputStr,
            label: '用户手机设备ID',
            key: 'userToken',
            config: {
              rules: [
                { required: true, message: '请选择用户手机设备ID' }
              ]
            },
          }, {
            type: EditType.InputStr,
            label: '邮箱',
            key: 'userEmail',
            rules: [
              { pattern: /^\w+((-\w+)|(\.\w+))*@\w+((\.|-)\w+)*\.\w+$/, message: '邮箱格式不正确' },
              { required: true, message: '请输入邮箱' }
            ]
          }, {
            type: EditType.Select,
            label: '来源类型',
            key: 'fromType',
            options: [
              { value: 1, label: '安卓' },
              { value: 2, label: 'IOS' },
              { value: 3, label: 'PC' },
              { value: 4, label: '其他' }
            ],
            isNum: true,
            config: {
              rules: [
                { required: true, message: '请选择来源类型' }
              ]
            },
          }, {
            type: EditType.Select,
            label: '状态',
            key: 'status',
            options: [
              { value: 1, label: '正常' },
              { value: 2, label: '不正常' },
            ],
            config: {
              rules: [
                { required: true, message: '请选择状态' }
              ]
            },
          },
        ]
      }
    })(),
    getNewItemFormItem: (() => {
      let formItem;
      return () => {
        if (formItem) {
          return formItem
        } else {
          return formItem = [
            {
              type: EditType.Select,
              label: '用户类型',
              key: 'userType',
              options: [
                { value: 1, label: '注册用户' },
                { value: 2, label: '游客用户' },
                { value: 3, label: '其他' }
              ],
              config: {
                rules: [{ required: true, message: '请选择用户类型' }]
              },
              isNum: true
            }, {
              type: EditType.InputStr,
              label: '用户名',
              key: 'userName',
              config: {
                rules: [{ required: true, message: '请输入用户名' }]
              }
            }, {
              type: EditType.InputStr,
              label: '用户手机号码',
              key: 'userMobile',
              config: {
                rules: [
                  { required: true, message: '请输入用户手机号码' },
                  {
                    pattern: /^1\d{10}$/gi, message: '手机号码格式不正确', transform(value) {
                      return Number(value);
                    }
                  }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '身份证号码',
              key: 'userIdCard',
              config: {
                rules: [
                  { required: true, message: '请输入身份证号码' },
                  { pattern: /\d{18}|\d{15}/, message: '身份证号码格式错误' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '支付密码',
              key: 'userPayPassword',
              config: {
                rules: [
                  { required: true, message: '支付密码' },
                  { pattern: /(\d).*/, message: '支付密码只能为数字' }
                ]
              },
              itemConfig: {
                type: 'password'
              }
            }, {
              type: EditType.InputStr,
              label: '登录密码',
              key: 'userPassword',
              config: {
                rules: [
                  { required: true, message: '登录密码' }
                ]
              },
              itemConfig: {
                type: 'password'
              }
            }, {
              type: EditType.InputStr,
              label: '真实姓名',
              key: 'userRealName',
              config: {
                rules: [{ required: true, message: '请输入真实姓名' }]
              }
            }, {
              type: EditType.InputStr,
              label: '用户昵称',
              key: 'userNick',
              config: {
                rules: [{ required: true, message: '请输入用户昵称' }]
              },
            }, {
              type: EditType.Image,
              label: '用户头像',
              key: 'userImages',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传用户头像' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传用户头像',
                accept: '.jpg, .png, .bmp, .jpeg',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('userImages') && props.form.getFieldValue('userImages').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '用户手机设备ID',
              key: 'userToken',
              config: {
                rules: [
                  { required: true, message: '请选择用户手机设备ID' }
                ]
              },
            }, {
              type: EditType.InputStr,
              label: '邮箱',
              key: 'userEmail',
              rules: [
                { pattern: /^\w+((-\w+)|(\.\w+))*@\w+((\.|-)\w+)*\.\w+$/, message: '邮箱格式不正确' },
                { required: true, message: '请输入邮箱' }
              ]
            }, {
              type: EditType.Select,
              label: '来源类型',
              key: 'fromType',
              options: [
                { value: 1, label: '安卓' },
                { value: 2, label: 'IOS' },
                { value: 3, label: 'PC' },
                { value: 4, label: '其他' }
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择来源类型' }
                ]
              },
            }, {
              type: EditType.Select,
              label: '账号类型',
              key: 'merAccType',
              options: [
                { value: 1, label: '对公' },
                { value: 2, label: '对私' },
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择账号类型' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '公司编码',
              key: 'merCode',
              config: {
                rules: [
                  { required: true, message: '请输入公司编码' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司名称',
              key: 'merName',
              config: {
                rules: [
                  { required: true, message: '请输入公司名称' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '企业邮箱',
              key: 'merEmail',
              config: {
                rules: [
                  { pattern: /^\w+((-\w+)|(\.\w+))*@\w+((\.|-)\w+)*\.\w+$/, message: '企业邮箱格式不正确' },
                  { required: true, message: '请输入企业邮箱' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司地址',
              key: 'merAddr',
              config: {
                rules: [
                  { required: true, message: '请输入公司地址' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司网址',
              key: 'merWebsite',
              config: {
                rules: [
                  { required: true, message: '请输入公司网址' }
                ]
              }
            }, {
              type: EditType.Textarea,
              label: '公司简介',
              key: 'merIntroduct',
              config: {
                rules: [
                  { required: true, message: '请输入公司简介' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '营业执照号',
              key: 'merBusiLicNo',
              config: {
                rules: [
                  { required: true, message: '请输入营业执照号' }
                ]
              }
            }, {
              type: EditType.Image,
              label: '营业执照',
              key: 'merBusiLicUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传营业执照' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传营业执照',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merBusiLicUrl') && props.form.getFieldValue('merBusiLicUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '企业法人',
              key: 'merLegalPerson',
              config: {
                rules: [{ required: true, message: '请输入企业法人' }]
              }
            }, {
              type: EditType.InputStr,
              label: '法人身份证号码',
              key: 'merIdCard',
              config: {
                rules: [
                  { required: true, message: '请输入法人身份证号码' },
                  { pattern: /\d{18}|\d{15}/, message: '身份证号码格式错误' }
                ],
              }
            }, {
              type: EditType.Image,
              label: '法人身份证复印件',
              key: 'merIdCardCopyUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传法人身份证复印件' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '身份证复印件',
                accept: '.jpg',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merIdCardCopyUrl') && props.form.getFieldValue('merIdCardCopyUrl').length >= 2) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.Image,
              label: '协议上传',
              key: 'merAgreementUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传协议上传' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传协议',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merAgreementUrl') && props.form.getFieldValue('merAgreementUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '公司银行开户名',
              key: 'bankAccountName',
              config: {
                rules: [
                  { required: true, message: '请输入公司银行开户名' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '开户银行名称',
              key: 'bankBankName',
              config: {
                rules: [{ required: true, message: '请输入开户银行名称' }]
              }
            }, {
              type: EditType.InputNum,
              label: '开户账号',
              key: 'bankBankNumber',
              rules: [
                { required: true, message: '请输入开户账号' }
              ]
            }, {
              type: EditType.Select,
              label: '商户行业类型',
              key: 'bankType',
              config: {
                rules: [
                  { required: true, message: '请输入商户行业类型' }
                ]
              },
              itemConfig: {
                options: formatParentIdOptions({
                  options: this.props.industryTypeOptions,
                  hasDefaultOption: false,
                  valueKey: 'value'
                })
              }
            }, {
              type: EditType.Select,
              label: '审核状态',
              key: 'assStatus',
              options: [
                { value: 0, label: '未审核' },
                { value: 1, label: '审核通过' },
                { value: 2, label: '审核不通过' },
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择审核状态' }
                ]
              },
            }, {
              type: EditType.Select,
              label: '状态',
              key: 'status',
              options: [
                { value: 1, label: '正常' },
                { value: 2, label: '不正常' },
              ],
              config: {
                rules: [
                  { required: true, message: '请选择状态' }
                ]
              },
            },
          ]
        }
      }
    })()
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    const { edit, remove, resetPwd, resetPayPwd, editUserinfo } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.Select,
          label: '商户行业类型',
          id: 'bankType',
          dataSource: formatParentIdOptions({
            options: this.props.industryTypeOptions,
            hasDefaultOption: false,
            valueKey: 'value'
          })
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime',
        }, {
          type: SearchType.String,
          label: '公司名称',
          id: 'merName',
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '公司名称',
        dataIndex: 'merName',
        key: 'merName',
      }, {
        title: '企业法人',
        dataIndex: 'merLegalPerson',
        key: 'merLegalPerson',
      }, {
        title: '公司编码',
        dataIndex: 'merCode',
        key: 'merCode',
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => (value == 1 ? '正常' : '不正常')
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item"> 删除</Button>
            </Popconfirm>
            <Button className="action-item" type="primary" onClick={() => { resetPwd(record, index) }}>重置登录密码</Button>
            <Button className="action-item" type="primary" onClick={() => { resetPayPwd(record, index) }}>重置支付密码</Button>
            <Button type="primary" className="action-item" onClick={() => { editUserinfo(record, index) }}>修改用户信息</Button>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = this.Util.getNewItemFormItem()
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { search, clearSearch, add, removeItems, save, cancel, changePage, editItems } = this.Action
    return (
      <div className="file-manage">
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
          className="file-manage-modal"
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    industryTypeOptions: hasAttr(state.index.dictList.filter((item, index) => item.value === 'IndustryType'), [0, 'items']) || [],
  }
}
export default connect(mapStateToProps)(FileManage)