import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
import './index.less'

const loadMerchantAudit = (cd) => {
  return import('./merchantAudit.js')
}
const loadFileManage = (cd) => {
    return import('./fileManage')
}
const MerchantAudit = getComponent(loadMerchantAudit)
const FileManage  = getComponent(loadFileManage)
export default class BusinessManage extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/businessManage"
          exact render={() => <Redirect to="/businessManage/merchantAudit" />}
        />
        <Route path='/businessManage/merchantAudit' render={(props) => <MerchantAudit {...props} />} />
        <Route path='/businessManage/fileManage' render={(props) => <FileManage {...props} />}  />
       </Switch>
    )
  }
}