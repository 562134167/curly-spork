import React, { Component } from 'react'
// import moment from 'moment'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
const addTitle = '新建数据字典',
  editTitle = '编辑数据字典',
  initGetParams = {
    pageIndex: 1,
  },
  newItem = {
    num: 1,
  }

export default class Dict extends Component {
  constructor(props) {
    super(props)
   
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch('/system/dict/paging', params).then(res => {
        const { models, totalModels, totalPages } = res
        const dataSource = formatData(models)
        this.setState({
          dataSource,
          totalModels,
          totalPages,
          current: params.pageIndex
        })
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch('/system/dict/add', params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch('/system/dict/remove', params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch('/system/dict/removelist', params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch('/system/dict/update', params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch('/system/dict/updatelist', params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 获取父级ID
    getList: (id) => {
      return getFetch('/system/dict/getlist').then(res => {
        const { models } = res
        this.setState({
          parentIdOptions: models,
          editId: id
        })
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.Request.getList(null).then(res => {
        this.setState({
          modalVis: true,
          modal: this.newItem,
          editId: null,
          title: addTitle
        })
      })

    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
    // 点击修改按钮
    edit: (record, index) => {
      this.Request.getList(record.id).then(res => {
        let modal = {}
        const obj = formateEditData(record, this.formItems)
        for (let i in record) {
          modal[i] = {
            value: obj[i]
          }
        }
        this.setState({
          editId: obj.id,
          modalVis: true,
          modal: modal,
          title: editTitle
        })
      })

    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            edit({
              ...dataSource[i],
              ...values,
            })
            break;
          }
        }
      } else {
        // 新增状态下的保存
        add(values)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    }
  }
  Util = {
    formatOptions: (options) => {
      const option = {
        label: '无',
        value: 0
      }
      options.push(option)
      return options
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: formatData([]),
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      totalPages: null,
      getDataParams: {},
      parentIdOptions: []
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '上级值（英文字母）',
          id: 'value',
          type: SearchType.String,
        }, {
          label: '上级名称（中文）',
          id: 'name',
          type: SearchType.String,
        },
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '上级数据字典',
        dataIndex: 'pid',
        key: 'pid',
        render: (id) => {
          const currentOption = this.state.parentIdOptions.filter(option => option.id === id)[0]
          if (currentOption) {
            return currentOption.name
          }
          return '无';
        }
      }, {
        title: '键',
        dataIndex: 'name',
        key: 'name',
      }, {
        title: '值',
        dataIndex: 'value',
        key: 'value',
      }, {
        title: '备注',
        dataIndex: 'tips',
        key: 'tips',
      }, {
        title: '排序',
        dataIndex: 'num',
        key: 'num',
        config: {
          initialValue: 1
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item"> 删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.Select,
        label: '上级数据字典',
        key: 'pid',
        isNum: true,
        options: this.Util.formatOptions(this.state.parentIdOptions),
        config: {
          initialValue: '0'
        }
      }, {
        type: EditType.InputStr,
        label: '键',
        key: 'name',
        config: {
          rules: [
            { message: '请输入文本', type: 'string', require: true },
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '值',
        key: 'value',
        config: {
          rules: [
            { message: '请输入文本', require: true },
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '备注',
        key: 'tips'
      }, {
        type: EditType.InputNum,
        label: '排序',
        key: 'num',
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, search, clearSearch, removeItems, save, cancel, changePage, editItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: true },
            { label: '批量禁用', value: false }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
    this.Request.getList()
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, parentIdOptions } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    if (nextState.parentIdOptions !== parentIdOptions) {
      const item = this.formItems.filter(formItem => formItem.key === 'pid')[0]
      item.options = formatParentIdOptions({ options: nextState.parentIdOptions, id: nextState.editId })
    }
  }
}