/*
 * @Author: miccy 
 * @Date: 2017-12-19 15:45:50 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-03-22 14:59:42
 * app版本控制
 */
import React, { Component } from 'react'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
import UrlItem from './component/UrlItem'
const addTitle = '新建版本控制',
  editTitle = '编辑版本控制',
  initGetParams = {
    pageIndex: 1,
  },
  newItem = {
    status: 1,
    type: 1
  }
const pagingUrl = '/system/appupdateinfo/paging', //获取列表
  addUrl = '/system/appupdateinfo/add', //添加
  updateUrl = '/system/appupdateinfo/update', //修改
  updatePropertyUrl = '/system/appupdateinfo/updateproperty', //批量修改
  removeUrl = '/system/appupdateinfo/remove', //删除
  removeItemsUrl = '/system/appupdateinfo/removelist' //批量删除
class VersionControl extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeItemsUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle,
        fileList: []
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems, this.Util.handleEditData)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }

      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            const temp = this.Util.handleChangedData({ ...dataSource[i], ...values })
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = this.Util.handleChangedData(values);
        add(temp)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
  }
  // 方法对象
  Util = {
    getFileList: (url) => {
      // 将获得的url转换成Upload要求的数据格式
      const tempArr = url.split(',')
      const fileList = []
      for (let i in tempArr) {
        fileList.push({
          uid: new Date().getTime() + i,
          status: 'done',
          url: tempArr[i],
          response: tempArr[i],
          name: url
        })
      }
      return fileList
    },
    getUrl: (fileList) => {
      const tempArr = []
      for (let i in fileList) {
        tempArr.push(fileList[i].response)
      }
      return tempArr.join(',')
    },
    // 处理传入表单的编辑内容的key、value以匹配组件的格式要求
    handleEditData: (obj) => {
      const { getFileList } = this.Util
      if (is.object(obj)) {
        if (obj.type == 1) {
          obj.url = (obj.url && obj.url.trim() && getFileList(obj.url.trim())) || []
        }
      }
      return obj
    },
    //处理表单的保存内容的key、value以匹配后台的格式
    handleChangedData: (obj) => {
      if (is.object(obj)) {
        if (is.array(obj.url)) {
          obj.url = this.Util.getUrl(obj.url)
        }
      }
      return obj
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }// 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '安装包版本号',
          id: 'keyword',
          type: SearchType.String,
        },
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '类型',
        dataIndex: 'type',
        key: 'type',
        render: value => value == 1 ? '安卓' : 'iOS'
      }, {
        title: '版本号',
        dataIndex: 'version',
        key: 'version',
      }, {
        title: '版本迭代数',
        dataIndex: 'num',
        key: 'num',
      }, {
        title: '是否强制更新',
        dataIndex: 'isForce',
        key: 'isForce',
        render: value => value == 1 ? '是' : '否'
      }, {
        title: '更新信息',
        dataIndex: 'desc',
        key: 'desc',
        width: 300
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.Select,
        label: '类型',
        key: 'type',
        itemConfig: {
          options: [
            { label: '安卓', value: 1 },
            { label: 'iOS', value: 2 },
          ]
        },
        config: {
          rules: [{ required: true, message: '请选择版本类型' }]
        },
        isSelectNum: true
      }, {
        type: EditType.InputStr,
        label: '版本号',
        key: 'version',
        config: {
          rules: [
            { required: true, message: '请输入版本号' }
          ]
        },
      }, {
        type: EditType.Textarea,
        label: '更新信息',
        key: 'desc',
        config: {
          rules: [
            { required: true, message: '请输入更新信息' }
          ]
        },
      }, {
        render: UrlItem,
        label: '安装包',
        key: 'url',
        config: {
          rules: [
            { required: true, message: '请上传安装包或填写安装包链接！' }
          ]
        }
      }, {
        type: EditType.Switch,
        label: '是否强制更新',
        key: 'isForce',
        isSwitchNum: true,
        config: {
          valuePropName: 'checked'
        }
      }, {
        type: EditType.InputNum,
        label: '版本迭代数',
        key: 'num',
        config: {
          rules: [
            { required: true, message: '请输入版本迭代数' }
          ]
        },
      }, {
        type: EditType.Select,
        label: '状态',
        key: 'status',
        options: [
          { value: 1, label: '正常' },
          { value: 0, label: '不正常' },
        ],
        config: {
          rules: [
            { required: true, message: '请选择状态' }
          ]
        },
      },
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, search, clearSearch, save, cancel, changePage, removeItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default VersionControl