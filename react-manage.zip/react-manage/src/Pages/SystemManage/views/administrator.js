import React, { Component } from 'react'
import moment from 'moment'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Icon, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
import './index.less'
const addTitle = '新建管理员',
  editTitle = '编辑管理员',
  initGetParams = {
    pageIndex: 1,
  },
  newItem = {}

export default class Administrator extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch('/system/administrator/paging', params).then(res => {
        const { models, totalModels } = res
        const dataSource = formatData(models)
        this.setState({
          dataSource,
          totalModels,
          current: params.pageIndex
        })
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch('/system/administrator/add', params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch('/system/administrator/remove', params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch('/system/administrator/removelist', params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch('/system/administrator/update', params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch('/system/administrator/updateproperty', params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle
      })
    },
    // 删
    remove: (id) => {
      const { dataSource, selectedRowKeys } = this.state
      this.Request.delete({ id })

    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in record) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...value }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId == 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            edit({
              ...dataSource[i],
              ...values,
            })
            break;
          }
        }
      } else {
        // 新增状态下的保存
        add(values)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    const { get } = this.Request
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }// 搜索面板元数据
    this.metadata = {
      orders: [
        { value: 'num', label: '排序号' },
      ],
      conditions: [
        {
          label: '部门', id: 'name', type: SearchType.Boolean
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '账户',
        dataIndex: 'account',
        key: 'account',
      }, {
        title: '姓名',
        dataIndex: 'name',
        key: 'name',
      },
      {
        title: '创建时间',
        dataIndex: 'createtime',
        key: 'createtime',
      }, {
        title: '生日',
        dataIndex: 'birthday',
        key: 'birthday',
      }, {
        title: '邮箱',
        dataIndex: 'email',
        key: 'email',
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: (status, record, index) => (
          <span>{status ? '正常' : '不正常'}</span>
        )
      }, {
        title: '性别',
        dataIndex: 'sex',
        key: 'sex',
        render: (sex, record, index) => {
          if (sex == 1) {
            return <span>男</span>
          } else if (sex == 2) {
            return <span>女</span>
          } else {
            return <span>未知</span>
          }
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger"> 删除</Button>
            </Popconfirm>
            <Button type="primary" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '账户',
        key: 'account',
        config: {
          rules: [
            { required: true, message: '请输入账户名', type: 'string' },
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '姓名',
        key: 'name',
        config: {
          rules: [
            { required: true, message: '请输入姓名', type: 'string' },
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '手机号码',
        key: 'phone',
        config: {
          rules: [
            {
              pattern: /^1\d{10}$/gi, message: '手机号码格式错误', transform(value) {
                return Number(value);
              }
            },
            { required: true, message: '请输入手机号码' },
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '密码',
        key: 'password',
        config: {
          rules: [
            { required: true, message: '请输入密码', type: 'string' },
            { min: 6, message: '密码不得少于6位' }
          ]
        },
        itemConfig: {
          type: 'password'
        }
      }, {
        type: EditType.DatePicker,
        label: '创建日期',
        key: 'createtime',
        itemConfig: { disabled: true }
      },
      {
        type: EditType.Select,
        label: '性别',
        key: 'sex',
        options: [
          { value: 1, label: '男' },
          { value: 2, label: '女' }
        ],
        isNum: true
      }, {
        type: EditType.DatePicker,
        label: '生日',
        key: 'birthday'
      }, {
        type: EditType.InputStr,
        label: '邮箱',
        key: 'email',
        config: {
          rules: [
            { pattern: /^(\w)+(\.\w+)*@(\w)+((\.\w{2,3}){1,3})$/, message: '邮箱格式错误', type: 'string' },
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '简称',
        key: 'simplename',
        config: {
          rules: [
            { required: true, message: '请输入简称', type: 'string' },
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '提示',
        key: 'tips',
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, totalPages } = this.state
    const { add, removeItems, search, clearSearch, save, cancel, changePage, editItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    // 获得初始化数据
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, selectedRowKeys } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}