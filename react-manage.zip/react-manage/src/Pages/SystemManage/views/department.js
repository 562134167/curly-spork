import React, { Component } from 'react'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
const addTitle = '新建部门',
  editTitle = '编辑部门',
  initGetParams = {
    pageIndex: 1,
  },
  newItem = {
    num: 1,
    pid: 0
  }

const pagingUrl = '/system/department/paging',
  addUrl = '/system/department/add',
  updateUrl = '/system/department/update',
  removeUrl = '/system/department/remove',
  removeListUrl = '/system/department/removelist',
  updatePropertyUrl = '/system/department/updateproperty',
  getListUrl = '/system/department/getlist';
export default class HelpPay extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        const { models, totalModels } = res
        const dataSource = formatData(models)
        this.setState({
          dataSource,
          totalModels,
          current: params.pageIndex
        })
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeListUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    getList: (id) => {
      return getFetch(getListUrl).then(res => {
        this.setState({
          parentIdOptions: res.models,
          editId: id
        })
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.Request.getList(null).then(res => {
        this.setState({
          modalVis: true,
          modal: this.newItem,
          title: addTitle,
        })
      })

    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
    // 点击修改按钮
    edit: (record, index) => {
      this.Request.getList(record.id).then(res => {
        let modal = {}
        const obj = formateEditData(record, this.formItems)
        for (let i in record) {
          modal[i] = {
            value: obj[i]
          }
        }
        this.setState({
          modalVis: true,
          modal: modal,
          title: editTitle
        })
      })

    },
    // 查
    search: (value) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...value }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            edit({
              ...dataSource[i],
              ...values,
            })
            break;
          }
        }
      } else {
        // 新增状态下的保存
        add(values)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      parentIdOptions: []
    }
    // 表头设置
    this.columns = [
      {
        title: '名称',
        dataIndex: 'name',
        key: 'name',
      }, {
        title: '排序',
        dataIndex: 'num',
        key: 'num',
      }, {
        title: '提示',
        dataIndex: 'tips',
        key: 'tips'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item"> 删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '名称',
        key: 'name',
        config: {
          rules: [
            { required: true, message: '请输入名称', type: 'string' },
          ]
        }
      }, {
        type: EditType.InputNum,
        label: '排序',
        key: 'num',
        config: {
          rules: [
            { required: true, message: '请输入排序', type: 'number' },
          ]
        }
      }, {
        type: EditType.Select,
        label: '父部门',
        key: 'pid',
        options: formatParentIdOptions({ options: this.state.parentIdOptions })
      }, {
        type: EditType.InputStr,
        label: '提示',
        key: 'tips',
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }

  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, removeItems, save, cancel, changePage, editItems } = this.Action
    return (
      <div>
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
    this.Request.getList()
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, parentIdOptions } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    if (nextState.parentIdOptions !== parentIdOptions) {
      const item = this.formItems.filter(formItem => formItem.key === 'pid')[0]
      item.options = formatParentIdOptions({ options: nextState.parentIdOptions, id: nextState.editId })
    }

  }
}