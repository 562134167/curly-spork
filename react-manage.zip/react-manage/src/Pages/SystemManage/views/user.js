import React, { Component } from 'react'
import moment from 'moment'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
import './index.less'
const addTitle = '新建用户',
  editTitle = '编辑用户',
  initGetParams = {
    pageIndex: 1,
  },
  newItem = {
    status: 1
  }
const pagingUrl = '/system/user/paging',
  addUrl = '/system/user/add',
  updateUrl = '/system/user/update',
  removeUrl = '/system/user/remove',
  removeListUrl = '/system/user/removelist',
  updatePropertyUrl = '/system/user/updateproperty',
  getListUrl = '/system/role/getlist',
  resetPwdUrl = '/system/user/resetpassword',
  resetPayPwdUrl = '/system/user/resetpaypassword'
export default class User extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        const { models, totalModels } = res
        const dataSource = formatData(models)
        this.setState({
          dataSource,
          totalModels,
          current: params.pageIndex
        })
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeListUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    getList: (id) => {
      return getFetch(getListUrl).then(res => {
        this.setState({
          roleOptions: res.models
        })
      })
    },
    resetPwd: (params) => {
      return fetch(resetPwdUrl, params).then(res => {
        if (res.status == 0) {
          message.success('重置密码成功')
        }
        return res
      })
    },
    resetPayPwd: (params) => {
      return fetch(resetPayPwdUrl, params).then(res => {
        if (res.status == 0) {
          message.success('重置支付密码成功')
        }
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle
      })
    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in record) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...value }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            edit({
              ...dataSource[i],
              ...values,
            })
            break;
          }
        }
      } else {
        // 新增状态下的保存
        add(values)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    },
    // 重置密码
    reset: (record, index) => {
      this.Request.resetPwd({ id: record.id })
    },
    // 重置支付密码
    resetPay: (record, index) => {
      this.Request.resetPayPwd({ id: record.id })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove, reset, resetPay } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      roleOptions: []
    }
    // 表头设置
    this.columns = [
      {
        title: '用户名',
        dataIndex: 'account',
        key: 'account',
      }, {
        title: '昵称',
        dataIndex: 'name',
        key: 'name',
      }, {
        title: '生日',
        dataIndex: 'birthday',
        key: 'birthday',
        render: value => moment(value).format('YYYY-MM-DD')
      }, {
        title: '性别',
        dataIndex: 'sex',
        key: 'sex',
        render: (sex, record, index) => {
          if (sex == 1) {
            return <span>男</span>
          } else {
            return <span>女</span>
          }
        }
      }, {
        title: '手机号码',
        dataIndex: 'phone',
        key: 'phone'
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: (status, record, index) => (
          <span>{status ? '正常' : '不正常'}</span>
        )
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button className="action-item" type="danger"> 删除</Button>
            </Popconfirm>
            <Button className="action-item" type="primary" onClick={() => { edit(record, index) }}>修改</Button>
            <Button className="action-item" type="primary" onClick={() => { reset(record, index) }}>重置密码</Button>
            <Button className="action-item" type="primary" onClick={() => { resetPay(record, index) }}>重置支付密码</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '用户名',
        key: 'account',
        config: {
          rules: [
            { required: true, message: '请输入用户名', type: 'string' },
          ]
        }
      }, {
        type: EditType.Select,
        label: '所属角色',
        key: 'roleId',
        config: {
          rules: [
            { required: true, message: '请选择用户所属角色' }
          ]
        },
        options: this.state.roleOptions
      }, {
        type: EditType.InputStr,
        label: '昵称',
        key: 'name',
        config: {
          rules: [
            { required: true, message: '请输入昵称', type: 'string' },
          ]
        }
      }, {
        type: EditType.DatePicker,
        label: '生日',
        key: 'birthday',
        config: {
          rules: [
            { required: true, message: '请选择生日日期' },
          ]
        }
      }, {
        type: EditType.Select,
        label: '性别',
        key: 'sex',
        options: [
          { value: 1, label: '男' },
          { value: 2, label: '女' }
        ],
        config: {
          rules: [
            { required: true, message: '请选择性别' },
          ]
        },
        isNum: true
      }, {
        type: EditType.InputStr,
        label: '手机号码',
        key: 'phone',
        config: {
          rules: [
            {
              pattern: /^1\d{10}$/gi, message: '手机号码格式错误', transform(value) {
                return Number(value);
              }
            },
            { required: true, message: '请输入手机号码' },
          ]
        }
      }, {
        type: EditType.Select,
        label: '状态',
        key: 'status',
        options: [
          { value: 1, label: '正常' },
          { value: 0, label: '不正常' }
        ],
        isNum: true
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, removeItems, save, cancel, changePage, editItems } = this.Action
    return (
      <div>
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    // 获得初始化数据
    this.setState({
      getDataParams: initGetParams
    })
    this.Request.getList()
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, roleOptions } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    if (nextState.roleOptions !== roleOptions) {
      const item = this.formItems.filter(formItem => formItem.key === 'roleId')[0]
      item.options = formatParentIdOptions({ options: nextState.roleOptions, hasDefaultOption: false })
    }
  }
}