import React, { PureComponent } from 'react'
import is from 'is_js'
import { Tree } from 'antd';
import { hasAttr } from '../../../../Util/index'
import { toNumber, toString } from '../../../../Util/reactUtil'
const TreeNode = Tree.TreeNode;
let parentIds = [];
export default class MenuTree extends PureComponent {
  constructor(props) {
    super(props)
    this.Action.handleCheck = this.Action.handleCheck.bind(this)
    const value = props.value || []
    this.state = {
      value: this.Util.formatCheckedKeys(value)
    }
  }
  Action = {
    handleCheck: (checkedKeys, info) => {
      if (!('value' in this.props)) {
        this.setState({
          value: checkedKeys
        })
      }
      this.Action.triggerChange(checkedKeys)
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(this.Util.formatChangedValue(changedValue))
      }
    }
  }
  Util = {
    getParentKeys: () => {
      parentIds = [];
      const menu = hasAttr(this.props, ['item', 'itemConfig', 'options']) || []
      menu.forEach(parent => {
        const items = parent.items || []
        if (items && items.length) {
          parentIds.push(parent.id);
        }
      })
    },
    formatCheckedKeys: (arr) => {
      if (is.array(arr)) {
        const temp = []
        arr.forEach(item => {
          if (parentIds.indexOf(item) === -1) {
            temp.push(toString(item));
          }
        })
        return temp
      }
      return arr

    },
    formatChangedValue: (arr) => {
      if (is.array(arr)) {
        const temp = []
        arr.forEach(item => temp.push(toNumber(item)))
        return temp
      }
      return arr
    }
  }
  RenderFunc = {
    renderNode: (items) => {
      if (items && items.length) {
        return items.map((item, index) => (
          <TreeNode title={item.name} key={item.id}>
            {this.RenderFunc.renderNode(item.items)}
          </TreeNode>
        ))

      }
      return null
    }
  }

  componentDidMount() {
    this.Util.getParentKeys()
  }

  componentWillReceiveProps(nextProps) {
    const { formatCheckedKeys } = this.Util
    if ('value' in nextProps) {
      this.setState({
        value: formatCheckedKeys(nextProps.value)
      })
    }
  }

  render() {
    const { handleCheck } = this.Action
    const { value } = this.state
    const options = hasAttr(this.props, ['item', 'itemConfig', 'options']) || []
    this.Util.getParentKeys();
    return (
      <Tree
        checkable
        onCheck={handleCheck}
        checkedKeys={value}
        defaultExpandAll={true}
      >
        {/*{this.RenderFunc.renderTree(options)}*/}
        {
          options.map((option, index) => (
            <TreeNode title={option.name} key={option.id}>
              {this.RenderFunc.renderNode(option.items)}
            </TreeNode>
          ))
        }
      </Tree>
    );
  }
}
