import React, { PureComponent } from 'react'
import is from 'is_js'
import { Upload, Input, Button, Icon } from 'antd';
const uploadFileUrl = '/system/file/upload' //上传图片

export default class UrlItem extends PureComponent {
  constructor(props) {
    super(props)
    // this.Action.handleCheck = this.Action.handleCheck.bind(this)
    this.state = {
      fileList: [],
      inputValue: ''
    }
  }
  Action = {
    handleInput: (e) => {
      const value = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggetChange(value)
    },
    handleUpload: (info) => {
      let fileList = info.fileList;
      this.Action.triggetChange(fileList)
    },
    triggetChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(changedValue)
      }
    }
  }
  componentDidMount() {
    if ('value' in this.props) {
      if (this.props.form.getFieldValue('type') == 2) {
        this.setState({
          inputValue: is.undefined(this.props.value) || is.array(this.props.value) ? '' : this.props.value
        })
      } else {
        this.setState({
          fileList: this.props.value && is.array(this.props.value) ? this.props.value : []
        })
      }
    }
  }

  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      if (nextProps.form.getFieldValue('type') == 2) {
        this.setState({
          inputValue: is.undefined(nextProps.value) || is.array(nextProps.value) ? '' : nextProps.value
        })
      } else {
        this.setState({
          fileList: nextProps.value && is.array(nextProps.value) ? nextProps.value : []
        })
      }

    }
  }

  render() {
    const { handleUpload, handleInput } = this.Action
    const { inputValue, fileList } = this.state
    const { form } = this.props
    return (
      <div>
        {form.getFieldValue('type') == 2 ?
          (<Input value={inputValue} onChange={handleInput} />) : (<Upload
            withCredentials={true}
            name="files"
            accept=".apk"
            action={window.baseUrl + uploadFileUrl}
            fileList={fileList}
            onChange={handleUpload}>
            {fileList && fileList.length ? null : (<Button>
              <Icon type="upload" /> 上传
          </Button>)}
          </Upload>)
        }

      </div>
    );
  }
}
