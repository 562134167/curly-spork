import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
const loadRole = (cb) => {
  return import('./role.js')
}
const loadDepartment = (cb) => {
  return import('./department.js')
}
const loadUser = (cb) => {
  return import('./user.js')
}
const loadMenu = (cb) => {
  return import('./menu.js')
}
const loadDict = (cb) => {
  return import('./dict.js')
}
const loadVersionControl = (cb) => {
  return import('./versionControl.js')
}
const Role = getComponent(loadRole)
const Department = getComponent(loadDepartment)
const User = getComponent(loadUser)
const Menu = getComponent(loadMenu)
const Dict = getComponent(loadDict)
const VersionControl = getComponent(loadVersionControl)
export default class SystemManage extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/system"
          exact render={() => <Redirect to="/system/role" />}
        />
        <Route path="/system/menu" render={(props) => <Menu {...props} />} />
        <Route path="/system/role" render={(props) => <Role {...props} />} />
        <Route path="/system/department" render={(props) => <Department {...props} />} />
        <Route path="/system/user" render={(props) => <User {...props} />} />
        <Route path="/system/dict" render={(props) => <Dict {...props} />} />
        <Route path="/system/versionControl" render={(props) => <VersionControl {...props} />} />
      </Switch>
    )
  }
}