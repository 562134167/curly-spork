import React, { Component } from 'react'
// import is from 'is_js'
// import moment from 'moment'
// import SearchPanel from '../../../Common/searchPanel'
// import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Icon, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
const addTitle = '新建菜单',
  editTitle = '编辑菜单',
  addCodeTitle = '用代码新建菜单',
  initGetParams = {
    pageIndex: 1,
  },
  newItem = {
    status: 1,
    num: 1,
    pid: 0
  }
const pagingUrl = '/system/menu/paging',
  addUrl = '/system/menu/add',
  updateUrl = '/system/menu/update',
  removeUrl = '/system/menu/remove',
  removeListUrl = '/system/menu/removelist',
  updatePropertyUrl = '/system/menu/updateproperty',
  getListUrl = '/system/menu/getlist'
export default class Menu extends Component {
  constructor(props) {
    super(props)
    this.Action.save = this.Action.save.bind(this);
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        const { models, totalModels } = res
        const dataSource = formatData(models)
        this.setState({
          dataSource,
          totalModels,
          current: params.pageIndex
        })
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeListUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    getList: (id) => {
      return getFetch(getListUrl).then(res => {
        this.setState({
          parentIdOptions: res.models,
          editId: id || null
        })
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.formItems = this.Util.getFormItem()
      this.Request.getList(null).then(res => {
        this.setState({
          modalVis: true,
          modal: this.newItem,
          title: addTitle,
        })
      })
    },
    addByCode: () => {
      this.formItems = this.Util.getCodeFormItem()
      this.setState({
        modalVis: true,
        modal: {},
        title: addCodeTitle,
        editId: null
      })
    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
    // 点击修改按钮
    edit: (record, index) => {
      this.formItems = this.Util.getFormItem()
      this.Request.getList(record.id).then(res => {
        let modal = {}
        const obj = formateEditData(record, this.formItems)
        for (let i in record) {
          modal[i] = {
            value: obj[i]
          }
        }
        this.setState({
          // editId: obj.id,
          modalVis: true,
          modal: modal,
          title: editTitle
        })
      })
    },
    // 查询
    search: (value) => {
    	const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...value }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId, title } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            edit({
              ...dataSource[i],
              ...values,
            })
            break;
          }
        }
      } else {
        if (title == addTitle) {
          // 新增状态下的保存
          add(values)
        } else {
          eval(values.code)
        }

      }
    },
    evalCode: (params) => {
      this.Request.add(params)
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    }
  }

  Util = {
    getFormItem: () => {
      return [
        {
          type: EditType.InputStr,
          label: '菜单编号',
          key: 'code',
          config: {
            rules: [
              { required: true, message: '请输入菜单编号', type: 'string' },
            ]
          }
        }, {
          type: EditType.InputStr,
          label: 'URL地址',
          key: 'url',
          config: {
            rules: [
              { required: true, message: '请输入URL地址', type: 'string' },
            ]
          }
        }, {
          type: EditType.InputStr,
          label: 'URI地址',
          key: 'uri'
        }, {
          type: EditType.InputStr,
          label: '菜单名称',
          key: 'name',
          config: {
            rules: [
              { required: true, message: '请输入菜单名称' }
            ]
          }
        }, {
          type: EditType.InputStr,
          label: '菜单图标',
          key: 'icon',
          itemConfig: {
            placeholder: '请参照ant design的icon名进行填写'
          }
        }, {
          type: EditType.Select,
          label: '是否菜单',
          key: 'isMenu',
          config: {
            rules: [
              { required: true, message: '请选择是否菜单' },
            ],
          },
          options: [
            { label: '是', value: 1 },
            { label: '否', value: 0 }
          ],
          isNum: true
        }, {
          type: EditType.InputNum,
          label: '菜单排序号',
          key: 'num',
          config: {
            rules: [
              { required: true, message: '请输入菜单排序号' }
            ]
          }
        }, {
          type: EditType.Select,
          label: '父菜单',
          key: 'pid',
          isNum: true,
          options: formatParentIdOptions({ options: this.state.parentDeptIdOptions })
        }, {
          type: EditType.Select,
          label: '状态',
          key: 'status',
          options: [
            { label: '正常', value: 1 },
            { label: '不正常', value: 0 }
          ]
        }, {
          type: EditType.InputStr,
          label: '备注',
          key: 'tips'
        }
      ]
    },
    getCodeFormItem: () => {
      return [
        {
          type: EditType.InputStr,
          label: '代码',
          key: 'code'
        }
      ]
    }
  }

  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      parentIdOptions: []
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '菜单名称',
          id: 'name',
          type: SearchType.String,
        },
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '记录ID',
        dataIndex: 'id',
        key: 'id'
      },
      {
        title: '菜单编号',
        dataIndex: 'code',
        key: 'code',
      }, {
        title: '菜单图标',
        dataIndex: 'icon',
        key: 'icon',
        render: icon => <Icon type={icon} />,
      }, {
        title: 'URL地址',
        dataIndex: 'url',
        key: 'url'
      }, {
        title: 'URI地址',
        dataIndex: 'uri',
        key: 'uri'
      }, {
        title: '菜单名称',
        dataIndex: 'name',
        key: 'name'
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: status => <span>{status ? '正常' : '不正常'}</span>,
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item"> 删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = this.Util.getFormItem()
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, search, clearSearch, removeItems, save, cancel, changePage, editItems, addByCode } = this.Action
    return (
      <div>
      	<SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Button type="primary" onClick={addByCode} className="action-item">用代码新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.Request.getList()
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, parentIdOptions } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    if (nextState.parentIdOptions !== parentIdOptions) {
      const item = this.formItems.filter(formItem => formItem.key === 'pid')[0]
      item.options = formatParentIdOptions({ options: nextState.parentIdOptions, id: nextState.editId })
    }
  }
}