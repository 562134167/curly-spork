/*
 * @Author: miccy 
 * @Date: 2018-03-16 11:07:07 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-18 17:53:43
 * 积分申购
 */

import React, {
    Component
} from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import {
    Table,
    message,
    Card, Button
} from 'antd'
import {
    handleEndTime,
    handleStartTime,
    toMoney
} from '../../../Util/reactUtil'
import { arrayToObject, getStore } from '../../../Util/index'
import { getFetch } from '../../../Config/request'
import {
    requestGet
} from '../../../Util/Request'
import {
    actionChangePage,
    initGetParams,
    actionOnShowSizeChange,
    actionShowTotal,
    actionSearch,
    actionClearSearch
} from '../../../Util/Action'

const pagingUrl = '/system/integral/pagingbuyenergy', //获取列表
    getCategoryListUrl = '/system/enums/goodscat',
    getChannelListUrl = '/common/getchannellist',
    getRefundStatusListUrl = '/system/enums/orderrefundstatus',//获取订单退款状态列表
    getOrderStatusListUrl = '/system/enums/orderstatus',//获取订单状态列表
    callbackUrl = '/system/integral/getcallback';

class Purchase extends Component {
    constructor(props) {
        super(props)

        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({
                params,
                pagingUrl,
                context: this
            }).then(res => {
                if (res && res.status == 0) {
                    const { categroyListOptions, channelListOptions } = this.state;
                    !categroyListOptions.length && this.Request.getCategoryList();
                    !channelListOptions.length && this.Request.getChannelList();
                    !this.state.refundStatusOptions.length && this.Request.getRefundStatusList();
                    !this.state.orderStatusOptions.length && this.Request.getOrderStatusList();
                }
            })
        },
        getCategoryList: (params) => {
            getFetch(getCategoryListUrl, params).then(res => {
                if (is.array(res)) {
                    const { categroyListOptions } = this.state
                    res.forEach(item => {
                        categroyListOptions.push({
                            label: item.name,
                            value: item.value
                        })
                    })
                    this.setState({
                        categroyEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
                        categroyListOptions
                    })
                }
            })
        },
        getRefundStatusList: (params) => {
            getFetch(getRefundStatusListUrl).then(res => {
                if (is.array(res)) {
                    const { refundStatusOptions } = this.state
                    res.forEach(item => {
                        refundStatusOptions.push({
                            label: item.name,
                            value: item.value
                        })
                    })
                    this.setState({
                        refundStatusEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
                        refundStatusOptions
                    })
                }
            })
        },
        getOrderStatusList: (params) => {
            getFetch(getOrderStatusListUrl).then(res => {
                if (is.array(res)) {
                    const { orderStatusOptions } = this.state
                    res.forEach(item => {
                        orderStatusOptions.push({
                            label: item.name,
                            value: item.value
                        })
                    })
                    this.setState({
                        orderStatusEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
                        orderStatusOptions
                    })
                }
            })
        },
        getChannelList: (params) => {
            getFetch(getChannelListUrl).then(res => {
                if (res && res.status == 0) {
                    const { channelListOptions } = this.state
                    res.models.forEach(item => {
                        channelListOptions.push({
                            label: item.remarks,
                            value: item.channelId
                        })
                    })
                    this.setState({
                        channelEnum: arrayToObject({ array: res.models, keyName: 'channelId', valueName: 'remarks' }),
                        channelListOptions
                    })
                }
            })
        },
        callback: () => {
            const { selectedRowKeys } = this.state;
            fetch(callbackUrl, { ids: selectedRowKeys }, undefined, true, 0)
        }
    }

    Util = {
        handleSearchValues: (values) => {
            const queryParams = Object.assign({}, values)
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }
            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }

            delete queryParams.createtime
            return queryParams
        },
        getTotalAmount: (dataSource) => {
            let totalAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (item.totalAmount) {
                    totalAmount += item.totalAmount
                }
            })
            return totalAmount
        },
        getSelectedAmount: (dataSource, selectedRowKeys) => {
            const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
            if (!tempSelectedRowKeys.length) {
                return 0
            }
            const selectedString = tempSelectedRowKeys.join(',')
            let selectedAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (selectedString.indexOf(item.id) > -1 && item.totalAmount) {
                    selectedAmount += item.totalAmount
                }
            })
            return selectedAmount
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        changePage: (page, pageSize) => {
            actionChangePage({
                page,
                pageSize,
                context: this
            })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({
                pageSize,
                context: this
            })
        },
        search: (values) => {
            const tmp = this.Util.handleSearchValues(values);
            if (tmp) {
                actionSearch({
                    value: tmp,
                    context: this
                })
            }
        },
        clearSearch: () => {
            actionClearSearch({
                context: this
            })
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {

        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            totalAmount: 0,
            selectedAmount: 0,
            categroyEnum: {},
            categroyListOptions: [],
            channelListOptions: [],
            channelEnum: {},
            refundStatusOptions: [],
            refundStatusEnum: {},
            orderStatusOptions: [],
            orderStatusEnum: {}
        }

        // 搜索面板元数据
        this.metadata = {
            conditions: [{
                type: SearchType.String,
                label: '手机号码',
                id: 'mobilePhone'
            },
            {
                type: SearchType.String,
                label: '订单号',
                id: 'orderNo'
            },
            {
                type: SearchType.DateRange,
                label: '时间段',
                id: 'createtime'
            }, {
                type: SearchType.Select,
                label: '产品类型',
                id: 'catId',
                dataSource: this.state.categroyListOptions
            }, {
                type: SearchType.Select,
                label: '申购渠道',
                id: 'channelId',
                dataSource: this.state.channelListOptions
            }, {
                type: SearchType.Select,
                label: '订单状态',
                id: 'orderStatus',
                dataSource: this.state.orderStatusOptions
            }, {
                type: SearchType.Select,
                label: '订单退款状态',
                id: 'refundStatus',
                dataSource: this.state.refundStatusOptions
            }
            ]
        }

        // 表头设置
        this.columns = [{
            title: '序号',
            dataIndex: 'index',
            key: 'index',
            fixed: 'left',
            width: 60,
            render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
        }, {
            title: '真实姓名',
            dataIndex: 'realName',
            key: 'realName',
            fixed: 'left',
            width: 100,
        }, {
            title: '手机号',
            dataIndex: 'mobilePhone',
            key: 'mobilePhone',
            fixed: 'left',
            width: 120,
        }, {
            title: '申购渠道',
            dataIndex: 'channelId',
            key: 'channelId',
            render: value => {
                return this.state.channelEnum[value] || '未知';
            }
        }, {
            title: '产品类型',
            dataIndex: 'catId',
            key: 'catId',
            render: value => this.state.categroyEnum[value] || '未知'
        }, {
            title: '充值产品',
            dataIndex: 'productName',
            key: 'productName',
            width: 110,
            // render: value => '区块链能量'
        }, {
            title: '订单总金额',
            dataIndex: 'originalPrice',
            key: 'originalPrice',
            render: value => toMoney(value),
            sorter: (a, b) => a.originalPrice - b.originalPrice
        }, {
            title: '随机立减金额',
            dataIndex: 'discount',
            key: 'discount',
            render: value => {
                let tmp = value && Math.floor(value);
                return toMoney(tmp);
            },
            sorter: (a, b) => a.discount - b.discount
        }, {
            title: '支付金额',
            dataIndex: 'totalAmount',
            key: 'totalAmount',
            render: value => toMoney(value),
            sorter: (a, b) => a.totalAmount - b.totalAmount
        }, {
            title: '充值能量数量',
            dataIndex: 'giveEnergy',
            key: 'giveEnergy',
            render: value => toMoney(value, '')
        }, {
            title: '充值游戏豆数量',
            dataIndex: 'giveBean',
            key: 'giveBean',
            render: value => toMoney(value, '')
        }, {
            title: '订单状态',
            dataIndex: 'orderStatus',
            key: 'orderStatus',
            render: value => this.state.orderStatusEnum[value] || value
        }, {
            title: '订单退款状态',
            dataIndex: 'refundStatus',
            key: 'refundStatus',
            render: value => this.state.refundStatusEnum[value] || value
        }, {
            title: '赠送产品',
            dataIndex: 'giveProduct',
            key: 'giveProduct',
            render: (value, record) => {
                return '区块链积分';
            }
        }, {
            title: '赠送积分数量',
            dataIndex: 'giveIntegral',
            key: 'giveIntegral',
            render: value => toMoney(value, '')
        }, {
            title: '创建时间',
            dataIndex: 'createTime',
            key: 'createTime',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '支付时间',
            dataIndex: 'payTime',
            key: 'payTime',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '订单完成时间',
            dataIndex: 'finishTime',
            key: 'finishTime',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '订单号',
            dataIndex: 'orderNo',
            key: 'orderNo'
        }
        ]


    }
    render() {
        const {
            dataSource,
            current,
            totalModels,
            pageSize,
            selectedRowKeys,
            totalAmount,
            selectedAmount
        } = this.state
        const {
            changePage,
            onShowSizeChange,
            search,
            clearSearch
        } = this.Action
        return (<div>
            <SearchPanel
                metadata={this.metadata}
                onSearch={search}
                onClearSearch={clearSearch}
            />
            <Card>
                <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }} >
                    当前页总金额： {
                        parseFloat(totalAmount / 100).toFixed(2) + '元'
                    }，
                已选中的项的总金额： {
                        parseFloat(selectedAmount / 100).toFixed(2) + '元'
                    } </p>
            </Card>
            {JSON.parse(getStore('user') || "{}").account === 'admin' ? <Card>
                <Button type="primary" disabled={!selectedRowKeys.length} onClick={this.Request.callback}>批量手动回调</Button>
            </Card> : null}

            <Table
                rowSelection={{
                    selectedRowKeys: selectedRowKeys,
                    onChange: (selectedRowKeys, selectedRows) => {
                        this.setState({
                            selectedRowKeys
                        })
                    },
                }}
                scroll={{ x: 2000 }}
                columns={this.columns}
                dataSource={dataSource}
                pagination={{
                    showSizeChanger: true,
                    pageSize,
                    current,
                    total: totalModels,
                    onChange: changePage,
                    onShowSizeChange,
                    showTotal: actionShowTotal,
                    pageSizeOptions: ['15', '50', '200', '500'],
                }}
            />
        </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: {
                ...initGetParams,
                pageSize: this.state.pageSize
            }
        });

    }

    componentWillUpdate(nextProps, nextState) {
        const {
            getDataParams,
            selectedRowKeys,
            dataSource
        } = this.state
        const {
            get
        } = this.Request
        const {
            getSelectedAmount,
            getTotalAmount
        } = this.Util
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
        // 选中的项发生变化时，计算已选中的项的总金额
        if (nextState.selectedRowKeys !== selectedRowKeys) {
            this.setState({
                selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
            })
        }
        // 当前页的数据发生变化时，计算当前页的总金额
        if (nextState.dataSource !== dataSource) {
            this.setState({
                totalAmount: getTotalAmount(nextState.dataSource)
            })
        }
    }
}
export default Purchase