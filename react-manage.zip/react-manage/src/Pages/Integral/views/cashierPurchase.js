/*
 * @Author: miccy 
 * @Date: 2018-03-16 13:45:12 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-11 11:13:41
 * 收银台申购积分
 */

import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Table, message, Card, Button } from 'antd'
import { handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { getFetch } from '../../../Config/request'
import { requestGet } from '../../../Util/Request'
import { arrayToObject } from '../../../Util'
import { actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal, actionSearch, actionClearSearch } from '../../../Util/Action'

import XLSX from 'xlsx';

const pagingUrl = '/system/gateway/getTransferPage', //获取列表
    getTransferStatusUrl = '/system/gateway/getTransferStatusList',//获取转账状态
    getMerchantListUrl = '/system/gateway/getMerchantList',//获取商家列表
    getChannelListUrl = '/common/getchannellist';



class CashierPurchase extends Component {
    constructor(props) {
        super(props)

        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({ params: { ...params, tradeCode: '13004' }, pagingUrl, context: this }).then(res => {
                if (res && res.status == 0) {
                    const { transferStatusOptions, merchantOptions, channelOptions } = this.state
                    !transferStatusOptions.length && this.Request.getTransferStatus();
                    !merchantOptions.length && this.Request.getMerchantList();
                    !channelOptions.length && this.Request.getChannelList();
                }
            })
        },
        getTransferStatus: () => {
            getFetch(getTransferStatusUrl).then(res => {
                if (res && res.status == 0) {
                    const { transferStatusOptions } = this.state
                    res.model.resultList.forEach(item => {
                        transferStatusOptions.push({
                            label: item.value,
                            value: item.key
                        })
                    })
                    this.setState({
                        transferStatusOptions
                    })
                }
            })
        },
        getMerchantList: () => {
            getFetch(getMerchantListUrl).then(res => {
                if (res && res.status == 0) {
                    const { merchantOptions } = this.state
                    res.model.resultList.forEach(item => {
                        merchantOptions.push({
                            label: item.merchantName,
                            value: item.merchantId
                        })
                    })
                    this.setState({
                        merchantOptions
                    })
                }
            })
        },
        getChannelList: (params) => {
            getFetch(getChannelListUrl).then(res => {
                if (res.status == 0) {
                    const { channelOptions } = this.state
                    res.models.forEach(item => {
                        channelOptions.push({
                            label: item.remarks,
                            value: item.channelId
                        })
                    })
                    this.setState({
                        channelEnum: arrayToObject({ array: res.models, keyName: 'channelId', valueName: 'remarks' }),
                        channelOptions
                    })
                }
            })
        }
    }

    Util = {
        handleSearchValues: (values) => {
            const queryParams = Object.assign({}, values)
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }
            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }

            delete queryParams.createtime
            return queryParams
        },
        getTotalAmount: (dataSource) => {
            let totalAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (item.totalAmount) {
                    totalAmount += item.totalAmount
                }
            })
            return totalAmount
        },
        getSelectedAmount: (dataSource, selectedRowKeys) => {
            const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
            if (!tempSelectedRowKeys.length) {
                return 0
            }
            const selectedString = tempSelectedRowKeys.join(',')
            let selectedAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (selectedString.indexOf(item.id) > -1 && item.totalAmount) {
                    selectedAmount += item.totalAmount
                }
            })
            return selectedAmount
        },
        handleExportData: () => {
            // const data = JSON.parse(JSON.stringify(this.state.dataSource));
            const data = [{}];
            for (let i in this.excelFormat) {
                const column = this.excelFormat[i];
                data[0][column.title] = column.title;
                for (let j in this.state.dataSource) {
                    if (!data[j - 0 + 1]) { data[j - 0 + 1] = {}; }
                    const item = this.state.dataSource[j][column.key];
                    if (column.render) {
                        data[j - 0 + 1][column.title] = column.render(item)
                    } else {
                        data[j - 0 + 1][column.title] = item;
                    }
                }
            }
            return data;
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this })
        },
        search: (values) => {
            const tmp = this.Util.handleSearchValues(values);
            if (tmp) {
                actionSearch({ value: tmp, context: this })
            }
        },
        clearSearch: () => {
            actionClearSearch({ context: this })
        },
        downloadFile: () => { // 点击导出按钮
            const data = this.Util.handleExportData();
            this.Action.downloadExl(data, `收银台充值列表-${moment().format('YYYY-MM-DD')}`)
        },
        downloadExl: (json, downName, type) => {  // 导出到excel
            let keyMap = [] // 获取键
            for (let k in json[0]) {
                keyMap.push(k)
            }
            let tmpdata = [] // 用来保存转换好的json
            json.map((v, i) => keyMap.map((k, j) => Object.assign({}, {
                v: v[k],
                position: (j > 25 ? this.getCharCol(j) : String.fromCharCode(65 + j)) + (i + 1)
            }))).reduce((prev, next) => prev.concat(next)).forEach(function (v) {
                tmpdata[v.position] = {
                    v: v.v
                }
            })
            let outputPos = Object.keys(tmpdata)  // 设置区域,比如表格从A1到D10
            let tmpWB = {
                SheetNames: ['收银台充值列表'], // 保存的表标题
                Sheets: {
                    '收银台充值列表': Object.assign({},
                        tmpdata, // 内容
                        {
                            '!ref': outputPos[0] + ':' + outputPos[outputPos.length - 1] // 设置填充区域
                        })
                }
            }
            let tmpDown = new Blob([this.Action.s2ab(XLSX.write(tmpWB,
                { bookType: (type === undefined ? 'xlsx' : type), bookSST: false, type: 'binary' } // 这里的数据是用来定义导出的格式类型
            ))], {
                    type: ''
                })  // 创建二进制对象写入转换好的字节流
            var href = URL.createObjectURL(tmpDown)  // 创建对象超链接
            this.outFile.download = downName + '.xlsx'  // 下载名称
            this.outFile.href = href  // 绑定a标签
            this.outFile.click()  // 模拟点击实现下载
            setTimeout(function () {  // 延时释放
                URL.revokeObjectURL(tmpDown) // 用URL.revokeObjectURL()来释放这个object URL
            }, 100)
        },
        s2ab: (s) => { // 字符串转字符流
            var buf = new ArrayBuffer(s.length)
            var view = new Uint8Array(buf)
            for (var i = 0; i !== s.length; ++i) {
                view[i] = s.charCodeAt(i) & 0xFF
            }
            return buf
        },
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {

        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            totalAmount: 0,
            selectedAmount: 0,
            channelEnum: {},
            transferStatusOptions: [],
            merchantOptions: [],
            channelOptions: []
        }
        this.excelFormat = [
            {
                title: '商户姓名',
                dataIndex: 'toUserName',
                key: 'toUserName'
            }, {
                title: '用户姓名',
                dataIndex: 'fromUserName',
                key: 'fromUserName'
            }, {
                title: '用户手机号',
                dataIndex: 'fromMobilePhone',
                key: 'fromMobilePhone'
            },
            {
                title: '积分',
                dataIndex: 'payIntegral',
                key: 'payIntegral',
                render: value => toMoney(value, '')
            }, {
                title: '兑换金额',
                dataIndex: 'totalAmount',
                key: 'totalAmount',
                render: value => toMoney(value, '')
            }, {
                title: '订单状态',
                dataIndex: 'transferStatusStr',
                key: 'transferStatusStr',
            }, {
                title: '付款渠道',
                dataIndex: 'channelId',
                key: 'channelId',
                render: value => {
                    return this.state.channelEnum[value] || '未知';
                }
            }, {
                title: '创建时间',
                dataIndex: 'createTime',
                key: 'createTime',
                render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
            }, {
                title: '订单描述',
                dataIndex: 'orderNote',
                key: 'orderNote'
            }, {
                title: '商家请求唯一订单号',
                dataIndex: 'orderId',
                key: 'orderId'
            }, {
                title: '聚管家平台订单号',
                dataIndex: 'serialNumber',
                key: 'serialNumber'
            }
        ]
        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone'
                }, {
                    type: SearchType.Select,
                    label: '商户名称',
                    id: 'merchantId',
                    dataSource: this.state.merchantOptions
                }, {
                    type: SearchType.Select,
                    label: '充值渠道',
                    id: 'channelId',
                    dataSource: this.state.channelOptions
                },
                {
                    type: SearchType.String,
                    label: '聚管家平台订单号',
                    id: 'serialNumber'
                }, {
                    type: SearchType.Select,
                    label: '订单状态',
                    id: 'transferStatus',
                    dataSource: this.state.transferStatusOptions
                }, {
                    type: SearchType.DateRange,
                    label: '时间段',
                    id: 'createtime'
                }
            ]
        }

        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            }, {
                title: '商户姓名',
                dataIndex: 'toUserName',
                key: 'toUserName'
            }, {
                title: '用户姓名',
                dataIndex: 'fromUserName',
                key: 'fromUserName'
            }, {
                title: '用户手机号',
                dataIndex: 'fromMobilePhone',
                key: 'fromMobilePhone'
            },
            //  {
            //     title: '产品类型',
            //     dataIndex: '',
            //     key: '',
            //     render: value => {
            //         //todo: return 余额或区块链积分
            //     }
            // }, 
            {
                title: '积分',
                dataIndex: 'payIntegral',
                key: 'payIntegral',
                render: value => toMoney(value, '')
            }, {
                title: '兑换金额',
                dataIndex: 'totalAmount',
                key: 'totalAmount',
                render: value => toMoney(value)
            }, {
                title: '订单状态',
                dataIndex: 'transferStatusStr',
                key: 'transferStatusStr',
            }, {
                title: '付款渠道',
                dataIndex: 'channelId',
                key: 'channelId',
                render: value => {
                    return this.state.channelEnum[value] || '未知';
                }
            }, {
                title: '创建时间',
                dataIndex: 'createTime',
                key: 'createTime',
                render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
            }, {
                title: '订单描述',
                dataIndex: 'orderNote',
                key: 'orderNote'
            }, {
                title: '商家请求唯一订单号',
                dataIndex: 'orderId',
                key: 'orderId'
            }, {
                title: '聚管家平台订单号',
                dataIndex: 'serialNumber',
                key: 'serialNumber'
            }
        ]


    }

    render() {
        const { dataSource, current, totalModels, pageSize, selectedRowKeys, totalAmount, selectedAmount } = this.state
        const { changePage, onShowSizeChange, search, clearSearch, downloadFile } = this.Action
        return (
            <div>
                <Card>
                    <Button onClick={downloadFile}>当前页导出为表格</Button>
                    {/* <a ref={inst => this.outFile = inst}></a> */}
                    <a style={{ width: 0, height: 0 }} ref={(inst) => { this.outFile = inst }}></a>
                </Card>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Card>
                    <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
                        当前页总金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的总金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
                </Card>
                <Table
                    scroll={{ x: 1500 }}
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal,
                        pageSizeOptions: ['15', '50', '200', '500'],
                    }}
                />

            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
        })
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams, selectedRowKeys, dataSource } = this.state
        const { get } = this.Request
        const { getSelectedAmount, getTotalAmount } = this.Util
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
        // 选中的项发生变化时，计算已选中的项的总金额
        if (nextState.selectedRowKeys !== selectedRowKeys) {
            this.setState({
                selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
            })
        }
        // 当前页的数据发生变化时，计算当前页的总金额
        if (nextState.dataSource !== dataSource) {
            this.setState({
                totalAmount: getTotalAmount(nextState.dataSource)
            })
        }
    }
}
export default CashierPurchase



