/*
 * @Author: miccy 
 * @Date: 2018-04-20 16:30:13 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-24 15:14:02
 * 积分兑换
 */
import React, { Component } from 'react'
import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel, { EditFormWrapper } from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, Button, message, notification, Card, Modal } from 'antd'
import { formatData, flattenObj, toMoney } from '../../../Util/reactUtil'
import { hasAttr, arrayToObject } from '../../../Util'
import { getFetch, fetch } from '../../../Config/request'
import ProxyPay from '../../FundRecord/views/component/proxyPay'

const title = '兑换失败理由'
const initGetParams = {
    pageIndex: 1,
}

const orderStatusOptions = [
    // { label: '待兑换', value: 0 },
    { label: '处理中', value: 1 },
    { label: '交易成功', value: 2 },
    { label: '审核拒绝', value: 3 },
    { label: '交易关闭', value: 4 }
],
    handleStatusOptions = [
        { label: '未处理', value: 0 },
        { label: '处理中', value: 1 },
        { label: '处理完成', value: 2 }
    ],
    payStatusOptions = [
        { label: '未处理', value: 0 },
        { label: '已提交', value: 1 },
        { label: '代付失败', value: 2 },
        { label: '代付成功', value: 3 }
    ]

const pagingUrl = '/system/integral/pagingrefund',
    payUrl = '/system/integral/pay',
    refuseUrl = '/system/integral/refuse',
    errorUrl = '/system/integral/error',
    uploadFileUrl = '/system/file/uploadexcel',
    checkProxyPayUrl = '/system/integral/checkproxypay'//手动回调地址
class Refund extends Component {
    constructor(props) {
        super(props)

        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {

            return getFetch(pagingUrl, params).then(res => {
                if (res && is.array(res.models)) {
                    const { models, totalModels } = res
                    const dataSource = formatData(flattenObj(models, ['integralRefund']))
                    this.setState({
                        dataSource,
                        totalModels,
                        current: params.pageIndex,
                        pageSize: params.pageSize,
                        selectedRowKeys: []
                    })
                }
                return res
            })
        },
        pay: (params) => {
            return fetch(payUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams)
                }
                return res
            })
        },
        error: (params) => {
            return fetch(errorUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams)
                }
                return res
            })
        },
        refuse: (params) => {
            return fetch(refuseUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams)
                }
                return res
            })
        },
        checkProxyPay: (params) => {
            return fetch(checkProxyPayUrl, params).then(res => {
                if (res.status == 0 && res.msg) {
                    const content = {
                        __html: res.msg
                    }
                    notification.warn({
                        message: '操作部分失败',
                        description: <span dangerouslySetInnerHTML={content}></span>,
                        duration: null
                    });
                }
                return res
            })
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        search: (value) => {
            const queryParams = Object.assign({}, value)
            const { getDataParams } = this.state
            const mobileRegx = /^1\d{10}$/gi
            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = queryParams.createtime[0].format('x')
                queryParams.endTime = queryParams.createtime[1].format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }
            delete queryParams.createtime
            const params = { ...getDataParams, ...queryParams }

            this.setState({
                getDataParams: params
            })
        },
        // 清空查找条件
        clearSearch: () => {
            this.setState({
                getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
            })
        },
        onShowSizeChange: (current, pageSize) => {
            const { getDataParams } = this.state
            this.setState({
                getDataParams: { ...getDataParams, pageSize, pageIndex: 1 },
                pageSize
            })
        },
        changePage: (page, pageSize) => {
            const { getDataParams } = this.state
            const params = { ...getDataParams, pageIndex: page }
            this.setState({
                getDataParams: params,
                selectedRowKeys: []
            })

        },
        save: (values) => {
            const { selectedRowKeys, type } = this.state
            this.Request[type]({
                reason: values.reason,
                payPassword: values.payPassword,
                ids: selectedRowKeys
            }).then(res => {
                if (res.status == 0) {
                    this.setState({
                        modalVis: false,
                        selectedRowKeys: []
                    })
                }
            })
        },
        onCancelPayModal: () => {
            this.setState({
                payModalVis: false,
                editId: null
            })
        },
        confirmPwd: (value) => {
            this.editPayForm.props.form.validateFieldsAndScroll(
                (err, values) => {
                    if (!err) {
                        this.Request.pay({
                            ids: this.state.selectedRowKeys,
                            payPassword: values.payPassword
                        }).then(res => {
                            if (res.status == 0) {
                                this.setState({
                                    payModalVis: false,
                                    // editId: null
                                })
                            }
                        })
                    }
                })
        },
        // 点击批量操作按钮
        editItems: (name) => {
            const { selectedRowKeys } = this.state
            if (!selectedRowKeys.length) {
                message.error('请至少选中一行要操作的数据')
                return;
            }
            // todo: 判断name是什么，如果是拒绝和异常，modalVis为true
            if (name == 'pay') {
                this.setState({
                    payModalVis: true,
                })
            } else {
                this.setState({
                    modalVis: true,
                    type: name
                })
            }

        },
        cancel: () => {
            this.setState({
                modalVis: false
            })
        },
        rowSelectionChange: (selectedRowKeys, selectedRows) => {
            const newSelectedRowKeys = [];
            const disabledSerialNumbers = [];
            selectedRows.forEach(item => {
                if (item.orderStatus === 1 && item.payStatus !== 1) {
                    newSelectedRowKeys.push(item.id);
                } else {
                    disabledSerialNumbers.push(item.serialNumber);
                }
            })
            if (disabledSerialNumbers.length) {
                notification.warn({
                    message: '操作警告',
                    description: `以下订单：
                    ${disabledSerialNumbers.join(' , ')}
                    不可进行操作！
                    `,
                    duration: null
                });
            }
            this.setState({
                selectedRowKeys: newSelectedRowKeys
            })
        },
        showCheckProxyPay: () => {
            this.setState({
                checkProxyPayModalVis: true
            })
        },
        cancelCheckProxyPay: () => {
            this.setState({
                checkProxyPayModalVis: false
            })
        },
        saveCheckProxyPay: (values) => {
            // actionSave({ context: this, values, handleChangedData: this.Util.handleChangedData })
            this.Request.checkProxyPay(this.Util.handleChangedData(values)).then(res => {
                if (res.status == 0) {
                    this.setState({
                        checkProxyPayModalVis: false,
                    })
                }
            })
        },
        showProxyPay: (record) => {
            this.setState({
                withdrawSn: record.serialNumber,
                proxyPayModalVis: true
            })
        },
        onCloseProxyPay: () => {
            this.setState({
                proxyPayModalVis: false
            })
        }
    }

    Util = {
        //处理表单的保存内容的key、value以匹配后台的格式
        handleChangedData: (obj) => {
            if (is.object(obj)) {
                const filePath = hasAttr(obj, ['filePath', 0, 'response', 'model'])
                if (filePath) {
                    obj.filePath = filePath
                }
            }
            return obj
        },
        getTotalAmount: (dataSource) => {
            let totalAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (item.amount) {
                    totalAmount += item.amount
                }
            })
            return totalAmount
        },
        getSelectedAmount: (dataSource, selectedRowKeys) => {
            const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
            if (!tempSelectedRowKeys.length) {
                return 0
            }
            const selectedString = tempSelectedRowKeys.join(',')
            let selectedAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (selectedString.indexOf(item.id) > -1 && item.amount) {
                    selectedAmount += item.amount
                }
            })
            return selectedAmount
        }
    }
    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        const { showProxyPay } = this.Action
        this.state = {
            title: title,
            dataSource: [],
            modalVis: false,
            modal: {},
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            CreditCard: {},
            editId: null,
            payModalVis: false,//支付密码输入面板
            totalAmount: 0,//当前页总金额
            selectedAmount: 0,//已选择的项的总金额
            checkProxyPayModalVis: false,
            proxyPayModalVis: false,
            withdrawSn: null
        }
        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone',
                }, {
                    type: SearchType.Select,
                    label: '用户订单状态',
                    id: 'orderStatus',
                    dataSource: orderStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '渠道代付状态',
                    id: 'payStatus',
                    dataSource: payStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '管理操作状态',
                    id: 'handleStatus',
                    dataSource: handleStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '是否分批次',
                    id: 'isBatch',
                    dataSource: [{
                        label: '是',
                        value: 1
                    }, {
                        label: '否',
                        value: 0
                    }]
                }, {
                    type: SearchType.DateRange,
                    label: '提现申请时间',
                    id: 'createtime',
                    config: {
                        showTime: true,
                        format: "YYYY-MM-DD HH:mm:ss",
                    },
                    // formOption: {
                    //     initialValue: [startTime, endTime]
                    // }
                }, {
                    type: SearchType.String,
                    label: '大额提现批次号',
                    id: 'batchNo'
                }, {
                    type: SearchType.String,
                    label: '订单号',
                    id: 'serialNumber'
                }
            ]
        }
        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            },
            {
                title: '用户名',
                dataIndex: 'realName',
                key: 'realName',
                fixed: 'left',
                width: 100,
            }, {
                title: '手机号',
                dataIndex: 'mobilePhone',
                key: 'mobilePhone'
            }, {
                title: '提现金额',
                dataIndex: 'amount',
                key: 'amount',
                render: value => toMoney(value)
            }, {
                title: '数量',
                dataIndex: 'integraNum',
                key: 'integraNum',
                // render: value => value + '积分'
                render: value => toMoney(value)
            },
            {
                title: '银行卡名称',
                dataIndex: 'bankCode',
                key: 'bankCode',
                render: (value, record, index) => {
                    if (this.state.CreditCard) {
                        return this.state.CreditCard[value]
                    }
                }
            },
            {
                title: '提现账号',
                dataIndex: 'cardNo',
                key: 'cardNo',
                render: (text, record, index) => {
                    return record.cardNo || record.alipayAccount || record.wechatAccount
                }
            }, {
                title: '用户订单状态',
                dataIndex: 'orderStatus',
                key: 'orderStatus',
                render: (value, record) => {
                    const option = orderStatusOptions.filter(item => item.value == value)
                    if (hasAttr(option, [0, 'label'])) {
                        return option[0].label
                    }
                }
            }, {
                title: '渠道代付状态',
                dataIndex: 'payStatus',
                key: 'payStatus',
                render: (value, record) => {
                    const option = payStatusOptions.filter(item => item.value == value)
                    if (hasAttr(option, [0, 'label'])) {
                        return option[0].label
                    }
                }
            }, {
                title: '管理操作状态',
                dataIndex: 'handleStatus',
                key: 'handleStatus',
                render: (value, record) => {
                    const option = handleStatusOptions.filter(item => item.value == value)
                    if (hasAttr(option, [0, 'label'])) {
                        return option[0].label
                    }
                }
            }, {
                title: '申请时间',
                dataIndex: 'createTime',
                key: 'createTime',
                render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
                sorter: (a, b) => a.createTime - b.createTime,
            }, {
                title: '代付时间',
                dataIndex: 'payTime',
                key: 'payTime',
                render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
            }, {
                title: '到账时间',
                dataIndex: 'finishTime',
                key: 'finishTime',
                render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
            }, {
                title: '订单编号',
                dataIndex: 'serialNumber',
                key: 'serialNumber'
            }, {
                title: '大额提现批次号',
                dataIndex: 'batchNo',
                key: 'batchNo'
            }, {
                title: '是否分批次',
                dataIndex: 'isBatch',
                key: 'isBatch',
                render: value => value == 1 ? '是' : '否'
            }, {
                title: '代付失败理由',
                width: 100,
                dataIndex: 'failReason',
                key: 'failReason',
            }, {
                title: '拒绝代付理由',
                width: 100,
                dataIndex: 'handleResult',
                key: 'handleResult',
            }, {
                title: '操作',
                dataIndex: 'action',
                key: 'action',
                fixed: 'right',
                render: (value, record) => {
                    return (record.payStatus !== 0 ? (<span>
                        <Button type="primary" onClick={() => showProxyPay(record)}>查看代付</Button>
                    </span>) : null)

                }
            }
        ];
        this.formItems = [
            {
                type: EditType.InputStr,
                key: 'reason',
                label: '失败理由',
                config: {
                    rules: [
                        { required: true, message: '请填写失败理由' }
                    ],
                },
            }, {
                type: EditType.InputStr,
                key: 'payPassword',
                label: '支付操作密码',
                itemConfig: {
                    type: 'password'
                },
                config: {
                    rules: [
                        { required: true, message: '请填写支付操作密码' }
                    ],
                },
            }
        ]
        this.payFormItems = [
            {
                type: EditType.InputStr,
                key: 'payPassword',
                label: '支付操作密码',
                itemConfig: {
                    type: 'password'
                },
                config: {
                    rules: [
                        { required: true, message: '请填写支付操作密码' }
                    ],
                },
            }
        ]
        // 编辑面板内容
        this.checkProxyPayFormItems = [
            {
                type: EditType.Image,
                label: 'excel文件',
                key: 'filePath',
                config: {
                    valuePropName: 'fileList',
                    getValueFromEvent: (e) => {
                        console.log(e);
                        if (Array.isArray(e)) {
                            return e;
                        }
                        return e && e.fileList;
                    },
                    rules: [
                        { required: true, message: '请上传excel文件' }
                    ]
                },
                itemConfig: {
                    action: window.baseUrl + uploadFileUrl,
                    tip: '上传excel文件',
                    accept: '.xls, .xlsx',
                    name: 'files',
                    listType: 'text',
                },
                isImageAutoHandle: false,
                isShowbtn: (props) => {
                    if (props.form.getFieldValue('filePath') && props.form.getFieldValue('filePath').length) {
                        return false
                    }
                    return true
                }
            }, {
                type: EditType.InputStr,
                label: '支付密码',
                key: 'payPassword',
                config: {
                    rules: [
                        { required: true, message: '请输入支付密码' }
                    ]
                },
                itemConfig: {
                    type: 'password'
                }
            }
        ]
    }
    render() {
        const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, pageSize, payModalVis, totalAmount, selectedAmount, checkProxyPayModalVis, withdrawSn, proxyPayModalVis } = this.state
        const { changePage, search, clearSearch, onShowSizeChange, cancel, save, editItems, onCancelPayModal, confirmPwd, rowSelectionChange, showCheckProxyPay, saveCheckProxyPay, cancelCheckProxyPay, onCloseProxyPay } = this.Action
        return (
            <div>
                <SearchPanel
                    isExport={true}
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Card>
                    <Button className="action-item" type="primary" ghost onClick={() => editItems('pay')}>批量代付</Button>
                    <Button className="action-item" type="primary" ghost onClick={() => editItems('refuse')}>批量拒绝</Button>
                    <Button className="action-item" type="primary" ghost onClick={() => editItems('error')}>批量异常</Button>
                    <Button className="action-item" type="primary" ghost onClick={showCheckProxyPay}>手动更新状态</Button>
                </Card>
                <Card>
                    <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
                        当前页总金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的总金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
                </Card>
                <Table
                    scroll={{ x: 2000 }}
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: rowSelectionChange,
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        showSizeChanger: true,
                        showTotal: (total, range) => `共 ${total} 条记录`,
                        onShowSizeChange: onShowSizeChange,
                        pageSizeOptions: ['15', '50', '200', '500']
                    }}
                />
                <EditPanel
                    title={title}
                    modalVis={modalVis}
                    formItems={this.formItems}
                    modal={modal}
                    onSave={save}
                    onCancel={cancel}
                />
                <EditPanel
                    title='批量手动回调'
                    modalVis={checkProxyPayModalVis}
                    formItems={this.checkProxyPayFormItems}
                    onSave={saveCheckProxyPay}
                    onCancel={cancelCheckProxyPay}
                />
                {
                    payModalVis ? (
                        <Modal
                            // className={className}
                            title="支付操作密码"
                            visible={payModalVis}
                            maskClosable={false}
                            onOk={confirmPwd}
                            onCancel={onCancelPayModal}>
                            <EditFormWrapper wrappedComponentRef={(inst) => this.editPayForm = inst} formItems={this.payFormItems} />
                        </Modal>
                    ) : null
                }
                <ProxyPay
                    modalVis={proxyPayModalVis}
                    onClose={onCloseProxyPay}
                    withdrawSn={withdrawSn}
                />
            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
        })
        // if (!is.empty(this.props.cashCardOption)) {
        //     this.setState({
        //         CashCard: arrayToObject({ array: this.props.cashCardOption, keyName: 'value', valueName: 'name' })
        //     })
        // }
        if (!is.empty(this.props.creditCardOption)) {
            this.setState({
                CreditCard: arrayToObject({ array: this.props.creditCardOption, keyName: 'value', valueName: 'name' })
            })
        }
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams, selectedRowKeys, dataSource } = this.state
        const { get } = this.Request
        const { getSelectedAmount, getTotalAmount } = this.Util
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
        // console.log(this.props)
        // if (nextProps.cashCardOption !== this.props.cashCardOption) {
        //     this.setState({
        //         CashCard: arrayToObject({ array: this.props.cashCardOption, keyName: 'value', valueName: 'name' })
        //     })
        // }
        if (nextProps.creditCardOption !== this.props.creditCardOption) {
            this.setState({
                CreditCard: arrayToObject({ array: this.props.creditCardOption, keyName: 'value', valueName: 'name' })
            })
        }
        // 选中的项发生变化时，计算已选中的项的总金额
        if (nextState.selectedRowKeys !== selectedRowKeys) {
            this.setState({
                selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
            })
        }
        // 当前页的数据发生变化时，计算当前页的总金额
        if (nextState.dataSource !== dataSource) {
            this.setState({
                totalAmount: getTotalAmount(nextState.dataSource)
            })
        }
    }
}
const mapStateToProps = (state, ownProps) => {
    // console.log(state)
    // const cashCard = state.index.dictList.filter((item, index) => item.value === 'CashCard')[0]
    // const creditCard = state.index.dictList.filter((item, index) => item.value === 'CreditCard')[0]
    // return {
    //   cashCardOption: (cashCard && cashCard.items) || [],
    //   creditCardOption: (creditCard && creditCard.items) || [],
    // }
    return {
        // cashCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CashCard'), [0, 'items']) || [],
        creditCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CreditCard'), [0, 'items']) || []
    }
}
export default connect(mapStateToProps)(Refund)
