/*
 * @Author: miccy 
 * @Date: 2018-03-22 10:24:47 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-03-27 17:32:35
 * 积分收付
 */

import React, { Component } from 'react'
// import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Table, message, Card } from 'antd'
import { handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { getFetch } from '../../../Config/request'
import { requestGet } from '../../../Util/Request'
import { arrayToObject } from '../../../Util'
import { actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal, actionSearch, actionClearSearch } from '../../../Util/Action'

const pagingUrl = '/system/gateway/getTransferPage', //获取列表
    getTransferStatusUrl = '/system/gateway/getTransferStatusList',//获取转账状态
    getChannelListUrl = '/common/getchannellist';


class Transfer extends Component {
    constructor(props) {
        super(props)
        
        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({ params: { ...params, tradeCode: '13002' }, pagingUrl, context: this }).then(res => {
                if (res && res.status == 0) {
                    !this.state.transferStatusOptions.length && this.Request.getTransferStatus();
                    is.empty(this.state.channelEnum) && this.Request.getChannelList();
                }
            })
        },
        getTransferStatus: () => {
            getFetch(getTransferStatusUrl).then(res => {
                if (res && res.status == 0) {
                    const { transferStatusOptions } = this.state
                    res.model.resultList.forEach(item => {
                        transferStatusOptions.push({
                            label: item.value,
                            value: item.key
                        })
                    })
                    this.setState({
                        transferStatusOptions
                    })
                }
            })
        },
        getChannelList: (params) => {
            getFetch(getChannelListUrl).then(res => {
                if (res && res.status == 0) {
                    this.setState({
                        channelEnum: arrayToObject({ array: res.models, keyName: 'channelId', valueName: 'remarks' })
                    })
                }
            })
        }
    }

    Util = {
        handleSearchValues: (values) => {
            const queryParams = Object.assign({}, values)
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }
            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }

            delete queryParams.createtime
            return queryParams
        },
        getTotalAmount: (dataSource) => {
            let totalAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (item.totalAmount) {
                    totalAmount += item.totalAmount
                }
            })
            return totalAmount
        },
        getSelectedAmount: (dataSource, selectedRowKeys) => {
            const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
            if (!tempSelectedRowKeys.length) {
                return 0
            }
            const selectedString = tempSelectedRowKeys.join(',')
            let selectedAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (selectedString.indexOf(item.id) > -1 && item.totalAmount) {
                    selectedAmount += item.totalAmount
                }
            })
            return selectedAmount
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this })
        },
        search: (values) => {
            const tmp = this.Util.handleSearchValues(values);
            if (tmp) {
                actionSearch({ value: tmp, context: this })
            }
        },
        clearSearch: () => {
            actionClearSearch({ context: this })
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {

        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            totalAmount: 0,
            selectedAmount: 0,
            channelEnum: {},
            transferStatusOptions: [],
        }

        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '手机号码（转入/转出）',
                    id: 'mobilePhone'
                },
                {
                    type: SearchType.String,
                    label: '平台订单号',
                    id: 'serialNumber'
                }, {
                    type: SearchType.Select,
                    label: '订单状态',
                    id: 'transferStatus',
                    dataSource: this.state.transferStatusOptions
                }, {
                    type: SearchType.DateRange,
                    label: '时间段',
                    id: 'createtime'
                }
            ]
        }

        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            }, {
                title: '转出真实姓名',
                dataIndex: 'fromUserName',
                key: 'fromUserName'
            }, {
                title: '转出手机号码',
                dataIndex: 'fromMobilePhone',
                key: 'fromMobilePhone'
            }, {
                title: '转入用户姓名',
                dataIndex: 'toUserName',
                key: 'toUserName'
            }, {
                title: '转入用户手机号',
                dataIndex: 'toMobilePhone',
                key: 'toMobilePhone'
            }, {
                title: '数量',
                dataIndex: 'payIntegral',
                key: 'payIntegral',
                render: value => toMoney(value, '')
            }, {
                title: '金额',
                dataIndex: 'totalAmount',
                key: 'totalAmount',
                render: value => toMoney(value)
            }, {
                title: '转赠方式',
                dataIndex: 'channelId',
                key: 'channelId',
                render: value => {
                    return this.state.channelEnum[value] || '未知';
                }
            }, {
                title: '订单状态',
                dataIndex: 'transferStatusStr',
                key: 'transferStatusStr'
            }, {
                title: '创建时间',
                dataIndex: 'createTimeStr',
                key: 'createTimeStr'
            }, {
                title: '订单描述',
                dataIndex: 'desc',
                key: 'desc'
            }, {
                title: '订单号',
                dataIndex: 'serialNumber',
                key: 'serialNumber'
            }
        ]


    }
    render() {
        const { dataSource, current, totalModels, pageSize, selectedRowKeys, totalAmount, selectedAmount } = this.state
        const { changePage, onShowSizeChange, search, clearSearch } = this.Action
        return (
            <div>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Card>
                    <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
                        当前页总金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的总金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
                </Card>
                <Table
                    scroll={{ x: 1500 }}
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal,
                        pageSizeOptions: ['50', '100', '200'],
                    }}
                />

            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
        })

    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams, selectedRowKeys, dataSource } = this.state
        const { get } = this.Request
        const { getSelectedAmount, getTotalAmount } = this.Util
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
        // 选中的项发生变化时，计算已选中的项的总金额
        if (nextState.selectedRowKeys !== selectedRowKeys) {
            this.setState({
                selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
            })
        }
        // 当前页的数据发生变化时，计算当前页的总金额
        if (nextState.dataSource !== dataSource) {
            this.setState({
                totalAmount: getTotalAmount(nextState.dataSource)
            })
        }
    }
}
export default Transfer




