import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
const loadPurchase = (cb) => {
    return import('./purchase.js')
},
    loadRefund = (cb) => {
        return import('./refund.js')
    },
    loadCashierPurchase = (cb) => {
        return import('./cashierPurchase.js')
    },
    loadCashierExchange = (cb) => {
        return import('./cashierExchange.js')
    },
    loadIntegralAudit = (cb) => {
        return import('./integralAudit.js')
    },
    loadGameCard = (cb) => {
        return import('./gameCard.js')
    },
    // loadPay = (cb) => {
    //     return import('./pay.js')
    // },
    loadTransfer = (cb) => {
        return import('./transfer.js')
    }

const Purchase = getComponent(loadPurchase),
    Refund = getComponent(loadRefund),
    CashierPurchase = getComponent(loadCashierPurchase),
    CashierExchange = getComponent(loadCashierExchange),
    IntegralAudit = getComponent(loadIntegralAudit),
    GameCard = getComponent(loadGameCard),
    // Pay = getComponent(loadPay),
    Transfer = getComponent(loadTransfer)



export default class Integral extends Component {
    render() {
        return (
            <Switch>
                <Route
                    path="/integral"
                    exact render={() => <Redirect to="/integral/purchase" />}
                />
                <Route path="/integral/refund" render={(props) => <Refund {...props} />} />
                <Route path="/integral/purchase" render={(props) => <Purchase {...props} />} />
                <Route path="/integral/cashierPurchase" render={(props) => <CashierPurchase {...props} />} />
                <Route path="/integral/cashierExchange" render={(props) => <CashierExchange {...props} />} />
                <Route path="/integral/integralAudit" render={(props) => <IntegralAudit {...props} />} />
                <Route path="/integral/gameCard" render={(props) => <GameCard {...props} />} />
                {/* <Route path="/integral/pay" render={(props) => <Pay {...props} />} /> */}
                <Route path="/integral/transfer" render={(props) => <Transfer {...props} />} />


            </Switch>
        )
    }
}