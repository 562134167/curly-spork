/*
 * @Author: miccy 
 * @Date: 2018-03-21 14:07:41 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:11:01
 * 退款管理
 */



import React, {
    Component
} from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import {
    Table,
    message,
    Card
} from 'antd'
import {
    handleEndTime,
    handleStartTime,
    formatData,
    toMoney
} from '../../../Util/reactUtil'
// import { fetch } from '../../../Config/request'
import {
    requestGet
} from '../../../Util/Request'
import {
    actionChangePage,
    initGetParams,
    actionOnShowSizeChange,
    actionShowTotal,
    actionSearch,
    actionClearSearch
} from '../../../Util/Action'

const pagingUrl = '/system/gamecard/paging' //获取列表

const activateStatusOptions = [{
    value: 1,
    label: '已激活'
},
{
    value: 2,
    label: '未激活'
}],
    activateStatusEnum = {
        1: '已激活',
        2: '未激活'
    };

class GameCard extends Component {
    constructor(props) {
        super(props)
       
        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({
                params, pagingUrl, context: this, successCallback: res => {
                    const { models, totalModels } = res
                    const dataSource = formatData(models, 'gameCard.id')
                    this.setState({
                        dataSource,
                        totalModels,
                        current: params.pageIndex,
                        pageSize: params.pageSize,
                        selectedRowKeys: []
                    })
                }
            })
        },
    }

    Util = {
        handleSearchValues: (values) => {
            const queryParams = Object.assign({}, values)
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }
            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }

            delete queryParams.createtime
            return queryParams
        },
        getTotalAmount: (dataSource) => {
            let totalAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (item.orderInfo.totalAmount) {
                    totalAmount += item.orderInfo.totalAmount;
                }
            })
            return totalAmount
        },
        getSelectedAmount: (dataSource, selectedRowKeys) => {
            const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
            if (!tempSelectedRowKeys.length) {
                return 0
            }
            // const selectedString = tempSelectedRowKeys.join(',');
            let selectedAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (tempSelectedRowKeys.indexOf(item.gameCard.id) > -1 && item.orderInfo.totalAmount) {
                    selectedAmount += item.orderInfo.totalAmount
                }
            })
            return selectedAmount
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        changePage: (page, pageSize) => {
            actionChangePage({
                page,
                pageSize,
                context: this
            })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({
                pageSize,
                context: this
            })
        },
        search: (values) => {
            const tmp = this.Util.handleSearchValues(values);
            if (tmp) {
                actionSearch({
                    value: tmp,
                    context: this
                })
            }
        },
        clearSearch: () => {
            actionClearSearch({
                context: this
            })
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {

        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            totalAmount: 0,
            selectedAmount: 0,
        }

        // 搜索面板元数据
        this.metadata = {
            conditions: [{
                type: SearchType.String,
                label: '手机号码',
                id: 'mobilePhone'
            },
            {
                type: SearchType.String,
                label: '订单号',
                id: 'orderNo'
            },
            {
                type: SearchType.DateRange,
                label: '创建时间段',
                id: 'createtime'
            }, {
                type: SearchType.Select,
                label: '状态',
                id: 'activateStatus',
                dataSource: activateStatusOptions
            }
            ]
        }

        // 表头设置
        this.columns = [{
            title: '序号',
            dataIndex: 'index',
            key: 'index',
            fixed: 'left',
            width: 60,
            render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
        }, {
            title: '真实姓名',
            dataIndex: 'realName',
            key: 'realName'
        }, {
            title: '手机号',
            dataIndex: 'mobilePhone',
            key: 'mobilePhone'
        }, {
            title: '订单号',
            dataIndex: 'gameCard.orderNo',
            key: 'gameCard.orderNo'
        }, {
            title: '帐号',
            dataIndex: 'gameCard.cardNo',
            key: 'gameCard.cardNo'
        }, {
            title: '密码',
            dataIndex: 'gameCard.password',
            key: 'gameCard.password'
        }, {
            title: '金额',
            dataIndex: 'orderInfo.totalAmount',
            key: 'orderInfo.totalAmount',
            render: value => toMoney(value)
        }, {
            title: '游戏豆数量',
            dataIndex: 'gameCard.bean',
            key: 'gameCard.bean'
        }, {
            title: '创建日期',
            dataIndex: 'gameCard.createTime',
            key: 'gameCard.createTime',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '激活日期',
            dataIndex: 'gameCard.activateTime',
            key: 'gameCard.activateTime',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '状态',
            dataIndex: 'gameCard.activateStatus',
            key: 'gameCard.activateStatus',
            render: value => activateStatusEnum[value] || '未知'
        }]
    }
    render() {
        const {
            dataSource,
            current,
            totalModels,
            pageSize,
            selectedRowKeys,
            totalAmount,
            selectedAmount
        } = this.state
        const {
            changePage,
            onShowSizeChange,
            search,
            clearSearch
        } = this.Action
        return (<div>
            <SearchPanel
                metadata={this.metadata}
                onSearch={search}
                onClearSearch={clearSearch}
            />
            <Card>
                <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }} >
                    当前页总金额： {
                        parseFloat(totalAmount / 100).toFixed(2) + '元'
                    }，
                已选中的项的总金额： {
                        parseFloat(selectedAmount / 100).toFixed(2) + '元'
                    } </p>
            </Card>
            <Table
                scroll={{ x: 1500 }}
                rowSelection={{
                    selectedRowKeys: selectedRowKeys,
                    onChange: (selectedRowKeys, selectedRows) => {
                        this.setState({
                            selectedRowKeys
                        })
                    },
                }}
                columns={this.columns}
                dataSource={dataSource}
                pagination={{
                    showSizeChanger: true,
                    pageSize,
                    current,
                    total: totalModels,
                    onChange: changePage,
                    onShowSizeChange,
                    showTotal: actionShowTotal,
                    pageSizeOptions: ['50', '100', '200'],
                }}
            />
        </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: {
                ...initGetParams,
                pageSize: this.state.pageSize
            }
        })
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams, selectedRowKeys, dataSource } = this.state
        const { get } = this.Request
        const { getSelectedAmount, getTotalAmount } = this.Util
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
        // 选中的项发生变化时，计算已选中的项的总金额
        if (nextState.selectedRowKeys !== selectedRowKeys) {
            this.setState({
                selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
            })
        }
        // 当前页的数据发生变化时，计算当前页的总金额
        if (nextState.dataSource !== dataSource) {
            this.setState({
                totalAmount: getTotalAmount(nextState.dataSource)
            })
        }
    }
}
export default GameCard