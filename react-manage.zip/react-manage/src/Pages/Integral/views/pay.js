/*
 * @Author: miccy 
 * @Date: 2018-03-20 16:21:46 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 17:53:34
 * 代付管理
 */
import React, { Component } from 'react';
import { Modal, Table, Button, Card, message } from 'antd';
import moment from 'moment';
import is from 'is_js';
import SearchPanel from '../../../Common/searchPanel';
import * as SearchType from '../../../Common/searchTypes';

import {handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { requestGet } from '../../../Util/Request'
import { actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal, actionSearch, actionClearSearch } from '../../../Util/Action'

const pagingUrl = '/system/integral/pagingbuyenergy'

const statusOptions = [{
    label: '成功',
    value: 1
}, {
    label: '失败',
    value: 1
}]

export default class Pay extends Component {
    constructor(props) {
        super(props);
       
        // 初始化数据
        this.onInit();
    }

    Request = {
        get: (params) => {
            requestGet({ params, pagingUrl, context: this });
        }
    }

    Util = {
        handleSearchValues: (values) => {
            const queryParams = Object.assign({}, values)
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }
            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }

            delete queryParams.createtime
            return queryParams
        },
        getTotalAmount: (dataSource) => {
            let amount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (item.amount) {
                    amount += item.amount
                }
            })
            return amount
        },
        getSelectedAmount: (dataSource, selectedRowKeys) => {
            const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
            if (!tempSelectedRowKeys.length) {
                return 0
            }
            const selectedString = tempSelectedRowKeys.join(',')
            let selectedAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (selectedString.indexOf(item.id) > -1 && item.amount) {
                    selectedAmount += item.amount
                }
            })
            return selectedAmount
        }
    }

    Action = {
        changePage: (page, pageSize) => {
            actionChangePage({
                page, pageSize, context: this
            });
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({
                pageSize, context: this
            });
        },
        search: (values) => {
            const tmp = this.Util.handleSearchValues(values);
            if (values) {
                actionSearch({ value: tmp, context: this });
            }
        },
        clearSearch: () => {
            actionClearSearch({ context: this })
        },
        view: (record) => {
            console.log(record);
            this.setState({
                modalVis: true,
                payOrderNoArr: ['11111111111111111111', '22222222222222222222']
            })
        },
        cancel: () => {
            this.setState({
                modalVis: false
            })
        }
    }

    onInit() {
        const { view } = this.Action

        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            totalAmount: 0,
            selectedAmount: 0,
            payOrderNoArr: [],
            modalVis: false
        }

        this.metadata = {
            conditions: [{
                type: SearchType.String,
                label: '手机号码',
                id: 'mobilePhone'
            },
            {
                type: SearchType.String,
                label: '订单号',
                id: 'orderNo'
            },
            {
                type: SearchType.DateRange,
                label: '订单时间段',
                id: 'createtime'
            },
            {
                type: SearchType.String,
                label: '代付号',
                id: 'todo'
            },
            {
                type: SearchType.DateRange,
                label: '代付时间段',
                id: 'createtime'
            }, {
                type: SearchType.Select,
                label: '代付状态',
                id: 'status',
                dataSource: statusOptions
            }, {
                type: SearchType.Boolean,
                label: '多个代付号',
                id: 'isMultiple'
            }
            ]
        }

        this.columns = [{
            title: '序号',
            dataIndex: 'index',
            key: 'index',
            fixed: 'left',
            width: 60,
            render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
        }, {
            title: '真实姓名',
            dataIndex: 'realName',
            key: 'realName'
        }, {
            title: '手机号',
            dataIndex: 'mobilePhone',
            key: 'mobilePhone'
        }, {
            title: '代付金额',
            dataIndex: 'amount',
            key: 'amount',
            render: value => toMoney(value)
        }, {
            title: '订单号',
            dataIndex: 'orderNo',
            key: 'orderNo'
        }, {
            title: '代付号',
            dataIndex: '',
            key: ''
        }, {
            title: '订单时间',
            dataIndex: '',
            key: '',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '代付时间',
            dataIndex: '',
            key: '',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '多个代付号',
            dataIndex: '',
            key: '',
            render: value => {
                if (value == 1) {
                    return '是';
                } else {
                    return '否';
                }
            }
        }, {
            title: '代付状态',
            dataIndex: '',
            key: '',
            render: value => {
                const options = statusOptions.filter(item => item.value === value);
                return options[0] && options[0].label;
            }
        }, {
            title: '代付渠道',
            dataIndex: '',
            key: '',
            render: value => '渠道'
        }, {
            title: '操作',
            dataIndex: 'action',
            key: 'action',
            render: (value, record) => {
                return (
                    <Button className="action-item" type="primary" onClick={() => view(record)}>查看</Button>
                )
            }
        }

        ]
    }

    render() {
        const { dataSource, current, totalModels, pageSize, selectedRowKeys, totalAmount, selectedAmount, modalVis, payOrderNoArr } = this.state
        const { changePage, onShowSizeChange, search, clearSearch, cancel } = this.Action

        return (
            <div>
                <SearchPanel
                    metadata={this.metadata}
                    search={search}
                    onClearSearch={clearSearch}
                />
                <Card>
                    <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
                        当前页总金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'},已选中的项的总金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}
                    </p>
                </Card>
                <Table
                    scroll={{ x: 1500 }}
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal,
                        pageSizeOptions: ['50', '100', '200'],
                    }}
                />
                <Modal title="查看代付订单号" visible={modalVis} onCancel={cancel} onOk={cancel}>
                    {payOrderNoArr.map((item, index) => {
                        return <p key={index} style={{ marginBottom: 10, fontSize: 15 }}>{item}</p>
                    })}
                </Modal>
            </div>
        )
    }

    componentDidMount() {
        this.setState({
            getDataParams: {
                ...initGetParams,
                pageSize: this.state.pageSize
            }
        })
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams, selectedRowKeys, dataSource } = this.state;
        const { get } = this.Request;
        const { getSelectedAmount, getTotalAmount } = this.Util;

        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams);
        }

        if (nextState.selectedRowKeys !== selectedRowKeys) {
            this.setState({
                selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
            })
        }

        if (nextState.dataSource !== dataSource) {
            this.setState({
                totalAmount: getTotalAmount(nextState.dataSource)
            })
        }

    }

}