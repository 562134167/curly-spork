/*
 * @Author: miccy 
 * @Date: 2018-03-16 14:18:26 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:10:59
 * 开通积分联盟审核表
 */
import React, { Component } from 'react'
// import { connect } from 'react-redux'
// import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
// import EditPanel from '../../../Common/editPanel'
// import * as EditType from '../../../Common/editType'
// import DropdownBtn from '../../../Common/dropdowmBtn'
import { Table, Button, message, Card } from 'antd'
import { handleEndTime, handleStartTime } from '../../../Util/reactUtil'
import { requestGet } from '../../../Util/Request'
import { actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal, actionSearch, actionClearSearch } from '../../../Util/Action'
import { fetch, getFetch } from '../../../Config/request'

// const title = '审核失败理由'

const pagingUrl = '/system/integral/getApplyList',
    passUrl = '/system/integral/pass',
    refuseUrl = '/system/integral/refuse',
    integralStatusListUrl = '/system/integral/getIntegralStatusList'

class integralAudit extends Component {
    constructor(props) {
        super(props)
       
        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({
                params, pagingUrl, context: this
            })
        },
        getIntegralStatusList: () => {
            getFetch(integralStatusListUrl).then(res => {
                if (res && res.status === 0) {
                    const { integralStatusOptions } = this.state;
                    res.model.resultList.forEach(item => {
                        integralStatusOptions.push({
                            label: item.value,
                            value: item.key
                        })
                    })
                    this.setState({
                        integralStatusOptions
                    })
                    // this.metadata.conditions.map(item => {
                    //     if (item.id === 'integralStatus') {
                    //         item.dataSource = formatParentIdOptions({ options: res.model.resultList, valueKey: 'key', labelKey: 'value', hasDefaultOption: false })
                    //     }
                    // })
                    // console.log(this.metadata);

                }
            })
        },
        // 修改数据
        pass: (params) => {
            return fetch(passUrl, params).then(res => {
                this.Request.get(this.state.getDataParams)
                return res
            })
        },
        refuse: (params) => {
            return fetch(refuseUrl, params).then(res => {
                this.Request.get(this.state.getDataParams)
                return res
            })
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        // 查
        search: (value) => {
            const queryParams = Object.assign({}, value)
            const mobileRegx = /^1\d{10}$/gi
            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }
            delete queryParams.createtime
            actionSearch({ value: queryParams, context: this })
        },
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this })
        },
        clearSearch: () => {
            actionClearSearch({ context: this })
        },
        refuse: () => {
            this.Request.refuse({
                ids: this.state.selectedRowKeys
            })
        },
        pass: () => {
            this.Request.pass({
                ids: this.state.selectedRowKeys
            })
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        this.state = {
            // title: title,
            dataSource: [],
            // modalVis: false,
            // modal: {},
            selectedRowKeys: [],
            current: 1,
            // editId: null,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            integralStatusOptions: []
        }
        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.Select,
                    label: '审核状态',
                    id: 'integralStatus',
                    dataSource: this.state.integralStatusOptions
                }, {
                    type: SearchType.DateRange,
                    label: '时间段',
                    id: 'createtime',
                }, {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone',
                }
            ]
        }
        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            }, {
                title: '手机号码',
                dataIndex: 'userMobile',
                key: 'userMobile',
            }, {
                title: '真实姓名',
                dataIndex: 'userRealName',
                key: 'userRealName',
            }, {
                title: '邀请人手机号码/姓名',
                dataIndex: 'referrerPhone',
                key: 'referrerPhone',
            }, {
                title: '提交时间',
                dataIndex: 'createTimeStr',
                key: 'createTimeStr'
            }, {
                title: '审核通过时间',
                dataIndex: 'updateTimeStr',
                key: 'updateTimeStr',
                render: (value, record) => {
                    if (record.integralStatus == 1) {
                        return value
                    }
                }
            }, {
                title: '审核状态',
                dataIndex: 'integralStatusStr',
                key: 'integralStatusStr'
            }
        ];

    }
    render() {
        const { dataSource, selectedRowKeys, current, totalModels, pageSize } = this.state
        const { search, clearSearch, changePage, onShowSizeChange, refuse, pass } = this.Action
        return (
            <div>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Card>
                    <Button className="action-item" onClick={refuse} disabled={selectedRowKeys.length === 0} type="primary">批量拒绝</Button>
                    <Button className="action-item" onClick={pass} disabled={selectedRowKeys.length === 0} type="primary">批量通过</Button>
                </Card>
                <Table
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal,
                        pageSizeOptions: ['50', '100', '200', '500'],
                    }}
                />

            </div>
        )
    }
    componentDidMount() {
        this.Request.getIntegralStatusList();
        this.setState({
            getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
        })
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
    }
}

export default integralAudit
