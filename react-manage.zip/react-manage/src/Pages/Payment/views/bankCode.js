import React, { Component } from 'react'
import { connect } from 'react-redux'
// import is from 'is_js'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, Popconfirm, Button } from 'antd'
import { hasAttr } from '../../../Util/index'
import { formatData, formatParentIdOptions } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
const editTitle = '编辑银行卡编码'
const initGetParams = {
  pageIndex: 1,
  pageSize: 20
}

const pagingUrl = '/system/bank/infos',
  updateUrl = '/system/bank/update';

class BankCode extends Component {
  constructor(props) {
    super(props)
    
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        const { models, totalModels, totalPages } = res
        const dataSource = formatData(models)
        this.setState({
          dataSource,
          totalModels,
          totalPages,
          current: params.pageIndex
        })
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      for (let i in record) {
        if (i == 'storageKey') {
          modal[i] = {
            value: record[i].replace('CashCard_', '')
          }
        } else if (i == 'creditKey') {
          modal[i] = {
            value: record[i].replace('CreditCard_', '')
          }
        } else {
          modal[i] = {
            value: record[i]
          }
        }
      }
      this.setState({
        editId: record.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      for (let i in dataSource) {
        if (dataSource[i].id === editId) {
          const temp = {
            ...dataSource[i],
            ...values,
            creditKey: 'CreditCard_' + values.creditKey,
            storageKey: 'CashCard_' + values.storageKey
          }
          edit(temp)
          break;
        }
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: editTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      totalPages: null,
      getDataParams: {},
    }
    // 表头设置
    this.columns = [
      {
        title: '银行卡名称',
        dataIndex: 'bankName',
        key: 'bankName',
      }, {
        title: '储蓄卡编码',
        dataIndex: 'storageKey',
        key: 'storageKey',
      }, {
        title: '信用卡编码',
        dataIndex: 'creditKey',
        key: 'creditKey',
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item"> 删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '银行卡编码',
        key: 'bankCode',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        label: '银行卡名称',
        key: 'bankName',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.Select,
        label: '储蓄卡',
        key: 'storageKey',
        config: {
          rules: [{ required: true, message: '请选择储蓄卡' }]
        },
        itemConfig: {
          options: formatParentIdOptions({
            options: this.props.cashCardOption,
            hasDefaultOption: false,
            valueKey: 'value'
          })
        }
      }, {
        type: EditType.Select,
        label: '信用卡',
        key: 'creditKey',
        config: {
          rules: [{ required: true, message: '请选择信用卡' }]
        },
        itemConfig: {
          options: formatParentIdOptions({
            options: this.props.creditCardOption,
            hasDefaultOption: false,
            valueKey: 'value'
          })
        }
      }
    ]
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { save, cancel, changePage } = this.Action
    return (
      <div>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    cashCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CashCard'), [0, 'items']) || [],
    creditCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CreditCard'), [0, 'items']) || [],
  }
}
export default connect(mapStateToProps)(BankCode)