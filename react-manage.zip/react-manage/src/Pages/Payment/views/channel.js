import React, { Component } from 'react'
import { connect } from 'react-redux'
import is from 'is_js'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions, toMoney } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import TwoDecimals from './component/TwoDecimals'
import BankCard from './component/BankCard'
const addTitle = '新建通道'
const editTitle = '编辑通道'
const initGetParams = {
  // keyword: '',
  pageIndex: 1,
  // pageSize: 20
}
const newItem = {
  status: 1
}
const pagingUrl = '/system/pass/paging',
  addUrl = '/system/pass/add',
  updateUrl = '/system/pass/update',
  removeUrl = '/system/pass/remove',
  removeListUrl = '/system/pass/removelist',
  updatePropertyUrl = '/system/pass/updateproperty',
  getSourceUrl = '/system/source/paging',
  getProductUrl = '/system/product/paging'
class Channel extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        const { models, totalModels } = res
        const dataSource = formatData(models)
        this.setState({
          dataSource,
          totalModels,
          current: params.pageIndex
        })
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeListUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 获取渠道商名称
    getSource: () => {
      return getFetch(getSourceUrl).then(res => {
        if (res.models && res.models.length) {
          this.setState({
            sourceOptions: res.models
          })
        }
        return res
      })
    },
    //获取产品类型 
    getProduct: () => {
      return getFetch(getProductUrl).then(res => {
        if (res && res.models) {
          this.setState({
            productOptions: res.models
          })
        }
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle
      })
    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems, this.Util.handleEditData)
      for (let i in record) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...value }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId == 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            const temp = this.Util.handleChangedData({ ...dataSource[i], ...values })
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = this.Util.handleChangedData(values);
        add(temp)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    }
  }
  Util = {
    // 更新模态框表单的配置
    updateFormItem: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
        fn(formItem)
      }
    },
    // 处理传入表单的编辑内容的key、value以匹配组件的格式要求
    handleEditData: (obj) => {
      // const temp = Object.assign({}, obj)
      if (is.object(obj)) {
        for (let i in obj.cardAddr) {
          if (obj.cardType[i] == 1) {
            obj.cashCard = obj.cardAddr[i]
            obj.cashCard = JSON.parse(obj.cardAddr[i])
          } else if (obj.cardType[i] == 2) {
            obj.creditCard = JSON.parse(obj.cradAddr[i])
          }
        }
        delete obj.cardAddr
      }
      return obj
    },
    //处理表单的保存内容的key、value以匹配后台的格式
    handleChangedData: (obj) => {
      // const temp = Object.assign({}, obj)
      if (is.object(obj)) {
        obj.codeNo = this.state.sourceOptions.filter(item => item.id == obj.channelId)[0].codeNo
        obj.productCode = this.state.productOptions.filter(item => item.id == obj.productId)[0].productCode
        obj.cardType = []
        obj.cardAddr = []
        if (obj.cashCard) {
          obj.cardType.push(1)
          obj.cardAddr.push(obj.cashCard)
        }
        if (obj.creditCard) {
          obj.cardType.push(2)
          obj.cardAddr.push(obj.creditCard)
        }
        obj.cardArr = JSON.stringify(obj.cardAddr)
        obj.cardType = JSON.stringify(obj.cardType)
      }
      return obj
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      sourceOptions: [],
      productOptions: [],
    }
    // 表头设置
    this.columns = [
      {
        title: '支付渠道商',
        dataIndex: 'channelId',
        key: 'channelId',
        render: id => {
          const options = this.state.sourceOptions
          const option = options.filter(item => item.id == id)
          return hasAttr(option, [0, 'name'])
        }
      },
      {
        title: '支付产品类型',
        dataIndex: 'productId',
        key: 'productId',
        render: id => {
          const options = this.state.productOptions
          const option = options.filter(item => item.id == id)
          return hasAttr(option, [0, 'productName'])
        }
      }, {
        title: '费率',
        dataIndex: 'bond',
        key: 'bond',
        render: value => (value ? value / 100 : 0)
      }, {
        title: '最低手续费',
        dataIndex: 'minBroker',
        key: 'minBroker',
        render: value => toMoney(value)
      }, {
        title: '单笔限额',
        dataIndex: 'single',
        key: 'single',
        render: value => toMoney(value)
      }, {
        title: '单卡单日限额',
        dataIndex: 'singleCD',
        key: 'singleCD',
        render: value => toMoney(value)
      }, {
        title: '单卡单月限额',
        dataIndex: 'singleCM',
        key: 'singleCM',
        render: value => toMoney(value)
      }, {
        title: '最小支付金额',
        dataIndex: 'minPaym',
        key: 'minPaym',
        render: value => toMoney(value)
      }, {
        title: '最大支付金额',
        dataIndex: 'maxPaym',
        key: 'maxPaym',
        render: value => toMoney(value)
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: status => {
          return status == 1 ? '正常' : '不正常'
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item"> 删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.Select,
        label: '支付渠道商名称',
        key: 'channelId',
        config: {
          rules: [{ required: true, message: '请选择支付渠道商名称' }]
        },
        itemConfig: {
          options: []
        }
      },
      {
        type: EditType.Select,
        label: '支付类型产品名称',
        key: 'productId',
        config: {
          rules: [
            { required: true, message: '请选择支付类型产品名称' }
          ]
        },
        itemConfig: {
          // options: formatParentIdOptions({ options: this.props.paymentTypeOptions, hasDefaultOption: false })
          options: this.state.productOptions
        }
      }, {
        type: EditType.InputNum,
        render: TwoDecimals,
        label: '费率',
        key: 'bond',
        config: {
          rules: [
            { required: true, message: '请输入相应费率', },
          ]
        },
        isInputNum: true
      }, {
        type: EditType.InputNum,
        label: '最低手续费',
        key: 'minBroker',
        render: TwoDecimals,
        isInputNum: true
      }, {
        type: EditType.InputNum,
        label: '单笔限额',
        key: 'single',
        render: TwoDecimals,
        isInputNum: true
      }, {
        type: EditType.InputNum,
        label: '单卡单日限额',
        key: 'singleCD',
        render: TwoDecimals,
        isInputNum: true
      }, {
        type: EditType.InputNum,
        label: '单卡单月限额',
        key: 'singleCM',
        render: TwoDecimals,
        isInputNum: true
      },
      {
        type: EditType.InputNum,
        label: '最小支付金额',
        key: 'minPaym',
        render: TwoDecimals,
        isInputNum: true
      }, {
        type: EditType.InputNum,
        label: '最大支付金额',
        key: 'maxPaym',
        render: TwoDecimals,
        isInputNum: true
      }, {
        type: EditType.InputNum,
        key: 'cashCard',
        label: '储蓄卡发卡行支持',
        render: BankCard,
        itemConfig: {
          options: this.props.cashCardOption
        }
      },
      {
        key: 'creditCard',
        label: '信用卡发卡行支持',
        render: BankCard,
        itemConfig: {
          options: this.props.creditCardOption
        }
      }, {
        type: EditType.Select,
        key: 'status',
        label: '状态',
        itemConfig: {
          options: [
            { label: '正常', value: 1 },
            { label: '不正常', value: 0 },
          ]
        }
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, removeItems, save, cancel, changePage, editItems } = this.Action
    return (
      <div>

        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.Request.getSource()
    this.Request.getProduct()
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, sourceOptions, productOptions } = this.state
    const { get } = this.Request
    const { updateFormItem } = this.Util
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    // 监听渠道商下拉选择
    updateFormItem(sourceOptions, nextState.sourceOptions, 'channelId', (formItem) => {
      if (hasAttr(formItem, ['itemConfig', 'options'])) {
        formItem.itemConfig.options = formatParentIdOptions({
          options: nextState.sourceOptions,
          hasDefaultOption: false,
        })
      }
    })
    // 监听产品下拉选择
    updateFormItem(productOptions, nextState.productOptions, 'productId', (formItem) => {
      if (hasAttr(formItem, ['itemConfig', 'options'])) {
        formItem.itemConfig.options = formatParentIdOptions({
          options: nextState.productOptions,
          hasDefaultOption: false,
          labelKey: 'productName'
        })
      }
    })
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    paymentTypeOptions: hasAttr(state.index.dictList.filter((item, index) => item.value === 'PaymentType'), [0, 'items']) || [],
    cashCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CashCard'), [0, 'items']) || [],
    creditCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CreditCard'), [0, 'items']) || [],

  }
}
export default connect(mapStateToProps)(Channel)