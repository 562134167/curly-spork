import React, { Component } from 'react'
import is from 'is_js'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions, toMoney } from '../../../Util/reactUtil'
import { hasAttr, getQueryObj } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import PayTime from './component/PayTime'
import BankCard from './component/BankCard'
import TwoDecimals from './component/TwoDecimals'
import RepayLeave from './component/RepayLeave'
const addTitle = '新建代付'
const editTitle = '编辑代付'
const initGetParams = {
  pageIndex: 1,
}
const newItem = {
  status: 1
}
const pagingUrl = '/system/helppay/paging',
  addUrl = '/system/helppay/add',
  updateUrl = '/system/helppay/update',
  removeUrl = '/system/helppay/remove',
  removeListUrl = '/system/helppay/removelist',
  updatePropertyUrl = '/system/helppay/updateproperty',
  getSourceUrl = '/system/source/paging'
export default class HelpPay extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      const queryObj = getQueryObj(this.props.location.search) || {}
      return getFetch(pagingUrl, { ...params, ...queryObj }).then(res => {
        const { models, totalModels } = res
        const dataSource = formatData(models)
        this.setState({
          dataSource,
          totalModels,
          current: params.pageIndex
        })
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params, { arrayFormat: 'indices' }).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeListUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params, { arrayFormat: 'indices' }).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 获取渠道商名称
    getSource: () => {
      return getFetch(getSourceUrl).then(res => {
        if (res.models && res.models.length) {
          this.setState({
            sourceOptions: res.models
          })
        }
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle,
        fileList: []
      })
    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems, this.Util.handleEditData)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...value }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            const temp = this.Util.handleChangedData({ ...dataSource[i], ...values })
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = this.Util.handleChangedData(values);
        add(temp)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    }
  }
  Util = {
    // 更新模态框表单的配置
    updateFormItem: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
        fn(formItem)
      }
    },
    // 处理传入表单的编辑内容的key、value以匹配组件的格式要求
    handleEditData: (obj) => {
      // const temp = Object.assign({}, obj)
      if (is.object(obj)) {
        // 代付账号类型单笔限额账号总限额
        if (is.array(obj.repayLeaveModelList)) {
          const repayLeaveModelList = obj.repayLeaveModelList
          for (let i in repayLeaveModelList) {
            const repayLeave = repayLeaveModelList[i]
            if (repayLeave.accountType === 1) {
              obj.public = {
                single: repayLeave.single && repayLeave.single / 100,
                total: repayLeave.total && repayLeave.total / 100,
              }
            } else if (repayLeave.accountType === 2) {
              obj.personal = {
                single: repayLeave.single && repayLeave.single / 100,
                total: repayLeave.total && repayLeave.total / 100,
              }
            }
          }
        }
        // 卡类型支持
        if (is.array(obj.cardModelList)) {
          const cardModelList = obj.cardModelList
          for (let i in cardModelList) {
            const card = cardModelList[i]
            if (card.type === 1) {
              obj.cashCard = card.cardAddr
            } else if (card.type === 2) {
              obj.creditCard = card.cardAddr
            }
          }
        }
        delete obj.repayLeaveModelList
        delete obj.cardModelList
      }
      return obj
    },
    //处理表单的保存内容的key、value以匹配后台的格式
    handleChangedData: (obj) => {
      // const temp = Object.assign({}, obj)
      if (is.object(obj)) {
        // 代付账号类型单笔限额账号总限额
        obj.repayLeaveModelList = []
        if (hasAttr(obj.public, 'single') || hasAttr(obj.public, 'total')) {
          obj.repayLeaveModelList.push({
            accountType: 1,
            single: obj.public.single,
            total: obj.public.total
          })
        }
        if (hasAttr(obj.personal, 'single') || hasAttr(obj.personal, 'total')) {
          obj.repayLeaveModelList.push({
            accountType: 2,
            single: obj.personal.single,
            total: obj.personal.total
          })
        }
        // 卡类型支持
        obj.cardModelList = []
        if (!is.undefined(obj.cashCard)) {
          obj.cardModelList.push({
            type: 1,
            cardAddr: obj.cashCard
          })
        }
        if (!is.undefined(obj.creditCard)) {
          obj.cardModelList.push({
            type: 2,
            cardAddr: obj.creditCard
          })
        }
        delete obj.public
        delete obj.personal
        delete obj.cashCard
        delete obj.creditCard
      }
      return obj
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      sourceOptions: []
    }
    // 搜索面板元数据
    // this.metadata = {
    //   // orders: [
    //   //   { value: 'num', label: '排序号' },
    //   // ],
    //   conditions: []
    // }
    // 表头设置
    this.columns = [
      {
        title: '支付渠道商',
        dataIndex: 'channelId',
        key: 'channelId',
        render: id => {
          const options = this.state.sourceOptions
          const option = options.filter(item => item.id == id)
          return hasAttr(option, [0, 'name'])
        }
      },
      {
        title: '代付手续费',
        key: 'repayRate',
        dataIndex: 'repayRate',
        render: value => toMoney(value)
      },
      {
        title: '代付服务费比例',
        key: 'repayServration',
        dataIndex: 'repayServration',
        render: value => value || 0
      },
      {
        title: '最高手续费',
        key: 'repayMaxRate',
        dataIndex: 'repayMaxRate',
        render: value => toMoney(value)
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: status => {
          return status == 1 ? '正常' : '不正常'
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item"> 删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.Select,
        label: '支付渠道商名称',
        key: 'channelId',
        config: {
          rules: [{ required: true, message: '请选择支付渠道商名称' }]
        },
        itemConfig: {
          options: []
        }
      }, {
        key: 'repayDateModelList',
        label: '代付时间、批次',
        render: PayTime,
        itemLayout: {
          wrapperCol: { span: 24 }
        }
      },
      {
        type: EditType.InputNum,
        render: TwoDecimals,
        key: 'repayRate',
        label: '代付手续费',
        isInputNum: true
      },
      {
        type: EditType.InputNum,
        render: TwoDecimals,
        key: 'repayServration',
        label: '代付服务费比例',
        isInputNum: true
      },
      {
        type: EditType.InputNum,
        render: TwoDecimals,
        key: 'repayMaxRate',
        label: '最高手续费',
        isInputNum: true
      },
      {
        type: EditType.InputNum,
        render: RepayLeave,
        key: 'public',
        label: '对公账号',
        isInputNum: true,
        numKey: ['single', 'total']
      }, {
        type: EditType.InputNum,
        render: RepayLeave,
        key: 'personal',
        label: '对私账号',
        isInputNum: true,
        numKey: ['single', 'total']
      }, {
        key: 'cashCard',
        label: '储蓄卡发卡行支持',
        render: BankCard,
        itemConfig: {
          options: []
        }
      },
      {
        key: 'creditCard',
        label: '信用卡发卡行支持',
        render: BankCard
      }, {
        type: EditType.Select,
        key: 'status',
        label: '状态',
        itemConfig: {
          options: [
            { label: '正常', value: 1 },
            { label: '不正常', value: 0 },
          ]
        }
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, removeItems, save, cancel, changePage, editItems } = this.Action
    return (
      <div>
        {/* <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        /> */}
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
    this.Request.getSource()
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, sourceOptions } = this.state
    const { get } = this.Request
    const { updateFormItem } = this.Util
    // console.log(nextState.selectedRowKeys)
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    // 监听渠道商下拉选择
    updateFormItem(sourceOptions, nextState.sourceOptions, 'channelId', (formItem) => {
      if (hasAttr(formItem, ['itemConfig', 'options'])) {
        formItem.itemConfig.options = formatParentIdOptions({
          options: nextState.sourceOptions,
          hasDefaultOption: false,
        })
      }
    })
  }
}