import React, { PureComponent } from 'react'
import { DatePicker, Upload, Button, Tag, Icon } from 'antd'
import is from 'is_js'
import moment from 'moment'
import { bindFunc } from '../../../../Util/reactUtil'
// import { hasAttr } from '../../../../Util'
const { RangePicker } = DatePicker
export default class Agreement extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || {}
    bindFunc([{ key: 'Action', value: ['onDateChange', 'onFileChange', 'deleteItem'] }], this)
    this.state = {
      agreement: this.Util.formatAgreement(value.agreement),
      validity: this.Util.formatDate(value.validity)
    }
  }
  Util = {
    formatDate: (dateArr) => {
      const temp = [];
      for (let i in dateArr) {
        temp.push({
          from: (dateArr[i].from && moment(dateArr[i].from, 'YYYY:MM:DD')) || undefined,
          to: (dateArr[i].to && moment(dateArr[i].to, 'YYYY:MM:DD')) || undefined,
          id: dateArr[i].id || (new Date().getTime() + i)
        })
      }
      return temp
    },
    formatAgreement: (arr) => {
      const temp = [];
      for (let i in arr) {
        // if (arr[i]) {
        //   temp.push({
        //     uid: arr[i].uid || new Date().getTime(),
        //     status: arr[i].status || (arr[i].response ? 'done' : null),
        //     url: arr[i].url || arr[i].response,
        //     name: arr[i].name || arr[i]
        //   })
        // } else {
        //   temp.push(arr[i])
        // }
        if (is.object(arr[i])) {
          temp.push(Object.assign({}, arr[i], { url: arr[i].url || arr[i].response }))
        } else if (is.string(arr[i])) {
          temp.push({
            uid: arr[i],
            name: i,
            url: arr[i]
          })
        } else {
          temp.push(arr[i])
        }

      }
      return temp
    }
  }
  Action = {
    deleteItem: (index) => {
      const agreement = Object.assign([], this.state.agreement)
      const validity = Object.assign([], this.state.validity)
      agreement.splice(index, 1)
      validity.splice(index, 1)
      if (!('value' in this.props)) {
        this.setState({
          agreement,
          validity
        })
      }
      this.Action.triggerChange({
        agreement,
        validity
      })
    },
    onDateChange: (dateString, index) => {
      const validity = Object.assign([], this.state.validity)
      // validity[index] = {
      //   from: dateString[0],
      //   to: dateString[1]
      // }
      validity[index].from = dateString[0]
      validity[index].to = dateString[1]
      if (!('value' in this.props)) {
        this.setState({
          validity
        })
      }
      this.Action.triggerChange({
        validity,
        agreement: this.state.agreement
      })
    },
    onFileChange: ({ file, fileList }, index) => {
      const agreement = Object.assign([], this.state.agreement)
      agreement[index] = fileList[0]
      if (!('value' in this.props)) {
        this.setState({
          agreement
        })
      }
      this.Action.triggerChange({
        validity: this.state.validity,
        agreement
      })
    },
    newTime: () => {
      const validity = Object.assign([], this.state.validity)
      validity.push({
        from: undefined,
        to: undefined,
        id: new Date().getTime()
      })
      const agreement = Object.assign([], this.state.agreement)
      agreement.push(undefined)
      if (!('value' in this.props)) {
        this.setState({
          agreement,
          validity
        })
      }
      this.Action.triggerChange({
        agreement: agreement,
        validity: validity
      })
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(changedValue)
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value || []
      this.setState({
        agreement: this.Util.formatAgreement(value.agreement),
        validity: this.Util.formatDate(value.validity)
      })
    }
  }
  RenderFunc = {
    renderTime: (agreement, validity) => {
      const { onDateChange, onFileChange, deleteItem } = this.Action
      return validity.map((item, index) => {
        return (
          <Tag
            closable
            onClose={() => deleteItem(index)}
            key={item.id}
          >
            <span style={{ marginRight: '2%' }}>
              <RangePicker
                value={[item.from, item.to]}
                onChange={(date, dateString) => onDateChange(dateString, index)}
                format="YYYY/MM/DD"
                addon={panel => (
                  <Button size="small" type="primary" onClick={() => panel.close()}>
                    确定
                  </Button>
                )}
              />
            </span>
            <Upload
              withCredentials={true}
              name='files'
              accept='.doc, .pdf, .docx'
              action={this.props.item.itemConfig.uploadUrl}
              fileList={agreement[index] && [agreement[index]]}
              onChange={({ file, fileList }) => onFileChange({ file, fileList }, index)}
            >
              {
                agreement[index] ? null : (
                  <Button>
                    <Icon type="upload" /> 上传
                  </Button>
                )
              }
            </Upload>

          </Tag >

        )
      })
    }
  }
  render() {
    const { newTime } = this.Action
    const { validity, agreement } = this.state
    return (
      <div className="agreement">
        <div>
          <Button type="primary" onClick={newTime}>新增</Button>
        </div>
        {this.RenderFunc.renderTime(agreement, validity)}
      </div>
    )
  }
}