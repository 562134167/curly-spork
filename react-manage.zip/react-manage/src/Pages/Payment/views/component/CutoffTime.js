import React, { PureComponent } from 'react'
import { Radio, Input } from 'antd'
import { changeTwoDecimal } from '../../../../Util/index'
import is from 'is_js'
const RadioGroup = Radio.Group
export default class CutoffTime extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || {}
    this.state = {
      radioVal: value.radioVal || '',
      inputVal: changeTwoDecimal(value.inputVal || 0)
    }
  }
  Action = {
    onRadioChange: (e) => {
      // console.log('radio checked', e.target.value);
      const radioVal = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          radioVal
        });
      }
      this.Action.triggerChange({ radioVal });
    },
    onInputChange: (e) => {
      const inputVal = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          inputVal
        })
      }
      this.Action.triggerChange({ inputVal })
    },
    onInputBlur: (e) => {
      const inputVal = changeTwoDecimal(e.target.value)
      if (!('value' in this.props)) {
        this.setState({
          inputVal
        })
      }
      this.Action.triggerChange({ inputVal })
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(Object.assign({}, this.state, changedValue))
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value
      this.setState(value)
    }
  }

  render() {
    const { onRadioChange, onInputChange, onInputBlur } = this.Action
    const { item } = this.props
    const options = !is.undefined(item.itemConfig.options) && item.itemConfig.options
    const { radioVal, inputVal } = this.state
    return (
      <div>
        <RadioGroup onChange={onRadioChange} value={radioVal}>
          {
            is.array(options) && options.map((o, index) => (
              <Radio value={o.value} key={index}> {o.label}</Radio>
            ))
          }
        </RadioGroup>
        <Input
          type="number"
          value={inputVal}
          onChange={onInputChange}
          onBlur={onInputBlur}
          style={{ marginRight: '3%' }}
        />
      </div>
    )
  }
}