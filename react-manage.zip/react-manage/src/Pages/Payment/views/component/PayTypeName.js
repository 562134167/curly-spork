import React, { PureComponent } from 'react'
import { Input } from 'antd'
import { hasAttr } from '../../../../Util/index'
export default class PayTypeName extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || ''
    this.state = {
      value,
      platCode: this.props.form.getFieldValue('platCode'),
      typeCode: this.props.form.getFieldValue('typeCode')
    }
  }
  Action = {
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(changedValue)
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    const { platCode, typeCode } = this.state
    const nextPlatCode = nextProps.form.getFieldValue('platCode')
    const nextTypeCode = nextProps.form.getFieldValue('typeCode')
    if (nextPlatCode !== platCode || nextTypeCode !== typeCode)
      if (hasAttr(nextProps, ['item', 'itemConfig', 'getValue'])) {
        this.setState({
          platCode: nextPlatCode,
          typeCode: nextTypeCode
        })
        const value = nextProps.item.itemConfig.getValue(nextPlatCode, nextTypeCode)
      
        this.Action.triggerChange(value)
      }
    if ('value' in nextProps) {
      this.setState({
        value: nextProps.value
      })
    }
  }

  render() {
    const { value } = this.state
    return (
      <div>
        <Input
          value={value}
          disabled
        />
      </div>
    )
  }
}