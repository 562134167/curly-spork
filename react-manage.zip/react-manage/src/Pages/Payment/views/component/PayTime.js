import React, { PureComponent } from 'react'
import { Radio, InputNumber, TimePicker,  Button } from 'antd'
// import { changeTwoDecimal } from '../../../../Util/index'
import moment from 'moment'
import { bindFunc } from '../../../../Util/reactUtil'
const RadioGroup = Radio.Group

const limitVal = [{
  startTIme: moment().format('x'),
  endTime: moment().format('x'),
  timeType: '1',
  batch: 0
}, {
  startTIme: moment().format('x'),
  endTime: moment().format('x'),
  timeType: '2',
  batch: 0
}]
const anyVal = [{
  startTIme: moment().format('x'),
  endTime: moment().format('x'),
  timeType: '0',
  batch: 0
}]
const format = 'HH:mm';
export default class PayTime extends PureComponent {
  constructor(props) {
    super(props)
    let value = this.props.value || []
    value = this.Util.formatTime(value.length ? value : anyVal)
    bindFunc([{ key: 'Action', value: ['onRadioChange'] }], this)
    this.state = {
      radioVal: value && value[0] && (value[0].timeType !== '0'),
      anyVal: this.Util.getVal(value, '0'),
      workDayVal: this.Util.getVal(value, '1'),
      offDayVal: this.Util.getVal(value, '2')
    }
  }
  Util = {
    getVal: (val, timeType) => {
      if (val && val.length) {
        for (let i in val) {
          if (val[i].timeType == timeType) {
            return val[i]
          }
        }
      }
      return {}
    },
    formatTime: (timeArr) => {
      var temp = [];
      for (let i in timeArr) {        
        temp.push({
          startTime: (timeArr[i].startTime && moment(timeArr[i].startTime, 'x')) || undefined,
          endTime: (timeArr[i].endTime && moment(timeArr[i].endTime, 'x')) || undefined,
          timeType: timeArr[i].timeType,
          batch: timeArr[i].batch
        })
      }
      return temp
    },
    formatChangedData: (timeArr) => {
      var temp = [];
      for (let i in timeArr) {
        console.log(timeArr[i].batch)
        temp.push({
          startTime: (timeArr[i].startTime && timeArr[i].startTime.format('x')) || undefined,
          endTime: (timeArr[i].endTime && timeArr[i].endTime.format('x')) || undefined,
          timeType: timeArr[i].timeArr,
          batch: timeArr[i].batch
        })
      }
      return temp
    },
  }
  Action = {
    onRadioChange: (e) => {
      const radioVal = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          radioVal
        })
      }
      if (radioVal) {
        this.Action.triggerChange(limitVal)
      } else {
        this.Action.triggerChange(anyVal)
      }
    },
    onTimeChange: ({ time, parent, rangeType }) => {
      let value = this.props.value || []
      value = value.length ? value : anyVal
      for (let i in value) {
        if (value[i].timeType == parent.timeType) {
          value[i][rangeType] = time.format('x')
          this.Action.triggerChange(value)
          break;
        }
      }
    },
    onInputChange: ({ num, parent }) => {
      let value = this.props.value || []
      value = value.length ? value : anyVal
      for (let i in value) {
        if (value[i].timeType == parent.timeType) {
          value[i]['batch'] = num
          this.Action.triggerChange(value)
          break;
        }
      }
    },
    triggerChange: (value) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(value)
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = this.Util.formatTime((nextProps.value && nextProps.value.length) ? nextProps.value : anyVal)
      this.setState({
        radioVal: value && value[0] && (value[0].timeType !== '0'),
        anyVal: this.Util.getVal(value, '0'),
        workDayVal: this.Util.getVal(value, '1'),
        offDayVal: this.Util.getVal(value, '2')
      })
    }
  }

  render() {
    const { radioVal, anyVal, workDayVal, offDayVal } = this.state
    const { onRadioChange, onInputChange, onTimeChange } = this.Action
    return (
      <div className="pay-time">
        <RadioGroup value={radioVal} onChange={onRadioChange}>
          <Radio value={false}>
            <div className="ant-row ant-form-item">
              <div className="ant-form-item-label ant-col-xs-24 ant-col-sm-6">
                <label title="不限代付时间">不限代付时间</label>
              </div>
              <div className="ant-col-xs-24 ant-col-sm-13 ant-form-item-control-wrapper">
                <TimePicker
                  format={format}
                  disabled={radioVal}
                  value={moment((anyVal && anyVal.startTime) || '00:00', 'HH:mm')}
                  onChange={(time, timeString) => { onTimeChange({ time, rangeType: 'startTime', parent: anyVal }) }}
                  addon={panel => (
                    <Button size="small" type="primary" onClick={() => panel.close()}>
                      确定
                      </Button>
                  )}
                />至
                  <TimePicker
                  format={format}
                  disabled={radioVal}
                  value={moment((anyVal && anyVal.endTime) || '00:00', 'HH:mm')}
                  onChange={(time, timeString) => { onTimeChange({ time, rangeType: 'endTime', parent: anyVal }) }}
                  addon={panel => (
                    <Button size="small" type="primary" onClick={() => panel.close()}>
                      确定
                      </Button>
                  )}
                />
              </div>
            </div>
            <div className="ant-row ant-form-item">
              <div className="ant-form-item-label ant-col-xs-24 ant-col-sm-6">
                <label title="不限代付批次">不限代付批次</label>
              </div>
              <div className="ant-col-xs-24 ant-col-sm-13 ant-form-item-control-wrapper">
                <InputNumber 
                  disabled={radioVal}
                  value={anyVal && anyVal.batch}
                  onChange={(value) => onInputChange({ num: value, parent: anyVal })}
                />
              </div>
            </div>
          </Radio>
          <Radio value={true}>
            <div className="ant-row ant-form-item">
              <div className="ant-form-item-label ant-col-xs-24 ant-col-sm-6">
                <label title="工作日代付时间">工作日代付时间</label>
              </div>
              <div className="ant-col-xs-24 ant-col-sm-13 ant-form-item-control-wrapper">
                <TimePicker
                  format={format}
                  disabled={!radioVal}
                  value={moment((workDayVal && workDayVal.startTime) || '00:00', 'HH:mm')}
                  onChange={(time, timeString) => { onTimeChange({ time, rangeType: 'startTime', parent: workDayVal }) }}
                  addon={
                    panel => (
                      <Button size="small" type="primary" onClick={() => panel.close()}>
                        确定
                        </Button>
                    )
                  }
                />
                至
                  <TimePicker
                  format={format}
                  disabled={!radioVal}
                  value={moment((workDayVal && workDayVal.endTime) || '00:00', 'HH:mm')}
                  onChange={(time, timeString) => { onTimeChange({ time, rangeType: 'endTime', parent: workDayVal }) }}
                  addon={panel => (
                    <Button size="small" type="primary" onClick={() => panel.close()}>
                      确定
                      </Button>
                  )}
                />
              </div>
            </div>
            <div className="ant-row ant-form-item">
              <div className="ant-form-item-label ant-col-xs-24 ant-col-sm-6">
                <label title="工作日代付批次">工作日代付批次</label>
              </div>
              <div className="ant-col-xs-24 ant-col-sm-13 ant-form-item-control-wrapper">
                <InputNumber 
                  disabled={!radioVal}
                  value={workDayVal && workDayVal.batch}
                  onChange={(value) => onInputChange({ num: value, parent: workDayVal })}
                />
              </div>
            </div>
            <div className="ant-row ant-form-item">
              <div className="ant-form-item-label ant-col-xs-24 ant-col-sm-6">
                <label title="非工作日代付时间">非工作日代付时间</label>
              </div>
              <div className="ant-col-xs-24 ant-col-sm-13 ant-form-item-control-wrapper">
                <TimePicker
                  format={format}
                  disabled={!radioVal}
                  value={moment((offDayVal && offDayVal.startTime) || '00:00', 'HH:mm')}
                  onChange={(time, timeString) => { onTimeChange({ time, rangeType: 'startTime', parent: offDayVal }) }}
                  addon={
                    panel => (
                      <Button size="small" type="primary" onClick={() => panel.close()}>
                        确定
                        </Button>
                    )
                  }
                />
                至
                  <TimePicker
                  format={format}
                  disabled={!radioVal}
                  value={moment((offDayVal && offDayVal.endTime) || '00:00', 'HH:mm')}
                  onChange={(time, timeString) => { onTimeChange({ time, rangeType: 'endTime', parent: offDayVal }) }}
                  addon={panel => (
                    <Button size="small" type="primary" onClick={() => panel.close()}>
                      确定
                      </Button>
                  )}
                />
              </div>
            </div>
            <div className="ant-row ant-form-item">
              <div className="ant-form-item-label ant-col-xs-24 ant-col-sm-6">
                <label title="非工作日代付批次">非工作日代付批次</label>
              </div>
              <div className="ant-col-xs-24 ant-col-sm-13 ant-form-item-control-wrapper">
                <InputNumber 
                  disabled={!radioVal}
                  value={offDayVal && offDayVal.batch}
                  onChange={(value) => onInputChange({ num: value, parent: offDayVal })}
                />
              </div>
            </div>
          </Radio>
        </RadioGroup>
      </div>
    )
  }
}