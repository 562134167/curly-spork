import React, { PureComponent } from 'react'
import { Modal, Checkbox, Button, Tag } from 'antd'
import { bindFunc } from '../../../../Util/reactUtil'
import { hasAttr } from '../../../../Util/index'
const CheckboxGroup = Checkbox.Group
const LabelComponent = ({ name, imgSrc }) => (
  <span>
    <div>{name}</div>
    <img alt={name} src={imgSrc} />
  </span>
)
export default class BankCard extends PureComponent {
  constructor(props) {
    super(props)
    bindFunc([{ key: 'Action', value: ['handleOk', 'handleCancel', 'openCardModal', 'handleCheckboxChange'] }], this)
    const value = this.props.value || []
    this.state = {
      modalVis: false,
      cardList: value,
      tagList: []
    }
    this.onInit()
  }
  Util = {
    getTagList: (arr, plainOptions) => {
      const tagList = []
      for (let i in arr) {
        for (let j in plainOptions) {
          if (arr[i] == plainOptions[j].value) {
            tagList.push(plainOptions[j])
          }
        }
      }
      return tagList
    },
    getPlainOptions: (options) => {
      const plainOptions = []
      for (let i in options) {
        const plainOption = {
          value: options[i].value,
          name: options[i].name,
          label: <LabelComponent name={options[i].name} imgSrc={options[i].imgSrc} />
        }
        plainOptions.push(plainOption)
      }
      return plainOptions
    }
  }
  Action = {
    handleOk: () => {
      this.Action.triggerChange(this.state.cardList)
      this.setState({
        modalVis: false
      })
    },
    handleCancel: () => {
      this.setState({
        modalVis: false
      })
    },
    openCardModal: () => {
      if (this.plainOptions && this.plainOptions.length) {
        this.setState({
          modalVis: true
        })
      }
    },
    handleCheckboxChange: (checkedValues) => {
      const cardList = checkedValues
      this.setState({
        cardList
      })
    },
    triggerChange: (value) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(value)
      }
    }
  }
  onInit() {
    const options = hasAttr(this.props, ['item', 'itemConfig', 'options']) || []
    this.plainOptions = this.Util.getPlainOptions(options)
  }
  componentDidMount() {
    const value = this.props.value || []
    this.setState({
      tagList: this.Util.getTagList(value, this.plainOptions)
    })
  }

  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value
      this.setState({
        value,
        tagList: this.Util.getTagList(value, this.plainOptions)
      })
    }
  }

  render() {
    const { modalVis, cardList,  tagList } = this.state
    const { typeName } = this.props
    const { handleCancel, handleOk, openCardModal, handleCheckboxChange } = this.Action
    return (
      <div>
        <Button type="primary" onClick={openCardModal}>选择卡</Button>
        {
          tagList && tagList.map((item, index) => (
            <Tag color="blue" key={index}>{item.name}</Tag>
          ))
        }
        <Modal
          visible={modalVis}
          title={`选择${typeName || ''}`}
          closable={true}
          maskClosable={true}
          onOk={handleOk}
          onCancel={handleCancel}
          className="bank-card-modal"
        >
          <CheckboxGroup options={this.plainOptions} value={cardList} onChange={(checkedValues) => { handleCheckboxChange(checkedValues) }} />
        </Modal>
      </div>
    )
  }
}