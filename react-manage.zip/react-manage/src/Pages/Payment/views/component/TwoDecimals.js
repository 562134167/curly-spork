import React, { PureComponent } from 'react'
import { Input } from 'antd'
import is from 'is_js'
import { changeTwoDecimal } from '../../../../Util/index'
export default class TwoDecimals extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value
    this.state = {
      value: changeTwoDecimal(value || 0)
    }
  }
  Action = {
    onInputChange: (e) => {
      const value = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    onInputBlur: (e) => {
      const value = changeTwoDecimal(e.target.value)
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(changedValue)
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value
      if (!is.undefined(value)) {
        this.setState({ value })
      }
    }
  }

  render() {
    const { onInputChange, onInputBlur } = this.Action
    const { value } = this.state
    return (
      <div>
        <Input
          type="number"
          value={value}
          onChange={onInputChange}
          onBlur={onInputBlur}
        />
      </div>
    )
  }
}