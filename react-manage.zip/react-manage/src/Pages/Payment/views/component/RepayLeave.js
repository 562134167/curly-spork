import React, { PureComponent } from 'react'
import { Input } from 'antd'
import is from 'is_js'
import { changeTwoDecimal } from '../../../../Util/index'
export default class TwoDecimals extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || {}
    this.state = {
      single: changeTwoDecimal(value.single || 0),
      total: changeTwoDecimal(value.total || 0),
    }
  }
  Action = {
    onInputChange: (e, type) => {
      const value = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          [type]: value
        })
      }
      this.Action.triggerChange({
        [type]: value
      })
    },
    onInputBlur: (e, type) => {
      const value = changeTwoDecimal(e.target.value)
      if (!('value' in this.props)) {
        this.setState({
          [type]: value
        })
      }
      this.Action.triggerChange({ [type]: value })
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(Object.assign({}, this.state, changedValue))
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value
      console.log('value',value)
      
      if (!is.undefined(value)) {
        this.setState(value)
      }
    }
  }

  render() {
    const { onInputChange, onInputBlur } = this.Action
    const { single, total } = this.state
    return (
      <div>
        <Input
          type="number"
          value={single}
          placeholder="单笔限额"
          onChange={(e) => onInputChange(e, 'single')}
          onBlur={(e) => onInputBlur(e, 'single')}
          style={{width: '50%'}}
        />
        <Input
          type="number"
          value={total}
          placeholder="账号总限额"
          onChange={(e) => onInputChange(e, 'total')}
          onBlur={(e) => onInputBlur(e, 'total')}
          style={{width: '50%'}}
        />
      </div>
    )
  }
}