import React, { Component } from 'react'
import { Modal, Card, Col, Row } from 'antd'
import { bindFunc } from '../../../../Util/reactUtil'
export default class ImgModal extends Component {
  constructor(props) {
    super(props);
    bindFunc([{ key: 'Action', value: ['handleDownload'] }], this)
  }
  Action = {
    handleDownload: () => {
      this.refs.download.click()
      this.props.handleCancel()
    }
  }
  render() {
    const { handleDownload } = this.Action
    const { handleCancel, modalVis, agreement } = this.props
    return (
      modalVis && agreement && agreement.length ? (
        <Modal
          title="协议"
          visible={true}
          onOk={handleDownload}
          onCancel={handleCancel}
          closable={true}
          okText={'下载'}
          cancelText={'关闭'}
          maskClosable={false}
        >
          <a ref="download" style={{ display: 'none' }} target="on_blank" href={this.props.downloadUrl} download={this.props.downloadUrl}></a>
          <Row>
            {
              agreement.map((item, index) => (
                <Col span="24" key={index}>
                  <Card bordered={true} style={{ textAlign: 'center' }}>
                    <a href={item} target="on_blank">{item}</a>
                  </Card>
                </Col>
              ))
            }
          </Row>
        </Modal>) : null
    )
  }
  componentDidMount() {
    const { agreement } = this.props
    if (!(agreement && agreement.length)) {
      // message.error('暂未上传协议！')
    }
  }

}