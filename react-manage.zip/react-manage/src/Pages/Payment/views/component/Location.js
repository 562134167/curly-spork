import React, { PureComponent } from 'react'
import { Cascader, Input } from 'antd'
import { hasAttr } from '../../../../Util'
// import is from 'is_js'
export default class Location extends PureComponent {
  constructor(props) {
    super(props)
    const value = Object.assign([], [null, null, null, null], (this.props.value || '').split(','))
    this.state = {
      options: value.slice(0, 3),
      inputVal: value[3]
    }
  }

  Action = {
    onCascaderChange: (value) => {
      if (!('value' in this.props)) {
        this.setState({
          options: value
        })
      }
      const temp = Object.assign([], [null, null, null, null], value);
      temp[3] = this.state.inputVal
      this.Action.triggerChange(temp)
    },
    onInputChange: (e) => {
      const inputVal = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          inputVal
        })
      }
      const temp = Object.assign([], [null, null, null, null], this.state.options);
      temp[3] = inputVal
      this.Action.triggerChange(temp)
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(changedValue.join(','))
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      // this.setState(value)
      const value = Object.assign([], [null, null, null, null], (nextProps.value || '').split(','))
      this.setState({
        options: value.slice(0, 3),
        inputVal: value[3]
      })
    }
  }

  render() {
    const { onCascaderChange, onInputChange } = this.Action
    const { item } = this.props
    const { options, inputVal } = this.state
    return (
      <div>
        <Cascader
          placeholder={item.itemConfig.cascaderPlaceholder}
          options={hasAttr(this.props, ['item', 'itemConfig', 'options']) || []}
          onChange={onCascaderChange}
          notFoundContent="目前无选项可选"
          changeOnSelect
          value={options}
        />
        <Input
          type="text"
          value={inputVal}
          onChange={onInputChange}
          style={{ marginRight: '3%' }}
          placeholder={item.itemConfig.inputPlaceholder}
        />
      </div>
    )
  }
}