import React, { Component } from 'react'
import { connect } from 'react-redux'
import is from 'is_js'
// import moment from 'moment'
// import SearchPanel from '../../../Common/searchPanel'
// import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import PayTypeName from './component/PayTypeName'
const addTitle = '新建产品类型'
const editTitle = '编辑产品类型'
const initGetParams = {
  // keyword: '',
  pageIndex: 1,
  // pageSize: 20
}
const newItem = {
  status: '1'
}
const pagingUrl = '/system/product/paging',
  addUrl = '/system/product/add',
  updateUrl = '/system/product/update',
  removeUrl = '/system/product/remove',
  removeListUrl = '/system/product/removelist',
  updatePropertyUrl = '/system/product/updateproperty'
class PayType extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        const { models, totalModels } = res
        const dataSource = formatData(models)
        console.log(params)
        this.setState({
          dataSource,
          totalModels,
          current: params.pageIndex
        })
        return res
      })
    },
    // 添加数据
    add: (params) => {
      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          console.log(selectedRowKeys[i])
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeListUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        console.log(`edit`, params)
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle
      })
    },
    // 删
    remove: (id) => {
      this.Request.delete({ id })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      console.log(selectedRowKeys)
      this.Request.deleteItems({ ids: selectedRowKeys })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      console.log(record)
      const obj = formateEditData(record, this.formItems)
      for (let i in record) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...value }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      values.productCode = values.platCode + '-' + values.typeCode
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            edit({
              ...dataSource[i],
              ...values,
            })
            break;
          }
        }
      } else {
        // 新增状态下的保存
        add(values)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      searchId: this.props.location.search.id
    }
    // 表头设置
    this.columns = [
      {
        title: '支付产品类型名称',
        dataIndex: 'productName',
        key: 'productName',
      }, {
        title: '支付类型',
        dataIndex: 'typeCode',
        key: 'typeCode',
        render: value => {
          const options = this.props.paymentTypeOptions && this.props.paymentTypeOptions.filter(item => item.value === value)
          return hasAttr(options, [0, 'name']) || ''
        },
      }, {
        title: '支付平台',
        dataIndex: 'platCode',
        key: 'platCode',
        render: value => {
          const options = this.props.paymentPlatformOptions && this.props.paymentPlatformOptions.filter(item => item.value === value)
          console.log(options)
          return hasAttr(options, [0, 'name']) || ''
        },
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: (text, record, index) => (
          text === '1' ? '正常' : '不正常'
        )
      },
      {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item"> 删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        // type: EditType.InputStr,
        label: '支付产品类型名称',
        key: 'productName',
        render: PayTypeName,
        itemConfig: {
          getValue: (platCode, typeCode) => {
            let value = ''
            if (!is.undefined(platCode)) {
              let options = this.props.paymentPlatformOptions && this.props.paymentPlatformOptions.filter(item => item.value === platCode)
              value += (hasAttr(options, [0, 'name']) || '') + '-'
            }
            if (!is.undefined(typeCode)) {
              let options = this.props.paymentTypeOptions && this.props.paymentTypeOptions.filter(item => item.value === typeCode)
              value += hasAttr(options, [0, 'name']) || ''
            }
            return value
          }
        }
      }, {
        type: EditType.Select,
        label: '支付平台',
        key: 'platCode',
        config: {
          rules: [
            { required: true, message: '请选择支付平台' },
          ]
        },
        itemConfig: {
          options: formatParentIdOptions({ options: this.props.paymentPlatformOptions, hasDefaultOption: false, valueKey: 'value' })
        }
      }, {
        type: EditType.Select,
        label: '支付类型',
        key: 'typeCode',
        config: {
          rules: [
            { required: true, message: '请选择支付类型' },
          ]
        },
        itemConfig: {
          options: formatParentIdOptions({ options: this.props.paymentTypeOptions, hasDefaultOption: false, valueKey: 'value' })
        }
      }, {
        type: EditType.Select,
        label: '状态',
        key: 'status',
        itemConfig: {
          options: [
            { value: '1', label: '正常' },
            { value: '0', label: '不正常' }
          ]
        }
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, removeItems, save, cancel, changePage, editItems } = this.Action
    return (
      <div>
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    // console.log(nextState.selectedRowKeys)
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    paymentPlatformOptions: hasAttr(state.index.dictList.filter((item, index) => item.value === 'PaymentPlatform'), [0, 'items']) || [],
    paymentTypeOptions: hasAttr(state.index.dictList.filter((item, index) => item.value === 'PaymentType'), [0, 'items']) || [],
  }
}
export default connect(mapStateToProps)(PayType)