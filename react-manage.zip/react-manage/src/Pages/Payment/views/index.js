import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
import './index.less'
const loadSource = (cb) => {
  return import('./source.js')
}
const loadChannel = (cb) => {
  return import('./channel.js')
}
const loadHelpPay = (cb) => {
  return import('./helpPay.js')
}
const loadPayType = (cb) => {
  return import('./payType.js')
}
const loadBankCode = (cb) => {
  return import('./bankCode.js')
}
const Source = getComponent(loadSource)
const HelpPay = getComponent(loadHelpPay)
const Channel = getComponent(loadChannel)
const PayType = getComponent(loadPayType)
const BankCode = getComponent(loadBankCode)
export default class Payment extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/payment"
          exact render={() => <Redirect to="/payment/source" />}
        />
        <Route path="/payment/source" render={(props) => <Source {...props} />} />
        <Route path="/payment/channel" render={(props) => <Channel {...props} />} />
        <Route path="/payment/helpPay" render={(props) => <HelpPay {...props} />} />
        <Route path="/payment/payType" render={(props) => <PayType {...props} />} />
        <Route path="/payment/bankCode" render={(props) => <BankCode {...props} />} />
      </Switch>
    )
  }
}