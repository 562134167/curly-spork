import React from 'react';
import { Layout, Menu, Icon } from 'antd';
const { SubMenu } = Menu;
const { Sider } = Layout;
const MSider = ({
  theme,
  trigger,
  pathMenus,
  collapsed,
  mode,
  openKeys,
  defaultOpenKeys,
  collapsible,
  current,
  onOpenChange,
  defaultSelectedKeys,
  selectedKeys,
  handleClick,
  onCollapse
}) => {
  return (
    <Sider
      trigger={trigger}
      collapsible={true}
      collapsed={collapsed}
      width={220}
      onCollapse={onCollapse}
    >
      <div className="logo">

      </div>
      <Menu
        theme={theme || "dark"}
        mode={mode}
        defaultSelectedKeys={[current]}
        defaultOpenKeys={defaultOpenKeys}
        openKeys={openKeys}
        selectedKeys={[current]}
        onOpenChange={onOpenChange}
        onClick={handleClick}>
        {pathMenus.map(menu => {
          return renderSub(menu)
        })
        }
      </Menu>
    </Sider>
  )
}
const renderSub = ({ url, icon, name, items }) => {
  if (items && items.length) {
    // 如果有子项
    return (
      <SubMenu
        key={url}
        title={<span > <Icon type={icon} /> < span > {
          name
        } </span></span >}>
        {items.map(sub => {
          return renderSub(sub)
        })
        }
      </SubMenu>
    )
  } else if (icon) {
    // 如果该项有icon标签
    return <Menu.Item key={url}>
      <span><Icon type={icon} />
        <span>{name}</span>
      </span>
    </Menu.Item>
  } else {
    return <Menu.Item key={url}>{name}</Menu.Item>
  }
}
export default MSider;