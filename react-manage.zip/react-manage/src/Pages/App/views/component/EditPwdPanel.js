import React, { PureComponent } from 'react';
import { Form, Modal, Input, Icon } from 'antd';

const FormItem = Form.Item;
class EditForm extends PureComponent {
  state = {
    confirmDirty: false,
    type: 'password'
  }
  Action = {
    handleConfirmBlur: (e) => {
      const value = e.target.value;
      this.setState({ confirmDirty: this.state.confirmDirty || !!value });
    },
    checkPassword: (rule, value, callback) => {
      const form = this.props.form;
      if (value && value !== form.getFieldValue('newPassword')) {
        callback('两次输入的密码不一致!');
      } else {
        callback();
      }
    },
    checkConfirm: (rule, value, callback) => {
      const form = this.props.form;
      if (value && this.state.confirmDirty) {
        form.validateFields(['confirmPassword'], { force: true });
      }
      callback();
    },
    toggleType: () => {
      this.setState({
        type: this.state.type === 'password' ? 'text' : 'password'
      })
    }
  }
  render() {
    const { type } = this.state;
    const { getFieldDecorator } = this.props.form;
    const { handleConfirmBlur, checkPassword, checkConfirm, toggleType } = this.Action
    return (
      <Form>
        <FormItem label="旧密码">
          {getFieldDecorator('oldPassword', {
            rules: [{ required: true, message: '请输入您的旧密码!' }],
          })(
            <Input type={type} placeholder="旧密码" prefix={<Icon type={type === 'password' ? 'eye-o' : 'eye'} onClick={toggleType} />} />
          )}
        </FormItem>
        <FormItem
          label="新密码"
          hasFeedback={true}>
          {getFieldDecorator('newPassword', {
            rules: [
              { required: true, message: '请输入您的新密码!' },
              { validator: checkConfirm }
            ],
          })(<Input type={type} placeholder="新密码" prefix={<Icon type={type === 'password' ? 'eye-o' : 'eye'} onClick={toggleType} />} />)}
        </FormItem>
        <FormItem
          label="确认密码"
          hasFeedback={true}>
          {getFieldDecorator('confirm Password', {
            rules: [
              { required: true, message: '请再次输入您的新密码!' },
              { validator: checkPassword }
            ],
          })(
            <Input onBlur={handleConfirmBlur} type={type} placeholder="再次输入新密码" prefix={<Icon type={type === 'password' ? 'eye-o' : 'eye'} onClick={toggleType} />} />
          )}
        </FormItem>
      </Form>
    )
  }

}


const EditFormWrapper = Form.create()(EditForm);

class EditPwdPanel extends PureComponent {
  render() {
    const { modalVis, onSave, onCancel, title } = this.props;

    return modalVis ? (<Modal
      title={title}
      visible={modalVis}
      maskClosable={false}
      onOk={() => {
        this.refs.editForm.validateFieldsAndScroll((err, values) => { if (!err) { onSave(values); } })
      }}
      onCancel={onCancel}
    >
      <EditFormWrapper ref='editForm' />
    </Modal>) : null

  }
}

export default EditPwdPanel;
