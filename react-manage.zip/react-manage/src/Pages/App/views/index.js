import React, { Component } from 'react';
// import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
// import { Link } from 'react-router-dom'
import is from 'is_js'
import moment from 'moment'
import { Layout, Breadcrumb, Icon, message, Popover, Button, Row, Col, Tag } from 'antd'
import Loading from '../../../Common/loading'
import MSider from './Sider';
import Menu from '../../../Config/menu'
import { getStore, removeStore } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import { setDictList } from '../../action'
import EditPwdPanel from './component/EditPwdPanel'
import './index.less'
const getDictListUrl = '/system/dict/getviewlist'
const editPwdUrl = '/system/user/updatepassword'
const editPayPwdUrl = '/system/user/updatepaypassword'
const getMenuUrl = '/system/administrator/menu'
const logoutUrl = '/system/logout'
const { Header, Content } = Layout;
const editPwdTitle = '修改登录密码'
const editPayPwdTitle = '修改支付密码'
const adminMenuItem = {
  "id": 269,
  "num": 1,
  "icon": "pie-chart",
  "url": "/validateFund",
  "name": "数据校验",
  "items": [
    {
      "id": 275,
      "num": 1,
      "items": [],
      "url": "/validateFund/validateAll",
      "name": "总数据校验"
    },
    {
      "id": 276,
      "items": [],
      "name": "每日数据校验列表",
      "num": 1,
      "url": "/validateFund/validateList"
    },
    {
      "id": 277,
      "items": [],
      "name": "每日数据校验详情",
      "num": 1,
      "url": "/validateFund/validateDetail"
    }
  ]
}
class App extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  Request = {
    getMenu: () => {
      // const isShowError = this.props.location.pathname 
      return getFetch(getMenuUrl).then((res) => {
        this.isGettingMenu = false

        if (is.array(res.models)) {
          // 如果登录账号是管理员账号，则添加数据校验的权限菜单
          const tmpMenu = JSON.parse(JSON.stringify(res.models));
          if (JSON.parse(getStore('user') || "{}").account === 'admin') {
            tmpMenu.push(adminMenuItem);
          }
          Menu.setItems(tmpMenu);

          this.Request.getDictList();

          const current = this.Util.getRightCurrentKey(this.props);
          this.setState({
            menuData: res.models,
            openKeys: Menu.getOpenKeys(current),
            current,
            hasPageRight: this.Util.hasRight(this.props.location.pathname)
          })
        }
        return res
      }, error => {
        this.isGettingMenu = false

        if ((!error.response || error.response.status !== 401) && this.props.location.pathname === '/login') {
          this.props.setDictList([{}])
          this.setState({
            menuData: [{}],
          })
        }
      })
    },
    getDictList: () => {
      return getFetch(getDictListUrl).then(res => {
        if (res && res.models) {
          this.props.setDictList(res.models)
        }
      }, error => {
        if ((!error.response || error.response.status !== 401) && this.props.location.pathname === '/login') {
          this.props.setDictList([{}])
          this.setState({
            menuData: [{}]
          })
        }
      })
    },
    editPwd: (params) => {
      return fetch(editPwdUrl, params).then(res => {
        this.setState({
          editPwdModalVis: false
        })
        if (res.status == 0) {
          message.success('修改密码成功!')
        }
        return res
      })
    },
    editPayPwd: (params) => {
      return fetch(editPayPwdUrl, params).then(res => {
        this.setState({
          editPwdModalVis: false
        })
        if (res.status == 0) {
          message.success('修改支付密码成功!')
        }
        return res
      })
    },
    logout: () => {
      return fetch(logoutUrl).then(res => {
        if (res.status == 0) {
          return true
        }
        return false
      })
    }
  }
  Action = {
    // 处理菜单的点击事件
    handleClick: (e) => {
      this.setState({ current: e.key });
      this.props.history.push(e.key)
    },
    // 切换菜单的打开和关闭
    toggle: () => {
      var collapsed = !this.state.collapsed
      this.setState({
        openKeys: [],
        collapsed,
      });
    },
    // 点击菜单父项时触发事件
    onOpenChange: (openKeys) => {
      this.setState({ openKeys: openKeys })
    },
    exit: (e) => {
      e.preventDefault();
      this.Request.logout().then(res => {
        if (res) {
          removeStore('user');
          this.props.history.push('/login')
          this.setState({
            menuData: []
          })
          this.props.setDictList([])

        } else {
          message.error('退出登录失败，请稍后重试！')
        }
      })
    },
    editPwd: () => {
      this.setState({
        editPwdModalVis: true,
        title: editPwdTitle
      })
    },
    editPayPwd: () => {
      this.setState({
        editPwdModalVis: true,
        title: editPayPwdTitle
      })
    },
    cancelEditPwdModal: () => {
      this.setState({
        editPwdModalVis: false
      })
    },
    saveEditPwd: (values) => {
      const { title } = this.state
      if (title === editPwdTitle) {
        this.Request.editPwd({
          oldPassword: values.oldPassword,
          newPassword: values.newPassword
        }).then(res => {
          if (res.status == 0) {
            this.Request.logout()
          }
        })
      } else {
        this.Request.editPayPwd({
          oldPassword: values.oldPassword,
          newPassword: values.newPassword
        })
      }

    }
  }
  Util = {
    // 将url/***/转换成key:value的对象
    formatUrl: (url) => {
      const arr = url.split('/');
      const temp = Object.assign([], arr);
      const urlArr = [];
      for (let i in arr) {
        if (i === 0 || i >= arr.length - 2) {
          continue;
        }
        temp.pop();
        urlArr.push(temp.join('/'))
      }
      return urlArr;
    },
    getRightCurrentKey: (props) => {
      let current = props.location.pathname;
      // 如果在菜单数据中找不到对应的path
      if (!Menu.hasItems(current)) {
        // 将url路径转换成一个数组
        const url = this.Util.formatUrl(current);
        for (let i in url) {
          // 获取当前url的父项
          const parentArr = Menu.getFullItems(url[i]);
          // 如果有父项
          if (parentArr && parentArr.length) {
            current = parentArr[0].path;
            break;
          }
        }
      }
      return current;
    },
    hasRight: (pathname) => {
      return Menu.hasItems(pathname) || pathname === '/login' || pathname === '/';
    },

  }
  RenderFunc = {
    renderBreadcrumb: () => {
      let fullPaths = Menu.getFullItems(this.state.current);
      if (fullPaths) {
        return (
          <Breadcrumb style={{
            margin: '12px 12px 0 12px'
          }}>
            {fullPaths
              .reverse()
              .map((o, i) => {
                return (
                  <Breadcrumb.Item key={i}>
                    {o.icon
                      ? <Icon type={o.icon} />
                      : ''}<span>{o.name}</span>
                  </Breadcrumb.Item>
                )
              })}
          </Breadcrumb>
        )
      }
      return null;
    },
    renderLoading: () => {
      const { loading, tip } = this.props;
      if (loading) {
        return <Loading tip={tip} />
      }
      return null
    },
    renderRight: () => {
      const { exit, editPwd, editPayPwd } = this.Action
      const user = JSON.parse(getStore('user'))
      const content = (
        <div className="user-info">
          <Row>
            <Col span={12}>用户名</Col>
            <Col span={12}>{user && user.account}</Col>
          </Row>
          <Row>
            <Col span={12}>昵称</Col>
            <Col span={12}>{user && user.name}</Col>
          </Row>
          <Row>
            <Col span={12}>生日</Col>
            <Col span={12}>{moment(user && user.birthday).format('YYYY-MM-DD')}</Col>
          </Row>
          <Button type="primary" className="action-item" onClick={editPwd}>修改密码</Button>
          <Button type="primary" className="action-item" onClick={editPayPwd}>修改支付密码</Button>
        </div>
      );
      return (
        <div className="right">
          <Popover id="user-content" content={content} title="个人信息" trigger="click">
            {/* <Button type="primary" className=""></Button> */}
            <Tag color="blue">
              <Icon type="user" />
              {user && (user.name || user.account)}
            </Tag>
          </Popover>
          <a onClick={exit}>退出</a>
        </div>
      )
    }
  }
  onInit() {
    this.state = {
      collapsed: false,
      current: this.props.location.pathname,
      openKeys: [],
      selectedKey: [],
      menuData: [],
      hasPageRight: false,
      editPwdModalVis: false,
      title: '',
    }
    this.isGettingMenu = false

  }
  componentDidMount() {

    this.isGettingMenu = true
    this.Request.getMenu()
    const { location, history } = this.props
    if (getStore('user') && location.pathname === '/login') {
      history.replace('/home')
    }
  }
  // componentWillReceiveProps(nextProps) {

  // }

  componentWillUpdate(nextProp, nextState) {
    const { location, history } = this.props
    // const { menuData } = this.state
    // 当isLogin状态发生改变时
    // if ((!getStore('user')) && location.pathname !== '/login') {
    //   history.push('/login')
    // }
    // if (nextProp.isLogin === false && !getStore('user') && location.pathname !== '/login') {
    //   history.push('/login')
    // }
    if (nextProp.isLogin === false && !getStore('user') && this.props.location.pathname !== '/login') {
      nextProp.history.push('/login')
    }

    if (getStore('user') && location.pathname === '/login') {
      history.replace('/home')
    }

    // 当url改变的时候，更改菜单展开项和当前key
    if (!(location.pathname === '/login' || nextProp.location.pathname === '/login')) {
      if (!(nextState.menuData && nextState.menuData.length) && !this.isGettingMenu) {
        this.isGettingMenu = true
        this.Request.getMenu().then(() => {
          this.setState({
            hasPageRight: this.Util.hasRight(nextProp.location.pathname)
          })
        })
      }

    }
    if (nextProp.location.pathname !== location.pathname && nextProp.location.pathname !== '/login') {
      const current = this.Util.getRightCurrentKey(nextProp);
      this.setState({
        openKeys: Menu.getOpenKeys(current),
        current,
        hasPageRight: this.Util.hasRight(nextProp.location.pathname)
      })
    }

  }
  render() {
    const defaultOpenKeys = Menu.getOpenKeys(this.props.location.pathname)
    const { handleClick, toggle, onOpenChange, cancelEditPwdModal, saveEditPwd } = this.Action
    const { renderBreadcrumb, renderLoading, renderRight } = this.RenderFunc
    const { collapsed, openKeys, current, hasPageRight, title } = this.state
    const { location, children } = this.props
    if (location.pathname === '/login') {
      return (
        <div>
          {this.props.children}
          {renderLoading()}
        </div>
      )
    }
    return (
      <div id="app">
        <Layout
          style={{
            minHeight: '100vh'
          }}
          className="ant-layout-has-sider">
          <MSider
            theme="dark"
            trigger={null}
            collapsible={true}
            collapsed={collapsed}
            pathMenus={Menu.items}
            mode='inline'
            defaultOpenKeys={defaultOpenKeys}
            openKeys={openKeys}
            current={current}
            handleClick={handleClick}
            onOpenChange={onOpenChange} />
          <Layout>
            <Header
              className="main-header">
              <Icon
                className="trigger"
                type={collapsed
                  ? 'menu-unfold'
                  : 'menu-fold'}
                onClick={toggle} />
              {renderRight()}
            </Header>
            {renderBreadcrumb()}
            <Content
              style={{
                margin: '24px 16px',
                padding: 24,
                background: '#fff',
              }}>
              {hasPageRight ? children : null}
            </Content>
          </Layout>
        </Layout>
        <EditPwdPanel
          modalVis={this.state.editPwdModalVis}
          onSave={saveEditPwd}
          onCancel={cancelEditPwdModal}
          title={title}
        />
        {renderLoading()}
      </div >
    );
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    loading: state.index.loading,
    tip: state.index.tip,
    isLogin: state.login.isLogin,
    dictList: state.index.dictList
  }
}
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    setDictList: (list) => {
      return dispatch(setDictList(list))
    }
  }
}
// export default withRouter(App);
export default connect(mapStateToProps, mapDispatchToProps)(App)
