import React from 'react';
import { Layout, Button } from 'antd';
// import { withRouter } from 'react-router';
import imgBg from './images/404.png';
const styles = {
    container: {
        height: '100vh',
        background: `url(${imgBg}) center center no-repeat`,
        backgroundSize: '100% 100%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    text: {
        color: '#fff',
        // fontWeight: 'bold',
        fontSize: '22px'
    },
    btn: {
        margin: '20px 10px 0'
    }
}
const NotFound = (props) => {
    return (
        <Layout style={styles.container} >
            <div style={styles.text}>
                <p>您要找的页面走丢了Ｏ(≧口≦)Ｏ</p>
                <p>SORRY,THE PAGE YOU FOUND IS LOST</p>
            </div>
            <div style={{ display: 'flex', flexDirection: 'row' }}>
                <Button size="large" onClick={() => { props.history.go(-1) }} style={styles.btn} type="primary">返回上一页</Button>
                <Button size="large" onClick={() => { props.history.replace('/home') }} style={styles.btn} ghost>回到首页</Button>
            </div>
        </Layout>
    )
}
export default NotFound