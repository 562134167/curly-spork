import React, { PureComponent } from 'react'
import { TimePicker, Input, Button, Select, Tag } from 'antd'
import moment from 'moment'
import { bindFunc } from '../../../../Util/reactUtil'
import { hasAttr } from '../../../../Util'
const { Option } = Select
export default class AmountScore extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || []
    bindFunc([{ key: 'Action', value: ['onTimeChange', 'onPriorityChange', 'newTime', 'onSelectChange', 'deleteItem'] }], this)
    this.state = {
      value: this.Util.formatTime(value)
    }
  }
  Util = {
    formatTime: (timeArr) => {
      var temp = [];
      for (let i in timeArr) {
        temp.push({
          startTime: (timeArr[i].startTime && moment(timeArr[i].startTime, 'x')) || undefined,
          endTime: (timeArr[i].endTime && moment(timeArr[i].endTime, 'x')) || undefined,
          priority: timeArr[i].priority,
          dateType: timeArr[i].dateType,
          id: timeArr[i].id || i
        })
      }
      return temp
    },
    formatChangedData: (timeArr) => {
      var temp = [];
      for (let i in timeArr) {
        temp.push({
          startTime: (timeArr[i].startTime && timeArr[i].startTime.format('x')) || undefined,
          endTime: (timeArr[i].endTime && timeArr[i].endTime.format('x')) || undefined,
          priority: timeArr[i].priority,
          dateType: timeArr[i].dateType,
          id: timeArr[i].id
        })
      }
      return temp
    },
  }
  Action = {
    deleteItem: (index) => {
      const value = Object.assign([], this.state.value)
      value.splice(index, 1)
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    onTimeChange: (time, index, key) => {
      const value = Object.assign([], this.state.value)
      value[index][key] = time
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    onSelectChange: (selectVal, index) => {
      const value = Object.assign([], this.state.value)
      value[index].dateType = selectVal
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    onPriorityChange: (e, index) => {
      const priority = e.target.value
      const value = Object.assign([], this.state.value)
      value[index].priority = priority
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    newTime: () => {
      const value = Object.assign([], this.state.value)
      value.push({
        startTime: moment(),
        endTime: moment(),
        priority: 0,
        dateType: 'Any',
        id: new Date().getTime()
      })
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(this.Util.formatChangedData(changedValue))
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value || []
      this.setState({
        value: this.Util.formatTime(value)
      })
    }
  }
  RenderFunc = {
    renderTime: (timeArr) => {
      const options = hasAttr(this.props, ['item', 'itemConfig', 'options'])
      const { onPriorityChange, onTimeChange, onSelectChange, deleteItem } = this.Action
      return timeArr.map((item, index) => {
        return (
          <Tag
            closable
            onClose={() => deleteItem(index)}
            key={item.id}
          >
            <span style={{ marginRight: '2%' }}>
              <TimePicker
                value={item.startTime}
                onChange={(time, timeString) => onTimeChange(time, index, 'startTime')}
                format="HH:mm"
                addon={panel => (
                  <Button size="small" type="primary" onClick={() => panel.close()}>
                    确定
                  </Button>
                )}
              />
            </span>
            <span style={{ marginRight: '2%' }}>至</span>
            <span style={{ marginRight: '2%' }}>
              <TimePicker
                value={item.endTime}
                onChange={(time, timeString) => onTimeChange(timeString, index, 'endTime')}
                format="HH:mm"
                addon={panel => (
                  <Button size="small" type="primary" onClick={() => panel.close()}>
                    确定
                  </Button>
                )}
              />
            </span>
            <Select
              value={item.dateType}
              style={{ marginRight: '2%', width: 90, display: 'inline-block' }}
              onChange={(value) => onSelectChange(value, index)}
              placeholder="日期选择"
            >
              {
                options && options.map((option, index) => (
                  <Option key={index} value={option.value}>{option.name}</Option>
                ))
              }

            </Select>
            <Input
              type="number"
              value={item.priority}
              onChange={(e) => onPriorityChange(e, index)}
              placeholder="权重分值"
              style={{ marginRight: '2%', width: '120px' }}
            />
          </Tag>

        )
      })
    }
  }
  render() {
    const { newTime } = this.Action
    const { value } = this.state
    return (
      <div className="score-time">
        <div>
          <Button type="primary" onClick={newTime}>新增</Button>
        </div>
        {this.RenderFunc.renderTime(value)}
      </div>
    )
  }
}