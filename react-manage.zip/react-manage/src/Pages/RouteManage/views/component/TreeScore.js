import React, { PureComponent } from 'react'
import is from 'is_js'
import { Tree, Input } from 'antd';
import { hasAttr } from '../../../../Util/index'
import { toNumber } from '../../../../Util/reactUtil'
const TreeNode = Tree.TreeNode;

export default class TreeScore extends PureComponent {
  constructor(props) {
    super(props)
    this.Action.onSelectChange = this.Action.onSelectChange.bind(this)
    this.Action.onPriorityChange = this.Action.onPriorityChange.bind(this)
    const value = props.value || {}
    this.state = {
      // value: this.Util.formatCheckedKeys(value)
      ids: this.Util.formatCheckedKeys(value.ids || []),
      priority: value.priority
    }
  }
  Action = {
    onSelectChange: (checkedKeys, info) => {
      if (!('value' in this.props)) {
        this.setState({
          ids: checkedKeys
        })
      }
      this.Action.triggerChange({ ids: checkedKeys })
    },
    onPriorityChange: (e) => {
      const priority = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          priority
        })
      }
      this.Action.triggerChange({ priority })
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange({
          ids: this.Util.formatChangedValue(changedValue.ids || this.state.ids),
          priority: changedValue.priority || this.state.priority
        })
      }
    }
  }
  Util = {
    formatCheckedKeys: (arr) => {
      if (is.array(arr)) {
        const temp = []
        arr.forEach(item => temp.push(item.toString()))
        return temp
      }
      return arr

    },
    formatChangedValue: (arr) => {
      if (is.array(arr)) {
        const temp = []
        arr.forEach(item => temp.push(toNumber(item)))
        return temp
      }
      return arr
    }
  }
  RenderFunc = {
    renderNode: (items) => {
      if (items && items.length) {
        return items.map((item, index) => (
          <TreeNode className={item.items && item.items.length ? 'has-child' : ''} title={item.name} key={item.id}>
            {this.RenderFunc.renderNode(item.items)}
          </TreeNode>
        ))
      }
      return null
    }
  }
  componentWillReceiveProps(nextProps) {
    const { formatCheckedKeys } = this.Util
    if ('value' in nextProps) {
      const value = nextProps.value || {}
      this.setState({
        ids: formatCheckedKeys(value.ids || []),
        priority: value.priority
      })
    }
  }

  render() {
    const { onSelectChange, onPriorityChange } = this.Action
    const { ids, priority } = this.state
    const options = hasAttr(this.props, ['item', 'itemConfig', 'options']) || []
    return (
      <div className="priority-tree">
        <Tree
          checkable
          onCheck={onSelectChange}
          checkedKeys={ids}
        /* defaultExpandAll={true} */
        >
          {
            options.map((option, index) => (
              <TreeNode className={option.items && option.items.length ? 'has-child' : ''} title={option.name} key={option.id}>
                {this.RenderFunc.renderNode(option.items)}
              </TreeNode>
            ))
          }
        </Tree>
        <Input
          type="number"
          value={priority}
          onChange={onPriorityChange}
          placeholder="权重分值"
        /* style={{ marginRight: '3%', width: '120px' }} */
        />
      </div>
    );
  }
}
