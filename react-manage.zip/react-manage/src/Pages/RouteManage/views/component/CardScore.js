import React, { PureComponent } from 'react'
import { Input } from 'antd'
import { bindFunc } from '../../../../Util/reactUtil'
export default class CardScore extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || {}
    bindFunc([{ key: 'Action', value: ['onMaxPriceChange', 'onCountChange', 'onPriorityChange'] }], this)
    this.state = {
      count: value.count,
      maxPrice: value.maxPrice,
      priority: value.priority
    }
  }
  Action = {
    onCountChange: (e) => {
      const count = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          count
        })
      }
      this.Action.triggerChange({ count })
    },
    onMaxPriceChange: (e) => {
      const maxPrice = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          maxPrice
        })
      }
      this.Action.triggerChange({ maxPrice })
    },
    onPriorityChange: (e) => {
      const priority = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          priority
        })
      }
      this.Action.triggerChange({ priority })
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(Object.assign({}, this.state, changedValue))
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value || {}
      // const { count, maxPrice, priority } = value
      // this.setState({
      //   count: is.undefined(count) ? 0 : count,
      //   maxPrice: is.undefined(maxPrice) ? 0 : maxPrice,
      //   priority: is.undefined(priority) ? 0 : priority
      // })
      this.setState(value)
    }
  }

  render() {
    const { onMaxPriceChange, onCountChange, onPriorityChange } = this.Action
    const { count, maxPrice, priority } = this.state
    return (
      <div>
        <Input
          type="number"
          value={maxPrice}
          placeholder="单笔最大金额"
          onChange={onMaxPriceChange}
          style={{ marginRight: '3%', width: '120px' }}
        />
        <Input
          type="number"
          value={count}
          onChange={onCountChange}
          placeholder="笔数限制"
          style={{ marginRight: '3%', width: '120px' }}
        />
        <Input
          type="number"
          value={priority}
          onChange={onPriorityChange}
          placeholder="权重分值"
          style={{ marginRight: '3%', width: '120px' }}
        />
      </div>
    )
  }
}