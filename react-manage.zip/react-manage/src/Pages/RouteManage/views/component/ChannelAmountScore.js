import React, { PureComponent } from 'react'
import { Input, Select } from 'antd'
import { bindFunc, toString } from '../../../../Util/reactUtil'
import { hasAttr } from '../../../../Util'
const Option = Select.Option
export default class ChannelmaxAmountScore extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || {}
    bindFunc([{ key: 'Action', value: ['onMaxAmountChange', 'onDateTypeChange', 'onPriorityChange'] }], this)
    this.state = {
      maxAmount: value.maxAmount,
      dateType: value.dateType,
      priority: value.priority
    }
  }
  Action = {
    onMaxAmountChange: (e) => {
      const maxAmount = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          maxAmount
        })
      }
      this.Action.triggerChange({ maxAmount })
    },
    onDateTypeChange: (value) => {
      if (!('value' in this.props)) {
        this.setState({
          dateType: value
        })
      }
      this.Action.triggerChange({ dateType: value })
    },
    onPriorityChange: (e) => {
      const priority = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          priority
        })
      }
      this.Action.triggerChange({ priority })
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(Object.assign({}, this.state, changedValue))
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value || {}
      this.setState(value)
    }
  }

  render() {
    const { onMaxAmountChange, onDateTypeChange, onPriorityChange } = this.Action
    const { maxAmount, dateType, priority } = this.state
    const options = hasAttr(this.props, ['item', 'itemConfig', 'options']) || []
    return (
      <div>
        <Input
          type="number"
          value={maxAmount}
          onChange={onMaxAmountChange}
          placeholder="通道最大金额"
          style={{ marginRight: '3%', width: '120px' }}
        />
        <Select value={toString(dateType || 'Any')} allowClear style={{ marginRight: '3%', width: 120 }} onChange={onDateTypeChange} placeholder="日期选择">
          {
            options.map((option, index) => (
              <Option key={index} value={option.value}>{option.name}</Option>
            ))
          }
        </Select>
        <Input
          type="number"
          value={priority}
          onChange={onPriorityChange}
          placeholder="权重分值"
          style={{ marginRight: '3%', width: '120px' }}
        />
      </div>
    )
  }
}