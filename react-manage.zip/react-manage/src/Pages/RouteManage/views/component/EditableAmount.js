import React, { PureComponent } from 'react'
import { Input, Radio } from 'antd'
import { bindFunc } from '../../../../Util/reactUtil'
const RadioGroup = Radio.Group
export default class EditableAmount extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || {}
    this.state = {
      fixedAmount: value.fixedAmount || 0,
      isFixedAmount: value.isFixedAmount,
      editable: this.props.editable || false,
    }
    bindFunc([{ key: 'Action', value: ['handleInputChange', 'handleRadioChange'] }], this)
  }
  componentWillReceiveProps(nextProps) {
    const { isFixedAmount, fixedAmount } = this.state
    if (nextProps.editable !== this.state.editable) {
      this.setState({ editable: nextProps.editable });
      if (nextProps.editable) {
        this.cacheValue = {
          isFixedAmount,
          fixedAmount
        }
      }
    }
    if (nextProps.status && nextProps.status !== this.props.status) {
      if (nextProps.status === 'save') {
        let { isFixedAmount, fixedAmount } = this.state
        this.props.onChange({ isFixedAmount, fixedAmount });
      } else if (nextProps.status === 'cancel') {
        let { isFixedAmount, fixedAmount } = this.cacheValue
        this.setState({ isFixedAmount, fixedAmount });
        this.props.onChange({ isFixedAmount, fixedAmount });
      }
    }
  }
  Action = {
    handleInputChange: (e) => {
      const value = e.target.value;
      this.setState({
        fixedAmount: value
      });
    },
    handleRadioChange: (e) => {
      const value = e.target.value;
      this.setState({
        isFixedAmount: value
      });
    }
  }
  render() {
    const { fixedAmount, isFixedAmount, editable } = this.state;
    return (
      <div>
        {
          editable ?
            <div>
              <Input
                type="number"
                value={fixedAmount}
                onChange={this.Action.handleInputChange}
              />
              <RadioGroup onChange={this.Action.handleRadioChange} value={isFixedAmount}>
                <Radio value={1}>禁止超过</Radio>
                <Radio value={2}>超过禁止</Radio>
              </RadioGroup>
            </div>
            :
            <div className="editable-row-text">
              {fixedAmount || 0}<br />
              {isFixedAmount === 1 ? '禁止超过' : null}
              {isFixedAmount === 2 ? '超过禁止' : null}
            </div>
        }
      </div>
    );
  }
}