import React, { PureComponent } from 'react'
import { DatePicker, Input } from 'antd'
import moment from 'moment'
import { bindFunc } from '../../../../Util/reactUtil'
const { RangePicker } = DatePicker;
export default class AmountScore extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || {}
    bindFunc([{ key: 'Action', value: ['onDateChange', 'onPriorityChange'] }], this)
    this.state = {
      startDate: value.startDate && moment(value.startDate, 'x'),
      endDate: value.endDate && moment(value.endDate, 'x'),
      priority: value.priority
    }
  }
  Action = {
    onDateChange: (date, dateString) => {
      if (!('value' in this.props)) {
        this.setState({
          startDate: date[0],
          endDate: date[1]
        })
      }
      this.Action.triggerChange({
        startDate: date[0],
        endDate: date[1]
      })
    },
    onPriorityChange: (e) => {
      const priority = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          priority
        })
      }
      this.Action.triggerChange({ priority })
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      const data = Object.assign({}, this.state, changedValue)
      data.startDate = (data.startDate && data.startDate.format('x')) || undefined
      data.endDate = (data.endDate && data.endDate.format('x')) || undefined
      if (onChange) {
        onChange(data)
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value || {}
      this.setState({
        startDate: value.startDate && moment(value.startDate, 'x'),
        endDate: value.endDate && moment(value.endDate, 'x'),
        priority: value.priority
      })
    }
  }

  render() {
    const { onPriorityChange, onDateChange } = this.Action
    const { priority, startDate, endDate } = this.state
    return (
      <div>
        <RangePicker
          format="YYYY-MM-DD"
          onChange={onDateChange}
          value={[startDate, endDate]}
          style={{ marginRight: '3%' }}
        />
        <Input
          type="number"
          value={priority}
          onChange={onPriorityChange}
          placeholder="权重分值"
          style={{ marginRight: '3%', width: '120px' }}
        />
      </div>
    )
  }
}