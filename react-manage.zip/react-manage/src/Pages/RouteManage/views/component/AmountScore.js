import React, { PureComponent } from 'react'
import { Input } from 'antd'
import { bindFunc } from '../../../../Util/reactUtil'
export default class AmountScore extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || {}
    bindFunc([{ key: 'Action', value: ['onMaxPriceChange', 'onMinPriceChange', 'onPriorityChange'] }], this)
    this.state = {
      minPrice: value.minPrice,
      maxPrice: value.maxPrice,
      priority: value.priority
    }
  }
  Action = {
    onMinPriceChange: (e) => {
      const minPrice = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          minPrice
        })
      }
      this.Action.triggerChange({ minPrice })
    },
    onMaxPriceChange: (e) => {
      const maxPrice = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          maxPrice
        })
      }
      this.Action.triggerChange({ maxPrice })
    },
    onPriorityChange: (e) => {
      const priority = e.target.value
      if (!('value' in this.props)) {
        this.setState({
          priority
        })
      }
      this.Action.triggerChange({ priority })
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(Object.assign({}, this.state, changedValue))
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value || {}
      // const { minPrice, maxPrice, priority } = value
      // this.setState({
      //   minPrice: is.undefined(minPrice) ? 0 : minPrice,
      //   maxPrice: is.undefined(maxPrice) ? 0 : maxPrice,
      //   priority: is.undefined(priority) ? 0 : priority
      // })
      this.setState(value)
    }
  }

  render() {
    const { onMaxPriceChange, onMinPriceChange, onPriorityChange } = this.Action
    const { minPrice, maxPrice, priority } = this.state
    return (
      <div>
        <Input
          type="number"
          value={minPrice}
          onChange={onMinPriceChange}
          placeholder="最小订单金额"
          style={{ marginRight: '3%', width: '120px' }}
        />
        <span style={{ marginRight: '3%' }}>至</span>
        <Input
          type="number"
          value={maxPrice}
          placeholder="最大订单金额"
          onChange={onMaxPriceChange}
          style={{ marginRight: '3%', width: '120px' }}
        />
        <Input
          type="number"
          value={priority}
          onChange={onPriorityChange}
          placeholder="权重分值"
          style={{ marginRight: '3%', width: '120px' }}
        />
      </div>
    )
  }
}