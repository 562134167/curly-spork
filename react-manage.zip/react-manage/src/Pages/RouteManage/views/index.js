import React, { Component } from 'react'
import { connect } from 'react-redux'
import moment from 'moment'
// import SearchPanel from '../../../Common/searchPanel'
// import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
// import DropdownBtn from '../../../Common/dropdowmBtn'
import { Table, Popconfirm, Button } from 'antd'
import { formatData, formateEditData } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import EditableInput from './component/EditableInput'
import EditableAmount from './component/EditableAmount'
import EditableRadio from './component/EditableRadio'
import AmountScore from './component/AmountScore'
import ChannelAmountScore from './component/ChannelAmountScore'
import TreeScore from './component/TreeScore'
import CardScore from './component/CardScore'
import DateScore from './component/DateScore'
import TimeScore from './component/TimeScore'
import './index.less'
const title = '通道权重管理'
const initGetParams = {
  pageIndex: 1,
}

const pagingUrl = '/system/route/paging',
  updateUrl = '/system/route/update',
  weightPagingUrl = '/system/weight/paging',
  weightUpdateUrl = '/system/weight/update',
  getSourceUrl = '/system/source/paging',
  getProductUrl = '/system/product/paging'
class Route extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl, params).then(res => {
        if (res) {
          const { models, totalModels } = res
          const dataSource = this.Util.formatDataSource(formatData(models || []))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 修改数据
    edit: (params) => {
      return fetch(updateUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 获取数据
    getWeight: (params) => {
      return getFetch(weightPagingUrl, params).then(res => {
        if (res) {
          const { models, totalModels, totalPages } = res
          const weightDataSource = formatData(models || [])
          this.setState({
            weightDataSource,
            totalModels,
            totalPages,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 修改数据
    editWeight: (params) => {
      return fetch(weightUpdateUrl, params, { arrayFormat: 'indices' }).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.getWeight(this.state.getDataParams)
        return res
      })
    },
    // 获取渠道商名称
    getSource: () => {
      return getFetch(getSourceUrl).then(res => {
        if (res.models && res.models.length) {
          this.setState({
            sourceOptions: res.models
          })
        }
        return res
      })
    },
    //获取产品类型 
    getProduct: () => {
      return getFetch(getProductUrl).then(res => {
        if (res && res.models) {
          this.setState({
            productOptions: res.models
          })
        }
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击修改通道权重按钮
    editScore: (record, index) => {
      // this.Request.getList(record.id).then(res => {
      const { weightDataSource } = this.state
      const temp = weightDataSource.filter(item => item.routeId === record.id)[0]
      let modal = {}
      const obj = formateEditData(temp, this.formItems)
      for (let i in temp) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        editId: obj.routeId,
        modalVis: true,
        modal: modal,
        title: title
      })
      // })
    },
    // 点击行修改按钮
    editColumn: (record) => {
      const { dataSource } = this.state;
      for (let i in dataSource) {
        if (dataSource[i].id === record.id) {
          Object.keys(record).forEach((item) => {
            if (record[item] && typeof record[item].editable !== 'undefined') {
              dataSource[i][item].editable = true;
            }
          });
          this.setState({ dataSource });
          this.editRecord = Object.assign({}, record)
        }
      }

    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { weightDataSource, editId } = this.state
      const { editWeight } = this.Request
      // 把保存的数值发送到服务器
      for (let i in weightDataSource) {
        if (weightDataSource[i].routeId === editId) {
          editWeight({
            ...weightDataSource[i],
            ...values,
          })
          break;
        }
      }

    },
    // 点击行的保存和取消按钮
    editColumnStatus: (record, type) => {
      const { dataSource } = this.state;
      // 将各项的editable设为false,将status设为'cancel'或者’save‘
      for (let i in dataSource) {
        if (dataSource[i].id === record.id) {
          const currentRecord = dataSource[i]
          Object.keys(currentRecord).forEach((item) => {
            if (currentRecord[item] && typeof currentRecord[item].editable !== 'undefined') {
              currentRecord[item].editable = false;
              currentRecord[item].status = type;
            }
          });
          this.setState({ dataSource }
            , () => {
              console.log(this.editRecord)
              Object.keys(currentRecord).forEach((item) => {
                if (currentRecord[item] && typeof currentRecord[item].editable !== 'undefined') {
                  delete currentRecord[item].status;
                }
              });
              if (type === 'save') {
                this.Request.edit(this.editRecord)
              }
            }
          );
        }
      }

    },
    // 取消模态框的修改
    cancel: () => {
      this.setState({
        modalVis: false
      })

    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },
    // 处理行的单元格的修改事件
    handleCellChange: (key, record, value) => {
      const newRecord = Object.assign({}, this.editRecord || record)
      const { dataSource } = this.state;
      for (let i in dataSource) {
        if (dataSource[i].id === record.id) {
          if (key === 'fixedAmount') {
            dataSource[i][key].value = value.fixedAmount
            dataSource[i].isFixedAmount = value.isFixedAmount
            newRecord[key] = value.fixedAmount
            newRecord.isFixedAmount = value.isFixedAmount
          } else {
            dataSource[i][key].value = value
            newRecord[key] = value
          }

        }
      }
      this.editRecord = newRecord
      this.setState({ dataSource })
    }
  }
  // 工具函数
  Util = {
    // 更新模态框表单的配置
    updateFormItem: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
        fn(formItem)
      }
    },
    formatDataSource: (arr) => {
      const dataSource = Object.assign([], arr)
      if (arr && arr.length) {
        for (let j in this.columns) {
          if (this.columns[j].isEditable) {
            let key = this.columns[j].key
            dataSource.forEach((item, index) => {
              item[key] = {
                value: item[key],
                editable: false
              }
            })
          }
        }
      }
      return dataSource
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { editScore, editColumnStatus, editColumn } = this.Action
    this.state = {
      title: title,
      dataSource: [],
      weightDataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      sourceOptions: [],
      productOptions: []
    }
    // 表格列表头配置
    this.columns = [
      {
        title: '路由名称',
        key: 'rouName',
        dataIndex: 'rouName',
      }, {
        title: '摩根生成路由编码',
        key: 'rouCode',
        dataIndex: 'rouCode',
      }, {
        title: '渠道名称',
        dataIndex: 'channelId',
        key: 'channelId',
        render: id => {
          const options = this.state.sourceOptions
          const option = options.filter(item => item.id == id)
          return hasAttr(option, [0, 'name'])
        }
      }, {
        title: '支付产品',
        dataIndex: 'productId',
        key: 'productId',
        render: id => {
          const options = this.state.productOptions
          const option = options.filter(item => item.id == id)
          return hasAttr(option, [0, 'productName'])
        }
      }, {
        title: '排序',
        dataIndex: 'sort',
        key: 'sort',
        isEditable: true,
        render: (text, record) => this.RenderFunc.renderInputColumns(record, 'sort', text, 'number')
      }, {
        title: '固定金额',
        dataIndex: 'fixedAmount',
        key: 'fixedAmount',
        isEditable: true,
        render: (text, record) => this.RenderFunc.renderAmountColumns(record, 'fixedAmount', text)
      }, {
        title: '比例金额',
        dataIndex: 'proAmount',
        key: 'proAmount',
        isEditable: true,
        render: (text, record) => this.RenderFunc.renderInputColumns(record, 'proAmount', text, 'number')
      }, {
        title: '次数',
        dataIndex: 'count',
        key: 'count',
        isEditable: true,
        render: (text, record) => this.RenderFunc.renderInputColumns(record, 'count', text, 'number')
      }, {
        title: '默认',
        dataIndex: 'isDefault',
        key: 'isDefault',
        isEditable: true,
        render: (text, record) => this.RenderFunc.renderRadioColumns(record, 'isDefault', text)
      }, {
        title: '通道权重',
        render: (text, record, index) => {
          return <Button type="primary" onClick={() => { editScore(record, index) }}>管理</Button>
        }
      },
      {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => {
          const { editable } = this.state.dataSource[index].sort;
          return (
            <div className="editable-row-operations">
              {
                editable ?
                  <span>
                    <Button type="primary" className="action-item" onClick={() => editColumnStatus(record, 'save')}>保存</Button>
                    <Popconfirm title="确定取消修改吗?" onConfirm={() => editColumnStatus(record, 'cancel')}>
                      <Button type="danger" className="action-item">取消</Button>
                    </Popconfirm>
                  </span>
                  :
                  <span className="action-item">
                    <Button type="primary" onClick={() => editColumn(record)}>修改</Button>
                  </span>
              }
            </div>
          );
        },
      }
    ];
    // 编辑面板表单配置
    this.formItems = [
      {
        type: EditType.InputNum,
        label: '手工权重分',
        key: 'priorityManual',
        config: {
          initialValue: 0
        }
      }, {
        type: EditType.InputNum,
        label: '费率权重分',
        key: 'priorityRate',
        config: {
          initialValue: 0
        }
      }, {
        render: (props, index) => {
          return (
            <div className="ant-row ant-form-item" key={index}>
              <div className="ant-form-item-label ant-col-xs-24 ant-col-sm-6">
                <label title="优先级条件分">优先级条件分</label>
              </div>
            </div>
          )
        }
      }, {
        type: EditType.InputNum,
        key: 'orderRateModel',
        label: '订单金额',
        render: AmountScore,
        config: {
          initialValue: {
            minPrice: 0,
            maxPrice: 0,
            priority: 0
          }
        },
        isInputNum: true,
        numKey: ['minPrice', 'maxPrice']
      }, {
        type: EditType.InputNum,
        key: 'amountLimitModel',
        label: '通道最大金额限制',
        render: ChannelAmountScore,
        config: {
          initialValue: {
            maxAmount: 0,
            dateType: 'Any',
            priority: 0
          }
        },
        itemConfig: {
          options: this.props.dayOptions
        },
        isInputNum: true,
        numKey: ['maxAmount']
      }, {
        key: 'tradeModel',
        label: '通道行业分类',
        render: TreeScore,
        itemConfig: {
          options: [
            { "icon": "setting", "id": 168, "items": [{ "id": 169, "items": [], "name": "其他餐饮业", "num": 1, "url": "/system/menu" }, { "icon": "", "id": 177, "items": [], "name": "酒吧服务", "num": 2, "url": "/system/department" }, { "id": 181, "items": [], "name": "茶馆服务", "num": 1, "url": "/system/dict" }, { "id": 182, "items": [], "name": "咖啡馆服务", "num": 1, "url": "/system/role" }], "name": "餐饮业", "num": 1, "url": "/system" }, { "icon": "pay-circle", "id": 183, "items": [{ "id": 184, "items": [], "name": "证券市场服务", "num": 1, "url": "/payment/source" }, { "id": 185, "items": [], "name": "财务公司", "num": 1, "url": "/payment/channel" }, { "id": 186, "items": [], "name": "典当", "num": 1, "url": "/payment/helpPay" }, { "id": 187, "items": [], "name": "银行服务", "num": 1, "url": "/payment/payType" }], "name": "金融服务", "num": 1, "url": "/payment" }, { "icon": "filter", "id": 188, "items": [], "name": "教育", "num": 1, "url": "/route" }
          ]
          // options: []
        },
        config: {
          initialValue: {
            priority: 0
          }
        },
      }, {
        key: 'merchantModel',
        label: '通道商户设置',
        render: TreeScore,
        itemConfig: {
          options: [
            { id: 1, name: '深圳市xx公司' },
            { id: 2, name: '广州市xx公司' },
            { id: 3, name: '汕头市xx公司' },
            { id: 4, name: '东莞市xx公司' },
            { id: 5, name: '佛山市xx公司' },
            { id: 6, name: '湛江市xx公司' }
          ]
          // options: []
        },
        config: {
          initialValue: {
            priority: 0
          }
        },
      }, {
        type: EditType.InputNum,
        key: 'cxCardModel',
        label: '储蓄卡金额',
        render: CardScore,
        config: {
          initialValue: {
            maxPrice: 0,
            count: 0,
            priority: 0
          }
        },
        isInputNum: true,
        numKey: ['maxPrice']
      }, {
        type: EditType.InputNum,
        key: 'xyCardModel',
        label: '信用卡金额',
        render: CardScore,
        config: {
          initialValue: {
            maxPrice: 0,
            count: 0,
            priority: 0
          }
        },
        isInputNum: true,
        numKey: ['maxPrice']
      }, {
        key: 'coincidenceDateModel',
        label: '日期时段',
        render: DateScore,
        config: {
          initialValue: {
            startDate: moment().format('YYYY-MM-DD'),
            endDate: moment().format('YYYY-MM-DD'),
            priority: 0
          }
        }
      }, {
        key: 'coincidenceTimesModelList',
        label: '时间时段',
        render: TimeScore,
        itemConfig: {
          options: this.props.dayOptions
        }
      }, {
        type: EditType.Select,
        key: 'status',
        label: '状态',
        config: {
          initialValue: '1'
        },
        itemConfig: {
          options: [
            { value: '1', label: '正常' },
            { value: '0', label: '不正常' },
          ]
        }
      }
    ]
  }
  // 渲染函数
  RenderFunc = {
    renderInputColumns: (record, key, text, type) => {
      const { editable, status } = (record && record[key]) || {};
      if (typeof editable === 'undefined') {
        return text;
      }
      return (<EditableInput
        editable={editable}
        value={text.value}
        type={type}
        onChange={value => this.Action.handleCellChange(key, record, value)}
        status={status}
      />);
    },
    renderRadioColumns: (record, key, text) => {
      const { editable, status } = (record && record[key]) || {};
      if (typeof editable === 'undefined') {
        return text;
      }
      return (<EditableRadio
        editable={editable}
        value={text.value}
        onChange={value => this.Action.handleCellChange(key, record, value)}
        status={status}
      />);
    },
    renderAmountColumns: (record, key, text) => {
      const { editable, status } = (record && record[key]) || {};
      if (typeof editable === 'undefined') {
        return text;
      }
      const value = {
        fixedAmount: record.fixedAmount.value,
        isFixedAmount: record.isFixedAmount
      }
      return (<EditableAmount
        editable={editable}
        value={value}
        onChange={value => this.Action.handleCellChange(key, record, value)}
        status={status}
      />);
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { save, cancel, changePage } = this.Action
    return (
      <div>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    // 获得初始化数据
    this.Request.getSource()
    this.Request.getProduct()
    this.setState({
      getDataParams: initGetParams,
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get, getWeight } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
      getWeight(nextState.getDataParams)
    }

  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    dayOptions: hasAttr(state.index.dictList.filter((item, index) => item.value === 'DayOptions'), [0, 'items']) || [],
    cashCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CashCard'), [0, 'items']) || [],
    creditCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CreditCard'), [0, 'items']) || [],
  }

}
export default connect(mapStateToProps)(Route)