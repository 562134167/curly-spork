import React, { Component } from 'react';
import { Table, Modal } from 'antd';
import moment from 'moment';
import { formatData, toMoney } from '../../../../Util/reactUtil'
import { arrayToObject } from '../../../../Util/index'
import { requestEnum } from '../../../../Util/Request'
import { getFetch } from '../../../../Config/request';

const pagingUrl = '/system/oil/getchannelorderlist'

export default class ProxyPay extends Component {
    constructor(props) {
        super(props);

        this.onInit();
    }
    Request = {
        get: (params) => {
            getFetch(pagingUrl, params).then(res => {
                if (res && res.status === 0) {
                    this.setState({
                        dataSource: formatData(res.models)
                    })
                }
            })
        }
    }

    onInit() {
        this.state = {
            dataSource: [],
            getDataParams:[]
        }

        this.columns = [{
            title: '序号',
            dataIndex: 'index',
            key: 'index',
            fixed: 'left',
            width: 60,
            render: (text, record, index) => (index + 1)
        }, {
            title: '订单号',
            dataIndex: 'orderNo',
            key: 'orderNo'
        }, {
            title: '提交状态',
            dataIndex: 'submitStatus',
            key: 'submitStatus',
            render: value => {
                    if (value == 1) {
                        return '已提交'
                    } else if (value == 2) {
                        return '成功'
                    }  else if (value == 3) {
                        return '失败'
                    } 
                }
        }, {
            title: '第三方订单号',
            dataIndex: 'submitNo',
            key: 'submitNo',
        }, {
            title: '订单创建时间',
            dataIndex: 'createTime',
            key: 'createTime',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '订单更新时间',
            dataIndex: 'updateTime',
            key: 'updateTime',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '失败原因',
            dataIndex: 'reason',
            key: 'reason',
        }]
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.orderNo !== this.props.orderNo) {
            this.Request.get({ orderNo: nextProps.orderNo })
        }
    }

    componentDidMount() {
        if (this.props.orderNo) {
            this.Request.get({ orderNo: this.props.orderNo })
        }
    }

    render() {
        const { dataSource } = this.state;
        const { modalVis, onClose } = this.props;
        return (
            <div>
                <Modal
                    title="查看记录"
                    visible={modalVis}
                    onOk={onClose}
                    onCancel={onClose}
                >
                    <Table
                        columns={this.columns}
                        dataSource={dataSource}
                    />
                </Modal>
            </div>
        )
    }
}
