import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'

const loadrefuelingCard = (cb) => {
  return import('./refuelingCard.js')
}
const loadtraintickets = (cb) => {
  return import('./traintickets.js')
}

const RefuelingCard = getComponent(loadrefuelingCard)
const Traintickets = getComponent(loadtraintickets)

export default class Subsidiary extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/thirdparty"
          exact render={() => <Redirect to="/thirdparty/refuelingCard" />}
        />
        <Route path="/thirdparty/refuelingCard" render={(props) => <RefuelingCard {...props} />} />
        <Route path="/thirdparty/traintickets" render={(props) => <Traintickets {...props} />} />
      </Switch>
    )
  }
}