import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import * as EditType from '../../../Common/editType'
import EditPanel, { EditFormWrapper } from '../../../Common/editPanel'
import { Table, message, Card , notification, Button, Modal ,Popconfirm} from 'antd'
import { formatData, flattenObj, handleEndTime, handleStartTime, toMoney , formatFormData } from '../../../Util/reactUtil'
import { hasAttr, arrayToObject } from '../../../Util'
import { actionChangePage, actionClearSearch, actionSearch, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'
import { getFetch,fetch } from '../../../Config/request'
import ProxyPay from './component/proxyPay'

const initGetParams = {
  pageIndex: 1
}
const refundtitle = '批量退款'
const timeout = 9999999
const pagingIntegralExchange = '/system/oil/pagingorder',  //加油卡充值订单列表
			getListUrl = '/system/oil/getparameter',  //获取下拉列表
			rechrargeUrl = '/system/oil/resubmit',//重新充值渠道
    	refundUrl = '/system/oil/refund', //批量退款
    	synchronousUrl = '/system/oil/checkorder' //同步订单状态

export default class refuelingCard extends Component {
  constructor(props) {
    super(props)
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      /**@param {Object} params 
       * 数据格式
       * {
        @param {String} keyword,
        @param {Number} pageIndex,
        @param {Number} pageSize'
      }
       */
      
      return getFetch(pagingIntegralExchange, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['refuelingCard']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex,
            pageSize: params.pageSize,
            selectedRowKeys: []
          })
          !this.state.CardTypeOptions.length && this.Request.getList();
        }
        return res
      })
    },
    getList: (params) => {
      getFetch(getListUrl).then(res => {
        if (res) {
          const { CardTypeOptions , ChannelOptions , refundStatusOptions , tradeStatusOptions} = this.state
          res.model.company.forEach(item => {
            CardTypeOptions.push({
              label: item.companyName,
              value: item.id
            })
          })
          res.model.channel.forEach(item => {
            ChannelOptions.push({
              label: item.name,
              value: item.value
            })
          })
          res.model.refundStatus.forEach(item => {
            refundStatusOptions.push({
              label: item.name,
              value: item.value
            })
          })
          res.model.tradeStatus.forEach(item => {
            tradeStatusOptions.push({
              label: item.name,
              value: item.value
            })
          })
          this.setState({
            CardTypeEnum: arrayToObject({ array: res.model.company, keyName: 'id', valueName: 'companyName' }),
            ChannelEnum: arrayToObject({ array: res.model.channel, keyName: 'value', valueName: 'name' }),
           	refundstatuEnum: arrayToObject({ array: res.model.refundStatus, keyName: 'value', valueName: 'name' }),
            tradeStatusEnum: arrayToObject({ array: res.model.tradeStatus, keyName: 'value', valueName: 'name' }),
            CardTypeOptions,
            ChannelOptions,
            refundStatusOptions,
            tradeStatusOptions
          })
        }
      })
    },
    
   	rechrarge: (params) => {
            return fetch(rechrargeUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams)
                }
                return res
            })
    },
    refund: (params) => {
            return fetch(refundUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams)
                }
                return res
            })
    },
    synchronousPwd: (params) => {
			      return fetch(synchronousUrl, params, null,timeout).then(res => {
				        if (res.status == 0) {
				        	this.Request.get(this.state.getDataParams)
				        }
				        return res
			      })
    }
  }

  Util = {
    getTotalAmount: (dataSource) => {
      let totalAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (item.price) {
        	
          totalAmount += item.price
        }
      })
      return totalAmount
    },
    getSelectedAmount: (dataSource, selectedRowKeys) => {
      const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
      if (!tempSelectedRowKeys.length) {
        return 0
      }
      const selectedString = tempSelectedRowKeys.join(',')
      let selectedAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (selectedString.indexOf(item.key) > -1 && item.price) {
          selectedAmount += item.price
        }
      })
      return selectedAmount
    }
  }

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
        message.error('请输入正确的转出手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
      })
    },
    onShowSizeChange: (current, pageSize) => {
      const { getDataParams } = this.state
      this.setState({
        getDataParams: { ...getDataParams, pageSize, pageIndex: 1 },
        pageSize
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },
    save: (values) => {
      const { selectedRowKeys, type } = this.state
      this.Request[type]({
          ...values,
          ids: selectedRowKeys
      }).then(res => {
          if (res.status == 0) {
              this.setState({
              modalVis: false,
              selectedRowKeys: []
            	})
          }
      })
    },
		onCancelPayModal: () => {
            this.setState({
                payModalVis: false,
                editId: null
            })
    },
    showProxyPay: (record) => {
      this.setState({
        orderNo: record.orderNo,
        proxyPayModalVis: true
      })
    },
    onCloseProxyPay: () => {
      this.setState({
        proxyPayModalVis: false
      })
    },
    // 同步更新状态
    synchronous: (ids) => {
      this.Request.synchronousPwd({ ids: ids});
      this.setState({
        orderNo: null
      })
    },
    confirmPwd: (value) => {
            this.editPayForm.props.form.validateFieldsAndScroll(
                (err, values) => {
                    if (!err) {
                        this.Request.rechrarge({
                            ids: this.state.selectedRowKeys,
                            ...formatFormData(values, this.payFormItems)
                        }).then(res => {
                            if (res.status == 0) {
                                this.setState({
                                    payModalVis: false,
                                })
                            }
                        })
                    }
                })
    },
    // 点击批量操作按钮
        editItems: (name) => {
            const { selectedRowKeys } = this.state
            if (!selectedRowKeys.length) {
                message.error('请至少选中一行要操作的数据')
                return;
            }
            if (name == 'rechrarge') {
            		if (selectedRowKeys.length>1) {
		                message.error('重新充值不支持批量功能，请确认选择的订单只有一条！')
		                return;
		            }
                this.setState({
                    payModalVis: true,
                })
            } else {
                this.setState({
                    modalVis: true,
                    type: name
                })
		            
            }

        },
        cancel: () => {
            this.setState({
                modalVis: false
            })
        },
       	rowSelectionChange: (selectedRowKeys, selectedRows) => {
            const newSelectedRowKeys = [];
            const disabledSerialNumbers = [];
            selectedRows.forEach(item => {
                if (item.tradeStatus == 5 && item.refundStatus == 1) {
                    newSelectedRowKeys.push(item.id);
                } else {
                    disabledSerialNumbers.push(item.orderNo);
                }
                
            })
            
            if (disabledSerialNumbers.length) {
			        notification.warn({
			          message: '操作警告',
			          description: `以下订单：
			              ${disabledSerialNumbers.join(' , ')}
			              不可进行操作！
			              `,
			          duration: null
			        });
			      }
            this.setState({
                selectedRowKeys: newSelectedRowKeys
            })
        }

  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
  	const { showProxyPay ,synchronous} = this.Action
    // const { selectedRowKeys } = this.state;
    // const { view, unfreeze } = this.Action
    this.state = {
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
      totalAmount: 0,
      selectedAmount: 0,
      CardTypeOptions: [],
      CardTypeEnum:[],
      ChannelOptions: [],
      ChannelEnum:[],
      refundStatusOptions: [],
      refundstatuEnum:[],
      tradeStatusOptions: [],
      tradeStatusEnum:[],
      editId: null,
      payModalVis: false,
      proxyPayModalVis: false,
      orderNo: null,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.Select,
          label: '加油卡类型',
          id: 'companyId',
          dataSource: this.state.CardTypeOptions
        },{
          type: SearchType.String,
          label: '加油卡手机号',
          id: 'buyerMobilePhone'
        },{
          type: SearchType.String,
          label: '加油卡卡号',
          id: 'cardNo'
        }, {
          type: SearchType.Select,
          label: '支付渠道',
          id: 'channelId',
          dataSource: this.state.ChannelOptions
        }, {
          type: SearchType.Select,
          label: '交易状态',
          id: 'tradeStatus',
          dataSource: this.state.tradeStatusOptions
        }, {
          type: SearchType.Select,
          label: '退款状态',
          id: 'refundStatus',
          dataSource: this.state.refundStatusOptions
        },{
          type: SearchType.String,
          label: '用户订单号',
          id: 'orderNo'
        },{
          type: SearchType.String,
          label: '第三方订单号',
          id: 'submitOrderNo'
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createTime'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        fixed: 'left',
        width: 40,
        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index - 0 + 1)
      },{
        title: '姓名',
        dataIndex: 'userRealName',
        key: 'userRealName',
        fixed: 'left',
        width: 60
      }, {
        title: '注册手机号',
        dataIndex: 'userMobilePhone',
        key: 'userMobilePhone',
        fixed: 'left',
        width: 100
      }, {
        title: '充值金额',
        dataIndex: 'price',
        key: 'price',
        fixed: 'left',
        width: 80,
        render: value => toMoney(value)
      }, {
        title: '加油卡面额',
        dataIndex: 'cardMoney',
        key: 'cardMoney',
        render: value => toMoney(value)
      }, {
        title: '退款状态',
        dataIndex: 'refundStatus',
        key: 'refundStatus',
        render: (value, record) => this.state.refundstatuEnum[value] || value
      }, {
        title: '交易状态',
        dataIndex: 'tradeStatus',
        key: 'tradeStatus',
        render: (value, record) => this.state.tradeStatusEnum[value] || value
      }, {
        title: '支付渠道',
        dataIndex: 'channelId',
        key: 'channelId',
        render: (value, record) => this.state.ChannelEnum[value] || value
      }, {
        title: '加油卡类型',
        dataIndex: 'companyId',
        key: 'companyId',
        render: (value, record) => this.state.CardTypeEnum[value] || value
      }, {
        title: '加油卡姓名',
        dataIndex: 'buyerRealName',
        key: 'buyerRealName',
      }, {
        title: '加油卡手机号',
        dataIndex: 'buyerMobilePhone',
        key: 'buyerMobilePhone',
      }, {
        title: '加油卡卡号',
        dataIndex: 'cardNo',
        key: 'cardNo',
      }, {
        title: '订单创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '订单更新时间',
        dataIndex: 'updateTime',
        key: 'updateTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '用户订单号',
        dataIndex: 'orderNo',
        key: 'orderNo',
      }, {
        title: '第三方订单号',
        dataIndex: 'merchantOrderNo',
        key: 'merchantOrderNo',
      }, {
        title: '失败原因',
        dataIndex: 'failReason',
        key: 'failReason',
      },{
        title: '操作',
        dataIndex: 'action',
        key: 'action',
        fixed: 'right',
        render: (text, record, index) => (
                    <span>
                    
                    	{(record.tradeStatus != 1 ) ? (
                        <Button type="primary" className="action-item" onClick={() => { showProxyPay(record, index) }}>查看</Button>
                      ) : null}  
                    <span>
                      {((record.tradeStatus ==2 || record.tradeStatus == 3) && record.refundStatus == 1 ) ? (
                      	<Popconfirm
						              title="确定要同步订单状态吗?"
						              onConfirm={() => synchronous(record.id)}
						              okText="确定"
						              cancelText="取消">
						              <Button className="action-item" type="primary"> 同步订单状态</Button>
						            </Popconfirm>
                      ) : null}
                    </span>
                        

                    </span>
                )
      }
    ];
    this.formItems = [
            {
                type: EditType.Select,
                key: 'channelId',
                label: '退款通道',
                itemConfig: {
                    options: [
                        { value: 0, label: '原路返回' },
                        { value: 6, label: '积分返回' },
                        { value: 8, label: '余额返回' },
                    ],
                    disabled: false
        				}
            }, {
                type: EditType.InputStr,
                key: 'payPassword',
                label: '支付操作密码',
                itemConfig: {
                    type: 'password'
                },
                config: {
                    rules: [
                        { required: true, message: '请填写支付操作密码' }
                    ],
                },
            },{
                type: EditType.Textarea,
                label: '退款理由',
                key: 'reason',
                itemConfig: {
                    disabled: false
                }
            }
    ]
    this.payFormItems = [
            {
                type: EditType.InputStr,
                key: 'payPassword',
                label: '支付操作密码',
                itemConfig: {
                    type: 'password'
                },
                config: {
                    rules: [
                        { required: true, message: '请填写支付操作密码' }
                    ],
                },
            }
    ]
  }
  render() {
    const { payModalVis,dataSource, current, totalModels, pageSize, totalAmount, modal, selectedAmount ,selectedRowKeys , title , modalVis , proxyPayModalVis ,orderNo} = this.state
    const { changePage, search, clearSearch, onShowSizeChange ,cancel, save, editItems, onCancelPayModal, confirmPwd, rowSelectionChange ,onCloseProxyPay } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button className="action-item" type="primary" ghost onClick={() => editItems('rechrarge')}>重新充值</Button>
          <Button className="action-item" type="primary" ghost onClick={() => editItems('refund')}>批量退款</Button>
        </Card>
        <Card>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: rowSelectionChange,
          }}
          scroll={{ x: 2000 }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            showSizeChanger: true,
            showTotal: (total, range) => `共 ${total} 条记录`,
            onShowSizeChange: onShowSizeChange,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
        <EditPanel
                    title={refundtitle}
                    modalVis={modalVis}
                    formItems={this.formItems}
                    modal={modal}
                    onSave={save}
                    onCancel={cancel}
                />
                {
                    payModalVis ? (
                        <Modal
                            // className={className}
                            title="重新充值渠道"
                            visible={payModalVis}
                            maskClosable={false}
                            onOk={confirmPwd}
                            onCancel={onCancelPayModal}>
                            <EditFormWrapper
                                modal={{ channelId: { value: '0' } }}
                                wrappedComponentRef={(inst) => this.editPayForm = inst}
                                formItems={this.payFormItems} />
                        </Modal>
                    ) : null
                }
        <ProxyPay
          modalVis={proxyPayModalVis}
          onClose={onCloseProxyPay}
          orderNo={orderNo}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, selectedRowKeys, dataSource } = this.state
    const { get } = this.Request
    const { getSelectedAmount, getTotalAmount } = this.Util
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }

    // 选中的项发生变化时，计算已选中的项的总金额
    if (nextState.selectedRowKeys !== selectedRowKeys) {
      this.setState({
        selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
      })
    }
    // 当前页的数据发生变化时，计算当前页的总金额
    if (nextState.dataSource !== dataSource) {
      this.setState({
        totalAmount: getTotalAmount(nextState.dataSource)
      })
    }
  }
}
