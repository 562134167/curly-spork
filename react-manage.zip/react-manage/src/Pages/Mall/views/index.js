import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
const loadGoods = (cb) => {
    return import('./goods.js')
},
    loadOrder = (cb) => {
        return import('./order.js')
    },
    loadOrderDetail = (cb) => {
        return import('./orderDetail.js')
    },
    loadReturnManage = (cb) => {
        return import('./returnManage.js')
    }
// loadIntegralAudit = (cb) => {
//     return import('./integralAudit.js')
// },
// loadGameCard = (cb) => {
//     return import('./gameCard.js')
// },
// // loadPay = (cb) => {
// //     return import('./pay.js')
// // },
// loadTransfer = (cb) => {
//     return import('./transfer.js')
// }

const Goods = getComponent(loadGoods),
    Order = getComponent(loadOrder),
    OrderDetail = getComponent(loadOrderDetail),
    ReturnManage = getComponent(loadReturnManage)
// IntegralAudit = getComponent(loadIntegralAudit),
// GameCard = getComponent(loadGameCard),
// // Pay = getComponent(loadPay),
// Transfer = getComponent(loadTransfer)



export default class Integral extends Component {
    render() {
        return (
            <Switch>
                <Route
                    path="/mall"
                    exact render={() => <Redirect to="/mall/goods" />}
                />
                <Route path="/mall/goods" render={(props) => <Goods {...props} />} />
                <Route path="/mall/order" render={(props) => <Order {...props} />} />
                <Route path="/mall/orderDetail" render={(props) => <OrderDetail {...props} />} />
                <Route path="/mall/returnManage" render={(props) => <ReturnManage {...props} />} />
                {/*<Route path="/integral/integralAudit" render={(props) => <IntegralAudit {...props} />} />
                <Route path="/integral/gameCard" render={(props) => <GameCard {...props} />} /> */}
                {/* <Route path="/integral/pay" render={(props) => <Pay {...props} />} /> */}
                {/* <Route path="/integral/transfer" render={(props) => <Transfer {...props} />} /> */}


            </Switch>
        )
    }
}