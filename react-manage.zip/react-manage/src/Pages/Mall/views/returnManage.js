/*
 * @Author: miccy 
 * @Date: 2018-03-31 15:58:59 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-19 17:18:31
 * 退款管理
 */


import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, message, Button } from 'antd'
import { toMoney, handleEndTime, handleStartTime } from '../../../Util/reactUtil'
import { getFetch, fetch } from '../../../Config/request'
import { requestGet } from '../../../Util/Request'
import { arrayToObject } from '../../../Util'
import { actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal, actionSearch, actionClearSearch } from '../../../Util/Action'

import TwoDecimals from '../../../Common/twoDecimals'

const pagingUrl = '/system/shop/pagingrefund', //获取列表
    getRefundStatusListUrl = '/system/enums/orderrefundstatus',//获取订单退款状态列表
    refundUrl = '/system/shop/agreerefund', //商品退款
    refuseUrl = '/system/shop/rejectrefund'; //拒绝退款

const refundTitle = '退款',
    refuseTitle = '拒绝';

const typeEnum = {
    REFUSE: 'refuse',
    REFUND: 'refund'
},
    isReceiveOptions = [{
        label: '已收货', value: 1
    }, { label: '未收回', value: 0 }];

class ReturnManage extends Component {
    constructor(props) {
        super(props)

        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({
                params, pagingUrl, context: this
            })
                .then(res => {
                    if (res && res.status == 0) {
                        // 获取相关下拉列表的选项数组
                        !this.state.refundStatusOptions.length && this.Request.getRefundStatusList();
                    }
                })
        },
        getRefundStatusList: (params) => {
            getFetch(getRefundStatusListUrl).then(res => {
                if (is.array(res)) {
                    const { refundStatusOptions } = this.state
                    res.forEach(item => {
                        refundStatusOptions.push({
                            label: item.name,
                            value: item.value
                        })
                    })
                    this.setState({
                        refundStatusEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
                        refundStatusOptions
                    })
                }
            })
        },

        refuse: (params) => {
            fetch(refuseUrl, params).then(res => {
                if (res.status == 0) {
                    this.setState({
                        refuseModalVis: false
                    })
                    this.Request.get(this.state.getDataParams);
                }
            })
        },
        refund: (params) => {
            fetch(refundUrl, params).then(res => {
                if (res.status == 0) {
                    this.setState({
                        refundModalVis: false
                    })
                    this.Request.get(this.state.getDataParams);
                }
            })
        }
    }

    Util = {
        handleSearchValues: (values) => {
            const queryParams = Object.assign({}, values)
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
                message.error('请输入正确的手机号码')
                return;
            }
            if (!is.undefined(queryParams.createTime) && !is.undefined(queryParams.createTime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createTime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createTime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }
            return queryParams
        },

    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this });
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this });
        },
        search: (values) => {
            const tmp = this.Util.handleSearchValues(values);
            if (tmp) {
                actionSearch({ value: values, context: this });
            }
        },
        clearSearch: () => {
            actionClearSearch({ context: this });
        },
        // 拒绝
        refuse: (values) => {
            this.Request.refuse({ ...values, orderProductId: this.state.editId })
        },
        refund: (values) => {
            this.Request.refund({ ...values, orderProductId: this.state.editId })
        },
        // 根据操作类型显示不同模态框
        showModal: (record, index, type) => {
            this.setState({
                editId: record.orderProductId,
                [type + 'ModalVis']: true,
                modal: record,
            })
        },
        // 根据不同类型隐藏模态框
        hideModal: (type) => {
            this.setState({
                [type + 'ModalVis']: false
            })
        },

    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        const { showModal } = this.Action
        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            refundStatusOptions: [],
            refundStatusEnum: {},
            modal: {},
            refundModalVis: false,
            refuseModalVis: false,
            editId: null,
        }

        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '订单号',
                    id: 'orderNo'
                }, {
                    type: SearchType.String,
                    label: '买家账号',
                    id: 'userMobile'
                },
                {
                    type: SearchType.Select,
                    label: '退款状态',
                    id: 'refundStatus',
                    dataSource: this.state.refundStatusOptions
                }, {
                    type: SearchType.DateRange,
                    label: '退款处理时间',
                    id: 'createTime'
                }, {
                    type: SearchType.Select,
                    label: '是否收到货',
                    id: 'isReceive',
                    dataSource: isReceiveOptions
                }

            ]
        }

        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            }, {
                title: '订单号',
                dataIndex: 'orderNo',
                key: 'orderNo'
            }, {
                title: '商品名称',
                dataIndex: 'productName',
                key: 'productName'
            }, {
                title: '问题描述',
                dataIndex: 'refundDesc',
                key: 'refundDesc',
                width: 150
            }, {
                title: '商品金额',
                dataIndex: 'price',
                key: 'price',
                render: value => toMoney(value)
            }, {
                title: '运费',
                dataIndex: 'freightCharge',
                key: 'freightCharge',
                render: value => toMoney(value)
            }, {
                title: '订单总价',
                dataIndex: 'totalAmount',
                key: 'totalAmount',
                render: value => toMoney(value)
            }, {
                title: '买家账号',
                dataIndex: 'mobilePhone',
                key: 'mobilePhone'
            }, {
                title: '买家姓名',
                dataIndex: 'realName',
                key: 'realName'
            }, {
                title: '退款状态',
                dataIndex: 'refundStatus',
                key: 'refundStatus',
                render: value => this.state.refundStatusEnum[value] || value
            }, {
                title: '退款金额',
                dataIndex: 'refundAmount',
                key: 'refundAmount',
                render: value => toMoney(value)
            }, {
                title: '退款备注',
                dataIndex: 'handleRemark',
                key: 'handleRemark'
            }, {
                title: '退款申请时间',
                dataIndex: 'refundApplyTime',
                key: 'refundApplyTime',
                render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
            }, {
                title: '退款处理时间',
                dataIndex: 'handleTime',
                key: 'handleTime',
                render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
            }, {
                title: '操作',
                dataIndex: 'actions',
                key: 'actions',
                // width: 250,
                render: (text, record, index) => (
                    record.refundStatus == 1 ? (<span>
                        <Button type="danger" className="action-item" onClick={() => { showModal(record, index, typeEnum.REFUSE) }}>拒绝</Button>
                        <Button type="primary" ghost className="action-item" onClick={() => { showModal(record, index, typeEnum.REFUND) }}>退款</Button>

                    </span>) : null
                )
            }
        ]
        this.refuseFormItems = [
            {
                type: EditType.InputStr,
                label: '拒绝原因',
                key: 'handleRemark'
            }
        ]
        this.refundFormItems = [
            {
                render: TwoDecimals,
                type: EditType.InputNum,
                label: '退款金额',
                key: 'refundAmount',
                config: {
                    rules: [{ required: true, message: '请输入退款金额' }]
                },
                isInputNum: true
            }, {
                type: EditType.InputStr,
                label: '退款备注',
                key: 'handleRemark',
            },
            {
                type: EditType.Select,
                key: 'channelId',
                label: '退款渠道',
                itemConfig: {
                    options: [
                        { label: '原路退回', value: '0' },
                        { label: '余额', value: '8' }
                    ]
                },
                isSelectNum: true
            },
            {
                type: EditType.InputStr,
                label: '支付密码',
                key: 'payPassword',
                config: {
                    rules: [
                        { required: true, message: '请输入支付密码' }
                    ]
                },
                itemConfig: {
                    type: 'password'
                }
            }
        ]
    }
    render() {
        const { dataSource, current, totalModels, pageSize, selectedRowKeys, refundModalVis, refuseModalVis } = this.state
        const { changePage, onShowSizeChange, search, clearSearch, refund, refuse, hideModal } = this.Action
        return (
            <div>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Table
                    scroll={{ x: 1800 }}
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal,
                        pageSizeOptions: ['50', '100', '200'],
                    }}
                />

                {/* 拒绝 */}
                <EditPanel
                    title={refuseTitle}
                    modalVis={refuseModalVis}
                    formItems={this.refuseFormItems}
                    onSave={refuse}
                    onCancel={() => { hideModal(typeEnum.REFUSE) }}
                />
                {/* 退款 */}
                <EditPanel
                    title={refundTitle}
                    modalVis={refundModalVis}
                    formItems={this.refundFormItems}
                    modal={{ channelId: { value: '0' } }}
                    onSave={refund}
                    onCancel={() => { hideModal(typeEnum.REFUND) }}
                />
            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
        })

    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }

    }
}
export default ReturnManage