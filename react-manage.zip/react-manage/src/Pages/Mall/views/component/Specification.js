import React, { PureComponent } from 'react'
import { Input, Button, Tag, Row, Col } from 'antd'
import is from 'is_js'
import { bindFunc } from '../../../../Util/reactUtil'
// import { hasAttr } from '../../../../Util'
export default class Specification extends PureComponent {
    constructor(props) {
        super(props)
        const value = this.Util.formatProp(this.props.value || []);
        this.Action.triggerChange(value);
        bindFunc([{ key: 'Action', value: ['deleteItem', 'newItem'] }], this);
        this.state = {
            list: value
        }
    }
    Util = {
        formatProp: (arr) => {
            const temp = [];
            arr.forEach((obj, index) => {
                if (is.undefined(obj.id)) {
                    const key = Object.keys(obj)[0];
                    temp.push({
                        key,
                        value: obj[key],
                        id: new Date().getTime() + index
                    })
                } else {
                    temp.push(obj);
                }
            });
            return temp;
        }
    }
    Action = {
        // 删除规格参数项
        deleteItem: (index) => {
            const list = JSON.parse(JSON.stringify(this.state.list));
            // agreement.splice(index, 1)
            list.splice(index, 1);
            if (!('value' in this.props)) {
                this.setState({
                    list
                })
            }
            this.Action.triggerChange(list)
        },

        onKeyChange: (e, index) => {
            const { value } = e.target,
                list = JSON.parse(JSON.stringify(this.state.list));
            list[index]['key'] = value;
            this.Action.triggerChange(list);
        },
        onValueChange: (e, index) => {
            const { value } = e.target,
                list = JSON.parse(JSON.stringify(this.state.list));
            list[index]['value'] = value;
            this.Action.triggerChange(list);
        },
        // 新增项
        newItem: () => {
            const list = JSON.parse(JSON.stringify(this.state.list));
            list.push({ key: '', value: '', id: new Date().getTime() });
            this.Action.triggerChange(list)
        },
        triggerChange: (changedValue) => {
            const onChange = this.props.onChange
            if (onChange) {
                onChange(changedValue)
            }
        }
    }
    componentWillReceiveProps(nextProps) {
        if ('value' in nextProps) {
            const value = nextProps.value || []
            this.setState({
                list: this.Util.formatProp(value)
            })
        }
    }
    RenderFunc = {
        renderItems: (list) => {
            const { onKeyChange, onValueChange, deleteItem } = this.Action;
            return list.map((item, index) => {
                return (
                    <Tag
                        closable
                        onClose={() => deleteItem(index)}
                        key={item.id}
                        style={{ height: 'auto',position: 'relative' }}
                    >
                        <Row>
                            <Col span="10">
                                <Input value={item.key} onChange={(e) => onKeyChange(e, index)} />
                            </Col>
                            <Col span="2">
                                <p style={{ textAlign: 'center' }}>:</p>
                            </Col>
                            <Col span="10">
                                <Input value={item.value} onChange={(e) => onValueChange(e, index)} />
                            </Col>
                        </Row>

                    </Tag >

                )
            })
        }
    }
    render() {
        const { newItem } = this.Action
        const { list } = this.state
        return (
            <div className="goods-attr">
                <div>
                    <Button type="primary" onClick={newItem}>新增</Button>
                </div>
                {this.RenderFunc.renderItems(list)}
            </div>
        )
    }
}