import React, { PureComponent } from 'react'
import { Select } from 'antd'
// import { hasAttr } from '../../../../Util'
import { getFetch } from '../../../../Config/request'
// import is from 'is_js'
const { Option } = Select;
const getOptionsUrl = '/system/shop/getAreaList';

export default class Location extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value || {}
    this.state = {
      provinceCode: value.provinceCode,
      cityCode: value.cityCode,
      areaCode: value.areaCode,
      provinceOptions: [],
      cityOptions: [],
      areaOptions: [],
    }
  }
  Request = {
    getOptions: (params) => {
      return getFetch(getOptionsUrl, params).then(res => {
        return res
      })
    }
  }
  Action = {
    handleProvinceChange: (value) => {
      // this.Request.getOptions(value).then(res => {
      //   if (res.status == 0) {
      //     this.setState({
      //       cityOptions: res.model.resultList,
      //       areaOptions: []
      //     })
      //   }
      // })
      if (!('value' in this.props)) {
        this.setState({
          provinceCode: value,
          cityCode: '',
          areaCode: ''
        })
      }
      this.Action.triggerChange({
        provinceCode: value,
        cityCode: '',
        areaCode: ''
      })
    },
    handleCityChange: (value) => {
      // this.Request.getOptions(value).then(res => {
      //   if (res.status == 0) {
      //     this.setState({
      //       areaOptions: res.model.resultList
      //     })
      //   }
      // })
      if (!('value' in this.props)) {
        this.setState({
          cityCode: value,
          areaCode: ''
        })
      }
      this.Action.triggerChange({
        cityCode: value,
        areaCode: ''
      })
    },
    handleAreaChange: (value) => {
      if (!('value' in this.props)) {
        this.setState({
          areaCode: value
        })
      }
      this.Action.triggerChange({
        areaCode: value
      })
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange;
      const { provinceCode, cityCode, areaCode } = this.state;
      if (onChange) {
        const value = Object.assign({}, { provinceCode, cityCode, areaCode }, changedValue);
        onChange(value)
      }
    },

  }

  componentDidMount() {
    const { provinceCode, cityCode } = this.state;
    this.Request.getOptions().then(res => {
      if (res.status == 0) {
        this.setState({
          provinceOptions: res.model.resultList
        })
      }
    })
    if (provinceCode) {
      this.Request.getOptions({ code: provinceCode }).then(res => {
        if (res.status == 0) {
          this.setState({
            cityOptions: res.model.resultList
          })
        }
      })
    }
    if (cityCode) {
      this.Request.getOptions({ code: cityCode }).then(res => {
        if (res.status == 0) {
          this.setState({
            areaOptions: res.model.resultList
          })
        }
      })
    }
  }


  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value || {}
      const { provinceCode, cityCode } = this.state;
      if (provinceCode !== value.provinceCode) {
        this.Request.getOptions({ code: value.provinceCode }).then(res => {
          if (res.status == 0) {
            this.setState({
              cityOptions: res.model.resultList,
              areaOptions: []
            })
          }
        })
      }
      if (cityCode !== value.cityCode) {
        this.Request.getOptions({ code: value.cityCode }).then(res => {
          if (res.status == 0) {
            this.setState({
              areaOptions: res.model.resultList
            })
          }
        })
      }
      this.setState({
        provinceCode: value.provinceCode,
        cityCode: value.cityCode,
        areaCode: value.areaCode
      })
    }
  }

  render() {
    const { handleProvinceChange, handleCityChange, handleAreaChange } = this.Action
    const { provinceCode, cityCode, areaCode, provinceOptions, cityOptions, areaOptions } = this.state
    return (
      <div>
        <Select value={provinceCode} style={{ width: 120 }} onChange={handleProvinceChange}>
          {provinceOptions.map((item, index) => <Option value={item.code} key={item.code}>{item.name}</Option>)}
        </Select>
        <Select value={cityCode} style={{ width: 120 }} onChange={handleCityChange}>
          {cityOptions.map((item, index) => <Option value={item.code} key={item.code}>{item.name}</Option>)}
        </Select>
        <Select value={areaCode} style={{ width: 120 }} onChange={handleAreaChange}>
          {areaOptions.map((item, index) => <Option value={item.code} key={item.code}>{item.name}</Option>)}
        </Select>
      </div>
    )
  }
}