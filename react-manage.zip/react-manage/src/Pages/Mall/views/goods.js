/*
 * @Author: miccy 
 * @Date: 2018-03-29 10:36:58 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-17 11:46:03
 * 单店商城的商品管理
 */
import React, { Component } from 'react'
// import moment from 'moment'
// import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, message, Card, Button } from 'antd'
import { toMoney, formatData, formateEditData } from '../../../Util/reactUtil'
import { getFetch, fetch } from '../../../Config/request'
import { requestGet, requestAdd, requestUpdate } from '../../../Util/Request'
// import { arrayToObject } from '../../../Util'
import { actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal, actionSearch, actionClearSearch, actionAdd, actionCancel, actionEdit, actionEditItems } from '../../../Util/Action'

import TwoDecimals from '../../../Common/twoDecimals'
import Editor from '../../../Common/Editor'
import Specification from './component/Specification'
import Location from './component/Location'

import './goods.less';

const pagingUrl = '/system/shop/getGoodsPage', //获取列表
    addUrl = '/system/shop/addGoods',
    updateUrl = '/system/shop/updateGoods', //修改
    getMerchantListUrl = '/system/shop/getMerchantList', //获取商家列表
    getUnitListUrl = '/system/shop/getUnitList', //获取商品单位列表
    getGoodsStatusListUrl = '/system/shop/getGoodsStatusList',//获取商品状态列表
    changeStatusUrl = '/system/shop/upOrDown', //修改商品上下架状态
    uploadFileUrl = '/system/file/upload'

const addTitle = '新建商品'
const editTitle = '编辑商品'



class Goods extends Component {
    constructor(props) {
        super(props)

        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({
                params, pagingUrl, context: this, successCallback: (res) => {
                    const { models, totalModels } = res
                    const dataSource = formatData(models, 'goodsId')
                    this.setState({
                        dataSource,
                        totalModels,
                        current: params.pageIndex,
                        pageSize: params.pageSize,
                        selectedRowKeys: []
                    })
                }
            }).then(res => {
                if (res && res.status == 0) {
                    !this.state.merchantOptions.length && this.Request.getMerchantList();
                    !this.state.unitOptions.length && this.Request.getUnitList();
                    !this.state.goodsStatusOptions.length && this.Request.getGoodsStatusList();
                }
            })
        },
        add: (params) => {
            requestAdd({ params, addUrl, context: this });
        },
        // 修改数据
        edit: (params) => {
            requestUpdate({ params, updateUrl, context: this })
        },
        getMerchantList: () => {
            getFetch(getMerchantListUrl).then(res => {
                if (res && res.status == 0) {
                    const { merchantOptions } = this.state
                    res.model.resultList.forEach(item => {
                        merchantOptions.push({
                            label: item.merchantName,
                            value: item.userId
                        })
                    })
                    this.setState({
                        merchantOptions
                    })
                }
            })
        },
        getUnitList: (params) => {
            getFetch(getUnitListUrl).then(res => {
                if (res && res.status == 0) {
                    const { unitOptions } = this.state
                    res.model.resultList.forEach(item => {
                        unitOptions.push({
                            label: item.value,
                            value: item.key
                        })
                    })
                    this.setState({
                        unitOptions
                    })
                }
            })
        },
        getGoodsStatusList: (params) => {
            getFetch(getGoodsStatusListUrl).then(res => {
                if (res && res.status == 0) {
                    const { goodsStatusOptions } = this.state
                    res.model.resultList.forEach(item => {
                        goodsStatusOptions.push({
                            label: item.value,
                            value: item.key
                        })
                    })
                    this.setState({
                        goodsStatusOptions
                    })
                }
            })
        },
        changeStatus: (params) => {
            fetch(changeStatusUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams);
                }
            })
        }
    }

    Util = {
        handleEditData: (record) => {
            if (record.images) {
                const fileList = [];
                for (let i in record.images) {
                    fileList.push({
                        uid: new Date().getTime() + i,
                        status: 'done',
                        url: record.images[i],
                        response: record.images[i]
                    })
                }
                record.images = fileList;
            }
            const location = {};
            location.provinceCode = record.provinceCode;
            location.cityCode = record.cityCode;
            location.areaCode = record.areaCode;
            record.location = location;
            return record;
        },
        handleChangedData: (record) => {
            // 处理商品规格
            if (record.attributeList) {
                const attributeList = [];
                record.attributeList.forEach(item => {
                    if (item.key && item.value) {
                        attributeList.push(JSON.stringify({
                            [item.key]: item.value
                        }))
                    }
                })
                record.attributeList = attributeList;
            }
            if (record.images) {
                const tempArr = []
                for (let i in record.images) {
                    tempArr.push(record.images[i].response)
                }
                record.images = tempArr;
            }
            if (record.location) {
                record.provinceCode = record.location.provinceCode;
                record.cityCode = record.location.cityCode;
                record.areaCode = record.location.areaCode;
                delete record.location;
            }
            return record;
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this });
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this });
        },
        search: (values) => {
            // const tmp = this.Util.handleSearchValues(values);
            // if (tmp) {
            actionSearch({ value: values, context: this });
            // }
        },
        clearSearch: () => {
            actionClearSearch({ context: this });
        },
        add: () => {
            actionAdd({ context: this, addTitle });
        },
        edit: (record, index) => {
            actionEdit({ context: this, record, editTitle, handleEditData: this.Util.handleEditData });
            let modal = {}
            let obj = formateEditData(record, this.formItems, this.Util.handleEditData)
            for (let i in obj) {
                modal[i] = {
                    value: obj[i]
                }
            }
            this.setState({
                editId: obj.goodsId,
                modalVis: true,
                modal: modal,
                title: editTitle
            })
        },
        // 点击批量操作按钮
        editItems: ({ name, value }) => {
            actionEditItems({ context: this, name, value });
        },
        save: (values) => {
            if (!values.location.provinceCode || !values.location.cityCode) {
                message.error('发货地省和市为必填项！');
                return;
            }
            const { dataSource, editId } = this.state
            const { add, edit } = this.Request
            // 把保存的数值发送到服务器
            // 编辑状态下的保存
            if (editId || editId === 0) {
                for (let i in dataSource) {
                    if (dataSource[i].goodsId === editId) {
                        const temp = this.Util.handleChangedData({ ...dataSource[i], ...values })
                        edit(temp)
                        break;
                    }
                }
            } else {
                // 新增状态下的保存
                const temp = this.Util.handleChangedData(values);
                add(temp)
            }
            // actionSave({ this: this, values, handleChangedData: this.Util.handleChangedData });
        },
        cancel: () => {
            actionCancel({ context: this });
        },
        changeStatus: (record) => {
            this.Request.changeStatus({ goodsId: record.goodsId });
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        const { changeStatus, edit } = this.Action
        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            // channelEnum: {},
            merchantOptions: [],
            unitOptions: [],
            goodsStatusOptions: [],
            modal: {},
            modalVis: false,
            title: addTitle,
            editId: null,
        }

        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.Select,
                    label: '所属商户',
                    id: 'userId',
                    dataSource: this.state.merchantOptions
                },
                {
                    type: SearchType.String,
                    label: '商品名称',
                    id: 'goodsName'
                },
                {
                    type: SearchType.Select,
                    label: '商品状态',
                    id: 'goodsStatus',
                    dataSource: this.state.goodsStatusOptions
                },
            ]
        }

        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            }, {
                title: '商品ID',
                dataIndex: 'goodsId',
                key: 'goodsId'
            }, {
                title: '所属商户',
                dataIndex: 'merchantName',
                key: 'merchantName'
            }, {
                title: '商品标题',
                dataIndex: 'title',
                key: 'title'
            }, {
                title: '商品图片',
                dataIndex: 'images',
                key: 'images',
                render: value => {
                    return value && value[0] && <img width={80} src={value[0]} alt="商品图片" />
                }
            }, {
                title: '商品描述',
                dataIndex: 'introduce',
                key: 'introduce',
                width: 100
            }, {
                title: '商品原价',
                dataIndex: 'originalPrice',
                key: 'originalPrice',
                render: value => toMoney(value)
            }, {
                title: '商品现价',
                dataIndex: 'price',
                key: 'price',
                render: value => toMoney(value)
            }, {
                title: '商品库存',
                dataIndex: 'stock',
                key: 'stock'
            }, {
                title: '商品运费',
                dataIndex: 'freightCharge',
                key: 'freightCharge',
                render: value => toMoney(value)
            }, {
                title: '商品状态',
                dataIndex: 'goodsStatusStr',
                key: 'goodsStatusStr'
            }, {
                title: '创建时间',
                dataIndex: 'createTimeStr',
                key: 'createTimeStr'
            }, {
                title: '操作',
                dataIndex: 'actions',
                key: 'actions',
                width: 250,
                render: (text, record, index) => (
                    <span>
                        <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
                        <Button type="primary" className="action-item" onClick={() => { changeStatus(record, index) }}>{record.goodsStatus == 1 ? '下架' : '上架'}</Button>
                    </span>
                )
            }
        ]

        this.formItems = [
            {
                type: EditType.Select,
                label: '所属商户',
                key: 'userId',
                config: {
                    rules: [{ required: true, message: '请选择所属商户' }]
                },
                itemConfig: {
                    options: this.state.merchantOptions
                }
            },
            {
                type: EditType.InputStr,
                label: '商品标题',
                key: 'title',
                config: {
                    rules: [{ required: true, message: '请输入商品标题' }]
                }
            }, {
                type: EditType.InputStr,
                label: '商品描述',
                key: 'introduce',
                config: {
                    rules: [{ required: true, message: '请输入商品描述' }]
                }
            }, {
                type: EditType.InputNum,
                label: '商品库存',
                key: 'stock',
                config: {
                    rules: [{ required: true, message: '请输入商品库存' }]
                }
            }, {
                render: TwoDecimals,
                type: EditType.InputNum,
                label: '商品原价格',
                key: 'originalPrice',
                config: {
                    rules: [{ required: true, message: '请输入商品原价格' }]
                },
                isInputNum: true
            }, {
                render: TwoDecimals,
                type: EditType.InputNum,
                label: '商品现价',
                key: 'price',
                config: {
                    rules: [{ required: true, message: '请输入商品现价' }]
                },
                isInputNum: true
            }, {
                render: TwoDecimals,
                type: EditType.InputNum,
                label: '运费',
                key: 'freightCharge',
                config: {
                    rules: [{ required: true, message: '请输入运费' }]
                },
                isInputNum: true
            }, {
                type: EditType.Select,
                label: '状态',
                key: 'goodsStatus',
                itemConfig: {
                    options: this.state.goodsStatusOptions
                },
                config: {
                    rules: [
                        { required: true, message: '请选择状态' }
                    ]
                },
            }, {
                type: EditType.Image,
                label: '商品图片',
                key: 'images',
                config: {
                    valuePropName: 'fileList',
                    getValueFromEvent: (e) => {
                        if (Array.isArray(e)) {
                            return e;
                        }
                        return e && e.fileList;
                    },
                    rules: [
                        { required: true, message: '请上传商品图片' }
                    ]
                },
                itemConfig: {
                    action: window.baseUrl + uploadFileUrl,
                    tip: '上传商品图片',
                    accept: '.jpg, .png, .bmp, .jpeg',
                    name: 'files'
                },
                isImageAutoHandle: false,
                isShowbtn: (props) => {
                    if (props.form.getFieldValue('images') && props.form.getFieldValue('images').length >= 5) {
                        return false
                    }
                    return true
                }
            }, {
                type: EditType.Select,
                label: '运费收取方式',
                key: 'freightBy',
                config: {
                    rules: [{ required: true, message: '请选择运费收取方式' }]
                },
                itemConfig: {
                    options: [
                        { label: '按每单收运费', value: 1 },
                        { label: '按每件收运费', value: 2 },
                    ]
                },
                isSelectNum: true
            }, {
                type: EditType.Select,
                label: '商品单位',
                key: 'unit',
                config: {
                    rules: [{ required: true, message: '请选择商品单位' }]
                },
                itemConfig: {
                    options: this.state.unitOptions
                },
                isSelectNum: true
            }, {
                render: Specification,
                key: 'attributeList',
                label: '商品规格'
            }, {
                render: Location,
                key: 'location',
                label: '发货地',
                config: {
                    rules: [{ required: true, message: '请选择发货地' }]
                },
            }, {
                label: '商品详情',
                key: 'content',
                render: Editor,
                config: {
                    rules: [
                        { required: true, message: '请输入商品详情' }
                    ]
                }
            }
        ]

    }
    render() {
        const { dataSource, current, totalModels, pageSize, selectedRowKeys, modal, modalVis, title } = this.state
        const { add, changePage, onShowSizeChange, search, clearSearch, save, cancel } = this.Action
        return (
            <div>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Card>
                    <Button type="primary" onClick={add} className="action-item">新增</Button>
                </Card>
                <Table
                    scroll={{ x: 1500 }}
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal,
                        pageSizeOptions: ['50', '100', '200'],
                    }}
                />
                <EditPanel
                    title={title}
                    modalVis={modalVis}
                    formItems={this.formItems}
                    modal={modal}
                    onSave={save}
                    onCancel={cancel}
                />
            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
        })

    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }

    }
}
export default Goods