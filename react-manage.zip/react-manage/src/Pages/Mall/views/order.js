/*
 * @Author: miccy 
 * @Date: 2018-03-29 18:31:15 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-03 13:40:08
 * 订单管理
 */
import React, { Component } from 'react'
// import moment from 'moment'
// import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, message, Button } from 'antd'
import { toMoney, formatData } from '../../../Util/reactUtil'
import { getFetch, fetch } from '../../../Config/request'
import { requestGet } from '../../../Util/Request'
// import { arrayToObject } from '../../../Util'
import { actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal, actionSearch, actionClearSearch } from '../../../Util/Action'

const pagingUrl = '/system/shop/getOrderPage', //获取列表
    getMerchantListUrl = '/system/shop/getMerchantList', //获取商家列表
    getOrderStatusListUrl = '/system/shop/getOrderStatusList',//获取订单状态列表
    sendUrl = '/system/shop/sendGoods'; //商品发货

// const viewTitle = '查看订单详情',
const sendTitle = '发货';



class Order extends Component {
    constructor(props) {
        super(props)
        
        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({
                params, pagingUrl, context: this, successCallback: (res) => {
                    const { models, totalModels } = res
                    const dataSource = formatData(models, 'orderId')
                    this.setState({
                        dataSource,
                        totalModels,
                        current: params.pageIndex,
                        pageSize: params.pageSize,
                        selectedRowKeys: []
                    })
                }
            }).then(res => {
                if (res && res.status == 0) {
                    // 获取相关下拉列表的选项数组
                    !this.state.merchantOptions.length && this.Request.getMerchantList();
                    !this.state.orderStatusOptions.length && this.Request.getOrderStatusList();
                }
            })
        },
        getMerchantList: () => {
            getFetch(getMerchantListUrl).then(res => {
                if (res && res.status == 0) {
                    const { merchantOptions } = this.state
                    res.model.resultList.forEach(item => {
                        merchantOptions.push({
                            label: item.merchantName,
                            value: item.userId
                        })
                    })
                    this.setState({
                        merchantOptions
                    })
                }
            })
        },
        getOrderStatusList: (params) => {
            getFetch(getOrderStatusListUrl).then(res => {
                if (res && res.status == 0) {
                    const { orderStatusOptions } = this.state
                    res.model.resultList.forEach(item => {
                        orderStatusOptions.push({
                            label: item.value,
                            value: item.key
                        })
                    })
                    this.setState({
                        orderStatusOptions
                    })
                }
            })
        },
        // 发货
        send: (params) => {
            fetch(sendUrl, params).then(res => {
                if (res.status == 0) {
                    this.setState({
                        sendModalVis: false
                    })
                    this.Request.get(this.state.getDataParams);
                }
            })
        }
    }

    Util = {
        handleSearchValues: (values) => {
            const queryParams = Object.assign({}, values)
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
                message.error('请输入正确的手机号码')
                return;
            }
            return queryParams
        },

    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this });
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this });
        },
        search: (values) => {
            const tmp = this.Util.handleSearchValues(values);
            if (tmp) {
                actionSearch({ value: values, context: this });
            }
        },
        clearSearch: () => {
            actionClearSearch({ context: this });
        },
        // 发货
        send: (values) => {
            this.Request.send({ ...values, orderId: this.state.editId })
        },
        showSendModal: (record, index) => {
            this.setState({
                editId: record.orderId,
                sendModalVis: true
            })
        },
        view: (record, index) => {
            this.props.history.push('/mall/orderDetail', { orderId: record.orderId, tradeCode: record.tradeCode, orderNo: record.orderNo });
        },
        sendCancel: () => {
            this.setState({
                sendModalVis: false
            })
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        const { showSendModal, view } = this.Action
        this.state = {
            dataSource: [],
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            // channelEnum: {},
            merchantOptions: [],
            orderStatusOptions: [],
            modal: {},
            modalVis: false,
            sendModalVis: false,
            editId: null,
        }

        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.Select,
                    label: '所属商户',
                    id: 'userId',
                    dataSource: this.state.merchantOptions
                },
                {
                    type: SearchType.String,
                    label: '订单号',
                    id: 'orderNo'
                }, {
                    type: SearchType.String,
                    label: '买家账号',
                    id: 'userMobile'
                },
                {
                    type: SearchType.Select,
                    label: '订单状态',
                    id: 'orderStatus',
                    dataSource: this.state.orderStatusOptions
                },

            ]
        }

        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            }, {
                title: '所属商户',
                dataIndex: 'merchantName',
                key: 'merchantName',
                width: 100
            }, {
                title: '订单号',
                dataIndex: 'orderNo',
                key: 'orderNo'
            }, {
                title: '商品金额',
                dataIndex: 'goodsAmount',
                key: 'goodsAmount',
                render: value => toMoney(value)
            }, {
                title: '运费',
                dataIndex: 'freightCharge',
                key: 'freightCharge',
                render: value => toMoney(value)
            }, {
                title: '订单总价',
                dataIndex: 'totalAmount',
                key: 'totalAmount',
                render: value => toMoney(value)
            }, {
                title: '买家账号',
                dataIndex: 'userMobile',
                key: 'userMobile'
            }, {
                title: '买家姓名',
                dataIndex: 'userRealName',
                key: 'userRealName'
            }, {
                title: '订单状态',
                dataIndex: 'orderStatusStr',
                key: 'orderStatusStr'
            }, {
                title: '下单时间',
                dataIndex: 'createTimeStr',
                key: 'createTimeStr'
            }, {
                title: '付款时间',
                dataIndex: 'payTimeStr',
                key: 'payTimeStr'
            }, {
                title: '付款渠道',
                dataIndex: 'channelIdStr',
                key: 'channelIdStr',
            }, {
                title: '发货时间',
                dataIndex: 'sendTimeStr',
                key: 'sendTimeStr'
            }, {
                title: '操作',
                dataIndex: 'actions',
                key: 'actions',
                width: 250,
                render: (text, record, index) => (
                    <span>
                        <Button type="primary" className="action-item" onClick={() => { view(record, index) }}>详情</Button>
                        {record.orderStatus === 2 ? (<Button type="primary" ghost className="action-item" onClick={() => { showSendModal(record, index) }}>发货</Button>) : null}
                    </span>
                )
            }
        ]

        this.sendFormItems = [
            {
                type: EditType.InputStr,
                label: '快递类型',
                key: 'expressType',
                config: {
                    rules: [{ required: true, message: '请输入快递类型' }]
                }
            }, {
                type: EditType.InputStr,
                label: '快递单号',
                key: 'expressNo',
                config: {
                    rules: [{ required: true, message: '请输入快递单号' }]
                }
            }, {
                type: EditType.InputStr,
                label: '快递备注',
                key: 'expressRemark'
            }
        ]

    }
    render() {
        const { dataSource, current, totalModels, pageSize, selectedRowKeys, sendModalVis } = this.state
        const { changePage, onShowSizeChange, search, clearSearch, send, sendCancel } = this.Action
        return (
            <div>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Table
                    scroll={{ x: 1500 }}
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal,
                        pageSizeOptions: ['50', '100', '200'],
                    }}
                />
                <EditPanel
                    title={sendTitle}
                    modalVis={sendModalVis}
                    formItems={this.sendFormItems}
                    onSave={send}
                    onCancel={sendCancel}
                />
            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
        })

    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }

    }
}
export default Order