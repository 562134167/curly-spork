/*
 * @Author: miccy 
 * @Date: 2018-03-30 16:32:16 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:10:55
 * 订单详情
 */
import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Button, Row, Col, Table } from 'antd'
import { toMoney } from '../../../Util/reactUtil'
import { fetch } from '../../../Config/request'
import './orderDetail.less'

const getOrderInfoUrl = '/system/order/getOrderInfo', //获取订单详情
    sendUrl = '/system/shop/sendGoods'; //商品发货

const sendTitle = '发货';



class OrderDetail extends Component {
    constructor(props) {
        super(props)
      
        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: () => {
            fetch(getOrderInfoUrl, { orderNo: this.locationState.orderNo, tradeCode: this.locationState.tradeCode }).then(res => {
                if (res.status == 0) {
                    this.setState({
                        orderInfo: res.model
                    })
                }
            })
        },
        // 发货
        send: (params) => {
            fetch(sendUrl, params).then(res => {
                if (res.status == 0) {
                    this.setState({
                        sendModalVis: false
                    })
                    this.Request.get();
                }
            })
        }
    }

    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        // 发货
        send: (values) => {
            this.Request.send({ ...values, orderId: this.locationState.orderId })
        },
        showSendModal: () => {
            this.setState({
                sendModalVis: true,
            })
        },
        sendCancel: () => {
            this.setState({
                sendModalVis: false
            })
        },
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        this.locationState = this.props.location.state || {}
        this.state = {
            sendModalVis: false,
            sendModal: {},
            orderInfo: {}
        }
        this.columns = [
            {
                title: '商品图片',
                dataIndex: 'image',
                key: 'image',
                render: value => <img width="80" src={value} alt="商品图片" />
            }, {
                title: '商品名称',
                dataIndex: 'productName',
                key: 'productName'
            }, {
                title: '单价',
                dataIndex: 'price',
                key: 'price',
                render: value => toMoney(value)
            }, {
                title: '数量',
                dataIndex: 'count',
                key: 'count'
            },
        ]
        this.sendFormItems = [
            {
                type: EditType.InputStr,
                label: '快递类型',
                key: 'expressType',
                config: {
                    rules: [{ required: true, message: '请输入快递类型' }]
                }
            }, {
                type: EditType.InputStr,
                label: '快递单号',
                key: 'expressNo',
                config: {
                    rules: [{ required: true, message: '请输入快递单号' }]
                }
            }, {
                type: EditType.InputStr,
                label: '快递备注',
                key: 'expressRemark'
            }
        ]

    }
    render() {
        const { orderInfo, sendModalVis } = this.state
        const { send, sendCancel, showSendModal } = this.Action
        const proList = orderInfo.proList || []
        return (
            <div className="order-info-wrapper">
                <Card title="订单基本信息">
                    <Row className="order-base-info">
                        <Col span="12">
                            <span className="order-label">订单编号：</span>
                            <span className="order-content">{orderInfo.orderno}</span>
                        </Col>
                        <Col span="12">
                            <span className="order-label">订单状态：</span>
                            <span className="order-content">{orderInfo.orderStatusName}</span>
                        </Col>
                    </Row>
                    <Row className="order-base-info">
                        <Col span="12">
                            <span className="order-label">下单人：</span>
                            <span className="order-content">{orderInfo.userMobile}</span>
                        </Col>
                        <Col span="12">
                            <span className="order-label">订单创建时间：</span>
                            <span className="order-content">{orderInfo.createtime && moment(orderInfo.createtime, 'x').format('YYYY-MM-DD HH:mm:ss')}</span>
                        </Col>
                    </Row>
                    <Row className="order-base-info">
                        <Col span="12">
                            <span className="order-label">支付时间：</span>
                            <span className="order-content">{orderInfo.payTime && moment(orderInfo.payTime, 'x').format('YYYY-MM-DD HH:mm:ss')}</span>
                        </Col>
                        <Col span="12">
                            <span className="order-label">发货时间：</span>
                            <span className="order-content">{orderInfo.sendTime && moment(orderInfo.sendTime, 'x').format('YYYY-MM-DD HH:mm:ss')}</span>
                        </Col>
                    </Row>
                    <Row className="order-base-info">
                        <Col span="12">
                            <span className="order-label">订单完成时间：</span>
                            <span className="order-content">{orderInfo.finishTime && moment(orderInfo.finishTime, 'x').format('YYYY-MM-DD HH:mm:ss')}</span>
                        </Col>
                    </Row>
                </Card>
                <Card title="订单支付信息">
                    <Row className="order-base-info">
                        <Col span="12">
                            <span className="order-label">付款方式：</span>
                            <span className="order-content">{orderInfo.channelIdName}</span>
                        </Col>
                        <Col span="12">
                            <span className="order-label">运费：</span>
                            <span className="order-content">{toMoney(orderInfo.freightCharge)}</span>
                        </Col>
                    </Row>
                    <Row className="order-base-info">
                        <Col span="12">
                            <span className="order-label">商品金额：</span>
                            <span className="order-content">{toMoney(orderInfo.productPrice)}</span>
                        </Col>
                        <Col span="12">
                            <span className="order-label">订单金额：</span>
                            <span className="order-content">{toMoney(orderInfo.totalAmount)}</span>
                        </Col>
                    </Row>
                </Card>
                <Card title="收货人信息">
                    <Row className="order-base-info">
                        <Col span="12">
                            <span className="order-label">姓名：</span>
                            <span className="order-content">{orderInfo.recipient}</span>
                        </Col>
                        <Col span="12">
                            <span className="order-label">联系电话：</span>
                            <span className="order-content">{orderInfo.telPhone}</span>
                        </Col>
                    </Row>
                    <Row className="order-base-info">
                        <Col span="24">
                            <span className="order-label">收货地址：</span>
                            <span className="order-content">{orderInfo.receiveAddress}</span>
                        </Col>
                    </Row>
                </Card>
                <Card title="物流信息" extra={orderInfo.orderStatus == 2 ? (<Button type="primary" onClick={showSendModal}>发货</Button>) : null}>
                    <Row className="order-base-info">
                        <Col span="24">
                            <span className="order-label">物流公司：</span>
                            <span className="order-content">{orderInfo.expressType}</span>
                        </Col>
                    </Row>
                    <Row className="order-base-info">
                        <Col span="24">
                            <span className="order-label">快递单号：</span>
                            <span className="order-content">{orderInfo.expressNo}</span>
                        </Col>
                    </Row>
                    <Row className="order-base-info">
                        <Col span="24">
                            <span className="order-label">发货备注：</span>
                            <span className="order-content">{orderInfo.expressRemark}</span>
                        </Col>
                    </Row>
                </Card>
                <Card title="发票信息">
                    <Row className="order-base-info">
                        <Col span="24">
                            <span className="order-label">发票抬头：</span>
                            <span className="order-content">{orderInfo.invoiceTitle}</span>
                        </Col>
                    </Row>
                </Card>
                <Card title="商品信息">
                    {/* <Row className="order-goods-info-top">
                        <Col span="4">
                            商品编号
                        </Col>
                        <Col span="8">
                            商品名称
                        </Col>
                        <Col span="4">
                            运费（元）
                        </Col>
                        <Col span="4">
                            单价（元）
                        </Col>
                        <Col span="4">
                            数量
                        </Col>
                    </Row>
                    <Row className="order-goods-info">
                        <Col span="4">
                            <span>{proList[0] && proList[0].orderNo}</span>
                        </Col>
                        <Col span="8" className="text-left">
                            <span>{proList[0] && proList[0].productName}</span>
                        </Col>
                        <Col span="4">
                            <span>{toMoney(orderInfo.freightCharge)}</span>
                        </Col>
                        <Col span="4">
                            <span>{toMoney(proList[0] && proList[0].price)}</span>
                        </Col>
                        <Col span="4">
                            <span>{proList[0] && proList[0].count}</span>
                        </Col>
                    </Row> */}
                    <Table
                        columns={this.columns}
                        dataSource={proList}
                    />
                </Card>

                <EditPanel
                    title={sendTitle}
                    modalVis={sendModalVis}
                    formItems={this.sendFormItems}
                    onSave={send}
                    onCancel={sendCancel}
                />
            </div>
        )
    }
    componentDidMount() {
        if (is.undefined(this.locationState.orderId)) {
            this.props.history.replace('/mall/order')
            return;
        }
        // 获取当前订单的详情
        this.Request.get();
    }

}
export default OrderDetail