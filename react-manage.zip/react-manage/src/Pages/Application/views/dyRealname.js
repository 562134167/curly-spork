/*
 * @Author: miccy 
 * @Date: 2018-04-19 15:25:54 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-20 17:15:20
 * 达雍实名审核专用
 */
import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, Button, message } from 'antd'
import { formatData, formateEditData, flattenObj ,delArrMark } from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
const title = '查看审核信息',
    initGetParams = {
        pageIndex: 1,
        pageSize: 1
    };
const pagingUrl = '/system/userauditor/paging',
    updateUrl = '/system/userauditor/auditing',
    uploadFileUrl = '/system/file/upload';

class DyRealname extends Component {
    constructor(props) {
       	super(props)
        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {

            return getFetch(pagingUrl, params).then(res => {
                if (res && is.array(res.models)) {
                    const { models, totalModels, totalPages } = res
                    const dataSource = formatData(flattenObj(models, ['userSafeInfo', 'userAuditor']))
                    this.setState({
                        dataSource,
                        totalModels,
                        totalPages,
                        current: params.pageIndex
                    })
                }
                return res
            })
        },
        // 修改数据
        update: (params) => {

            return fetch(updateUrl, params).then(res => {
                this.setState({
                    modalVis: false
                })
                this.Request.get(this.state.getDataParams)
                return res
            })
        },
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        // 查
        search: (value) => {
            const mobileRegx = /^1\d{10}$/gi
            if (value.mobilePhone && (!mobileRegx.test(value.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }
            if((!value.mobilePhone)||(!value)){
            	message.error('请输入正确的手机号码')
                return;
            }

            this.setState({
                getDataParams: { ...initGetParams, ...value }
            })
        },
        // 清空查找条件
        clearSearch: () => {
            this.setState({
                dataSource: []
            })
        },
        // 点击修改按钮
        edit: (record, index) => {
            let modal = {}
            if(record.examineType == 1){
            	this.formItems[5].label = '人脸识别图片';
            }
            else{
            	this.formItems[5].label = '';
            }
            if(record.isAuditor==3){
            	var len = this.formItems.length;
            	if(len == 8){
            		this.formItems[7].itemConfig.disabled = false;
            	}
            	if(len == 9){
            		this.formItems[8].itemConfig.disabled = false;
            	}
            	
            }
            else{
            	var len = this.formItems.length;
            	if(len == 7){
            		this.formItems[7].itemConfig.disabled = true;
            	}
            	if(len == 8){
            		this.formItems[8].itemConfig.disabled = true;
            	}
            }
            record.userIdCardUrl = delArrMark(record.userIdCardUrl);
            const obj = formateEditData(record, this.formItems)
            for (let i in obj) {
                modal[i] = {
                    value: obj[i]
                }
            }
            this.setState({
                modalVis: true,
                modal: modal,
                title: title,
                editId: obj.userId,
            })
        },
        // 保存模态框表单数据（新建/编辑）
        editStatus: (type, context) => {
            const reason = context.editForm.props.form.getFieldValue('reason');
            const { editId } = this.state
            if (type === 'cancel') {
                if (!reason) {
                    message.error('请填写审核失败的理由！')
                    return;
                }
                this.Request.update({
                    userId: editId,
                    isSuccess: false,
                    reason: reason
                })
            } else {
                this.Request.update({
                    userId: editId,
                    isSuccess: true,
                    reason: ''
                })
            }

        },
        cancel: () => {
            this.setState({
                modalVis: false
            })
        },
        changePage: (page, pageSize) => {
            const { getDataParams } = this.state
            const params = { ...getDataParams, pageIndex: page }
            this.setState({
                selectedRowKeys: [],
                getDataParams: params
            })
        },
    }
    RenderFunc = {
        // 模态框底部的渲染函数
        renderFooter: (context) => {
            const { editStatus, cancel } = this.Action
            const isAuditor = context.props.modal.isAuditor;
            if (isAuditor.value == 3) {
                return (
                    <div>
                        <Button onClick={() => { editStatus('ok', context) }} type="primary">审核通过</Button>
                        <Button onClick={() => { editStatus('cancel', context) }}>审核不通过</Button>
                    </div>
                )
            } else {
                return (
                    <div>
                        <Button onClick={cancel} type="primary">确定</Button>
                    </div>
                )
            }
        }
    }
    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        // const { selectedRowKeys } = this.state;
        const { edit } = this.Action
        this.state = {
            title: title,
            dataSource: [],
            modalVis: false,
            modal: {},
            selectedRowKeys: [],
            current: 1,
            editId: null,
            totalModels: null,
            totalPages: null,
            getDataParams: {},
        }
        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone',
                }
            ]
        }
        // 表头设置
        this.columns = [
            {
                title: '用户名',
                dataIndex: 'userName',
                key: 'userName',
            }, {
                title: '手机号码',
                dataIndex: 'userMobile',
                key: 'userMobile',
            }, {
                title: '真实姓名',
                dataIndex: 'userRealName',
                key: 'userRealName',
            }, {
                title: '身份证',
                dataIndex: 'userIdCard',
                key: 'userIdCard',
            }, {
                title: '提交时间',
                dataIndex: 'createTime',
                key: 'createTime',
                render: value => (value && moment(value, 'x').format('YYYY/MM/DD HH:mm:ss')) || moment().format('YYYY/MM/DD HH:mm:ss')
            }, {
                title: '审核状态',
                dataIndex: 'isAuditor',
                key: 'isAuditor',
                render: value => {
                    if (value == 1) {
                        return '审核通过'
                    } else if (value == 2) {
                        return '未通过审核'
                    } else if (value == 3) {
                        return '待审核'
                    } else if (value == 4) {
                        return '黑名单'
                    }
                }
            }, {
                title: '操作',
                dataIndex: 'actions',
                key: 'actions',
                render: (text, record, index) => (
                    <span>
                        <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>查看</Button>
                    </span>
                )
            }
        ];
        this.formItems = [
            {
                type: EditType.InputStr,
                label: '用户名',
                key: 'userName',
                itemConfig: {
                    disabled: true
                }
            }, {
                type: EditType.InputStr,
                label: '手机号码',
                key: 'userMobile',
                itemConfig: {
                    disabled: true
                }
            }, {
                type: EditType.InputStr,
                label: '真实姓名',
                key: 'userRealName',
                itemConfig: {
                    disabled: true
                }
            }, {
                type: EditType.InputStr,
                label: '身份证',
                key: 'userIdCard',
                itemConfig: {
                    disabled: true
                }
            }, {
                type: EditType.Image,
                label: '身份证照片',
                key: 'userIdCardUrl',
                config: {
                    valuePropName: 'fileList',
                    getValueFromEvent: (e) => {
                        if (Array.isArray(e)) {
                            return e;
                        }
                        return e && e.fileList;
                    },
                },
                itemConfig: {
                    action: window.baseUrl + uploadFileUrl,
                    name: 'files'
                },
                isShowbtn: (props) => {
                    return false
                }
            }, {
                type: EditType.DatePicker,
                label: '提交时间',
                key: 'createTime',
                itemConfig: {
                    disabled: true,
                }
            }, {
                type: EditType.Select,
                label: '审核状态',
                key: 'isAuditor',
                itemConfig: {
                    options: [
                        { value: 1, label: '审核通过' },
                        { value: 2, label: '未通过审核' },
                        { value: 3, label: '待审核' },
                        { value: 4, label: '黑名单' },
                    ],
                    disabled: true
                }

            }, {
                type: EditType.InputStr,
                label: '审核不通过理由',
                key: 'reason'
            }
        ]
    }
    render() {
        const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
        const { search, clearSearch, cancel, changePage } = this.Action
        return (
            <div className="file-manage">
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Table
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        current,
                        total: totalModels,
                        onChange: changePage,
                        pageSize: 20,
                        showTotal: (total, range) => `共 ${total} 条记录`
                    }}
                />
                <EditPanel
                    title={title}
                    modalVis={modalVis}
                    formItems={this.formItems}
                    modal={modal}
                    footer={(context) => this.RenderFunc.renderFooter(context)}
                    onCancel={cancel}
                    className="file-manage-modal"
                />
            </div>
        )
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
    }
}

export default DyRealname
