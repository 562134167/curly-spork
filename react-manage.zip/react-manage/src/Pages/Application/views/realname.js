/*
 * @Author: miccy 
 * @Date: 2018-04-09 16:58:18 
<<<<<<< .mine
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2018-04-27 10:10:35
||||||| .r2248
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-20 14:23:58
=======
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2018-04-27 17:24:23
>>>>>>> .r2269
 * 用户实名审核
 */


import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel, { EditFormWrapper } from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, Button, message, Modal } from 'antd'
import { formatData, formateEditData, flattenObj, handleEndTime, handleStartTime ,delArrMark } from '../../../Util/reactUtil'
import { getQueryObj } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
const title = '查看审核信息',
    rejectTitle = '驳回信息'
const initGetParams = {
    pageIndex: 1,
    pageSize: 20
}
const pagingUrl = '/system/userauditor/paging',
    updateUrl = '/system/userauditor/auditing',
    uploadFileUrl = '/system/file/upload',
    rejectUrl = '/system/userauditor/rejectAuditing'

class Realname extends Component {
    constructor(props) {
        super(props)
        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            const queryObj = getQueryObj(this.props.location.search) || {}
            return getFetch(pagingUrl, { ...params, ...queryObj }).then(res => {
                if (res && is.array(res.models)) {
                    const { models, totalModels, totalPages } = res
                    const dataSource = formatData(flattenObj(models, ['userSafeInfo', 'userAuditor']))
                    this.setState({
                        dataSource,
                        totalModels,
                        totalPages,
                        current: params.pageIndex
                    })
                }
                return res
            })
        },
        // 修改数据
        update: (params) => {

            return fetch(updateUrl, params).then(res => {
                this.setState({
                    modalVis: false
                })
                this.Request.get(this.state.getDataParams)
                return res
            })
        },
        //驳回
        reject: (params) => {
            return fetch(rejectUrl, params).then(res => {
                this.setState({
                    modalVis: false
                })
                this.Request.get(this.state.getDataParams)
                return res
            })
        }
        
    }     
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        // 查
        search: (value) => {
            const queryParams = Object.assign({}, value)
            const { getDataParams } = this.state
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }

            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }
            delete queryParams.createtime

            const params = { ...getDataParams, ...queryParams }

            this.setState({
                getDataParams: params
            })
        },
        // 清空查找条件
        clearSearch: () => {
            this.setState({
                getDataParams: initGetParams
            })
        },
        // 点击修改按钮
        edit: (record, index) => {
            let modal = {}
            if(record.examineType == 1){
            	this.formItems[5].label = '人脸识别图片';
            }
            else{
            	this.formItems[5].label = '';
            }
            if(record.isAuditor==3){
            	var len = this.formItems.length;
            	if(len == 8){
            		this.formItems[7].itemConfig.disabled = false;
            	}
            	if(len == 9){
            		this.formItems[8].itemConfig.disabled = false;
            	}
            	
            }
            else{
            	var len = this.formItems.length;
            	if(len == 8){
            		this.formItems[7].itemConfig.disabled = true;
            	}
            	if(len == 9){
            		this.formItems[8].itemConfig.disabled = true;
            	}
            }
            record.userIdCardUrl = delArrMark(record.userIdCardUrl);
            
            
            const obj = formateEditData(record, this.formItems)
            
            for (let i in obj) {
                modal[i] = {
                    value: obj[i]
                }
            }
            this.setState({
                modalVis: true,
                modal: modal,
                title: title,
                editId: obj.userId,
            })
        },
        reject: (record, index) => {
            this.setState({
                rejectModalVis: true,
                // modal: this.newItem,
                editId: record.userId,
                title: rejectTitle,
            })
        },
        onCancelRejectModal: () => {
            this.setState({
                rejectModalVis: false,
                editId: null
            })
        },
        //驳回理由确认
        confirmReject: (value) => {
            this.editRejectForm.props.form.validateFieldsAndScroll(
              (err, values) => {
                if (!err) {
                  this.Request.reject({ userId: this.state.editId, reason: values.reason }).then(res => {
                    if (res.status == 0) {
                      this.setState({
                        rejectModalVis: false,
                        editId: null,
                        reason: null
                      })
                    }
                  })
                }
              })
          },
          
        // 保存模态框表单数据（新建/编辑）
        editStatus: (type, context) => {
            const reason = context.editForm.props.form.getFieldValue('isAuditorDesc');
            const { editId } = this.state
            if (type === 'cancel') {
                if (!reason) {
                    message.error('请填写审核失败的理由！')
                    return;
                }
                this.Request.update({
                    userId: editId,
                    isSuccess: false,
                    reason: reason
                })
            } else {
                this.Request.update({
                    userId: editId,
                    isSuccess: true,
                    reason: ''
                })
            }

        },
        cancel: () => {
            this.setState({
                modalVis: false
            })
        },
        changePage: (page, pageSize) => {
            const { getDataParams } = this.state
            const params = { ...getDataParams, pageIndex: page }
            this.setState({
                selectedRowKeys: [],
                getDataParams: params
            })
        },
    }
    RenderFunc = {
        // 模态框底部的渲染函数
        renderFooter: (context) => {
            const { editStatus, cancel } = this.Action
            const isAuditor = context.props.modal.isAuditor;
            if (isAuditor.value == 3) {
                return (
                    <div>
                        <Button onClick={() => { editStatus('ok', context) }} type="primary">审核通过</Button>
                        <Button onClick={() => { editStatus('cancel', context) }}>审核不通过</Button>
                    </div>
                )
            } else {
                return (
                    <div>
                        <Button onClick={cancel} type="primary">确定</Button>
                    </div>
                )
            }
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        // const { selectedRowKeys } = this.state;
        const { edit } = this.Action;
        const { reject } = this.Action;
        this.state = {
            title: title,
            dataSource: [],
            modalVis: false,
            modal: {},
            selectedRowKeys: [],
            current: 1,
            editId: null,
            totalModels: null,
            totalPages: null,
            getDataParams: {},
            rejectModalVis: false,
            reason: ''
        }
        // 搜索面板元数据
        this.metadata = {   
            conditions: [
                {
                    type: SearchType.Select,
                    label: '审核状态',
                    id: 'isAuditor',
                    dataSource: [
                        { value: 1, label: '审核通过' },
                        { value: 2, label: '未通过审核' },
                        { value: 4, label: '黑名单' },
                        { value: 3, label: '待审核' },
                    ]
                }, {
                    type: SearchType.DateRange,
                    label: '时间段',
                    id: 'createtime',
                }, {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone',
                },{
                	type: SearchType.Select,
                    label: '审核类型',
                    id: 'examineType',
                    dataSource: [
                        { value: 1, label: '人脸审核' },
                        { value: 2, label: '人工审核' }
                    ]
                }
            ]
        }
        // 表头设置
        this.columns = [
            {
                title: '用户名',
                dataIndex: 'userName',
                key: 'userName',
            }, {
                title: '手机号码',
                dataIndex: 'userMobile',
                key: 'userMobile',
            }, {
                title: '真实姓名',
                dataIndex: 'userRealName',
                key: 'userRealName',
            }, {
                title: '身份证',
                dataIndex: 'userIdCard',
                key: 'userIdCard',
            }, {
                title: '提交时间',
                dataIndex: 'createTime',
                key: 'createTime',
                render: value => (value && moment(value, 'x').format('YYYY/MM/DD HH:mm:ss')) || moment().format('YYYY/MM/DD HH:mm:ss')
            },{
                title: '审核类型',
                dataIndex: 'examineType',
                key: 'examineType',
                render: value => {
                    if (value == 1) {
                        return '人脸审核'
                    } else if (value == 2) {
                        return '人工审核'
                    } 
                }
                
            },{
                title: '审核状态',
                dataIndex: 'isAuditor',
                key: 'isAuditor',
                render: value => {
                    if (value == 1) {
                        return '审核通过'
                    } else if (value == 2) {
                        return '未通过审核'
                    } else if (value == 3) {
                        return '待审核'
                    } else if (value == 4) {     
                        return '黑名单'
                    }   
                }
            }, {
                title: '操作',
                dataIndex: 'actions',  
                key: 'actions',   
                render: (text, record, index) => (
                    <span>
                        <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>查看</Button>
                        <span>
                            {(record.isAuditor == 1 ) ? (
                            <Button type="primary" className="action-item" onClick={() => { reject(record, index) }}>驳回</Button>
                            ) : null}
                        </span>
                        

                    </span>
                )
            }
        ];

        this.rejectFormItems = [
            {
                type: EditType.Textarea,
                label: '驳回理由',
                key: 'reason',
                itemConfig: {
                    disabled: false
                }
            }
        ],

        this.formItems = [
            {
                type: EditType.InputStr,
                label: '用户名',
                key: 'userName',
                itemConfig: {
                    disabled: true
                }
            }, {
                type: EditType.InputStr,
                label: '手机号码',
                key: 'userMobile',
                itemConfig: {
                    disabled: true
                }
            }, {
                type: EditType.InputStr,
                label: '真实姓名',
                key: 'userRealName',
                itemConfig: {
                    disabled: true
                }
            }, {
                type: EditType.InputStr,
                label: '身份证',
                key: 'userIdCard',
                itemConfig: {
                    disabled: true
                }
            }, {
                type: EditType.Image,
                label: '身份证照片',
                key: 'userIdCardUrl',
                config: {
                    valuePropName: 'fileList',
                    getValueFromEvent: (e) => {
                        if (Array.isArray(e)) {
                            return e;
                        }
                        return e && e.fileList;
                    },
                },
                itemConfig: {
                    action: window.baseUrl + uploadFileUrl,
                    name: 'files'
                },
                isShowbtn: (props) => {
                    return false
                }
            },{
                type: EditType.Image,
                label: '本人图片',
                key: 'userFaceurl',
                config: {
                    valuePropName: 'fileList',
                    getValueFromEvent: (e) => {
                        if (Array.isArray(e)) {
                            return e;
                        }
                        return e && e.fileList;
                    },
                },
                itemConfig: {
                    action: window.baseUrl + uploadFileUrl,
                    name: 'files'
                },
                isShowbtn: (props) => {
                    return false
                }
            },{
                type: EditType.DatePicker,
                label: '提交时间',
                key: 'createTime',
                itemConfig: {
                    disabled: true,
                }
            }, {
                type: EditType.Select,
                label: '审核状态',
                key: 'isAuditor',
                itemConfig: {
                    options: [
                        { value: 1, label: '审核通过' },
                        { value: 2, label: '未通过审核' },
                        { value: 3, label: '待审核' },
                        { value: 4, label: '黑名单' },
                    ],
                    disabled: true
                }

            }, {
                type: EditType.Textarea,
                label: '审核不通过理由',
                dataIndex: 'isAuditor',
                key: 'isAuditorDesc',
                itemConfig: {
                    disabled: true
                }
            }
        ]
    }
    render() {
        const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, rejectModalVis, reason } = this.state
        const { search, clearSearch, cancel, changePage, reject, confirmReject, onCancelRejectModal } = this.Action
        return (
            <div className="file-manage">
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Table
                    scroll={{ x: 1000 }}
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        current,
                        total: totalModels,
                        onChange: changePage,
                        pageSize: 20,
                        showTotal: (total, range) => `共 ${total} 条记录`
                    }}
                />
                <EditPanel
                    title={title}
                    modalVis={modalVis}
                    formItems={this.formItems}
                    modal={modal}
                    footer={(context) => this.RenderFunc.renderFooter(context)}
                    onCancel={cancel}
                    className="file-manage-modal"
                />
                {
                rejectModalVis ? (
                    <Modal
                    // className={className}
                    title="驳回理由："
                    visible={rejectModalVis}
                    maskClosable={false}
                    onOk={confirmReject}
                    onCancel={onCancelRejectModal}>
                    <EditFormWrapper wrappedComponentRef={(inst) => this.editRejectForm = inst} formItems={this.rejectFormItems} />
                    </Modal>
                ) : null
                }



            </div>
        )
    }   
    componentDidMount() {
        this.setState({
            getDataParams: initGetParams
        })
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
    }
}

export default Realname