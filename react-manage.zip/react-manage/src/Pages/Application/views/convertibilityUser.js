import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import * as EditType from '../../../Common/editType'
import EditPanel, { EditFormWrapper } from '../../../Common/editPanel'
import { Table, message, Card , notification, Button, Modal} from 'antd'
import { formatData, flattenObj, handleEndTime, handleStartTime, toMoney , formatFormData } from '../../../Util/reactUtil'
import { hasAttr, arrayToObject } from '../../../Util'
import { actionChangePage, actionClearSearch, actionSearch, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'
import { getFetch,fetch } from '../../../Config/request'

const initGetParams = {
  pageIndex: 1
}
const title = '批量拒绝'

const pagingIntegralExchange = '/system/integral/pagingIntegralExchange',
			payUrl = '/system/integralExchange/approved',//批量提交渠道
    	refuseUrl = '/system/integral/integralExchangeRefuse' //批量拒绝

export default class convertibilityUser extends Component {
  constructor(props) {
    super(props)
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      /**@param {Object} params 
       * 数据格式
       * {
        @param {String} keyword,
        @param {Number} pageIndex,
        @param {Number} pageSize'
      }
       */
      
      return getFetch(pagingIntegralExchange, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['withdraw']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex,
            pageSize: params.pageSize,
            selectedRowKeys: []
          })
          !this.state.exchangeStatusOptions.length && this.Request.getTransferStatusList();
        }
        return res
      })
    },
    getTransferStatusList: () => {
        	const statusOptions = [
					  { label: '兑换中', value: 1 },
					  { label: '交易成功', value: 2 },
					  { label: '交易失败', value: 3 }
					]
          const { exchangeStatusOptions } = this.state
          statusOptions.forEach(item => {
            exchangeStatusOptions.push({
              label: item.label,
              value: item.value
            })
          })
          this.setState({
            exchangeStatusEnum: arrayToObject({ array: statusOptions, keyName: 'value', valueName: 'label' }),
            exchangeStatusOptions
            
          })
    },
    
   	pay: (params) => {
            return fetch(payUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams)
                }
                return res
            })
    },
    refuse: (params) => {
            return fetch(refuseUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams)
                }
                return res
            })
    }
    
    
    
  }

  Util = {
    getTotalAmount: (dataSource) => {
      let totalAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (item.integralNum) {
          totalAmount += item.integralNum
        }
      })
      return totalAmount
    },
    getSelectedAmount: (dataSource, selectedRowKeys) => {
      const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
      if (!tempSelectedRowKeys.length) {
        return 0
      }
      const selectedString = tempSelectedRowKeys.join(',')
      let selectedAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (selectedString.indexOf(item.key) > -1 && item.integralNum) {
          selectedAmount += item.integralNum
        }
      })
      return selectedAmount
    }
  }

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
        message.error('请输入正确的转出手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
      })
    },
    onShowSizeChange: (current, pageSize) => {
      const { getDataParams } = this.state
      this.setState({
        getDataParams: { ...getDataParams, pageSize, pageIndex: 1 },
        pageSize
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },
    save: (values) => {
      const { selectedRowKeys, type } = this.state
      this.Request[type]({
          ...values,
          ids: selectedRowKeys
      }).then(res => {
          if (res.status == 0) {
              this.setState({
              modalVis: false,
              selectedRowKeys: []
            	})
          }
      })
    },
		onCancelPayModal: () => {
            this.setState({
                payModalVis: false,
                editId: null
            })
    },
    confirmPwd: (value) => {
            this.editPayForm.props.form.validateFieldsAndScroll(
                (err, values) => {
                    if (!err) {
                        this.Request.pay({
                            ids: this.state.selectedRowKeys,
                            ...formatFormData(values, this.payFormItems)
                        }).then(res => {
                            if (res.status == 0) {
                                this.setState({
                                    payModalVis: false,
                                })
                            }
                        })
                    }
                })
    },
    // 点击批量操作按钮
        editItems: (name) => {
            const { selectedRowKeys } = this.state
            if (!selectedRowKeys.length) {
                message.error('请至少选中一行要操作的数据')
                return;
            }
            if (name == 'pay') {
                this.setState({
                    payModalVis: true,
                })
            } else {
                this.setState({
                    modalVis: true,
                    type: name
                })
            }

        },
        cancel: () => {
            this.setState({
                modalVis: false
            })
        },
       	rowSelectionChange: (selectedRowKeys, selectedRows) => {
            const newSelectedRowKeys = [];
            const disabledSerialNumbers = [];
            selectedRows.forEach(item => {
                if (item.exchangeStatus == 1) {
                    newSelectedRowKeys.push(item.id);
                    
                } else {
                    disabledSerialNumbers.push(item.orderNo);
                }
            })
            if (disabledSerialNumbers.length) {
			        notification.warn({
			          message: '操作警告',
			          description: `以下订单：
			              ${disabledSerialNumbers.join(' , ')}
			              不可进行操作！
			              `,
			          duration: null
			        });
			      }
            this.setState({
                selectedRowKeys: newSelectedRowKeys
            })
        }

  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    // const { view, unfreeze } = this.Action
    this.state = {
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
      totalAmount: 0,
      selectedAmount: 0,
      transferStatusOptions: [],
      exchangeStatusOptions:[],
      transferStatusEnum: {},
      exchangeStatusEnum: {},
      channelOptions: [],
      channelEnum: {},
      refundShowStatusEnum: {},
      refundShowStatusOptions: [],
      refundStatusOptions: [],
      refundStatusEnum: {},
      editId: null,
      payModalVis: false,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号',
          id: 'userMobile'
        },  {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime'
        }, {
          type: SearchType.Select,
          label: '转账状态',
          id: 'exchangeStatus',
          dataSource: this.state.exchangeStatusOptions
        },{
          type: SearchType.String,
          label: '订单号',
          id: 'orderNo'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        fixed: 'left',
        width: 50,
        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index - 0 + 1)
      },{
        title: '姓名',
        dataIndex: 'userRealName',
        key: 'userRealName',
        fixed: 'left',
        width: 100,
      }, {
        title: '手机号',
        dataIndex: 'userMobile',
        key: 'userMobile'
      }, {
        title: '转入类型',
        dataIndex: 'fromChannelIdDesc',
        key: 'fromChannelIdDesc',
      }, {
        title: '转出类型',
        dataIndex: 'toChannelIdDesc',
        key: 'toChannelIdDesc'
      }, {
        title: '金额',
        dataIndex: 'integralNum',
        key: 'integralNum',
        render: value => toMoney(value)
      }, {
        title: '兑换状态',
        dataIndex: 'exchangeStatus',
        key: 'exchangeStatus',
        render: value => this.state.exchangeStatusEnum[value] || value
      }, {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }
      , {
        title: '审核通过/拒绝时间',
        dataIndex: 'updateTime',
        key: 'updateTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '订单号',
        dataIndex: 'orderNo',
        key: 'orderNo',
      }, {
        title: '拒绝原因',
        dataIndex: 'refuseReson',
        key: 'refuseReson',
      }
    ];
    this.formItems = [
            {
                type: EditType.InputStr,
                key: 'reason',
                label: '拒绝理由',
                config: {
                    rules: [
                        { required: true, message: '请填写拒绝理由' }
                    ],
                },
            }, {
                type: EditType.InputStr,
                key: 'password',
                label: '支付操作密码',
                itemConfig: {
                    type: 'password'
                },
                config: {
                    rules: [
                        { required: true, message: '请填写支付操作密码' }
                    ],
                },
            }
    ]
    this.payFormItems = [
            {
                type: EditType.InputStr,
                key: 'payPassword',
                label: '支付操作密码',
                itemConfig: {
                    type: 'password'
                },
                config: {
                    rules: [
                        { required: true, message: '请填写支付操作密码' }
                    ],
                },
            }
    ]
  }
  render() {
    const { payModalVis,dataSource, current, totalModels, pageSize, totalAmount, modal, selectedAmount ,selectedRowKeys , title, modalVis,} = this.state
    const { changePage, search, clearSearch, onShowSizeChange ,cancel, save, editItems, onCancelPayModal, confirmPwd, rowSelectionChange  } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button className="action-item" type="primary" ghost onClick={() => editItems('pay')}>批量通过</Button>
          <Button className="action-item" type="primary" ghost onClick={() => editItems('refuse')}>批量拒绝</Button>
        </Card>
        <Card>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: rowSelectionChange,
          }}
          scroll={{ x: 900 }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            showSizeChanger: true,
            showTotal: (total, range) => `共 ${total} 条记录`,
            onShowSizeChange: onShowSizeChange,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
        <EditPanel
                    title={title}
                    modalVis={modalVis}
                    formItems={this.formItems}
                    modal={modal}
                    onSave={save}
                    onCancel={cancel}
                />
                {
                    payModalVis ? (
                        <Modal
                            // className={className}
                            title="批量提交渠道"
                            visible={payModalVis}
                            maskClosable={false}
                            onOk={confirmPwd}
                            onCancel={onCancelPayModal}>
                            <EditFormWrapper
                                modal={{ channelId: { value: '0' } }}
                                wrappedComponentRef={(inst) => this.editPayForm = inst}
                                formItems={this.payFormItems} />
                        </Modal>
                    ) : null
                }
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, selectedRowKeys, dataSource } = this.state
    const { get } = this.Request
    const { getSelectedAmount, getTotalAmount } = this.Util
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }

    // 选中的项发生变化时，计算已选中的项的总金额
    if (nextState.selectedRowKeys !== selectedRowKeys) {
      this.setState({
        selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
      })
    }
    // 当前页的数据发生变化时，计算当前页的总金额
    if (nextState.dataSource !== dataSource) {
      this.setState({
        totalAmount: getTotalAmount(nextState.dataSource)
      })
    }
  }
}
