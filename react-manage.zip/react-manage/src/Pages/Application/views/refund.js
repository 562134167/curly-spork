/*
 * @Author: miccy 
 * @Date: 2018-04-09 17:16:07 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-20 14:24:20
 * 积分退款管理（运营）
 */
import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, Button, message, Card, notification } from 'antd'
import { formatData, toMoney } from '../../../Util/reactUtil'
import { actionChangePage, actionClearSearch, actionSearch, actionOnShowSizeChange, initGetParams, actionShowTotal } from '../../../Util/Action'
import { arrayToObject } from '../../../Util'
import { getFetch, fetch } from '../../../Config/request'

const title = '拒绝退款'

const pagingUrl = '/system/refund/pagingrefund',
    passUrl = '/system/refund/examinerefund',
    refuseUrl = '/system/refund/rejectexaminerefund',
    getChannelListUrl = '/common/getchannellist',
    getEnumUrl = '/common/getEnumeByClassName';
class Refund extends Component {
    constructor(props) {
        super(props)

        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            return fetch(pagingUrl, params).then(res => {
                if (res && is.array(res.models)) {
                    // 更新table列表数据
                    const { models, totalModels } = res
                    const dataSource = formatData(models)
                    this.setState({
                        dataSource,
                        totalModels,
                        current: params.pageIndex,
                        pageSize: params.pageSize,
                        selectedRowKeys: []
                    })

                    // 判断下拉列表的数据源是否有数据，无则请求获取数据源
                    const { channelOptions, refundShowStatusOptions, refundStatusOptions } = this.state
                    !channelOptions.length && this.Request.getChannelList();
                    !refundShowStatusOptions.length && this.Request.getEnum({ className: 'OrderRefundShowStatusEnums' }, { optionsKey: 'refundShowStatusOptions', enumsKey: 'refundShowStatusEnum' });
                    !refundStatusOptions.length && this.Request.getEnum({ className: 'OrderRefundStatusEnums' }, { optionsKey: 'refundStatusOptions', enumsKey: 'refundStatusEnum' });
                }
                return res
            })
        },
        getChannelList: () => {
            getFetch(getChannelListUrl).then(res => {
                if (res.status == 0) {
                    const { channelOptions } = this.state
                    res.models.forEach(item => {
                        channelOptions.push({
                            label: item.remarks,
                            value: item.channelId
                        })
                    })
                    this.setState({
                        channelEnum: arrayToObject({ array: res.models, keyName: 'channelId', valueName: 'remarks' }),
                        channelOptions
                    })
                }
            })
        },
        getEnum: (params, { optionsKey, enumsKey }) => {
            if (!optionsKey || !enumsKey) {
                return;
            }
            getFetch(getEnumUrl, params).then(res => {
                if (res.status == 0) {
                    const options = this.state[optionsKey];
                    res.models.forEach(item => {
                        options.push({
                            label: item.value,
                            value: item.key
                        })
                    })
                    this.setState({
                        [enumsKey]: arrayToObject({ array: res.models, keyName: 'key', valueName: 'value' }),
                        [optionsKey]: options
                    })
                }
            })
        },
        pass: (params) => {
            return fetch(passUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams)
                }
                return res
            })
        },
        refuse: (params) => {
            return fetch(refuseUrl, params).then(res => {
                if (res.status == 0) {
                    this.Request.get(this.state.getDataParams)
                }
                return res
            })
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        search: (value) => {
            const queryParams = Object.assign({}, value)
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
                message.error('请输入正确的手机号码')
                return;
            }
            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = queryParams.createtime[0].format('x')
                queryParams.endTime = queryParams.createtime[1].format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }

            delete queryParams.createtime

            actionSearch({ value: queryParams, context: this });
        },
        // 清空查找条件
        clearSearch: () => {
            actionClearSearch({ context: this })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this })
        },
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this })
        },
        save: (values) => {
        	
            const { selectedRowKeys } = this.state
            this.Request.refuse({
                handleRemark: values.handleRemark,
                payPassword: values.payPassword,
                ids: selectedRowKeys
            }).then(res => {
                if (res.status == 0) {
                    this.setState({
                        modalVis: false,
                        selectedRowKeys: []
                    })
                }
            })
        },
        // 点击批量操作按钮
        editItems: (name) => {
            const { selectedRowKeys } = this.state
            if (!selectedRowKeys.length) {
                message.error('请至少选中一行要操作的数据')
                return;
            }

            if (name == 'pass') {
                this.Request.pass({ ids: selectedRowKeys, orderNos: this.Util.getOrderNos() })
            } else {
                this.setState({
                    modalVis: true,
                })
            }

        },
        cancel: () => {
            this.setState({
                modalVis: false
            })
        },
        rowSelectionChange: (selectedRowKeys, selectedRows) => {
            const newSelectedRowKeys = [];
            const disabledSerialNumbers = [];
            selectedRows.forEach(item => {
                // 管理台退款状态：（申请退款）&& 用户退款状态：退款处理中
                if (item.refundShowStatus === 1 && item.refundStatus === 1) {
                    newSelectedRowKeys.push(item.id);
                } else {
                    disabledSerialNumbers.push(item.orderNo);
                }
            })
            if (disabledSerialNumbers.length) {
                notification.warn({
                    message: '操作警告',
                    description: `以下订单：
                    ${disabledSerialNumbers.join(' , ')}
                    不可进行操作！
                    `,
                    duration: null
                });
            }
            this.setState({
                selectedRowKeys: newSelectedRowKeys
            })
        }
    }

    Util = {
        getTotalAmount: (dataSource) => {
            let totalAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (item.refundAmount) {
                    totalAmount += item.refundAmount
                }
            })
            return totalAmount
        },
        getSelectedAmount: (dataSource, selectedRowKeys) => {
            const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
            if (!tempSelectedRowKeys.length) {
                return 0
            }
            const selectedString = tempSelectedRowKeys.join(',')
            let selectedAmount = 0;
            (dataSource || this.state.dataSource).forEach((item, index) => {
                if (selectedString.indexOf(item.id) > -1 && item.refundAmount) {
                    selectedAmount += item.refundAmount
                }
            })
            return selectedAmount
        },
        // 根据ids获取orders数组
        getOrderNos: () => {
            const orderNos = [],
                { selectedRowKeys, dataSource } = this.state;
            dataSource.forEach((item, index) => {
                if (selectedRowKeys.indexOf(item.id) > -1) {
                    orderNos.push(item.orderNo);
                }
            })
            return orderNos;
        }
    }
    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        // const startTime = moment({ hour: 0, minute: 0, seconds: 0 }).subtract(1, 'days'),
        //     endTime = moment({ hour: 23, minute: 59, seconds: 0 }).subtract(1, 'days');
        this.state = {
            title: title,
            dataSource: [],
            modalVis: false,
            modal: {},
            selectedRowKeys: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 50,
            editId: null,
            totalAmount: 0,//当前页总金额
            selectedAmount: 0,//已选择的项的总金额
            channelOptions: [],
            channelEnum: {},
            refundShowStatusEnum: {},
            refundShowStatusOptions: [],
            refundStatusOptions: [],
            refundStatusEnum: {}
        }
        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'userMobile',
                }, {
                    type: SearchType.Select,
                    label: '用户退款状态',
                    id: 'refundShowStatus',
                    dataSource: this.state.refundShowStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '管理退款状态',
                    id: 'refundStatus',
                    dataSource: this.state.refundStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '退款渠道',
                    id: 'channelId',
                    dataSource: this.state.channelOptions
                }, {
                    type: SearchType.DateRange,
                    label: '退款申请时间',
                    id: 'createtime',
                    config: {
                        showTime: true,
                        format: "YYYY-MM-DD HH:mm:ss",
                    },
                }, {
                    type: SearchType.String,
                    label: '退款订单号',
                    id: 'refundNo'
                }, {
                    type: SearchType.String,
                    label: '原订单号',
                    id: 'orderNo'
                }
            ]
        }
        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            },
            {
                title: '真实姓名',
                dataIndex: 'realName',
                key: 'realName',
                fixed: 'left',
                width: 100,
            }, {
                title: '手机号',
                dataIndex: 'userMobile',
                key: 'userMobile'
            }, {
                title: '退款金额',
                dataIndex: 'refundAmount',
                key: 'refundAmount',
                render: value => toMoney(value)
            }, {
                title: '退款渠道',
                dataIndex: 'channelId',
                key: 'channelId',
                render: value => this.state.channelEnum[value] || value
            },
            {
                title: '用户退款状态',
                dataIndex: 'refundShowStatus',
                key: 'refundShowStatus',
                render: (value, record) => this.state.refundShowStatusEnum[value] || value
            }, {
                title: '管理台退款状态',
                dataIndex: 'refundStatus',
                key: 'refundStatus',
                render: (value, record) => this.state.refundStatusEnum[value] || value
            }, {
                title: '退款申请时间',
                dataIndex: 'createTime',
                key: 'createTime',
                render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
                sorter: (a, b) => a.createTime - b.createTime,
            }, {
                title: '退款审核时间',
                dataIndex: 'examineTime',
                key: 'examineTime',
                render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
                sorter: (a, b) => a.examineTime - b.examineTime,
            }, {
                title: '提交渠道退款时间',
                dataIndex: 'commitPayTime',
                key: 'commitPayTime',
                render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
                sorter: (a, b) => a.commitPayTime - b.commitPayTime,
            }, {
                title: '退款原因',
                dataIndex: 'refundDesc',
                key: 'refundDesc',
                width: 100
            }, {
                title: '退款备注',
                dataIndex: 'refundRemark',
                key: 'refundRemark',
                width: 100
            }, {
                title: '退款拒绝理由',
                width: 100,
                dataIndex: 'handleRemark',
                key: 'handleRemark',
            }, {
                title: '渠道退款失败原因',
                width: 100,
                dataIndex: 'refundFailReson',
                key: 'refundFailReson',
            }, {
                title: '退款订单号',
                dataIndex: 'refundNo',
                key: 'refundNo'
            }, {
                title: '原订单号',
                dataIndex: 'orderNo',
                key: 'orderNo'
            }
        ];
        this.formItems = [
            {
                type: EditType.InputStr,
                key: 'handleRemark',
                label: '拒绝理由',
                config: {
                    rules: [
                        { required: true, message: '请填写拒绝理由' }
                    ],
                },
            }, {
                type: EditType.InputStr,
                key: 'payPassword',
                label: '支付操作密码',
                itemConfig: {
                    type: 'password'
                },
                config: {
                    rules: [
                        { required: true, message: '请填写支付操作密码' }
                    ],
                },
            }
        ]
    }
    render() {
        const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, pageSize, totalAmount, selectedAmount } = this.state
        const { changePage, search, clearSearch, onShowSizeChange, cancel, save, editItems, rowSelectionChange } = this.Action
        return (
            <div>
                <SearchPanel
                    isExport={true}
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Card>
                    <Button className="action-item" type="primary" ghost onClick={() => editItems('pass')}>批量通过审核</Button>
                    <Button className="action-item" type="primary" ghost onClick={() => editItems('refuse')}>批量拒绝</Button>
                </Card>
                <Card>
                    <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
                        当前页总金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的总金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
                </Card>
                <Table
                    scroll={{ x: 2000 }}
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: rowSelectionChange,
                    }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        showSizeChanger: true,
                        showTotal: actionShowTotal,
                        onShowSizeChange: onShowSizeChange,
                        pageSizeOptions: ['50', '100', '200', '500']
                    }}
                />
                <EditPanel
                    title={title}
                    modalVis={modalVis}
                    formItems={this.formItems}
                    modal={modal}
                    onSave={save}
                    onCancel={cancel}
                />
            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
        })

    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams, selectedRowKeys, dataSource } = this.state
        const { get } = this.Request
        const { getSelectedAmount, getTotalAmount } = this.Util
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }

        // 选中的项发生变化时，计算已选中的项的总金额
        if (nextState.selectedRowKeys !== selectedRowKeys) {
            this.setState({
                selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
            })
        }
        // 当前页的数据发生变化时，计算当前页的总金额
        if (nextState.dataSource !== dataSource) {
            this.setState({
                totalAmount: getTotalAmount(nextState.dataSource)
            })
        }
    }
}

export default Refund

