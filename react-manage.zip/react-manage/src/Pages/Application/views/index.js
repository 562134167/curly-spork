import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
// import './index.less'

const loadRealname = (cd) => {
    return import('./realname.js')
},
    loadDyRealname = (cd) => {
        return import('./dyRealname.js')
    },
    loadIntegral = (cd) => {
        return import('./integral.js')
    },
    loadRefund = (cb) => {
        return import('./refund.js')
    },
    loadFinanceRefund = (cb) => {
        return import('./financeRefund.js')
    },
	loadconvertibilityUser = (cd) => {
	    return import('./convertibilityUser.js')
	}

const Realname = getComponent(loadRealname),
    DyRealname = getComponent(loadDyRealname),
    Integral = getComponent(loadIntegral),
    Refund = getComponent(loadRefund),
    FinanceRefund = getComponent(loadFinanceRefund),
    ConvertibilityUser = getComponent(loadconvertibilityUser)

export default class Finance extends Component {
    render() {
        return (
            <Switch>
                <Route
                    path="/application"
                    exact render={() => <Redirect to="/application/realname" />}
                />

                <Route path='/application/realname' render={(props) => <Realname {...props} />} />
                <Route path='/application/dyRealname' render={(props) => <DyRealname {...props} />} />
                <Route path='/application/integral' render={(props) => <Integral {...props} />} />
                <Route path='/application/refund' render={(props) => <Refund {...props} />} />
                <Route path='/application/financeRefund' render={(props) => <FinanceRefund {...props} />} />
                <Route path='/application/convertibilityUser' render={(props) => <ConvertibilityUser {...props} />} />

            </Switch>
        )
    }
}