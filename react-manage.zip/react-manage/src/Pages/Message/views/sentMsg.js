/*
 * @Author: miccy 
 * @Date: 2017-12-15 18:01:09 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:10:51
 * 发件箱列表
 */
import React, { Component } from 'react'
// import { connect } from 'react-redux'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
// import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Button, Popconfirm } from 'antd'
import { formatData, formatParentIdOptions } from '../../../Util/reactUtil'
// import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import * as Status from '../constants'
const initGetParams = {
  pageIndex: 1,
}

const pagingUrl = '/system/message/paging',
  removeUrl = '/system/message/remove',
  removeItemsUrl = '/system/message/removelist',
  getPublicUrl = '/system/officialaccounts/getlist',//获取公众号id列表
  getMerchantUrl = '/system/merchant/queryNumber'; //获取商户号id

export default class DraftMsg extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {

      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      return fetch(removeUrl, params).then(res => {
        const { selectedRowKeys } = this.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        this.setState({
          selectedRowKeys
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    deleteItems: (params) => {
      return fetch(removeItemsUrl, params).then(res => {
        this.setState({
          selectedRowKeys: []
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    getPublic: (params) => {
      return getFetch(getPublicUrl, params).then(res => {
        if (res && res.models) {
          this.setState({
            publicOptions: formatParentIdOptions({
              options: res.models,
              hasDefaultOption: false,
            })
          })
        }
      })
    },
    getMerchant: (params) => {
      return getFetch(getMerchantUrl, params).then(res => {
        if (res && res.models) {
          this.setState({
            merchantOptions: formatParentIdOptions({
              options: res.models,
              hasDefaultOption: false,
            })
          })
        }
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    //点击查看按钮
    view: (record, index) => {
      if (record.messageType == 1) {
        this.props.history.push(`/message/editMsg?groupId=${record.id}`, Status.ViewMsg)
      } else {
        this.props.history.push(`/message/editText?groupId=${record.id}`, Status.ViewMsg)
      }
    },
    // 删
    remove: (groupId) => {
      this.Request.delete({ groupId })
    },
    // 批量删
    removeItems: () => {
      const { selectedRowKeys } = this.state;
      this.Request.deleteItems({ groupIds: selectedRowKeys })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      if (queryParams.updatetime) {
        queryParams.startTime = queryParams.updatetime[0].format('x')
        queryParams.endTime = queryParams.updatetime[1].format('x')
        delete queryParams.updatetime
      }
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { view, remove } = this.Action
    this.state = {
      dataSource: [],
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      publicOptions: [],
      merchantOptions: []
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '消息描述',
          id: 'desc',
        }, {
          type: SearchType.Select,
          label: '消息类型',
          id: 'type',
          dataSource: [
            { label: '公众号', value: 1 },
            { label: '商户号', value: 2 },
            { label: '系统消息', value: 3 }
          ]
        }, {
          type: SearchType.Select,
          label: '消息文本模式',
          id: 'messageType',
          dataSource: [
            { label: '图文模式', value: 1 },
            { label: '纯文本模式', value: 2 }
          ]
        }, {
          type: SearchType.DateRange,
          label: '更新时间',
          id: 'updatetime'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '消息描述',
        dataIndex: 'desc',
        key: 'desc',
      }, {
        title: '消息类型',
        dataIndex: 'type',
        key: 'type',
        render: value => {
          if (value == 1) {
            return '公众号消息'
          } else if (value == 2) {
            return '商户消息'
          } else {
            return '系统消息'
          }
        }
      }, {
        title: '所属公众号/所属商户',
        dataIndex: 'ownerId',
        key: 'ownerId',
        render: (value, record, index) => {
          let options
          if (record.type == 1) {
            options = this.state.publicOptions
          } else {
            options = this.state.merchantOptions
          }
          const option = options.filter((item, index) => item.value == value)
          if (option[0]) {
            return option[0].label
          }
          return ''
        }
      }, {
        title: '消息文本模式',
        dataIndex: 'messageType',
        key: 'messageType',
        render: value => {
          if (value == 1) {
            return '图文模式'
          }
          return '纯文本模式'
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item"> 删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { view(record, index) }}>查看</Button>
          </span>
        )
      }
    ];
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels } = this.state
    const { changePage, search, clearSearch, removeItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.Request.getPublic()
    // this.Request.getMerchant()
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
