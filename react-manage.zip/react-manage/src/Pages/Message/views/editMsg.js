/*
 * @Author: miccy 
 * @Date: 2017-12-13 17:30:20 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-03-22 19:10:30
 * 编辑图文消息
 */

import React, { Component } from 'react'
import is from 'is_js'
import { Row, Col, Button, message } from 'antd'
import MsgLeft from './component/MsgLeft'
// import Editor from './component/Editor'
import Editor from '../../../Common/Editor'
import { EditFormWrapper } from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { formateEditData, formatFormData, formatParentIdOptions } from '../../../Util/reactUtil'
import { getQueryObj } from '../../../Util/index';
import { fetch, getFetch } from '../../../Config/request'
import UserModal from './component/UserModal'
// import noImage from './images/35574339ab3c813.jpg'
import * as Status from '../constants'


const uploadFileUrl = '/system/file/upload' //上传图片
const addDraftUrl = '/system/draft/add' //添加草稿
const updateDraftUrl = '/system/draft/update' //更新草稿
const getMsgUrl = '/system/message/getinfolist'//获取某个groupId的已发送消息列表
const getDraftUrl = '/system/draft/getinfolist'//获取某个groupId的草稿箱消息列表
const sendMsgUrl = '/system/message/send'//发送消息
const getPublicUrl = '/system/officialaccounts/getlist'//获取公众号id列表
const getMerchantUrl = '/system/merchant/queryNumber' //获取商户号id

const newItem = {
  id: new Date().getTime(),
  content: '',
  image: '',
  messageType: 1,
  ownerId: '',
  releaseTime: new Date().getTime(),
  title: '',
  type: 1,
  editor: '',
  summary: ''
}
export default class EditMsg extends Component {

  constructor(props) {
    super(props)
    this.state = {
      userModalVis: false,
      msgItems: [],                //文章列表
      current: 0,                   //当前文章index
      modal: {},                    //当前表单内容
      publicOptions: [],            //所属公众号下拉选项
      merchantOptions: [],            //所属公众号下拉选项
      // messageType: Status.NewDraft,
      // formItems: [],
      isSend: false,
      groupId: null

    }
    this.onInit()
  }
  // formItems = []
  Request = {
    getMsg: (params) => {
      const queryStr = getQueryObj(this.props.location.search)
      return getFetch(getMsgUrl, { ...params, ...queryStr }).then(res => {
        if (res && res.models) {
          this.setState({
            msgItems: res.models,
            current: 0
          })
        }
      })
    },
    getDraft: (params) => {
      const queryStr = getQueryObj(this.props.location.search)
      return getFetch(getDraftUrl, { ...params, ...queryStr }).then(res => {
        if (res && res.models) {
          this.setState({
            msgItems: res.models,
            current: 0
          })
        }
      })
    },
    addDraft: (params) => {
      return fetch(addDraftUrl, params, { arrayFormat: 'indices' }).then(res => {
        if (res.status == 0) {
          if (this.state.isSend) {
            message.success('添加消息到草稿箱成功,请选择接收消息的用户')
            this.setState({
              userModalVis: true,
              groupId: res.model
            })
          } else {
            message.success('添加消息到草稿箱成功,2秒后跳转到草稿箱')
            setTimeout(() => {
              this && this.props.history.replace('/message/draftMsg')
            }, 2000)
          }
        }
        return res
      })
    },
    updateDraft: (params) => {
      return fetch(updateDraftUrl, params, { arrayFormat: 'indices' }).then(res => {
        if (res.status == 0) {
          if (this.state.isSend) {
            message.success('修改草稿箱消息成功,请选择接收消息的用户')
            this.setState({
              userModalVis: true,
              groupId: res.model
            })
          } else {
            message.success('修改草稿箱消息成功,2秒后跳转到草稿箱')
            setTimeout(() => {
              this && this.props.history.replace('/message/draftMsg')
            }, 2000)
          }

        }
      })
    },
    getPublic: (params) => {
      return getFetch(getPublicUrl, params).then(res => {
        if (res && res.models) {
          this.setState({
            publicOptions: formatParentIdOptions({
              options: res.models,
              hasDefaultOption: false,
            })
          })
        }
      })
    },
    getMerchant: (params) => {
      return getFetch(getMerchantUrl, params).then(res => {
        if (res && res.models) {
          this.setState({
            merchantOptions: formatParentIdOptions({
              options: res.models,
              hasDefaultOption: false,
              valueKey: 'merchantId',
              labelKey: 'merchantName'
            })
          })
        }
      })
    },
    sendMsg: (params) => {
      return fetch(sendMsgUrl, params).then(res => {
        if (res.status == 0) {
          message.success('发送消息成功,2秒后跳转到发件箱')
          setTimeout(() => {
            this && this.props.history.replace('/message/sentMsg')
          }, 2000)
        }
      })
    }
  }
  // 执行页面上的点击操作
  Action = {
    // 添加文章
    addMsg: () => {
      const msgItems = [...this.state.msgItems]
      // 新建文章内容
      const newMsg = {
        id: new Date().getTime(),
        title: '',
        content: '',
        image: '',
        ownerId: msgItems[0].ownerId,
        releaseTime: new Date().getTime(),
        type: msgItems[0].type,
        messageType: 1,
        summary: '',
        editor: ''
      }
      msgItems.push(newMsg)
      this.setState({
        msgItems,
        current: msgItems.length - 1,
        // modal: this.Util.formatModal(newMsg)
      })
    },
    // 修改文章
    editMsg: (index) => {
      // console.log('index',index)
      if (index == this.state.current) {
        return;
      }
      const { current } = this.state
      const msgItems = [...this.state.msgItems]
      const values = this.editForm.props.form.getFieldsValue();
      msgItems[current] = this.Util.handleChangedData({ ...msgItems[current], ...values })
      this.setState({
        current: index,
        msgItems,
        // modal: this.Util.formatModal(msgItems[index])
      })
    },
    // 删除文章
    deleteMsg: (index) => {
      const msgItems = [...this.state.msgItems]
      const { current } = this.state
      if (index <= current) {
        this.setState({
          current: current - 1
        })
      } else if (index == msgItems.length - 1) {
        this.setState({
          current: msgItems.length - 2
        })
      }
      msgItems.splice(index, 1)
      this.setState({
        msgItems,
        // modal: this.Util.formatModal(tempArr[current])
      })
    },
    // 当表单的值发生改变时
    onValuesChange: (fields) => {
      const { current } = this.state
      const msgItems = [...this.state.msgItems]
      if ('type' in fields || 'ownerId' in fields) {
        for (let i = -1; msgItems[++i];) {
          if (!is.undefined(fields.type)) {
            msgItems[i].type = fields.type
          }
          if (!is.undefined(fields.ownerId)) {
            msgItems[i].ownerId = fields.ownerId
          }
        }
      }
      msgItems[current] = this.Util.handleChangedData({ ...msgItems[current], ...fields })
      this.setState({
        msgItems,
        // modal: this.Util.formatModal(msgItems[current])
      })
    },
    save: (type) => {
      console.log(this.editForm.props.form.getFieldValue('content'));
      // const { msgItems } = this.state
      const msgItems = [...this.state.msgItems]
      // 判断消息表单是否填写正确
      for (let i = -1; msgItems[++i];) {
        if (!this.Util.validateItem(msgItems[i])) {
          this.setState({
            current: i,
            // modal: this.Util.formatModal(msgItems[i])
          }, () => {
            this.editForm.props.form.validateFieldsAndScroll((error, values) => {
            })
          })
          return
        }
      }
      if (type == 'save') {
        this.setState({
          isSend: true
        })
      } else {
        this.setState({
          isSend: false
        })
      }
      // 将消息格式化发送到服务器
      for (let j = -1; msgItems[++j];) {
        msgItems[j].messageType = 1
        delete msgItems[j].id
        msgItems[j] = formatFormData(msgItems[j], this.formItems)
        // if (this.props.location.state == Status.EditDraft && is.undefined(msgItems.groupId)) {
        //   msgItems[j].groupId = getQueryObj(this.props.location.search).groupId
        // }
      }
      // console.log(msgItems)
      this.Util.save(msgItems)
    },
    send: () => {
      this.Action.save('save')
    },
    sendMsg: (ids) => {
      // console.log(ids)
      this.Request.sendMsg({
        draftGroupId: this.state.groupId,
        userIds: ids
      })
    },
    cancel: () => {
      this.props.history.replace('/message/draftMsg')
    }
  }
  // 工具函数对象
  Util = {
    // 将获得的url转换成Upload要求的数据格式
    getFileList: (url) => {
      const tempArr = url.split(',')
      const fileList = []
      for (let i in tempArr) {
        fileList.push({
          uid: tempArr[i],
          status: 'done',
          url: tempArr[i],
          response: tempArr[i]
        })
      }
      return fileList
    },
    // 将fileList转换成url
    getUrl: (fileList) => {
      const tempArr = []
      for (let i = -1; fileList[++i];) {
        tempArr.push(fileList[i].response)
      }
      return tempArr.join(',')
    },
    // 处理传入表单的编辑内容的key、value以匹配组件的格式要求
    handleEditData: (obj) => {
      const { getFileList } = this.Util
      const temp = { ...obj }
      if (!is.array(temp.image) && temp.image) {
        temp.image = getFileList(obj.image) || []
      }
      if (!is.array(temp.sharedImage) && temp.sharedImage) {
        temp.sharedImage = getFileList(obj.sharedImage) || []
      }
      return temp
    },
    //处理表单的保存内容的key、value以匹配后台的格式
    handleChangedData: (obj) => {
      const { getUrl } = this.Util
      // const temp = formatFormData(obj, this.formItems)
      const temp = { ...obj }
      if (is.array(temp.image)) {
        if (temp.image[0] && temp.image[0].response) {
          temp.image = getUrl(obj.image)
        }
      }
      if (is.array(temp.sharedImage)) {
        if (temp.sharedImage[0] && temp.sharedImage[0].response) {
          temp.sharedImage = getUrl(obj.sharedImage)
        }
      }
      return temp
    },
    // 将数据格式转换成表单的格式
    formatModal: (obj) => {
      const temp = this.Util.handleEditData(formateEditData(obj, this.formItems))
      const modal = {}
      for (let i in temp) {
        modal[i] = {
          value: temp[i]
        }
      }
      return modal
    },
    // 设置ownerId的下拉选项
    setOwnerOptions: (type, publicOptions, merchantOptions) => {
      const locationState = this.props.location.state || Status.NewDraft
      let formItem = {}
      for (let i in this.formItems) {
        if (this.formItems[i].key == 'ownerId') {
          formItem = this.formItems[i]
          break
        }
      }
      if (type == 1) {
        formItem.itemConfig.options = publicOptions || this.state.publicOptions
        if (locationState == Status.CopyDraft || locationState == Status.NewDraft) {
          formItem.itemConfig.disabled = false
        }
      } else if (type == 2) {
        formItem.itemConfig.options = merchantOptions || this.state.merchantOptions
        if (locationState == Status.CopyDraft || locationState == Status.NewDraft) {
          formItem.itemConfig.disabled = false
        }
      } else {
        formItem.itemConfig.options = []
        formItem.itemConfig.disabled = true
        this.editForm.props.form.setFieldsValue({
          ownerId: ''
        })
      }
    },
    // 判断值是否为undefined || {} || [] || ''
    isEmpty: (value) => {
      return is.undefined(value) || !is.existy(value) || is.empty(value)
    },
    // 保存时验证填写的所有消息表单项
    validateItem: (item) => {
      const { isEmpty } = this.Util
      if (isEmpty(item.title) || isEmpty(item.content) || isEmpty(item.releaseTime) || isEmpty(item.sharedImage) || isEmpty(item.image) || isEmpty(item.type) || isEmpty(item.summary) || isEmpty(item.editor)) {
        return false
      } else if (item.type != 3 && isEmpty(item.ownerId)) {
        return false
      } else if (item.summary.length > 255 || item.title.length > 255) {
        return false
      }
      return true
    },
    // 根据当前页面的类型，获取配置的表单项 
    getFormItem: (type) => {
      if (type == Status.NewDraft || type == Status.CopyDraft) {
        return;
      } else if (type == Status.EditDraft) {
        for (let i in this.formItems) {
          const formItem = this.formItems[i]
          if (formItem.key == 'type' || formItem.key == 'ownerId') {
            formItem.itemConfig = formItem.itemConfig || {}
            formItem.itemConfig.disabled = true
          }
        }
      } else if (type == Status.ViewMsg) {
        for (let i in this.formItems) {
          const formItem = this.formItems[i]
          formItem.itemConfig = formItem.itemConfig || {}
          formItem.itemConfig.disabled = true
        }
      }
    },
    // 根据当前页面的类型，设置编辑的消息列表
    setMsg: (type) => {
      if (type == Status.NewDraft) {
        this.setState({
          msgItems: [newItem]
        })
      } else if (type == Status.CopyDraft || type == Status.EditDraft) {
        this.Request.getDraft()
      } else if (type == Status.ViewMsg) {
        this.Request.getMsg()
      }
    },
    // 根据不同的状态，新增或者修改消息
    save: (msgItems) => {
      const locationState = this.props.location.state || Status.NewDraft
      if (locationState == Status.NewDraft || locationState == Status.CopyDraft) {
        this.Request.addDraft({ list: msgItems })
      } else if (locationState == Status.EditDraft) {
        this.Request.updateDraft({ list: msgItems })
      }
    }
  }
  onInit() {
    // 初始化配置项
    this.formItems = [
      {
        type: EditType.Select,
        label: '消息类型',
        key: 'type',
        config: {
          rules: [
            { required: true, message: '请选择消息类型' }
          ],
          getValueFromEvent: (value) => {
            this.Util.setOwnerOptions(value)
            return value
          }
        },
        itemConfig: {
          options: [
            { value: 1, label: '公众号消息' },
            { value: 2, label: '商户号消息' },
            { value: 3, label: '系统消息' },
          ]
        },
        isSelectNum: true
      }, {
        type: EditType.Select,
        label: '所属商户/所属公众号',
        key: 'ownerId',
        config: {
          rules: [
            {
              validator: (rule, value, callback) => {
                const form = this.editForm.props.form;
                if (form.getFieldValue('type') != 3 && (is.undefined(value) || value.trim() == '')) {
                  callback('请选择所属商户/所属公众号');
                }
                callback();
              }
            }
          ]
        },
        itemConfig: {
          options: []
        },
        isSelectNum: true
      }, {
        type: EditType.InputStr,
        label: '标题',
        key: 'title',
        config: {
          rules: [
            { required: true, message: '请输入标题' },
            {
              validator: (rule, value, callback) => {
                if (value && value.length > 255) {
                  callback('标题的字数必须小于255！');
                }
                callback();
              }
            }
          ]
        }
      }, {
        type: EditType.InputStr,
        label: '作者',
        key: 'editor',
        config: {
          rules: [
            { required: true, message: '请输入作者' }
          ]
        }
      }, {
        type: EditType.DatePicker,
        key: 'releaseTime',
        label: '发布时间',
        itemConfig: {
          showTime: true,
          format: 'YYYY-MM-DD HH:mm:ss'
        },
        config: {
          rules: [
            { required: true, message: '请选择发布时间' }
          ]
        }
      }, {
        type: EditType.Image,
        key: 'sharedImage',
        label: '分享封面',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            // 当上传图片的状态为done的时候，手动将图片设置回msgItem中
            if (Array.isArray(e)) {
              const imageUrl = e[0] && e[0].response;
              if (imageUrl) {
                const fileList = this.Util.getFileList(imageUrl);
                this.Action.onValuesChange({ sharedImage: fileList })
                return fileList
              }
              return e;
            }
            if (e && is.array(e.fileList)) {
              const imageUrl = e.fileList[0] && e.fileList[0].response;
              if (imageUrl) {
                const fileList = this.Util.getFileList(imageUrl);
                this.Action.onValuesChange({ sharedImage: fileList })
                return fileList
              }
            }
            return e && e.fileList;
          },
          rules: [
            // { required: true, },
            {
              validator: (rule, value, callback) => {
                if (is.undefined(value) || is.empty(value)) {
                  callback('请上传分享封面');
                }
                callback();
              }
            }
          ]
        },
        isImageAutoHandle: false,
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          name: 'files'
        },
        isShowbtn: (props) => {
          if (props.form.getFieldValue('sharedImage') && props.form.getFieldValue('sharedImage').length >= 1) {
            return false
          }
          return true
        }
      }, {
        type: EditType.Image,
        key: 'image',
        label: '封面',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            // 当上传图片的状态为done的时候，手动将图片设置回msgItem中
            if (Array.isArray(e)) {
              const imageUrl = e[0] && e[0].response;
              if (imageUrl) {
                const fileList = this.Util.getFileList(imageUrl);
                this.Action.onValuesChange({ image: fileList })
                return fileList
              }
              return e;
            }
            if (e && is.array(e.fileList)) {
              const imageUrl = e.fileList[0] && e.fileList[0].response;
              if (imageUrl) {
                const fileList = this.Util.getFileList(imageUrl);
                this.Action.onValuesChange({ image: fileList })
                return fileList
              }
            }
            return e && e.fileList;
          },
          rules: [
            // { required: true, },
            {
              validator: (rule, value, callback) => {
                if (is.undefined(value) || is.empty(value)) {
                  callback('请上传封面');
                }
                callback();
              }
            }
          ]
        },
        isImageAutoHandle: false,
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          name: 'files'
        },
        isShowbtn: (props) => {
          if (props.form.getFieldValue('image') && props.form.getFieldValue('image').length >= 1) {
            return false
          }
          return true
        }
      }, {
        label: '消息详情',
        key: 'content',
        render: Editor,
        config: {
          rules: [
            { required: true, message: '请输入消息详情' }
          ]
        }
      }, {
        type: EditType.Textarea,
        label: '消息摘要',
        key: 'summary',
        itemConfig: {
          autosize: { minRows: 2, maxRows: 6 },
          // minHeight: 32
        },
        config: {
          rules: [
            { required: true, message: '请输入消息摘要' },
            {
              validator: (rule, value, callback) => {
                if (value && value.length > 255) {
                  callback('消息摘要的字数必须小于255！');
                }
                callback();
              }
            }
          ]
        }
      }
    ]
  }
  componentDidMount() {
    const locationState = this.props.location.state
    // 根据state配置表单项
    this.Util.getFormItem(locationState || Status.NewDraft)
    // 根据state设置消息
    this.Util.setMsg(locationState || Status.NewDraft)
    // 获取所属公众号id的下拉选项
    this.Request.getPublic()
    // 获取所属商户号id的下拉选项
    this.Request.getMerchant()

  }
  componentWillUpdate(nextProps, nextState) {
    // console.log(nextState)
    if (nextState.msgItems !== this.state.msgItems || nextState.current !== this.state.current) {
      this.setState({
        modal: this.Util.formatModal(nextState.msgItems[nextState.current])
      })
    }
    // 如果当前modal的type为公众号消息，那么获取到公众号id列表后 ，手动触发设置下拉列表
    if (nextState.msgItems[nextState.current] && (nextState.msgItems[nextState.current].type == 1 || nextState.publicOptions !== this.state.publicOptions)) {
      this.Util.setOwnerOptions(nextState.msgItems[nextState.current].type, nextState.publicOptions, nextState.merchantOptions)
    }
    //  如果当前modal的type为商户消息，获取到商户列表后，手动触发设置下拉列表
    if (nextState.msgItems[nextState.current] && (nextState.msgItems[nextState.current].type == 2 || nextState.merchantOptions !== this.state.merchantOptions)) {
      this.Util.setOwnerOptions(nextState.msgItems[nextState.current].type, nextState.publicOptions, nextState.merchantOptions)
    }
  }
  render() {
    const { msgItems, current, modal, userModalVis } = this.state
    const { addMsg, editMsg, deleteMsg, onValuesChange, save, send, sendMsg, cancel } = this.Action
    const locationState = this.props.location.state
    return (
      <div>
        <Row>
          <Col md={3} sm={24}>
            <MsgLeft
              items={msgItems}
              current={current}
              addItem={addMsg}
              editItem={editMsg}
              deleteItem={deleteMsg}
            />
          </Col>
          <Col md={21} sm={24}>
            <EditFormWrapper
              wrappedComponentRef={(inst) => this.editForm = inst}
              modal={modal}
              formItems={this.formItems}
              onValuesChange={onValuesChange}
            />
            <Row style={{ marginTop: 20 }}>
              <Col offset={6}>
                <Button type="primary" className="action-item" onClick={save} disabled={locationState == Status.ViewMsg} >保存到草稿箱</Button>
                <Button className="action-item" onClick={send} disabled={locationState == Status.ViewMsg} >发送</Button>
              </Col>
            </Row>
          </Col>
        </Row>
        <UserModal
          modalVis={userModalVis}
          send={sendMsg}
          cancel={cancel}
          type={(msgItems[0] && msgItems[0].type) || ''}
          ownerId={(msgItems[0] && msgItems[0].ownerId) || ''}
        />
      </div>
    )
  }
}