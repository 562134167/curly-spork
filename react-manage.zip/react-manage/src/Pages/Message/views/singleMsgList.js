/*
 * @Author: miccy 
 * @Date: 2018-02-08 11:17:45 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-03-23 15:07:52
 * 已发送的单图文列表
 */

import React, { Component } from 'react'
// import { connect } from 'react-redux'
import is from 'is_js'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Table, Button } from 'antd'
import { formatParentIdOptions, handleEndTime, handleStartTime } from '../../../Util/reactUtil'
import { requestGet, requestUpdate } from '../../../Util/Request'
import { actionEdit, actionSave, actionCancel, actionChangePage, actionClearSearch, actionSearch, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'
import Editor from '../../../Common/Editor'

const pagingUrl = '/system/message/paginginfo',
  updateUrl = '/system/message/updateinfo',
  uploadFileUrl = '/system/file/upload', //上传图片
  getPublicUrl = '/system/officialaccounts/getlist',//获取公众号id列表
  getMerchantUrl = '/system/merchant/queryNumber' //获取商户号id

const editTitle = '编辑单条消息'

export default class SingleMsgList extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({ params, pagingUrl, context: this }).then((res) => {
        if (res.status == 0 && !this.state.merchantOptions.length) {
          this.Request.getMerchant()
          this.Request.getPublic()
        }
      })
    },
    edit: (params) => {
      requestUpdate({ params, updateUrl, context: this })
    },
    getPublic: (params) => {
      requestGet({
        params, pagingUrl: getPublicUrl, context: this, successCallback: (res) => {
          this.setState({
            publicOptions: formatParentIdOptions({
              options: res.models,
              hasDefaultOption: false,
            })
          })
        }
      })
    },

    getMerchant: (params) => {
      requestGet({
        params, pagingUrl: getMerchantUrl, context: this, successCallback: (res) => {
          this.setState({
            merchantOptions: formatParentIdOptions({
              options: res.models,
              hasDefaultOption: false,
            })
          })
        }
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 编辑单条的图文消息，点击跳转到单图文的编辑页面
    edit: (record, index) => {
      this.Util.setFormItem(record.type, record.messageType)
      actionEdit({ record, context: this, editTitle })
    },
    save: (values) => {
      actionSave({ context: this, values })
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      if (!is.undefined(queryParams.updatetime) && !is.undefined(queryParams.updatetime[0])) {
        queryParams.startTime = handleStartTime(queryParams.updatetime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.updatetime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      delete queryParams.updatetime
      actionSearch({ value: queryParams, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    }
  }
  Util = {
    // 更新模态框表单的配置
    updateFormItem: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
        fn(formItem)
      }
    },
    setFormItem: (type, messageType) => {
      if (messageType == 1) {
        this.formItems = this.Util.getMsgFormItem(type)
      } else {
        this.formItems = this.Util.getTextFormItem(type)
      }
      // // 修改下拉选项框
      // const selectFormItem = this.formItems.filter((item, index) => item.key === 'ownerId')[0]
      // if (type == 1) {
      //   selectFormItem.itemConfig.options = this.state.publicOptions
      // } else if (type == 2) {
      //   selectFormItem.itemConfig.options = this.state.merchantOptions
      // } else if (type == 3) {
      //   selectFormItem.itemConfig.options = []
      // }


    },
    getTextFormItem: (type) => {
      let options;
      if (type == 1) {
        options = this.state.publicOptions
      } else if (type == 2) {
        options = this.state.merchantOptions
      } else if (type == 3) {
        options = []
      }
      return [
        {
          type: EditType.Select,
          label: '消息类型',
          key: 'type',
          // config: {
          //   rules: [
          //     { required: true, message: '请选择消息类型' }
          //   ],
          // },
          itemConfig: {
            options: [
              { value: 1, label: '公众号消息' },
              { value: 2, label: '商户号消息' },
              { value: 3, label: '系统消息' },
            ],
            disabled: true,
          },
          isSelectNum: true
        }, {
          type: EditType.Select,
          label: '所属商户/所属公众号',
          key: 'ownerId',
          itemConfig: {
            options: options || [],
            disabled: true
          },
          isSelectNum: true
        }, {
          type: EditType.InputStr,
          label: '标题',
          key: 'title',
          config: {
            rules: [
              { required: true, message: '请输入标题' },
              {
                validator: (rule, value, callback) => {
                  if (value && value.length > 255) {
                    callback('标题的字数必须小于255！');
                  }
                  callback();
                }
              }
            ]
          }
        }, {
          type: EditType.InputStr,
          label: '作者',
          key: 'editor',
          config: {
            rules: [
              { required: true, message: '请输入作者' }
            ]
          }
        }, {
          type: EditType.DatePicker,
          key: 'releaseTime',
          label: '发布时间',
          itemConfig: {
            showTime: true,
            format: 'YYYY-MM-DD HH:mm:ss'
          },
          config: {
            rules: [
              { required: true, message: '请选择发布时间' }
            ]
          }
        }, {
          type: EditType.Textarea,
          label: '消息详情',
          key: 'content',
          config: {
            rules: [
              { required: true, message: '请输入消息详情' },
              {
                validator: (rule, value, callback) => {
                  if (!is.undefined(value) && value.length > 500) {
                    callback('消息详情的字数不得多于500');
                  }
                  callback();
                }
              }
            ]
          }
        }
      ]
    },
    getMsgFormItem: (type) => {
      let options;
      if (type == 1) {
        options = this.state.publicOptions
      } else if (type == 2) {
        options = this.state.merchantOptions
      } else if (type == 3) {
        options = []
      }
      return [
        {
          type: EditType.Select,
          label: '消息类型',
          key: 'type',
          // config: {
          //   rules: [
          //     { required: true, message: '请选择消息类型' }
          //   ]
          // },
          itemConfig: {
            options: [
              { value: 1, label: '公众号消息' },
              { value: 2, label: '商户号消息' },
              { value: 3, label: '系统消息' },
            ],
            disabled: true
          },
          isSelectNum: true
        }, {
          type: EditType.Select,
          label: '所属商户/所属公众号',
          key: 'ownerId',
          itemConfig: {
            options: options || [],
            disabled: true
          },
          isSelectNum: true
        }, {
          type: EditType.InputStr,
          label: '标题',
          key: 'title',
          config: {
            rules: [
              { required: true, message: '请输入标题' },
              {
                validator: (rule, value, callback) => {
                  if (value && value.length > 255) {
                    callback('标题的字数必须小于255！');
                  }
                  callback();
                }
              }
            ]
          }
        }, {
          type: EditType.InputStr,
          label: '作者',
          key: 'editor',
          config: {
            rules: [
              { required: true, message: '请输入作者' }
            ]
          }
        }, {
          type: EditType.DatePicker,
          key: 'releaseTime',
          label: '发布时间',
          itemConfig: {
            showTime: true,
            format: 'YYYY-MM-DD HH:mm:ss'
          },
          config: {
            rules: [
              { required: true, message: '请选择发布时间' }
            ]
          }
        }, {
          type: EditType.Image,
          key: 'sharedImage',
          label: '分享封面',
          config: {
            valuePropName: 'fileList',
            getValueFromEvent: (e) => {
              if (Array.isArray(e)) {
                return e;
              }
              return e && e.fileList;
            },
            rules: [
              { required: true, },
              {
                validator: (rule, value, callback) => {
                  console.log(value)
                  if (is.undefined(value) || is.empty(value)) {
                    callback('请上传分享封面');
                  }
                  callback();
                }
              }
            ]
          },
          itemConfig: {
            action: window.baseUrl + uploadFileUrl,
            name: 'files'
          },
          isShowbtn: (props) => {
            if (props.form.getFieldValue('sharedImage') && props.form.getFieldValue('sharedImage').length >= 1) {
              return false
            }
            return true
          }
        }, {
          type: EditType.Image,
          key: 'image',
          label: '封面',
          config: {
            valuePropName: 'fileList',
            getValueFromEvent: (e) => {
              if (Array.isArray(e)) {
                return e;
              }
              return e && e.fileList;
            },
            rules: [
              { required: true, },
              {
                validator: (rule, value, callback) => {
                  console.log(value)
                  if (is.undefined(value) || is.empty(value)) {
                    callback('请上传封面');
                  }
                  callback();
                }
              }
            ]
          },
          itemConfig: {
            action: window.baseUrl + uploadFileUrl,
            name: 'files'
          },
          isShowbtn: (props) => {
            if (props.form.getFieldValue('image') && props.form.getFieldValue('image').length >= 1) {
              return false
            }
            return true
          }
        }, {
          label: '消息详情',
          key: 'content',
          render: Editor,
          config: {
            rules: [
              { required: true, message: '请输入消息详情' }
            ]
          }
        }, {
          type: EditType.Textarea,
          label: '消息摘要',
          key: 'summary',
          itemConfig: {
            autosize: { minRows: 2, maxRows: 6 },
          },
          config: {
            rules: [
              { required: true, message: '请输入消息摘要' },
              {
                validator: (rule, value, callback) => {
                  if (value && value.length > 255) {
                    callback('消息摘要的字数必须小于255！');
                  }
                  callback();
                }
              }
            ]
          }
        }
      ]
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    const { edit } = this.Action
    this.state = {
      dataSource: [],
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      totalPages: null,
      getDataParams: {},
      publicOptions: [],
      merchantOptions: [],
      modal: {},
      editId: null,
      modalVis: false,
      title: editTitle
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '消息标题',
          id: 'title',
        }, {
          type: SearchType.Select,
          label: '消息类型',
          id: 'type',
          dataSource: [
            { label: '公众号', value: 1 },
            { label: '商户号', value: 2 },
            { label: '系统消息', value: 3 }
          ]
        }, {
          type: SearchType.Select,
          label: '消息文本模式',
          id: 'messageType',
          dataSource: [
            { label: '图文模式', value: 1 },
            { label: '纯文本模式', value: 2 }
          ]
        }, {
          type: SearchType.DateRange,
          label: '更新时间',
          id: 'updatetime'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '消息标题',
        dataIndex: 'title',
        key: 'title',
      }, {
        title: '消息类型',
        dataIndex: 'type',
        key: 'type',
        render: value => {
          if (value == 1) {
            return '公众号消息'
          } else if (value == 2) {
            return '商户消息'
          } else {
            return '系统消息'
          }
        }
      }, {
        title: '所属公众号/所属商户',
        dataIndex: 'ownerId',
        key: 'ownerId',
        render: (value, record, index) => {
          let options
          if (record.type == 1) {
            options = this.state.publicOptions
          } else {
            options = this.state.merchantOptions
          }
          const option = options.filter((item, index) => item.value == value)
          if (option[0]) {
            return option[0].label
          }
          return ''
        }
      }, {
        title: '封面',
        dataIndex: 'image',
        key: 'image',
        render: value => value && <img src={value} width={50} alt="" />
      }, {
        title: '消息文本模式',
        dataIndex: 'messageType',
        key: 'messageType',
        render: value => {
          if (value == 1) {
            return '图文模式'
          }
          return '纯文本模式'
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>编辑</Button>
          </span>
        )
      }
    ];
    // 初始化配置项
    this.formItems = []
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels, title, modalVis, modal } = this.state
    const { changePage, search, clearSearch, save, cancel } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: actionShowTotal
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
