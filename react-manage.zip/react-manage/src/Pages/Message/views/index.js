import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
import './index.less'
const loadDraftMsg = (cb) => {
  return import('./draftMsg.js')
}
const loadEditMsg = (cb) => {
  return import('./editMsg.js')
}
const loadSentMsg = (cb) => {
  return import('./sentMsg.js')
}
const loadEditText = (cb) => {
  return import('./editText.js')
}
const loadSingleMsgList = (cb) => {
  return import('./singleMsgList.js')
}
const DraftMsg = getComponent(loadDraftMsg)
const EditMsg = getComponent(loadEditMsg)
const SentMsg = getComponent(loadSentMsg)
const EditText = getComponent(loadEditText)
const SingleMsgList = getComponent(loadSingleMsgList)

export default class Message extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/message"
          exact render={() => <Redirect to="/message/draftMsg" />}
        />
        <Route path="/message/draftMsg" render={(props) => <DraftMsg {...props} />} />
        <Route path="/message/editMsg" render={(props) => <EditMsg {...props} />} />
        <Route path="/message/sentMsg" render={(props) => <SentMsg {...props} />} />
        <Route path="/message/editText" render={(props) => <EditText {...props} />} />
        <Route path="/message/singleMsgList" render={(props) => <SingleMsgList {...props} />} />

      </Switch>
    )
  }
}