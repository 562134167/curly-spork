import React, { Component } from 'react'
import is from 'is_js'
import { Card, Button, Col } from 'antd'
import noImage from '../images/35574339ab3c813.jpg'
export default class MsgLeft extends Component {
  // Utils = {
  //   formatItems: (arr) => {
  //     const tempArr = Object.assign([], arr)
  //     for (let i = -1; tempArr[++i];) {
  //       tempArr[i].uniqueId = arr[i].id || arr[i].uniqueId || new Date().getTime() + i;
  //     }
  //     return tempArr;
  //   }
  // }
  render() {
    const { items, deleteItem, editItem, addItem, current } = this.props
    // const renderItems = this.Utils.formatItems(items || [])
    return (
      <div className="msg-left">
        {
          items.map((item, index) => {
            // 如果当前为第一条文章，显示为上下布局
            if (index == 0) {
              return (<Card key={item.id || index} className={index == current ? "msg-card active" : "msg-card"}>
                <img src={item.image && !is.empty(item.image) ? item.image : noImage} className="msg-thumb" alt="封面" />
                <div className="action-panel">
                  {/* <Button icon="delete" onClick={() => deleteItem(index)} size="small" className="btn-action" /> */}
                  <Button icon="edit" onClick={() => editItem(index)} size="small" className="btn-action" />
                  <p>{item.title}</p>
                </div>
              </Card>)
            } else {
              // 不是第一条文章，显示成左右布局
              return (
                <Card key={item.id || index} className={index == current ? "msg-card active" : "msg-card"}>
                  <Col span={10}>
                    <p>{item.title}</p>
                  </Col>
                  <Col span={14}>
                    <img src={item.image ? item.image : noImage} className="msg-thumb" alt="封面" />
                  </Col>
                  <div className="action-panel">
                    <Button icon="delete" onClick={() => deleteItem(index)} size="small" className="btn-action" />
                    <Button icon="edit" onClick={() => editItem(index)} size="small" className="btn-action" />
                  </div>
                </Card>
              )
            }
          })
        }
        {items.length >= 10 ? null : (<Card className="msg-card">
          <Button icon="edit" onClick={addItem} size="small" className="btn-action btn-new" >新建图文</Button>
        </Card>)}
      </div>
    )
  }
}