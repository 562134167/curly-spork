/*
 * @Author: miccy 
 * @Date: 2017-12-16 11:05:49 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-01-20 17:41:11
 * 草稿箱点击发送 显示模态框可选择发送给哪些用户
 */
import React, { Component } from 'react'
import is from 'is_js'
import { Modal, Table, Button, message } from 'antd'
import { formatData, flattenObj } from '../../../../Util/reactUtil'
import { getFetch } from '../../../../Config/request'
import SearchPanel from '../../../../Common/searchPanel'
import * as SearchType from '../../../../Common/searchTypes'

const pagingUrl = '/system/detail/get'
const pagingMerchantUrl = '/system/fans/merchantinfos'
export default class UserModal extends Component {
  constructor(props) {
    super(props)
    this.onInit()
  }
  Request = {
    // 获取全部用户列表数据
    get: (params) => {
      /**@param {Object} params 
       * 数据格式
       * {
        @param {String} keyword,
        @param {Number} pageIndex,
        @param {Number} pageSize'
      }
       */
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels, totalPages } = res
          const dataSource = formatData(flattenObj(models, ['userInfo']))
          this.setState({
            dataSource,
            totalModels,
            totalPages,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 获取关注商户用户列表数据
    getMerchant: (params) => {
      /**@param {Object} params 
       * 数据格式
       * {
        @param {String} keyword,
        @param {Number} pageIndex,
        @param {Number} pageSize'
      }
       */
      return getFetch(pagingMerchantUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels, totalPages } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            totalPages,
            current: params.pageIndex
          })
        }
        return res
      })
    },
  }
  Action = {
    rowSelectionChange: (selectedRowKeys, selectedRows) => {
      // const { current, idsObj } = this.state
      // idsObj[current] = selectedRowKeys
      this.setState({
        // idsObj,
        selectedRowKeys
      })
    },
    changePage: (pageIndex, pageSize) => {
      const { type, ownerId } = this.props
      this.Util.getDataSource(type, ownerId, pageIndex)
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      // const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
        message.error('请输入正确的手机号码')
        return;
      }
      // const params = { ...getDataParams, ...queryParams }
      // this.setState({
      //   getDataParams: params
      // })
      this.Util.getDataSource(this.props.type, this.props.ownerId, 1, queryParams)
      this.setState({
        selectedRowKeys: []
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.Util.getDataSource(this.props.type, this.props.ownerId, 1)
      this.setState({
        selectedRowKeys: []
      })
    },
  }
  Util = {
    getDataSource: (type, ownerId, pageIndex = 1, queryParams) => {
      if (type == 1 || type == 3) {
        this.Request.get({ pageIndex, ...queryParams })
      } else if (type == 2) {
        this.Request.getMerchant({ id: ownerId, pageIndex, ...queryParams })
      }
    },
    // objToArray: (obj) => {
    //   const arr = []
    //   for (let i in obj) {
    //     if (is.array(obj[i])) {
    //       Array.prototype.push.apply(arr, obj[i])
    //     }
    //   }
    //   return arr
    // }
  }
  RenderFunc = {
    renderFooter: () => {
      const { send } = this.props
      const { selectedRowKeys } = this.state
      return (
        <div>
          <Button type="primary" ghost className="action-item" onClick={() => send([0])}>发送给全部用户</Button>
          <Button type="primary" className="action-item" onClick={() => send(selectedRowKeys)}>发送给选择的用户</Button>
        </div>
      )
    }
  }
  onInit() {
    this.state = {
      dataSource: [],
      idsObj: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      totalPages: null,
    }
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'userMobile',
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '用户名',
        dataIndex: 'userName',
        key: 'userName'
      }, {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile'
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      }
    ]
  }
  componentDidMount() {
    const { type, ownerId } = this.props
    this.Util.getDataSource(type, ownerId)
  }
  componentWillReceiveProps(nextProps, nextState) {
    // if (nextProps.type !== this.props.type || nextProps.ownerId !== this.props.ownerId) {
    if (nextProps.modalVis !== this.props.modalVis && nextProps.modalVis == true) {
      this.Util.getDataSource(nextProps.type, nextProps.ownerId)
    }
  }
  render() {
    const { cancel, modalVis } = this.props
    const { selectedRowKeys, dataSource, current, totalModels } = this.state
    const { rowSelectionChange, changePage, search, clearSearch } = this.Action
    return (
      <Modal
        title='选择接收消息的用户'
        visible={modalVis}
        onCancel={cancel}
        footer={this.RenderFunc.renderFooter()}
      >
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: rowSelectionChange,
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
      </Modal>
    )
  }
}