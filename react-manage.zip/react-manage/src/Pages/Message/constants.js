// 当前状态
export const NewDraft = 'newDraft' //新建草稿
export const EditDraft = 'editDraft' //编辑草稿
export const ViewMsg = 'viewMsg'//查看已发送消息
export const CopyDraft = 'copyDraft' //复制草稿