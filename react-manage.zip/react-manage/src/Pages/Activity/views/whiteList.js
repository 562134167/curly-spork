/*
 * @Author: miccy 
 * @Date: 2018-02-01 10:22:14 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-19 15:12:28
 * 抽奖白名单
 */
import React, { Component } from 'react'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Table, Popconfirm, Button, message, notification } from 'antd'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { fetch } from '../../../Config/request'
import { requestGet, requestAdd, requestRemove, requestRemoveItems, requestUpdateProperty } from '../../../Util/Request'
import { actionAdd, actionCancel, actionChangePage, actionClearSearch, actionRemove, actionRemoveItems, actionSearch, initGetParams, actionOnShowSizeChange, actionShowTotal, actionEditItems } from '../../../Util/Action'
const addTitle = '新增白名单用户',
  batchAddTitle = '批量新增白名单用户',
  pagingUrl = '/system/whitelist/paging', //获取列表
  addUrl = '/system/whitelist/add', //添加
  batchAddUrl = '/system/whitelist/batchadd',//批量添加
  removeUrl = '/system/whitelist/remove', //删除
  removeItemsUrl = '/system/whitelist/removelist',//批量删除
  updatePropertyUrl = '/system/whitelist/updateproperty'//批量更新属性
class ActivityWhiteList extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      const queryParams = { ...params }
      queryParams.activityId = this.locationState.activityId
      requestGet({ params: queryParams, pagingUrl, context: this })
    },
    // 添加数据
    add: (params) => {
      requestAdd({ params, addUrl, context: this })
    },
    batchAdd: (params) => {
      return fetch(batchAddUrl, params, '', false).then(res => {
        if (res.status == 0) {
          this.setState({
            modalVis: false
          })
          this.Request.get(this.state.getDataParams)
        } else if (res.msg) {
          this.Util.openNotification('批量添加白名单失败', res.msg, 0)
        }
        return res
      })
    },
    // 删除数据
    delete: (params) => {
      requestRemove({ params, removeUrl, context: this })
    },
    deleteItems: (params) => {
      requestRemoveItems({ params, removeItemsUrl, context: this })
    },
    editItems: (params) => {
      requestUpdateProperty({ params, updatePropertyUrl, context: this })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.formItems = this.Util.getFormItem()
      actionAdd({ addTitle, context: this })
    },
    batchAdd: () => {
      this.formItems = this.Util.getBatchFormItem()
      actionAdd({ addTitle: batchAddTitle, context: this })
      this.setState({
        isBatch: true
      })
    },
    // 查
    search: (value) => {
      const mobileRegx = /^1\d{10}$/gi
      if (value.mobilePhone && (!mobileRegx.test(value.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      actionSearch({ value, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const temp = { ...values }
      delete temp.activityName
      temp.activityId = this.locationState.activityId
      if (this.state.isBatch) {
        temp.mobilePhones = temp.mobilePhones.replace(/\s/g, '')
        this.Request.batchAdd(temp)
      } else {
        this.Request.add(temp)
      }
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    // 删
    remove: (id) => {
      actionRemove({ id, context: this })
    },
    // 批量删
    removeItems: () => {
      actionRemoveItems({ context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
    // 点击批量操作按钮
    updateProperty: ({ name, value }) => {
      actionEditItems({ context: this, name, value })
    },
  }
  Util = {
    getFormItem: () => {
      return [
        {
          type: EditType.InputStr,
          label: '活动名称',
          key: 'activityName',
          config: {
            initialValue: this.locationState.name
          },
          itemConfig: {
            disabled: true
          }
        },
        {
          type: EditType.InputStr,
          label: '手机号码',
          key: 'mobilePhone',
          config: {
            rules: [
              { required: true, message: '请输入手机号码' },
              {
                validator: (rule, value, callback) => {
                  if (value && !(/^1\d{10}$/gi.test(value))) {
                    callback('手机号码格式不正确');
                  }
                  callback();
                }
              }
            ]
          }

        }
      ]
    },
    getBatchFormItem: () => {
      return [
        {
          type: EditType.InputStr,
          label: '活动名称',
          key: 'activityName',
          config: {
            initialValue: this.locationState.name
          },
          itemConfig: {
            disabled: true
          }
        },
        {
          type: EditType.Textarea,
          label: '手机号码(以英文逗号隔开)',
          key: 'mobilePhones',
          config: {
            rules: [
              { required: true, message: '请输入手机号码' }
            ]
          }

        }
      ]
    },
    openNotification: (msg, des, duration) => {
      const content = {
        __html: des
      }
      const args = {
        message: msg,
        description: <span dangerouslySetInnerHTML={content}></span>,
        duration: duration,
      };
      notification.error(args);
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.locationState = this.props.location.state || {}
    // const { selectedRowKeys } = this.state;
    const { remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      isBatch: false,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '所属活动',
        dataIndex: 'activityId',
        key: 'activityId',
        render: value => this.locationState.name
      }, {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName'
      }, {
        title: '手机号码',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone'
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '启用' : '禁用'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>

          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = []
    //新建面板表单的初始内容
    this.newItem = {}
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, pageSize } = this.state
    const { add, search, clearSearch, save, cancel, changePage, removeItems, onShowSizeChange, batchAdd, updateProperty } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Button type="primary" onClick={batchAdd} className="action-item">批量新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: '1' },
            { label: '批量禁用', value: '0' }]}
            onClick={(obj) => { updateProperty(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange,
            showTotal: actionShowTotal
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    if (is.undefined(this.locationState.activityId)) {
      this.props.history.replace('/activity/list')
      return;
    }
    this.setState({
      getDataParams: initGetParams
    })

  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default ActivityWhiteList