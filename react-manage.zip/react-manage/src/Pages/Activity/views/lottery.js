/*
 * @Author: miccy 
 * @Date: 2018-01-20 18:00:43 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-19 15:11:39
 * 活动开奖
 */
import React, { Component } from 'react'
import is from 'is_js'
import { EditFormWrapper } from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Button } from 'antd'
import { formatFormData, formatParentIdOptions } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { requestAdd, requestGet } from '../../../Util/Request'

const pagingUrl = '/system/prize/getlist' //获取列表
// const 
const addUrl = '/system/activity/run' //添加

class ActivityLottery extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取奖品列表数据
    get: (params) => {
      const queryParams = { ...params }
      queryParams.activityId = this.locationState.activityId
      requestGet({
        params: queryParams, pagingUrl, context: this, successCallback: (res) => {
          this.setState({
            prizeOptions: formatParentIdOptions({ options: res.models, valueKey: 'id', labelKey: 'name', hasDefaultOption: false })
          })
        }
      })
    },
    // 确定开奖
    add: (params) => {
      requestAdd({
        params, addUrl, context: this, successCallback: (res) => {
          this.props.history.replace('/activity/lotteryRecord', { lotteryId: res.model, activityId: this.locationState.activityId, name: this.locationState.name })
        }
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.editForm.props.form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          // 保存表单数据
          const temp = { ...values }
          delete temp.activityName
          temp.activityId = this.locationState.activityId
          this.Request.add(formatFormData(temp, this.formItems));
        }
      })
    },
    back: () => {
      this.props.history.replace('/activity/list')
    }
  }
  Util = {
    updateFormItem: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
        fn(formItem)
      }
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.locationState = this.props.location.state || {}
    //将url的查询参数转换成查询对象
    this.state = {
      modal: {
        status: {
          value: '1'
        }
      },
      prizeOptions: []
    }
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '活动名称',
        key: 'activityName',
        itemConfig: {
          disabled: true,
        }
      }, {
        type: EditType.Select,
        label: '奖品',
        key: 'prizeId',
        config: {
          rules: [{ required: true, message: '请选择奖品' }],
        },
        itemConfig: {
          options: this.state.prizeOptions
        }
      }, {
        type: EditType.InputNum,
        label: '本次开奖人数',
        key: 'count',
        config: {
          rules: [
            { required: true, message: '请输入本次开奖人数' }
          ],
          initialValue: '1'
        },
      }, {
        type: EditType.InputNum,
        label: '开奖时间(单位秒)',
        key: 'time',
        config: {
          rules: [
            { required: true, message: '请输入开奖时间' }
          ]
        },
      }, {
        type: EditType.Select,
        label: '状态',
        key: 'status',
        itemConfig: {
          options: [
            { value: 1, label: '正常' },
            { value: 0, label: '不正常' },
          ]
        },
        config: {
          rules: [
            { required: true, message: '请选择状态' }
          ]
        },
      }
    ]
  }
  render() {
    const { modal } = this.state
    const { add, back } = this.Action
    return (
      <div>
        <EditFormWrapper wrappedComponentRef={(inst) => this.editForm = inst} modal={modal} formItems={this.formItems} />
        <div style={{ textAlign: 'center' }}>
          <Button type="danger" onClick={back} className="action-item">取消</Button>
          <Button type="primary" onClick={add} className="action-item">确定开奖</Button>
        </div>
      </div>
    )
  }
  componentDidMount() {
    if (is.undefined(this.locationState.activityId)) {
      this.props.history.replace('/activity/list')
      return;
    }
    this.editForm.props.form.setFieldsValue({
      'activityName': this.locationState.name
    })
    // todo: 请求获取奖品列表
    this.Request.get()
  }

  componentWillUpdate(nextProps, nextState) {

    const { updateFormItem } = this.Util
    // 监听广告位下拉框
    updateFormItem(this.state.prizeOptions, nextState.prizeOptions, 'prizeId', (formItem) => {
      if (hasAttr(formItem, ['itemConfig', 'options'])) {
        formItem.itemConfig.options = nextState.prizeOptions
      }
    })
  }
}
export default ActivityLottery