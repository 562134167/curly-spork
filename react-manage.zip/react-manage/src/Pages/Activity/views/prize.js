import React, { Component } from 'react'
import is from 'is_js'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import Editor from '../../../Common/Editor'
import { Card, Table, Popconfirm, Button } from 'antd'
import { formateEditData } from '../../../Util/reactUtil'
import { requestGet, requestAdd, requestUpdate, requestRemove } from '../../../Util/Request'
import { actionAdd, actionEdit, actionCancel, actionChangePage, actionRemove, actionSave, initGetParams, actionOnShowSizeChange } from '../../../Util/Action'
const addTitle = '新建奖品',
  editTitle = '编辑奖品',
  LinkPath = {
    DefaultList: '/activity/defaultList',
  },
  newItem = {
    status: 1
  }
const pagingUrl = '/system/prize/paging', //获取列表
  addUrl = '/system/prize/add', //添加
  updateUrl = '/system/prize/update', //修改
  removeUrl = '/system/prize/remove', //删除
  uploadFileUrl = '/system/file/upload'; //上传图片
class ActivityPrize extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      const queryParams = { ...params }
      queryParams.activityId = this.locationState.activityId
      requestGet({ params: queryParams, pagingUrl, context: this })
    },
    // 添加数据
    add: (params) => {
      requestAdd({ params, addUrl, context: this })
    },
    // 修改数据
    edit: (params) => {
      requestUpdate({ params, updateUrl, context: this })
    },
    // 删除数据
    delete: (params) => {
      requestRemove({ params, removeUrl, context: this })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      actionAdd({ addTitle, context: this })
    },
    // 点击修改按钮
    edit: (record, index) => {
      actionEdit({ record, editTitle, context: this })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const temp = { ...values }
      temp.activityId = this.locationState.activityId
      actionSave({ context: this, values: temp })
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    // 删
    remove: (id) => {
      actionRemove({ id, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
    // 点击根据类型跳转页面
    link: (record, linkPath) => {
      this.props.history.push(linkPath, { prizeId: record.id, activityId: this.locationState.activityId, prizeName: record.name, activityName: this.locationState.name })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.locationState = this.props.location.state || {}
    const { edit, remove, link } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '活动名称',
        dataIndex: 'activityName',
        key: 'activityName',
        render: value => {
          return this.locationState.name
        }
      }, {
        title: '奖项名称',
        dataIndex: 'name',
        key: 'name',
      }, {
        title: '奖品名称',
        dataIndex: 'prizeName',
        key: 'prizeName',
      }, {
        title: '奖品图片',
        dataIndex: 'image',
        key: 'image',
        render: value => {
          if (value) {
            return <img width="50" src={value} />
          }
        }
      }, {
        title: '总奖品数量',
        dataIndex: 'count',
        key: 'count'
      }, {
        title: '已开奖数量',
        dataIndex: 'awardedCount',
        key: 'awardedCount',
        render: value => value || 0
      }, {
        title: '奖品排序',
        dataIndex: 'num',
        key: 'num'
      }, {
        title: '开奖状态',
        dataIndex: 'isOpen',
        key: 'isOpen',
        render: value => value == 1 ? '已开奖' : '未开奖'
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          record.isOpen == 1 ? null : (<span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
            {/* <Button type="primary" className="action-item" onClick={() => { link(record, LinkPath.BlackList) }}>设置黑名单</Button> */}
            <Button type="primary" className="action-item" onClick={() => { link(record, LinkPath.DefaultList) }}>设置内定名单</Button>
          </span>)
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '奖项名称',
        key: 'name',
        config: {
          rules: [{ required: true, message: '请输入奖项名称' }]
        }
      }, {
        type: EditType.InputStr,
        label: '奖品名称',
        key: 'prizeName',
        config: {
          rules: [{ required: true, message: '请输入奖品名称' }]
        }
      }, {
        type: EditType.Image,
        label: '奖品图片',
        key: 'image',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            if (Array.isArray(e)) {
              return e;
            }
            return e && e.fileList;
          },
          rules: [
            { required: true, message: '请上传奖品图片' }
          ]
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          tip: '奖品图片',
          accept: '.jpg, .png, .bmp, .jpeg',
          name: 'files',
        },
        isImageAutoHandle: true,
        isShowbtn: (props) => {
          if (props.form.getFieldValue('image') && props.form.getFieldValue('image').length) {
            return false
          }
          return true
        }
      }, {
        type: EditType.InputNum,
        label: '总奖品数量',
        key: 'count',
        config: {
          rules: [
            { required: true, message: '请输入总奖品数量' }
          ]
        },
      }, {
        type: EditType.InputNum,
        label: '奖品排序',
        key: 'num',
        config: {
          rules: [
            { required: true, message: '请输入奖品排序' }
          ]
        },
      }, {
        type: EditType.Select,
        label: '状态',
        key: 'status',
        itemConfig: {
          options: [
            { value: 1, label: '正常' },
            { value: 0, label: '不正常' },
          ]
        },
        config: {
          rules: [
            { required: true, message: '请选择状态' }
          ]
        },
      }, {
        render: Editor,
        label: '奖品详情',
        key: 'content',
        config: {
          rules: [
            { required: true, message: '请输入奖品详情' }
          ]
        },
      }
    ]
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, current, totalModels, pageSize } = this.state
    const { add, save, cancel, changePage, onShowSizeChange } = this.Action
    return (
      <div>

        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
        </Card>
        <Table
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    if (is.undefined(this.locationState.activityId)) {
      this.props.history.replace('/activity/list')
      return;
    }
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default ActivityPrize