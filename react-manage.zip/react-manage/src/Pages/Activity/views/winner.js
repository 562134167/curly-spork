/*
 * @Author: miccy 
 * @Date: 2018-01-20 18:51:33 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-19 15:10:48
 * 中奖记录
 */
import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { requestGet, requestUpdateProperty } from '../../../Util/Request'
import { actionChangePage, actionSearch, actionClearSearch, actionEditItems, initGetParams, actionOnShowSizeChange } from '../../../Util/Action'

const pagingUrl = '/system/winner/paging', //获取列表
  updatePropertyUrl = '/system/winner/updateproperty'; //批量修改
class ActivityWinner extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      const queryParams = { ...params }
      queryParams.activityId = this.locationState.activityId
      queryParams.lotteryId = this.locationState.lotteryId
      requestGet({ params: queryParams, pagingUrl, context: this })
    },
    // 批量更新属性
    editItems: (params) => {
      requestUpdateProperty({ params, updatePropertyUrl, context: this })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
    // 批量无效
    editItems: () => {
      actionEditItems({ context: this, name: 'isEffective', value: 0 })
    },
    // 查
    search: (value) => {
      const mobileRegx = /^1\d{10}$/gi
      if (value.mobilePhone && (!mobileRegx.test(value.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      actionSearch({ value, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.locationState = this.props.location.state || {}
    this.state = {
      dataSource: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
      selectedRowKeys: []
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '所属活动',
        dataIndex: 'activityId',
        key: 'activityId',
        render: value => this.locationState.name
      }, {
        title: '奖品名称',
        dataIndex: 'prizeName',
        key: 'prizeName',
        render: (value, record) => {
          return `【${record.name}】${value}`
        }
      }, {
        title: '手机号码',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone'
      }, {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName'
      }, {
        title: '是否有效',
        dataIndex: 'isEffective',
        key: 'isEffective',
        render: value => value == 1 ? '有效' : '无效'
      }, {
        title: '中奖时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      }
    ]
  }
  render() {
    const { dataSource, current, totalModels, pageSize, selectedRowKeys } = this.state
    const { changePage, clearSearch, search, onShowSizeChange, editItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Popconfirm title="确定要失效吗?" onConfirm={editItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量失效</Button>
          </Popconfirm>

        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    if (is.undefined(this.locationState.activityId)) {
      this.props.history.replace('/activity/list')
      return;
    }
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default ActivityWinner