/*
 * @Author: miccy 
 * @Date: 2018-01-24 11:34:31 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2018-04-27 16:19:35
 * 开奖记录
 */

import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import { Table, Button } from 'antd'
import { requestGet } from '../../../Util/Request'
import { actionChangePage, initGetParams, actionOnShowSizeChange } from '../../../Util/Action'

const pagingUrl = '/system/lottery/paging' //获取列表
const getPrizeUrl = '/system/prize/getlist' //获取奖品列表
class ActivityLotteryRecord extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      const queryParams = { ...params }
      queryParams.activityId = this.locationState.activityId
      requestGet({ params: queryParams, pagingUrl, context: this })
    },
    getPrize: (params) => {
      const queryParams = { ...params }
      queryParams.activityId = this.locationState.activityId
      requestGet({
        params: queryParams, pagingUrl: getPrizeUrl, context: this, successCallback: (res) => {
          this.setState({
            prizeOptions: res.models
          })
        }
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
    view: (record) => {
      this.props.history.push('/activity/winner', { lotteryId: record.id, activityId: this.locationState.activityId, name: this.locationState.name })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {    
    this.locationState = this.props.location.state || {}
    const { view } = this.Action    
    this.state = {
      dataSource: [],
      prizeOptions: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
      selectedRowKeys: [],
    }

    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '所属活动',
        dataIndex: 'activityId',
        key: 'activityId',
        render: value => this.locationState.name
      }, {
        title: '奖项名-奖品名',
        dataIndex: 'prizeId',
        key: 'prizeId',
        render: value => {
          const options = this.state.prizeOptions.filter(item => item.id == value)
          if (!is.empty(options)) {
            return `${options[0].name}--${options[0].prizeName}`
          }
        }
      }, {
        title: '本次开奖人数',
        dataIndex: 'count',
        key: 'count',
        render: value => value || 0
      }, {
        title: '开奖时间',
        dataIndex: 'time',
        key: 'time',
        render: value => value || 0 + '秒'
      }, {
        title: '开奖时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        // width: 250,
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => view(record)} > 查看</Button>
          </span>
        )
      }
    ]
  }
  render() {
    const { dataSource, current, totalModels, pageSize } = this.state
    const { changePage, onShowSizeChange } = this.Action
    return (
      <div>
        <Table
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    if (is.undefined(this.locationState.activityId)) {
      this.props.history.replace('/activity/list')
      return;
    }
    this.Request.getPrize()
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default ActivityLotteryRecord