import React, { Component } from 'react'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { requestGet, requestAdd, requestRemove, requestRemoveItems } from '../../../Util/Request'
import { actionAdd, actionCancel, actionChangePage, actionClearSearch, actionRemove, actionRemoveItems, actionSearch, actionSave, initGetParams, actionOnShowSizeChange } from '../../../Util/Action'
const addTitle = '新增内定用户',
  pagingUrl = '/system/prizedesignated/paging', //获取列表
  addUrl = '/system/prizedesignated/add', //添加
  removeUrl = '/system/prizedesignated/remove', //删除
  removeItemsUrl = '/system/prizedesignated/removelist'; //批量删除
class ActivityDefaultList extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      const queryParams = { ...params }
      queryParams.activityId = this.locationState.activityId
      queryParams.prizeId = this.locationState.prizeId
      requestGet({ params: queryParams, pagingUrl, context: this })
    },
    // 添加数据
    add: (params) => {
      requestAdd({ params, addUrl, context: this })
    },
    // 删除数据
    delete: (params) => {
      requestRemove({ params, removeUrl, context: this })
    },
    deleteItems: (params) => {
      requestRemoveItems({ params, removeItemsUrl, context: this })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      actionAdd({ addTitle, context: this })
    },
    // 查
    search: (value) => {
      const mobileRegx = /^1\d{10}$/gi
      if (value.mobilePhone && (!mobileRegx.test(value.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      actionSearch({ value, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const temp = { ...values }
      delete temp.activityName
      delete temp.prizeName
      temp.activityId = this.locationState.activityId
      temp.prizeId = this.locationState.prizeId
      actionSave({ context: this, values: temp })
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    // 删
    remove: (id) => {
      actionRemove({ id, context: this })
    },
    // 批量删
    removeItems: () => {
      actionRemoveItems({ context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.locationState = this.props.location.state || {}
    const { remove } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '所属活动',
        dataIndex: 'activityId',
        key: 'activityId',
        render: value => this.locationState.activityName
      }, {
        title: '奖项名称',
        dataIndex: 'prizeId',
        key: 'prizeId',
        render: value => this.locationState.prizeName
      }, {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName'
      }, {
        title: '手机号码',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>

          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '活动名称',
        key: 'activityName',
        config: {
          initialValue: this.locationState.activityName
        },
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        label: '奖项名称',
        key: 'prizeName',
        config: {
          initialValue: this.locationState.prizeName
        },
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        label: '手机号码',
        key: 'mobilePhone',
        config: {
          rules: [
            { required: true, message: '请输入手机号码' },
            {
              validator: (rule, value, callback) => {
                if (value && !(/^1\d{10}$/gi.test(value))) {
                  callback('手机号码格式不正确');
                }
                callback();
              }
            }
          ]
        }

      }
    ]
    //新建面板表单的初始内容
    this.newItem = {}
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, pageSize } = this.state
    const { add, search, clearSearch, save, cancel, changePage, removeItems, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <Popconfirm title="确定要删除吗?" onConfirm={removeItems} okText="是" cancelText="否">
            <Button type="danger" className="action-item" disabled={!selectedRowKeys.length}> 批量删除</Button>
          </Popconfirm>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    if (is.undefined(this.locationState.prizeId)) {
      this.props.history.replace('/activity/list')
      return;
    }
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default ActivityDefaultList