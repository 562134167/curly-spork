import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
// import './index.less'

const loadList = (cd) => {
  return import('./list.js')
}
const loadPrize = (cd) => {
  return import('./prize.js')
}
const loadLottery = (cd) => {
  return import('./lottery.js')
}
const loadLotteryRecord = (cd) => {
  return import('./lotteryRecord.js')
}
const loadWinner = (cd) => {
  return import('./winner.js')
}
const loadBlackList = (cd) => {
  return import('./blackList.js')
}
const loadDefaultList = (cd) => {
  return import('./defaultList.js')
}
const loadParticipant = (cd) => {
  return import('./participant.js')
}
const loadLotteryParticipant = (cd) => {
  return import('./lotteryParticipant.js')
}
const loadFeeling = (cd) => {
  return import('./feeling.js')
}
const loadWhiteList = (cd) => {
  return import('./whiteList.js')
}
const List = getComponent(loadList)
const Prize = getComponent(loadPrize)
const Lottery = getComponent(loadLottery)
const LotteryRecord = getComponent(loadLotteryRecord)
const Winner = getComponent(loadWinner)
const BlackList = getComponent(loadBlackList)
const DefaultList = getComponent(loadDefaultList)
const Participant = getComponent(loadParticipant)
const LotteryParticipant = getComponent(loadLotteryParticipant)
const Feeling = getComponent(loadFeeling)
const WhiteList = getComponent(loadWhiteList)
export default class Activity extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/activity"
          exact render={() => <Redirect to="/activity/list" />}
        />
        <Route path='/activity/list' render={(props) => <List {...props} />} />
        <Route path='/activity/prize' render={(props) => <Prize {...props} />} />
        <Route path='/activity/lottery' render={(props) => <Lottery {...props} />} />
        <Route path='/activity/lotteryRecord' render={(props) => <LotteryRecord {...props} />} />
        <Route path='/activity/winner' render={(props) => <Winner {...props} />} />
        <Route path='/activity/blackList' render={(props) => <BlackList {...props} />} />
        <Route path='/activity/defaultList' render={(props) => <DefaultList {...props} />} />
        <Route path='/activity/participant' render={(props) => <Participant {...props} />} />
        <Route path='/activity/lotteryParticipant' render={(props) => <LotteryParticipant {...props} />} />
        <Route path='/activity/feeling' render={(props) => <Feeling {...props} />} />
        <Route path='/activity/whiteList' render={(props) => <WhiteList {...props} />} />
        {/*<Route path='/activity/recharge' render={(props) => <Recharge {...props} />} /> */}
      </Switch>
    )
  }
}