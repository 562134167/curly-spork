/*
 * @Author: miccy 
 * @Date: 2018-01-20 18:51:33 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-19 15:11:47
 * 中奖记录
 */
import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Table, message } from 'antd'
import { requestGet } from '../../../Util/Request'
import { actionChangePage, actionSearch, actionClearSearch, initGetParams, actionOnShowSizeChange } from '../../../Util/Action'

const pagingUrl = '/system/lotteryparticipants/paging' //获取列表
class ActivityLotteryParticipant extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      const queryParams = { ...params }
      queryParams.activityId = this.locationState.activityId
      requestGet({ params: queryParams, pagingUrl, context: this })
    }
  }

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
    // 查
    search: (value) => {
      const mobileRegx = /^1\d{10}$/gi
      if (value.mobilePhone && (!mobileRegx.test(value.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      actionSearch({ value, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
  }

  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.locationState = this.props.location.state || {}
    this.state = {
      dataSource: [],
      prizeOptions: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
      selectedRowKeys: []
    }

    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone'
        }
      ]
    }

    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '所属活动',
        dataIndex: 'activityId',
        key: 'activityId',
        render: value => this.locationState.name
      }, {
        title: '手机号码',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone'
      }, {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName'
      }, {
        title: '参与时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      }
    ]
  }

  render() {
    const { dataSource, current, totalModels, pageSize } = this.state
    const { changePage, clearSearch, search, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          scroll={{ x: 1500 }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange
          }}
        />

      </div>
    )
  }

  componentDidMount() {
    if (is.undefined(this.locationState.activityId)) {
      this.props.history.replace('/activity/list')
      return;
    }
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default ActivityLotteryParticipant