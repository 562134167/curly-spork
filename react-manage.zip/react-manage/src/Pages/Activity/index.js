import view from './views'
export { view } 