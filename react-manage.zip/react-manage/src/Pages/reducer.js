import * as actionType from './constants' //引入action类型常量名
// 初始化state数据
const initialState = {
  loading: false,
  tip: '',
  dictList: []
}
export default function index(state = initialState, action) {
  switch (action.type) {
    case actionType.SHOW_LOADING:
      return { ...state, loading: true, tip: action.tip || '' };
    case actionType.HIDE_LOADING:
      return { ...state, loading: false };
    case actionType.SET_DICT_LIST:
      return { ...state, dictList: action.list || [] }
    default:
      return state;
  }
}