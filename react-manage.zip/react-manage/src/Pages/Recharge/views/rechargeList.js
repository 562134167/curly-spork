/*
 * @Author: miccy 
 * @Date: 2018-04-23 10:46:57 
 * @Last Modified by:   miccy 
 * @Last Modified time: 2018-04-23 10:46:57 
 * 快钱充值记录列表页
 */
import React, { Component } from 'react'
import moment from 'moment'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Table, message } from 'antd'
import { formatParentIdOptions, toMoney } from '../../../Util/reactUtil'
import { requestGet } from '../../../Util/Request'
import { actionChangePage, actionClearSearch, actionSearch, initGetParams, actionOnShowSizeChange } from '../../../Util/Action'
import { getQueryObj, hasAttr } from '../../../Util'

const pagingUrl = '/system/recharge/getRechargeList' //获取列表

const getRechargeStatusUrl = '/system/status/getRechargeStatusList'//获取充值状态

class RechargeList extends Component {

  constructor(props) {
    super(props)

    this.onInit()
  }

  // 服务器请求
  Request = {

    // 获取数据
    get: (params) => {
      const queryObj = getQueryObj(this.props.location.search) || {}
      requestGet({ params: { ...params, ...queryObj }, pagingUrl, context: this }).then(res => {
        this.Request.getRechargeStatus();
      })

    },

    getRechargeStatus: (params) => {
      requestGet({
        params, pagingUrl: getRechargeStatusUrl, context: this, successCallback: (res) => {
          if (res.status == 0) {
            this.setState({
              rechargeStatusOptions: formatParentIdOptions({
                options: res.models,
                valueKey: 'rechargeStatus',
                labelKey: 'rechargeStatusStr',
                hasDefaultOption: false
              })
            })
          }
        }
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {

    // 查
    search: (value) => {
      const mobileRegx = /^1\d{10}$/gi
      if (value.mobilePhone && (!mobileRegx.test(value.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      actionSearch({ value, context: this })
    },

    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },

    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },

    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    }
  }
  Util = {
    // 更新模态框表单的配置
    updateMetaData: (value, nextValue, keyValue, fn) => {
      if (nextValue !== value) {
        const metadata = this.metadata.conditions.filter((item, index) => item.id === keyValue)[0]
        fn(metadata)
      }
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.state = {
      dataSource: [],
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
      rechargeStatusOptions: []
    }

    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'userMobile'
        }, {
          type: SearchType.String,
          label: '快钱流水号',
          id: 'serialNumber'
        }, {
          type: SearchType.Select,
          label: '交易状态',
          id: 'rechargeStatus',
          dataSource: this.state.rechargeStatusOptions
        }
      ]
    }

    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '真实姓名',
        dataIndex: 'userRealName',
        key: 'userRealName'
      }, {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile'
      }, {
        title: '订单金额',
        dataIndex: 'amount',
        key: 'amount',
        render: value => toMoney(value)
      }, {
        title: '交易流水号',
        dataIndex: 'serialNumber',
        key: 'serialNumber',
      }, {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '完成时间',
        dataIndex: 'payTime',
        key: 'payTime',
        render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '订单状态',
        dataIndex: 'rechargeStatusStr',
        key: 'rechargeStatusStr'
      },
      // {
      //   title: '卡类型',
      //   dataIndex: 'isBindCardStr',
      //   key: 'isBindCardStr',
      // }, {
      //   title: '银行卡号',
      //   dataIndex: 'isBindCardStr',
      //   key: 'isBindCardStr',
      // }, {
      //   title: '银行卡预留手机号码',
      //   dataIndex: 'isBindCardStr',
      //   key: 'isBindCardStr',
      // }, {
      //   title: '发卡机构名称',
      //   dataIndex: 'isBindCardStr',
      //   key: 'isBindCardStr',
      // }, {
      //   title: '交易失败错误原因',
      //   dataIndex: 'isBindCardStr',
      //   key: 'isBindCardStr',
      // }, {
      //   title: '终端号',
      //   dataIndex: 'isBindCardStr',
      //   key: 'isBindCardStr',
      // },
      {
        title: '操作人',
        dataIndex: 'createUsrStr',
        key: 'createUsrStr',
      }
    ]

  }

  render() {
    const { dataSource, selectedRowKeys, current, totalModels, pageSize } = this.state
    const { search, clearSearch, changePage, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })

  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, rechargeStatusOptions } = this.state
    const { get } = this.Request
    // console.log(nextState.selectedRowKeys)
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
    const { updateMetaData } = this.Util
    // 监听充值状态下拉框
    updateMetaData(rechargeStatusOptions, nextState.rechargeStatusOptions, 'rechargeStatus', (metadata) => {
      console.log(metadata)
      if (hasAttr(metadata, 'dataSource')) {
        metadata.dataSource = nextState.rechargeStatusOptions
      }
    })
  }
}
export default RechargeList