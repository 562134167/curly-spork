/*
 * @Author: miccy 
 * @Date: 2018-04-23 10:46:30 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:10:49
 * 快钱充值用户列表页
 */
import React, { Component } from 'react'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import TwoDecimals from '../../../Common/twoDecimals'
import OrderModal from './component/OrderModal'
import { Table, Button, message } from 'antd'
import { requestGet, requestAdd } from '../../../Util/Request'
import { actionCancel, actionChangePage, actionClearSearch, actionSearch, initGetParams, actionOnShowSizeChange } from '../../../Util/Action'
const addTitle = '输入充值金额'
const viewTitle = '查看订单信息'

const pagingUrl = '/system/recharge/getUserList' //获取列表
const addUrl = '/system/recharge/createOrder' //添加
class UserList extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({ params, pagingUrl, context: this })
    },
    // 添加数据
    add: (params) => {
      requestAdd({
        params, addUrl, context: this, successCallback: (res) => {
          if (res.status == 0) {
            const { userRealName, userMobile } = this.state.record
            this.setState({
              modalVis: false,
              editId: null,
              orderModalVis: true,
              title: viewTitle,
              order: {
                ...res.model,
                userRealName,
                userMobile
              }
            }, () => {
              this.setState({
                record: {}
              })
            })
          }
        }
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击充值按钮
    recharge: (record) => {
      this.setState({
        editId: record.userId,
        modalVis: true,
        modal: this.newItem,
        title: addTitle,
        record: record
      })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const mobileRegx = /^1\d{10}$/gi
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      actionSearch({ value: queryParams, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const temp = { ...values };
      temp.userId = this.state.editId;
      this.Request.add(temp);
    },
    cancel: () => {
      actionCancel({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    },
    view: (record) => {
      this.props.history.push('/recharge/rechargeList?userMobile=' + record.userMobile)
    },
    orderCancel: () => {
      this.setState({
        orderModalVis: false
      })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { recharge, view } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      orderModalVis: false,
      order: {},
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 20,
      record: {}
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'userMobile'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 60,
        render: (text, record, index) => {
          return (this.state.current - 1) * (this.state.pageSize || 20) + (index + 1)
        }
      }, {
        title: '真实姓名',
        dataIndex: 'userRealName',
        key: 'userRealName'
      }, {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile'
      }, {
        title: '资金账号',
        dataIndex: 'isOpenCapitalStr',
        key: 'isOpenCapitalStr',
      }, {
        title: '实名审核状态',
        dataIndex: 'isRealNameStr',
        key: 'isRealNameStr',
      }, {
        title: '激活银行卡',
        dataIndex: 'isBindCardStr',
        key: 'isBindCardStr',
      },
      {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { recharge(record, index) }}>快钱充值</Button>
          </span>
        )
      }, {
        title: '订单',
        dataIndex: 'order',
        key: 'order',
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { view(record, index) }}>查看</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = [
      {
        render: TwoDecimals,
        type: EditType.InputNum,
        key: 'amount',
        label: '充值金额',
        config: {
          rules: [
            { required: true, message: '请填写要充值的金额数目' },
            {
              validator: (rule, value, callback) => {
                if (value && value <= 0) {
                  callback('充值的金额必须大于0');
                }
                callback();
              }
            }
          ],
        },
        isInputNum: true
      }
    ]
    //新建面板表单的初始内容
    this.newItem = {}
  }

  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels, pageSize, orderModalVis, order } = this.state
    const { search, clearSearch, save, cancel, changePage, orderCancel, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
        {orderModalVis ? (<OrderModal
          onCancel={orderCancel}
          modalVis={orderModalVis}
          order={order}
        />) : null}
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default UserList