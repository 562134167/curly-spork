import React, { PureComponent } from 'react'
import moment from 'moment'
import { Modal, Button, Row, Col } from 'antd'

export default class OrderModal extends PureComponent {
  RenderFunc = {
    renderOrder: (order) => {
      return (
        <Row className="order">
          <Col offset={3} span={18}>
            <Row>
              <Col span={6}>订单号：</Col>
              <Col span={18}>{order.serialNumber}</Col>
            </Row>
            <Row>
              <Col span={6}>姓名：</Col>
              <Col span={18}>{order.userRealName}</Col>
            </Row>
            <Row>
              <Col span={6}>手机号码：</Col>
              <Col span={18}>{order.userMobile}</Col>
            </Row>
            <Row>
              <Col span={6}>充值金额：</Col>
              <Col span={18}>{(isNaN(order.amount) ? 0 : order.amount / 100) + '元'}</Col>
            </Row>
            <Row>
              <Col span={6}>创建时间：</Col>
              <Col span={18}>{moment().format('YYYY-MM-DD HH:mm:ss')}</Col>
            </Row>
          </Col>
        </Row>
      )
    }
  }
  render() {
    const { onCancel, modalVis, order } = this.props
    return (
      <Modal
        visible={modalVis}
        onCancel={onCancel}
        footer={<Button onClick={onCancel}>关闭</Button>}
        title="订单信息"
      >
        {this.RenderFunc.renderOrder(order)}
      </Modal>
    )
  }
}