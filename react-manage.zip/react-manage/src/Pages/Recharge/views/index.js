import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
import './index.less'
const loadUserList = (cb) => {
  return import('./userList.js')
}
const loadRechargeList = (cb) => {
  return import('./rechargeList.js')
}

const UserList = getComponent(loadUserList)
const RechargeList = getComponent(loadRechargeList)

export default class Recharge extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/recharge"
          exact render={() => <Redirect to="/recharge/source" />}
        />
        <Route path="/recharge/userList" render={(props) => <UserList {...props} />} />
        <Route path="/recharge/rechargeList" render={(props) => <RechargeList {...props} />} />
      </Switch>
    )
  }
}