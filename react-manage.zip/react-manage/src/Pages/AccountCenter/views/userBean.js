import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Table, message } from 'antd'
import { formatData, handleEndTime, handleStartTime } from '../../../Util/reactUtil'
import { getFetch } from '../../../Config/request'
import { getQueryObj } from '../../../Util'
const initGetParams = {
  pageIndex: 1,
}

const pagingUrl = '/system/detail/consumptionDetail'
class UserBean extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {

      const queryObj = getQueryObj(this.props.location.search) || {}
      return getFetch(pagingUrl, { ...params, ...queryObj }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models, 'orderId')
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
  }
  // 点击按钮的操作（搜索、清空搜索、点击页数按钮）
  Action = {

    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }

      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      delete queryParams.createtime

      const params = { ...getDataParams, ...queryParams }

      this.setState({
        getDataParams: params
      })
    },

    // 清空查找条件
    clearSearch: (params) => {
      this.setState({
        getDataParams: initGetParams,
      })
    },
    //点击页数按钮
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.state = {
      dataSource: formatData([]),
      modal: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '手机号码',
          id: 'mobilePhone',
          type: SearchType.String,
        }, {
          label: '操作时间',
          id: 'createtime',
          type: SearchType.DateRange,
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '订单号',
        dataIndex: 'orderId',
        key: 'orderId'
      }, {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName',
      }, {
        title: '手机号码',
        dataIndex: 'mobilehone',
        key: 'mobilehone',
      }, {
        title: '消费豆数量',
        dataIndex: 'beanNum',
        key: 'beanNum',
      }, {
        title: '消费豆总额',
        dataIndex: 'beanTotal',
        key: 'beanTotal',
      }, {
        title: '操作时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: (value) => { return value && moment(value).format('YYYY/MM/DD') }
      },
    ];
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels, } = this.state
    const { search, clearSearch, changePage } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}

export default UserBean