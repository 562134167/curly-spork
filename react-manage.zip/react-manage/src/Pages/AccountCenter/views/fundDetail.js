import React, { Component } from 'react'
import is from 'is_js'
import moment from 'moment'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, Button, message, Popconfirm } from 'antd'
import { formatData, formateEditData, flattenObj, handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { getQueryObj, arrayToObject } from '../../../Util'
import { getFetch, fetch } from '../../../Config/request'
import TwoDecimals from '../../../Common/twoDecimals'

const title = '查看详情',
  initGetParams = {
    pageIndex: 1,
  },

  pagingUrl = '/system/funddetails/paging',
  unfreezeUrl = '/system/funddetails/thawing',
  getTradeCodeUrl = '/system/enums/tradecode';//获取交易类型

export default class FundDetail extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {

      const queryObj = getQueryObj(this.props.location.search) || {}
      return getFetch(pagingUrl, { ...params, ...queryObj }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['fundDetails']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })

          !this.state.tradeCodeOptions.length && this.Request.getTradeCode();
        }
        return res
      })
    },
    unfreeze: (params) => {
      return fetch(unfreezeUrl, params).then(res => {
        if (res.status == 0) {
          this.Request.get(this.state.getDataParams)
        }
        return res
      })
    },
    getTradeCode: (params) => {
      getFetch(getTradeCodeUrl).then(res => {
        if (is.array(res)) {
          const { tradeCodeOptions } = this.state
          res.forEach(item => {
            tradeCodeOptions.push({
              label: item.name,
              value: item.value
            })
          })
          this.setState({
            tradeCodeEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
            tradeCodeOptions
          })
        }
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }

      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击修改按钮
    view: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        // editId: obj.id,
        modalVis: true,
        modal: modal,
        title: title
      })
    },
    unfreeze: (id) => {
      this.Request.unfreeze({
        id: id
      })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { view, unfreeze } = this.Action
    this.state = {
      title: title,
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      tradeCodeOptions: [],
      tradeCodeEnum: {}
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone',
        }, {
          type: SearchType.Select,
          label: '交易类型',
          id: 'tradeCode',
          dataSource: this.state.tradeCodeOptions
        }, {
          type: SearchType.String,
          label: '订单编号',
          id: 'orderNo'
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName',
      }, {
        title: '用户名',
        dataIndex: 'userName',
        key: 'userName',
      }, {
        title: '手机号',
        dataIndex: 'userMobile',
        key: 'userMobile'
      }, {
        title: '订单编号',
        dataIndex: 'orderNo',
        key: 'orderNo'
      }, {
        title: '交易类型',
        key: 'tradeCode',
        dataIndex: 'tradeCode',
        render: value => this.state.tradeCodeEnum[value] || '未知'
      }, {
        title: '金额',
        dataIndex: 'capitalBalance',
        key: 'capitalBalance',
        render: value => toMoney(value)
      }, {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      },
      {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            {(record.capitalType == 53 && record.isFrozen == 1) ?
              (<Popconfirm
                title="确定要解除冻结吗?"
                onConfirm={() => unfreeze(record.id)}
                okText="是"
                cancelText="否">
                <Button type="danger" className="action-item"> 解除冻结</Button>
              </Popconfirm>) : null}
            <Button type="primary" className="action-item" onClick={() => { view(record, index) }}>查看详情</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        key: 'userName',
        label: '用户名',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        key: 'userMobile',
        label: '手机号码',
        itemConfig: {
          disabled: true
        }
      }, {
        render: TwoDecimals,
        type: EditType.InputNum,
        key: 'capitalBalance',
        label: '金额',
        itemConfig: {
          disabled: true
        },
        isInputNum: true,
      }, {
        type: EditType.InputStr,
        key: 'orderNo',
        label: '订单编号',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.Select,
        key: 'capitalType',
        label: '资金明细类型',
        itemConfig: {
          disabled: true,
          options: this.state.tradeCodeOptions
        }
      }, {
        type: EditType.Switch,
        key: 'isAllowCash',
        label: '是否允许提现',
        config: {
          valuePropName: 'checked'
        },
        itemConfig: {
          disabled: true
        },
        isSwitchNum: true
      }, {
        type: EditType.Switch,
        key: 'isFrozen',
        label: '是否冻结资金',
        config: {
          valuePropName: 'checked'
        },
        itemConfig: {
          disabled: true
        },
        isSwitchNum: true
      }, {
        type: EditType.DatePicker,
        key: 'createTime',
        label: '操作时间',
        itemConfig: {
          disabled: true,
          format: 'YYYY-MM-DD HH:mm:ss'
        },
      }, {
        type: EditType.Select,
        key: 'status',
        label: '状态',
        itemConfig: {
          disabled: true,
          options: [
            { label: '正常', value: 1 },
            { label: '不正常', value: 0 },
          ]
        }
      }
    ]
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { cancel, changePage, search, clearSearch } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={cancel}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
