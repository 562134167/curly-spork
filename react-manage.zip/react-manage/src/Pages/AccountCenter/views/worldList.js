/*
 * @Author: lvxuejun 
 * @Date: 2018-04-24 10:42:37 
 * @Last Modified by: mikey.zhaopeng
 * @Last Modified time: 2018-04-27 16:27:58
 * 留言回复列表
 */
import React, { Component } from 'react'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { formateEditData } from '../../../Util/reactUtil'
import moment from 'moment'    
import is from 'is_js'
import { Table, message, Button, Card, Popconfirm } from 'antd'
import { requestWorldList } from '../../../Util/Request'
import { getFetch } from '../../../Config/request'
import { formatData } from '../../../Util/reactUtil'
import { requestUpdate, requestAdd, requestRemove } from '../../../Util/Request'
import { actionAdd, actionSave, actionCancel, actionEdit, actionRemove, actionChangePage, actionSearch, actionClearSearch, initNullParams, actionOnShowSizeChange } from '../../../Util/Action'


const editTitle = '编辑操作类型', 
      addTitle = '新增留言反馈',
      newItem = { };

const listUrl = '/system/appealmessage/detail', //获取列表
      updateUrl = '', //修改
      addUrl = '/system/appealmessage/addReply',//添加
      removeUrl = '/system/appealmessage/removeReply'  //删除

class worldList extends Component {
  constructor(props) {       
    super(props)
    this.onInit()
  }    
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      const queryParams = { ...params };   
      queryParams.id = this.locationState.id;

      return getFetch(listUrl, queryParams).then(res => {

        if (res && res.status == 0) {
          
          const appealReplyList = (res.model && res.model.appealReplyList) || []
          const dataSource = formatData(appealReplyList);
          console.log( dataSource );
          this.setState({
            dataSource,
            selectedRowKeys: []
          })
        }

        console.log ( res ); 
        return res
      })
    },

    //修改
    edit: (params) => {
      requestUpdate({ params, updateUrl, context: this })
    },
    //新增
    add: (params) => {
      requestAdd({ params, addUrl, context: this })

    },
    //删除
    delete: (params) => {
      requestRemove({ params, removeUrl, context: this })
    },

  }     

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    //点击修改按钮
    edit: (record, index) => {
      actionEdit({ record, editTitle, context: this })
    },
    //新增
    add: () => {
      actionAdd({ addTitle, context: this })
    },
    //保存
    save: (values) => {
      if (this.state.editId) {
        this.setState({
          modalVis: false,
          editId: null
        })
      } else {
        console.log ('slese');
        actionSave({ context: this, values })
      }
    },
    
    remove: (id) => {
      actionRemove({ id, context: this })
    },

    cancel: () => {
      actionCancel({ context: this })
    }
    //删除
  }

  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    const { edit } = this.Action
    this.locationState = this.props.location.state || {};
    const { remove } = this.Action;
    this.state = {
      dataSource: [],
      editId: null,
      getDataParams: {},
      selectedRowKeys: [],
      title: addTitle,
      modalVis: false,
      modal: {}
    }

    // 表头设置
    this.columns = [
        {
          title: '反馈Id',
          dataIndex: 'appealId',
          key: 'appealId',
          width: 60
        },
       {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
        width: 200,
        render: (value) => { return value && moment(value).format('YYYY/MM/DD') }
      }, {
        title: '回复内容',
        dataIndex: 'replyContent',
        key: 'replyContent'
      },{
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            {/* <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button> */}
            <Popconfirm
              title="确定要删除吗?"
              onConfirm={() => remove(record.id)}
              okText="是"
              cancelText="否">
              <Button type="danger" className="action-item">删除</Button>
            </Popconfirm>
          </span>
        )

      }
    ]

    this.formItems = [ 
      {
        type: EditType.InputStr,   
        label: '反馈Id',
        key: 'id',
        config: {
          initialValue: this.locationState.id
        },
        
      },   
      {
          type: EditType.InputStr,
          label: '回复内容',
          key: 'replyContent',
          config: {
              rules: [
                  { required: true, message: '请输入回复内容' },
              ]
          }
      }, 
  ]
  //新建面板表单的初始内容
  this.newItem = formateEditData(newItem, this.formItems)
  for (let i in this.newItem) {
      this.newItem[i] = {
          value: this.newItem[i]
      }
  }
  }

  render() {
    const { dataSource, title, modalVis, modal } = this.state
    const { add, save, cancel, edit } = this.Action
    return (
      <div>
        {/* <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        /> */}
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增留言反馈</Button>
        </Card>
        <Table
          scroll={{ x: 1000 }}
          columns={this.columns}
          dataSource={dataSource}
        // pagination={{
        //   showSizeChanger: true,
        //   pageSize,
        //   current,
        //   total: totalModels,
        //   onChange: changePage,
        //   onShowSizeChange
        // }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />

      </div>
    )
  }

  componentDidMount() {
    if (is.undefined(this.locationState.id)) {
      this.props.history.replace('/accountCenter/feedback')
      return;
    }
    this.setState({
      getDataParams: initNullParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default worldList;