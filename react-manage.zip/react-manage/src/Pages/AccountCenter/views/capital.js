import React, { Component } from 'react'
// import { connect } from 'react-redux'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, message, notification, Button} from 'antd'
import { hasAttr, arrayToObject } from '../../../Util'
import { getQueryObj } from '../../../Util'
import { formatData, flattenObj, handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { actionChangePage, actionClearSearch, actionSearch, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'
import { getFetch, fetch } from '../../../Config/request'
import TwoDecimals from '../../../Common/twoDecimals'
const title = '冻结用户资金'
const converttitle= '积分兑换'
const initGetParams = {
  pageIndex: 1,
}
const frozeformItems = [
      {
        render: TwoDecimals,
        type: EditType.InputNum,
        key: 'frozenNum',
        label: '冻结资金',
        config: {
          rules: [
            { required: true, message: '请填写要冻结的金额数目' }
          ],
        },
        isInputNum: true
      }
    ]
const conformItems = [
      {
        render: TwoDecimals,
        type: EditType.InputNum,
        key: 'ingegralNum',
        label: '金额数量',
        config: {
          rules: [
            { required: true, message: '请填写要转换的积分数量' }
          ],
        },
        isInputNum: true
      },{
        type: EditType.InputStr,
        label: '支付密码',
        key: 'password',
        config: {
          rules: [
            { required: true, message: '请输入支付密码' }
          ]
        },
        itemConfig: {
          type: 'password'
        }
      }
    ]
const pagingUrl = '/system/capital/paging'
const editFrozenNumUrl = '/system/funddetails/frozemoney'
const editconNumUrl = '/system/integral/integralExchangeToShop'

class Capital extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
    	 
      const queryObj = getQueryObj(this.props.location.search) || {}
      return getFetch(pagingUrl, { ...params, ...queryObj }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels, totalPages } = res
          const dataSource = formatData(flattenObj(models, ['capital']))
          this.setState({
            dataSource,
            totalModels,
            totalPages,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    editFrozenNum: (params) => {
      return fetch(editFrozenNumUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        if (res.status == 0) {
          this.Request.get(this.state.getDataParams)
        }
        return res
      })
    },
    editToshopNum: (params) => {
      return getFetch (editconNumUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        if (res.status == 0) {
          this.Request.get(this.state.getDataParams)
        }
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
       
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        getDataParams: params,
        selectedRowKeys: []
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = { ...record }
      this.setState({
        editId: record.userId,
        modalVis: true,
        modal: modal,
        title: title,
        formItems: frozeformItems
      })
    },
     // 点击积分兑换
    convertedit: (record, index) => {
      let modal = { ...record }
      this.setState({
        editId: record.userId,
        modalVis: true,
        modal: modal,
        title: converttitle,
        formItems: conformItems
      })
    },
    save: (values) => {
      const { editId, modal } = this.state
      const { editFrozenNum } = this.Request
      const { editToshopNum } = this.Request
      // note: 判断条件可能会更改
      if (values.frozenNum > modal.available || values.frozenNum > modal.cashAvailable || values.frozenNum > modal.totalResidual) {
        message.error('资金不得大于用户的可用余额！')
        return;
      } else if (values.frozenNum <= 0) {
        message.error('金额必须大于0')
        return;
      }
      if (values.ingegralNum > modal.totalIntegral || values.ingegralNum > modal.totalIntegral || values.ingegralNum > modal.totalIntegral) {
        message.error('资金不得大于用户的可用余额！')
        return;
      } else if (values.ingegralNum <= 0) {
        message.error('金额必须大于0')
        return;
      }
      // 把保存的数值发送到服务器
      if(values.frozenNum){
      	editFrozenNum({
        	userId: editId,
        	money: values.frozenNum
      	})
      }
      if(values.ingegralNum){
      	editToshopNum({
        	userId: editId,
        	...values
      	})
      }
      

    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    const { edit } = this.Action;
    const { convertedit } = this.Action;
    this.state = {
      dataSource: [],
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      totalPages: null,
      getDataParams: {},
      editId: null,
      modalVis: false,
      modal: null,
      title: title,
      formItems: [],
      userTypeOptions: [ 
      			{ label: '普通钱包用户', value: 1 },
      			{ label: '摩根员工账户', value: 2},
					  { label: '钱包商户', value: 3 },
					  { label: '收银台商户', value: 4 },
					  { label: '平台系统账户', value: 5 }
			],
      
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone',
        }, {
          type: SearchType.Select,
          label: '类型',
          id: 'userType',
          dataSource: this.state.userTypeOptions
        }
      ]
    }
    
    // 表头设置
    this.columns = [
      {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName',
      },
      {
        title: '用户名',
        dataIndex: 'userName',
        key: 'userName',
      }, {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile',
      }, {
        title: '积分总额',
        dataIndex: 'totalIntegral',
        key: 'totalIntegral',
        render: value => toMoney(value, '')
      }, {
        title: '可用余额',
        dataIndex: 'available',
        key: 'available',
        render: value => toMoney(value)
      }, {
        title: '可提现余额',
        dataIndex: 'cashavailable',
        key: 'cashavailable',
        render: value => toMoney(value)
      }, {
        title: '冻结金额',
        dataIndex: 'frozen',
        key: 'frozen',
        render: value => toMoney(value)
      },{
        title: '类型',
        dataIndex: 'userTypeName',
        key: 'userTypeName',
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <Button type="primary" className="action-item" onClick={() => edit(record, index)}> 冻结用户金额</Button>
        )
      },{
        title: '兑换',
        dataIndex: 'userType',
        key: 'userType',
        render: (text, record, index) => {
          return (record.userType == 4 ? (<Button type="primary" className="action-item" onClick={() => convertedit(record, index)}> 积分兑换</Button>
          ) : null)
        }
      }
    ];
    
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels, title, modalVis, modal, formItems  } = this.state
    const { changePage, search, clearSearch, save, cancel } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
        
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}

export default Capital