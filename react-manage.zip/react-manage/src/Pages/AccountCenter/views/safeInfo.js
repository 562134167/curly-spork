/*
 * @Author: miccy 
 * @Date: 2018-01-30 11:03:25 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-24 15:05:47
 * 用户绑卡信息
 */
import React, { Component } from 'react'
import { connect } from 'react-redux'
import is from 'is_js'
import moment from 'moment'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
// import EditPanel from '../../../Common/editPanel'
// import * as EditType from '../../../Common/editType'
// import DropdownBtn from '../../../Common/dropdowmBtn'
import { Table, Button, message } from 'antd'
import { formatData } from '../../../Util/reactUtil'
import { getQueryObj, hasAttr } from '../../../Util'
import { getFetch } from '../../../Config/request'
import BankModal from './component/BankModal'
const initGetParams = {
  pageIndex: 1,
}

const pagingUrl = '/system/usersafe/paging'

class SafeInfo extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      const queryObj = getQueryObj(this.props.location.search) || {}
      return getFetch(pagingUrl, { ...params, ...queryObj }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    viewBank: (bank) => {
      if (!bank || !bank.length) {
        message.info('该用户暂未绑定银行卡')
        return;
      }
      const cashCardList = this.Util.getCashCardList(bank)
      const creditCardList = this.Util.getCreditCardList(bank)
      this.setState({
        cashCardList,
        creditCardList,
        modalVis: true
      })
    }
  }
  // 工具函数类
  Util = {
    getCashCardList: (cardList) => {
      const cashCardList = []
      if (cardList) {
        for (let i in cardList) {
          let card = cardList[i]
          if (card.typeCode === 'CashCard') {
            const options = this.props.cashCardOption.filter(item => item.value === card.bankCode)
            if (options[0]) {
              cashCardList.push({
                imgSrc: options[0].tips || '',
                name: options[0].name,
                cardNo: card.cardNo
              })
            }

          }
        }
      }

      return cashCardList
    },
    getCreditCardList: (cardList) => {
      const creditCardList = []
      if (cardList) {
        for (let i in cardList) {
          let card = cardList[i]
          if (card.typeCode === 'CreditCard') {
            const options = this.props.creditCardOption.filter(item => item.value === card.bankCode)
            if (options[0]) {
              creditCardList.push({
                imgSrc: options[0].tips || '',
                name: options[0].name,
                cardNo: card.cardNo
              })
            }

          }
        }
      }

      return creditCardList
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { viewBank } = this.Action
    // const { get } = this.Request
    this.state = {
      dataSource: [],
      modalVis: false,
      cashCardList: [],
      creditCardList: [],
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [{
        type: SearchType.String,
        label: '手机号码',
        id: 'mobilePhone',
      }, {
        type: SearchType.String,
        label: '用户真实姓名（姓名全称）',
        id: 'userRealName',
      }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '用户ID',
        dataIndex: 'userId',
        key: 'userId',
        fixed: 'left',
        width: 100,
      },
      {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName',
      },
      {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile',
      }, {
        title: '资金账户',
        dataIndex: 'isOpenCapital',
        key: 'isOpenCapital',
        render: value => value == 1 ? '已激活' : '未激活'
      },
      {
        title: '绑定的银行卡',
        dataIndex: 'bankInfoList',
        key: 'bankInfoList',
        render: value => {
          if (!value || !value.length) {
            return;
          }
          return <Button type="primary" onClick={() => viewBank(value)}>查看</Button>
        }
      }, {
        title: '身份证号码',
        dataIndex: 'userIdCard',
        key: 'userIdCard'
      }, {
        title: '注册时间',
        dataIndex: 'registerTime',
        key: 'registerTime',
        render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '实名通过时间',
        dataIndex: 'realNameTime',
        key: 'realNameTime',
        render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '激活资金账户时间',
        dataIndex: 'openCapitalTime',
        key: 'openCapitalTime',
        render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      }
    ];

  }
  render() {
    const { dataSource, cashCardList, creditCardList, modalVis, selectedRowKeys, current, totalModels } = this.state
    const { changePage, cancel, search, clearSearch } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
        <BankModal
          onCancel={cancel}
          modalVis={modalVis}
          cashCardList={cashCardList}
          creditCardList={creditCardList}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    cashCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CashCard'), [0, 'items']) || [],
    creditCardOption: hasAttr(state.index.dictList.filter((item, index) => item.value === 'CreditCard'), [0, 'items']) || [],
  }
}
export default connect(mapStateToProps)(SafeInfo)
