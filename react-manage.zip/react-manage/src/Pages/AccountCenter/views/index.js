import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
const loadCapital = (cb) => {
  return import('./capital.js')
}
// const loadUserAuditor = (cb) => {
//   return import('./userAuditor.js')
// }
const loadFundDetail = (cb) => {
  return import('./fundDetail.js')
}
const loadSetting = (cb) => {
  return import('./setting.js')
}
const loadSafeInfo = (cb) => {
  return import('./safeInfo.js')
}
const loadUpLowRelation = (cb) => {
  return import('./upLowRelation')
}
const loadUserIntegral = (cb) => {
  return import('./userIntegral')
}
const loadUserBean = (cb) => {
  return import('./userBean')
}
// const loadUserInfo = (cb) => {
//   return import('./userInfo')
// }
const loadFeedback = (cb) => {
  return import('./feedback')
}
const loadWorldList = (cb) => {
  return import('./worldList')
}
const Capital = getComponent(loadCapital)
const FundDetail = getComponent(loadFundDetail)
const Setting = getComponent(loadSetting)
const SafeInfo = getComponent(loadSafeInfo)
const UpLowRelation = getComponent(loadUpLowRelation)
const UserIntegral = getComponent(loadUserIntegral)
const UserBean = getComponent(loadUserBean)
// const UserAuditor = getComponent(loadUserAuditor)
// const UserInfo = getComponent(loadUserInfo)
const Feedback = getComponent(loadFeedback)
const WorldList = getComponent(loadWorldList)

export default class AccountCenter extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/accountCenter"
          exact render={() => <Redirect to="/accountCenter/capital" />}
        />
        <Route path="/accountCenter/fundDetail" render={(props) => <FundDetail {...props} />} />
        <Route path="/accountCenter/capital" render={(props) => <Capital {...props} />} />
        <Route path="/accountCenter/safeInfo" render={(props) => <SafeInfo {...props} />} />
        <Route path="/accountCenter/setting" render={(props) => <Setting {...props} />} />
        <Route path="/accountCenter/upLowRelation" render={(props) => <UpLowRelation {...props} />} />
        <Route path="/accountCenter/userIntegral" render={(props) => <UserIntegral {...props} />} />
        <Route path="/accountCenter/userBean" render={(props) => <UserBean {...props} />} />
        {/* <Route path="/accountCenter/userAuditor" render={(props) => <UserAuditor {...pr ops} />} /> */}
        {/* <Route path="/accountCenter/userInfo" render={(props) => <UserInfo {...props} />} /> */}
        <Route path="/accountCenter/feedback" render={(props) => <Feedback {...props} />} />
        <Route path="/accountCenter/worldList" render={(props) => <WorldList {...props} />} />
      </Switch>
    )
  }
}