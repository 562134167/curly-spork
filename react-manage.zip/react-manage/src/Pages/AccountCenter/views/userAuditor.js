import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
// import DropdownBtn from '../../../Common/dropdowmBtn'
import { Table, Button, message } from 'antd'
import { bindFunc, formatData, formateEditData, flattenObj, handleEndTime, handleStartTime } from '../../../Util/reactUtil'
import { getQueryObj } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
const title = '查看审核信息'
const initGetParams = {
  pageIndex: 1,
  pageSize: 20
}
const pagingUrl = '/system/userauditor/paging'
const updateUrl = '/system/userauditor/auditing'
const uploadFileUrl = '/system/file/upload'

class userAuditor extends Component {
  constructor(props) {
    super(props)
    // 绑定作用域
    bindFunc([{
      key: 'Action',
      value: ['edit', 'changePage', 'cancel', 'editStatus', 'search', 'clearSearch']
    }, { key: 'RenderFunc', value: ['renderFooter'] }], this)
    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {

      const queryObj = getQueryObj(this.props.location.search) || {}
      return getFetch(pagingUrl, { ...params, ...queryObj }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['userSafeInfo', 'userAuditor']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 修改数据
    update: (params) => {

      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }

      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        modalVis: true,
        modal: modal,
        title: title,
        editId: obj.userId,
      })
    },
    // 保存模态框表单数据（新建/编辑）
    editStatus: (type, context) => {
      const reason = context.editForm.props.form.getFieldValue('reason');
      const { editId } = this.state
      if (type === 'cancel') {
        if (!reason) {
          message.error('请填写审核失败的理由！')
          return;
        }
        this.Request.update({
          userId: editId,
          isSuccess: false,
          reason: reason
        })
      } else {
        this.Request.update({
          userId: editId,
          isSuccess: true,
          reason: ''
        })
      }

    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },
  }
  RenderFunc = {
    // 模态框底部的渲染函数
    renderFooter: (context) => {
      const { editStatus, cancel } = this.Action
      const isAuditor = context.props.modal.isAuditor;
      console.log(isAuditor)
      if (isAuditor.value == 3) {
        return (
          <div>
            <Button onClick={() => { editStatus('ok', context) }} type="primary">审核通过</Button>
            <Button onClick={() => { editStatus('cancel', context) }}>审核不通过</Button>
          </div>
        )
      } else {
        return (
          <div>
            <Button onClick={cancel} type="primary">确定</Button>
          </div>
        )
      }
    }
  }

  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    const { edit } = this.Action
    this.state = {
      title: title,
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      editId: null,
      totalModels: null,
      getDataParams: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.Select,
          label: '审核状态',
          id: 'isAuditor',
          dataSource: [
            { value: 1, label: '审核通过' },
            { value: 2, label: '未通过审核' },
            { value: 4, label: '黑名单' },
            { value: 3, label: '待审核' },
          ]
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime',
        }, {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone',
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '用户名',
        dataIndex: 'userName',
        key: 'userName',
      }, {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile',
      }, {
        title: '真实姓名',
        dataIndex: 'userRealName',
        key: 'userRealName',
      }, {
        title: '身份证',
        dataIndex: 'userIdCard',
        key: 'userIdCard',
      }, {
        title: '提交时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => (value && moment(value, 'x').format('YYYY/MM/DD HH:mm:ss')) || moment().format('YYYY/MM/DD HH:mm:ss')
      }, {
        title: '审核状态',
        dataIndex: 'isAuditor',
        key: 'isAuditor',
        render: value => {
          if (value == 1) {
            return '审核通过'
          } else if (value == 2) {
            return '未通过审核'
          } else if (value == 3) {
            return '待审核'
          } else if (value == 4) {
            return '黑名单'
          }
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>查看</Button>
          </span>
        )
      }
    ];
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '用户名',
        key: 'userName',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        label: '手机号码',
        key: 'userMobile',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        label: '真实姓名',
        key: 'userRealName',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        label: '身份证',
        key: 'userIdCard',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.Image,
        label: '身份证照片',
        key: 'userIdCardUrl',
        config: {
          valuePropName: 'fileList',
          getValueFromEvent: (e) => {
            if (Array.isArray(e)) {
              return e;
            }
            return e && e.fileList;
          },
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          name: 'files'
        },
        isShowbtn: (props) => {
          return false
        }
      }, {
        type: EditType.DatePicker,
        label: '提交时间',
        key: 'createTime',
        itemConfig: {
          disabled: true,
        }
      }, {
        type: EditType.Select,
        label: '审核状态',
        key: 'isAuditor',
        itemConfig: {
          options: [
            { value: 1, label: '审核通过' },
            { value: 2, label: '未通过审核' },
            { value: 3, label: '待审核' },
            { value: 4, label: '黑名单' },
          ],
          disabled: true
        }

      }, {
        type: EditType.InputStr,
        label: '审核不通过理由',
        key: 'reason'
      }
    ]
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { search, clearSearch, cancel, changePage } = this.Action
    return (
      <div className="file-manage">
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            current,
            total: totalModels,
            onChange: changePage,
            pageSize: 20,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          footer={(context) => this.RenderFunc.renderFooter(context)}
          onCancel={cancel}
          className="file-manage-modal"
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}

export default userAuditor