import React, { Component } from 'react'
// import { connect } from 'react-redux'
// import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Card, Table, Button, message } from 'antd'
import { formatData, formateEditData } from '../../../Util/reactUtil'
// import { hasAttr, getQueryObj } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'

const title = '查看留言反馈'
const initGetParams = {
  // keyword: '',
  pageIndex: 1,
  // pageSize: 20
}

const pagingUrl = '/system/appealmessage/paging'
const updateUrl = '/system/appealmessage/handle'
const updatePropertyUrl = '/system/appealmessage/handlelist'
const uploadFileUrl = '/system/file/upload'

class Feedback extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      /**@param {Object} params 
       * 数据格式
       * {
        @param {String} keyword,
        @param {Number} pageIndex,
        @param {Number} pageSize'
      }
       */
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels, totalPages } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            totalPages,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 修改数据
    update: (params) => {
      /**@param {Object} params 
      * 数据格式
      */
      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {
      /**@param {Object} params 
       * 数据格式
       *{
        @param {Array} ids,
        @param {String} ename,
        @param {*} value
      }
      */
      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        modalVis: true,
        modal: modal,
        title: title,
        editId: obj.id,
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (context) => {
      const { editId } = this.state
      console.log(editId)
      this.Request.update({
        id: editId
      })
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        getDataParams: params,
        selectedRowKeys: [],
      })
    },
    // 点击批量操作按钮
    editItems: (name) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        // name,
        // value,
        ids: selectedRowKeys
      })
    }
  }
  RenderFunc = {
    // 模态框底部的渲染函数
    renderFooter: (context) => {
      // const { editId } = this.state
      const { save, cancel } = this.Action
      const processStatus = context.props.modal.processStatus;
      if (processStatus.value == 0) {
        return (
          <div>
            <Button onClick={cancel}>取消</Button>
            <Button type="primary" onClick={() => { save(context) }}>标注为已处理</Button>
          </div>
        )
      } else {
        return (
          <div>
            <Button onClick={cancel} type="primary">确定</Button>
          </div>
        )
      }
    }
  }
  Util = {
    // getFileList: (url) => {
    //   // 将获得的url转换成Upload要求的数据格式
    //   const tempArr = url.split(',')
    //   const fileList = []
    //   for (let i in tempArr) {
    //     fileList.push({
    //       uid: new Date().getTime() + i,
    //       status: 'done',
    //       url: tempArr[i],
    //       response: tempArr[i]
    //     })
    //   }
    //   return fileList
    // },
    // 更新模态框表单的配置
    // updateFormItem: (value, nextValue, keyValue, fn) => {
    //   if (nextValue !== value) {
    //     const formItem = this.formItems.filter((item, index) => item.key === keyValue)[0]
    //     fn(formItem)
    //   }
    // },
    // 处理传入表单的编辑内容的key、value以匹配组件的格式要求
    // handleEditData: (obj) => {
    //   const { getFileList } = this.Util
    //   if (is.object(obj)) {
    //     if (!is.undefined(obj.appealPic)) {
    //       obj.appealPic = getFileList(obj.appealPic)
    //     }
    //   }
    //   return obj
    // }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit } = this.Action
    // const { get } = this.Request
    this.state = {
      title: title,
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      editId: null,
      totalModels: null,
      totalPages: null,
      getDataParams: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.Select,
          label: '处理状态',
          id: 'isAuditor',
          dataSource: [
            { value: 0, label: '未处理' },
            { value: 1, label: '已处理' },
          ]
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '申诉内容',
        dataIndex: 'msgContent',
        key: 'msgContent',
        render: value => {
          return value && value.substr(0, 20) + '...'
        }
      }, {
        title: '处理状态',
        dataIndex: 'processStatus',
        key: 'processStatus',
        render: value => {
          if (value == 1) {
            return '已处理'
          } else {
            return '未处理'
          }
        }
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>查看</Button>
          </span>
        )
      }
    ];
    this.formItems = [
      {
        type: EditType.InputStr,
        label: '联系姓名',
        key: 'linkName',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        label: '联系电话',
        key: 'linkTel',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        label: '联系邮箱',
        key: 'linkEmail',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        label: '申诉内容',
        key: 'msgContent',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.Image,
        label: '申诉照片',
        key: 'appealPic',
        config: {
          valuePropName: 'fileList',
        },
        itemConfig: {
          action: window.baseUrl + uploadFileUrl,
          name: 'files',
          onRemove: () => {
            return false;
          }
        },
        isShowbtn: (props) => {
          return false
        }
      }, {
        type: EditType.DatePicker,
        label: '提交时间',
        key: 'createTime',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.Select,
        label: '审核状态',
        key: 'processStatus',
        itemConfig: {
          options: [
            { value: 0, label: '未处理' },
            { value: 1, label: '已处理' },
          ],
          disabled: true
        }

      }
    ]
  }
  render() {
    const { dataSource, title, modalVis, modal, current, totalModels, selectedRowKeys } = this.state
    const { search, clearSearch, cancel, changePage, editItems } = this.Action
    return (
      <div className="file-manage">
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button className="action-item" type="primary" ghost onClick={() => editItems('pay')}>批量标注为已处理</Button>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            current,
            total: totalModels,
            onChange: changePage,
            pageSize: 20,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          footer={(context) => this.RenderFunc.renderFooter(context)}
          onCancel={cancel}
          className="file-manage-modal"
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}

export default Feedback