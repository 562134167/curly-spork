import React, { Component } from 'react'
// import { connect } from 'react-redux'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Button, message } from 'antd'
import { formatData, formateEditData, flattenObj } from '../../../Util/reactUtil'
import { getQueryObj } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
import SwitchState from './component/SwitchState'
const title = '修改设置'
const initGetParams = {
  pageIndex: 1,
}

const pagingUrl = '/system/setting/paging'
const updateUrl = '/system/setting/update'
const updatePropertyUrl = '/system/setting/updateproperty'

export default class Setting extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {

      const queryObj = getQueryObj(this.props.location.search) || {}
      return getFetch(pagingUrl, { ...params, ...queryObj }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['setting']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 修改数据
    edit: (params) => {

      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {

      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in record) {
        modal[i] = {
          value: obj[i]
        }
      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: title
      })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      for (let i in dataSource) {
        if (dataSource[i].id === editId) {
          const temp = { ...dataSource[i], ...values }
          edit(temp)
          break;
        }
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit } = this.Action
    this.state = {
      title: title,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone',
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName',
      }, {
        title: '用户名',
        dataIndex: 'userName',
        key: 'userName',
      }, {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile',
      }, {
        title: '激活',
        dataIndex: 'isActivation',
        key: 'isActivation',
        render: value => value ? '是' : '否'
      }, {
        title: '冻结',
        dataIndex: 'isFrozen',
        key: 'isFrozen',
        render: value => value ? '是' : '否'
      }, {
        title: '余额开关',
        dataIndex: 'isBalance',
        key: 'isBalance',
        render: value => value ? '是' : '否'
      }, {
        title: '允许转账进入',
        dataIndex: 'isTransferEntry',
        key: 'isTransferEntry',
        render: value => value ? '是' : '否'
      }, {
        title: '允许转账支出',
        dataIndex: 'isTransferExpend',
        key: 'isTransferExpend',
        render: value => value ? '是' : '否'
      }, {
        title: '允许充值',
        dataIndex: 'isRecharge',
        key: 'isRecharge',
        render: value => value ? '是' : '否'
      }, {
        title: '允许提现',
        dataIndex: 'isCash',
        key: 'isCash',
        render: value => value ? '是' : '否'
      }, {
        title: '允许消费',
        dataIndex: 'isConsume',
        key: 'isConsume',
        render: value => value ? '是' : '否'
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      },
      {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
          </span>
        )
      }
    ];
    // 编辑面板内容
    this.formItems = [
      {
        type: EditType.InputStr,
        key: 'userName',
        label: '用户名',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.InputStr,
        key: 'userMobile',
        label: '手机号码',
        itemConfig: {
          disabled: true
        }
      }, {
        type: EditType.Switch,
        key: 'isAllOpen',
        label: '全部开关启用',
        isSwitchNum: true,
        render: SwitchState,
        itemConfig: {
          onChange: (value, props) => {
            props.form.setFieldsValue({
              'isActivation': value,
              'isFrozen': value,
              'isBalance': value,
              'isTransferEntry': value,
              'isTransferExpend': value,
              'isRecharge': value,
              'isCash': value,
              'isConsume': value
            })
            return value
          }
        }
      }, {
        type: EditType.Switch,
        key: 'isActivation',
        label: '是否激活',
        isSwitchNum: true,
        render: SwitchState,
        itemConfig: {
          onChange: (value, props) => {
            if (!value) {
              props.form.setFieldsValue({
                'isFrozen': value,
                'isBalance': value,
                'isTransferEntry': value,
                'isTransferExpend': value,
                'isRecharge': value,
                'isCash': value,
                'isConsume': value
              })
            }
            return value
          }
        }
      }, {
        type: EditType.Switch,
        key: 'isFrozen',
        label: '是否冻结',
        render: SwitchState,
        isSwitchNum: true,
        itemConfig: {
          onChange: (value, props) => {
            if (!props.form.getFieldValue('isActivation')) {
              return false
            }
            return value
          }
        }
      }, {
        type: EditType.Switch,
        key: 'isBalance',
        label: '余额开关',
        render: SwitchState,
        isSwitchNum: true,
        itemConfig: {
          onChange: (value, props) => {
            if (!props.form.getFieldValue('isActivation')) {
              return false
            }
            if (!value) {
              props.form.setFieldsValue({
                'isTransferEntry': value,
                'isTransferExpend': value,
                'isRecharge': value,
                'isCash': value,
                'isConsume': value
              })
            }
            return value
          }
        }
      }, {
        type: EditType.Switch,
        key: 'isTransferEntry',
        label: '是否允许转账进入',
        render: SwitchState,
        isSwitchNum: true,
        itemConfig: {
          onChange: (value, props) => {
            if (!props.form.getFieldValue('isActivation') || !props.form.getFieldValue('isBalance')) {
              return false
            }
            return value
          }
        }
      }, {
        type: EditType.Switch,
        key: 'isTransferExpend',
        label: '是否允许转账支出',
        render: SwitchState,
        isSwitchNum: true,
        itemConfig: {
          onChange: (value, props) => {
            if (!props.form.getFieldValue('isActivation') || !props.form.getFieldValue('isBalance')) {
              return false
            }
            return value
          }
        }
      }, {
        type: EditType.Switch,
        key: 'isRecharge',
        label: '是否允许充值',
        render: SwitchState,
        isSwitchNum: true,
        itemConfig: {
          onChange: (value, props) => {
            if (!props.form.getFieldValue('isActivation') || !props.form.getFieldValue('isBalance')) {
              return false
            }
            return value
          }
        }
      }, {
        type: EditType.Switch,
        key: 'isCash',
        label: '是否允许提现',
        render: SwitchState,
        isSwitchNum: true,
        itemConfig: {
          onChange: (value, props) => {
            if (!props.form.getFieldValue('isActivation') || !props.form.getFieldValue('isBalance')) {
              return false
            }
            return value
          }
        }
      }, {
        type: EditType.Switch,
        key: 'isConsume',
        label: '是否允许消费',
        render: SwitchState,
        isSwitchNum: true,
        itemConfig: {
          onChange: (value, props) => {
            if (!props.form.getFieldValue('isActivation') || !props.form.getFieldValue('isBalance')) {
              return false
            }
            return value
          }
        }
      }
    ]
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { save, cancel, changePage, editItems, search, clearSearch } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <DropdownBtn
            className="action-item"
            mainLabel="批量激活"
            keyName="isActivation"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
          <DropdownBtn
            className="action-item"
            mainLabel="批量冻结"
            keyName="isFrozen"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
          <DropdownBtn
            className="action-item"
            mainLabel="批量余额开关"
            keyName="isBalance"
            items={[{ label: '批量启用', value: 1 },
            { label: '批量禁用', value: 0 }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage,
            showTotal: (total, range) => `共 ${total} 条记录`
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
