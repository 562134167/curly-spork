import React, { Component } from 'react'
// import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
// import EditPanel from '../../../Common/editPanel'
// import * as EditType from '../../../Common/editType'
// import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Button, message, Modal, Row, Col } from 'antd'
import { formatData } from '../../../Util/reactUtil'
import { getFetch } from '../../../Config/request'
import { getQueryObj } from '../../../Util'
// import { connect } from 'react-redux';
import '../index.less'
// const editTitle = '查看详情'
const initGetParams = {
  // keyword: '',
  pageIndex: 1,
  // pageSize: 20
}
const pagingUrl = '/system/detail/relationDetail'
export default class UpLowRelation extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {

      const queryObj = getQueryObj(this.props.location.search) || {}
      return getFetch(pagingUrl, { ...params, ...queryObj }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(models, 'mobilePhone')
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
  }
  // 点击按钮的操作（搜索、清空搜索,点击页数按钮,点击批量操作按钮）
  Action = {
    // 搜索
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi

      if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
        message.error('请输入正确的用户手机号码')
        return;
      }
      if (queryParams.upperUserMobile && (!/^1\d{10}$/gi.test(queryParams.upperUserMobile))) {
        message.error('请输入正确的上级手机号码')
        return;
      }
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })

    },
    // 清空查找条件
    clearSearch: (params) => {
      this.setState({
        getDataParams: initGetParams,
      })
    },
    //点击查看
    see: (text) => {
      if (!text || !text.length) {
        message.info('该用户暂未有下级');
        return;
      }
      this.setState({
        modalVis: true,
        modal: text
      })
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    //点击页数按钮
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },

  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    this.state = {
      dataSource: [],
      modal: [],
      selectedRowKeys: [],
      modalVis: false,
      current: 1,
      totalModels: null,
      getDataParams: {},
    }// 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '用户手机号码',
          id: 'userMobile',
          type: SearchType.String,
        }, {
          label: '上级手机号码',
          id: 'upperUserMobile',
          type: SearchType.String,
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName',
      }, {
        title: '手机号码',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone',
      }, {
        title: '上级姓名',
        dataIndex: 'superiorName',
        key: 'superiorName',
      }, {
        title: '下级人数',
        dataIndex: 'persion',
        key: 'persion',
      }, {
        title: '下级详情',
        dataIndex: 'subordinateShips',
        key: 'subordinateShips',
        render: (text, record, index) => (<Button type='primary' onClick={() => { this.Action.see(text) }}>查看</Button>)
      }
    ];
  }
  render() {
    const { dataSource, modal, selectedRowKeys, current, totalModels, modalVis } = this.state
    const { search, clearSearch, changePage, cancel } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <Modal
          title='查看下级'
          style={{ width: 200 }}
          visible={modalVis}
          onCancel={cancel}
          footer={null}
        >
          <Row>{
            modal.map((item, index) => (
              <Col span={12} key={index}>
                <Card>
                  <Col span={12}>用户名：{item.userName}</Col>
                  <Col span={12}>手机号码：{item.userMobile}</Col>
                </Card>
              </Col>
            ))
          }</Row>
        </Modal>
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
