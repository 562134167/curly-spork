import React, { PureComponent } from 'react'
import { Switch } from 'antd'
import is from 'is_js'
export default class SwitchState extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value
    this.state = {
      value
    }
  }
  Action = {
    onSwitchChange: (checked) => {
      let value = checked
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      if (this.props.item.itemConfig.onChange) {
        value = this.props.item.itemConfig.onChange(value, this.props)
      }
      this.Action.triggerChange(value)
    },

    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(changedValue)
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value
      if (!is.undefined(value)) {
        this.setState({ value })
      }
    }
  }

  render() {
    const { onSwitchChange } = this.Action
    const { value } = this.state
    return (
      <div>
        <Switch
          checked={value}
          onChange={onSwitchChange}
        />
      </div>
    )
  }
}