import React, { PureComponent } from 'react'
import { Modal, Button, Row, Col, Card } from 'antd'

export default class BankModal extends PureComponent {
  RenderFunc = {
    renderCard: (cardList, type) => {
      if (cardList && cardList.length) {
        return (
          <Card title={type === 'cashCard' ? '储蓄卡' : '信用卡'}>
            <Row>
              {
                cardList && cardList.map((card, index) => (
                  <Col key={index} span={8} style={{ verticalAlign: 'middle' }}>
                    <img
                      style={{ maxWidth: '100%', height: 50 }}
                      src={card.imgSrc}
                      alt="银行卡" />
                    <p>{card.name}</p>
                    <p>{card.cardNo}</p>
                  </Col>
                ))
              }
            </Row>
          </Card>
        )
      }
    }
  }
  render() {
    const { onCancel, modalVis, cashCardList, creditCardList } = this.props
    return (
      <Modal
        visible={modalVis}
        onCancel={onCancel}
        footer={<Button onClick={onCancel}>关闭</Button>}
        title="银行卡信息"
      >
        {this.RenderFunc.renderCard(cashCardList, 'cashCard')}
        {this.RenderFunc.renderCard(creditCardList, 'creditCard')}
      </Modal>
    )
  }
}