import React, { Component } from 'react'
import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Button, message } from 'antd'
import { formatData, formateEditData, formatParentIdOptions, flattenObj } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { fetch, getFetch } from '../../../Config/request'
const addTitle = '新建用户'
const editTitle = '编辑用户'
const initGetParams = {
  pageIndex: 1,
  pageSize: 20
}
const newItem = {
  status: 1,
  createTime: new Date().getTime(),
  isRealName: 0,
  userSex: 1,
  isOpenCapital: 0,
}
const pagingUrl = '/system/detail/get',
  addUrl = '/system/detail/add/user',
  updateUrl = 'system/detail/update/user',
  updatePropertyUrl = '/system/detail/update/state',
  uploadFileUrl = '/system/file/upload'
class UserInfo extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {

      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['userInfo']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex
          })
        }
        return res
      })
    },
    // 添加数据
    add: (params) => {

      return fetch(addUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 修改数据
    edit: (params) => {

      return fetch(updateUrl, params).then(res => {
        this.setState({
          modalVis: false
        })
        this.Request.get(this.state.getDataParams)
        return res
      })
    },
    // 批量更新属性
    editItems: (params) => {

      return fetch(updatePropertyUrl, params).then(res => {
        this.Request.get(this.state.getDataParams)
        return res
      })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    // 点击新建按钮
    add: () => {
      this.setState({
        modalVis: true,
        modal: this.newItem,
        editId: null,
        title: addTitle,
        fileList: []
      })
    },
    // 点击修改按钮
    edit: (record, index) => {
      let modal = {}
      const obj = formateEditData(record, this.formItems)
      for (let i in obj) {
        modal[i] = {
          value: obj[i]
        }

      }
      this.setState({
        editId: obj.id,
        modalVis: true,
        modal: modal,
        title: editTitle
      })
    },
    // 查
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
        message.error('请输入正确的手机号码')
        return;
      }
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: initGetParams
      })
    },
    // 保存模态框表单数据（新建/编辑）
    save: (values) => {
      const { dataSource, editId } = this.state
      const { add, edit } = this.Request
      // 把保存的数值发送到服务器
      // 编辑状态下的保存
      if (editId || editId === 0) {
        for (let i in dataSource) {
          if (dataSource[i].id === editId) {
            const temp = { ...dataSource[i], ...values }
            edit(temp)
            break;
          }
        }
      } else {
        // 新增状态下的保存
        const temp = values
        add(temp)
      }
    },
    cancel: () => {
      this.setState({
        modalVis: false
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    },
    // 点击批量操作按钮
    editItems: ({ name, value }) => {
      const { selectedRowKeys } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      this.Request.editItems({
        name,
        value,
        ids: selectedRowKeys
      })
    },
    linkTo: (record, pageName) => {
      this.props.history.push(`/accountCenter/${pageName}?userId=${record.id}`)
    }
  }
  // 方法对象
  Util = {
    getMerchantFormItem: (() => {
      let merchantFormItem;
      return () => {
        if (merchantFormItem) {
          return merchantFormItem
        } else {
          return merchantFormItem = [
            {
              type: EditType.Select,
              label: '账号类型',
              key: 'merAccType',
              options: [
                { value: 1, label: '对公' },
                { value: 2, label: '对私' },
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择账号类型' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '公司编码',
              key: 'merCode',
              config: {
                rules: [
                  { required: true, message: '请输入公司编码' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司名称',
              key: 'merName',
              config: {
                rules: [
                  { required: true, message: '请输入公司名称' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '企业邮箱',
              key: 'merEmail',
              config: {
                rules: [
                  { pattern: /^\w+((-\w+)|(\.\w+))*@\w+((\.|-)\w+)*\.\w+$/, message: '企业邮箱格式不正确' },
                  { required: true, message: '请输入企业邮箱' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司地址',
              key: 'merAddr',
              config: {
                rules: [
                  { required: true, message: '请输入公司地址' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司网址',
              key: 'merWebsite',
              config: {
                rules: [
                  { required: true, message: '请输入公司网址' }
                ]
              }
            }, {
              type: EditType.Textarea,
              label: '公司简介',
              key: 'merIntroduct',
              config: {
                rules: [
                  { required: true, message: '请输入公司简介' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '营业执照号',
              key: 'merBusiLicNo',
              config: {
                rules: [
                  { required: true, message: '请输入营业执照号' }
                ]
              }
            }, {
              type: EditType.Image,
              label: '营业执照',
              key: 'merBusiLicUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传营业执照' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传营业执照',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merBusiLicUrl') && props.form.getFieldValue('merBusiLicUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '企业法人',
              key: 'merLegalPerson',
              config: {
                rules: [{ required: true, message: '请输入企业法人' }]
              }
            }, {
              type: EditType.InputStr,
              label: '法人身份证号码',
              key: 'merIdCard',
              config: {
                rules: [
                  { required: true, message: '请输入法人身份证号码' },
                  { pattern: /\d{18}|\d{15}/, message: '身份证号码格式错误' }
                ],
              }
            }, {
              type: EditType.Image,
              label: '法人身份证复印件',
              key: 'merIdCardCopyUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传法人身份证复印件' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '身份证复印件',
                accept: '.jpg',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merIdCardCopyUrl') && props.form.getFieldValue('merIdCardCopyUrl').length >= 2) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.Image,
              label: '协议上传',
              key: 'merAgreementUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传协议上传' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传协议',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merAgreementUrl') && props.form.getFieldValue('merAgreementUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '公司银行开户名',
              key: 'bankAccountName',
              config: {
                rules: [
                  { required: true, message: '请输入公司银行开户名' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '开户银行名称',
              key: 'bankBankName',
              config: {
                rules: [{ required: true, message: '请输入开户银行名称' }]
              }
            }, {
              type: EditType.InputNum,
              label: '开户账号',
              key: 'bankBankNumber',
              rules: [
                { required: true, message: '请输入开户账号' }
              ]
            }, {
              type: EditType.Select,
              label: '商户行业类型',
              key: 'bankType',
              config: {
                rules: [
                  { required: true, message: '请输入商户行业类型' }
                ]
              },
              itemConfig: {
                options: formatParentIdOptions({
                  options: this.props.industryTypeOptions,
                  hasDefaultOption: false,
                  valueKey: 'value'
                })
              }
            }, {
              type: EditType.Select,
              label: '审核状态',
              key: 'assStatus',
              options: [
                { value: 0, label: '未审核' },
                { value: 1, label: '审核通过' },
                { value: 2, label: '审核不通过' },
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择审核状态' }
                ]
              },
            }, {
              type: EditType.Select,
              label: '状态',
              key: 'status',
              options: [
                { value: 1, label: '正常' },
                { value: 2, label: '不正常' },
              ],
              config: {
                rules: [
                  { required: true, message: '请选择状态' }
                ]
              },
            },
          ]
        }
      }
    })(),
    getUserinfoFormItem: (() => {
      let userInfoFormItem;
      return () => {
        if (userInfoFormItem) {
          return userInfoFormItem
        }
        return userInfoFormItem = [
          {
            type: EditType.InputStr,
            label: '用户名',
            key: 'userName',
            config: {
              rules: [{ required: true, message: '请输入用户名' }]
            }
          }, {
            type: EditType.InputStr,
            label: '用户手机号码',
            key: 'userMobile',
            config: {
              rules: [
                { required: true, message: '请输入用户手机号码' },
                { pattern: /^1\d{10}$/gi, message: '手机号码格式不正确' }
              ]
            }
          }, {
            type: EditType.InputStr,
            label: '身份证号码',
            key: 'userIdCard',
            config: {
              rules: [
                { required: true, message: '请输入身份证号码' },
                { pattern: /\d{18}|\d{15}/, message: '身份证号码格式错误' }
              ]
            }
          }, {
            type: EditType.InputStr,
            label: '真实姓名',
            key: 'userRealName',
            config: {
              rules: [{ required: true, message: '请输入真实姓名' }]
            }
          }, {
            type: EditType.InputStr,
            label: '用户昵称',
            key: 'userNick',
            config: {
              rules: [{ required: true, message: '请输入用户昵称' }]
            },
          }, {
            type: EditType.Image,
            label: '用户头像',
            key: 'userImages',
            config: {
              valuePropName: 'fileList',
              getValueFromEvent: (e) => {
                if (Array.isArray(e)) {
                  return e;
                }
                return e && e.fileList;
              },
              rules: [
                { required: true, message: '请上传用户头像' }
              ]
            },
            itemConfig: {
              action: window.baseUrl + uploadFileUrl,
              tip: '上传用户头像',
              accept: '.jpg, .png, .bmp, .jpeg',
              name: 'files'
            },
            isShowbtn: (props) => {
              if (props.form.getFieldValue('userImages') && props.form.getFieldValue('userImages').length) {
                return false
              }
              return true
            }
          }, {
            type: EditType.InputStr,
            label: '用户手机设备ID',
            key: 'userToken',
            config: {
              rules: [
                { required: true, message: '请选择用户手机设备ID' }
              ]
            },
          }, {
            type: EditType.InputStr,
            label: '邮箱',
            key: 'userEmail',
            rules: [
              { pattern: /^\w+((-\w+)|(\.\w+))*@\w+((\.|-)\w+)*\.\w+$/, message: '邮箱格式不正确' },
              { required: true, message: '请输入邮箱' }
            ]
          }, {
            type: EditType.Select,
            label: '来源类型',
            key: 'fromType',
            options: [
              { value: 1, label: '安卓' },
              { value: 2, label: 'IOS' },
              { value: 3, label: 'PC' },
              { value: 4, label: '其他' }
            ],
            isNum: true,
            config: {
              rules: [
                { required: true, message: '请选择来源类型' }
              ]
            },
          }, {
            type: EditType.Select,
            label: '状态',
            key: 'status',
            options: [
              { value: 1, label: '正常' },
              { value: 2, label: '不正常' },
            ],
            config: {
              rules: [
                { required: true, message: '请选择状态' }
              ]
            },
          },
        ]
      }
    })(),
    getNewItemFormItem: (() => {
      let formItem;
      return () => {
        if (formItem) {
          return formItem
        } else {
          return formItem = [
            {
              type: EditType.Select,
              label: '用户类型',
              key: 'userType',
              options: [
                { value: 1, label: '注册用户' },
                { value: 2, label: '游客用户' },
                { value: 3, label: '其他' }
              ],
              config: {
                rules: [{ required: true, message: '请选择用户类型' }]
              },
              isNum: true
            }, {
              type: EditType.InputStr,
              label: '用户名',
              key: 'userName',
              config: {
                rules: [{ required: true, message: '请输入用户名' }]
              }
            }, {
              type: EditType.InputStr,
              label: '用户手机号码',
              key: 'userMobile',
              config: {
                rules: [
                  { required: true, message: '请输入用户手机号码' },
                  { pattern: /^1\d{10}$/gi, message: '手机号码格式不正确' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '身份证号码',
              key: 'userIdCard',
              config: {
                rules: [
                  { required: true, message: '请输入身份证号码' },
                  { pattern: /\d{18}|\d{15}/, message: '身份证号码格式错误' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '支付密码',
              key: 'userPayPassword',
              config: {
                rules: [
                  { required: true, message: '支付密码' },
                  { pattern: /(\d).*/, message: '支付密码只能为数字' }
                ]
              },
              itemConfig: {
                type: 'password'
              }
            }, {
              type: EditType.InputStr,
              label: '登录密码',
              key: 'userPassword',
              config: {
                rules: [
                  { required: true, message: '登录密码' }
                ]
              },
              itemConfig: {
                type: 'password'
              }
            }, {
              type: EditType.InputStr,
              label: '真实姓名',
              key: 'userRealName',
              config: {
                rules: [{ required: true, message: '请输入真实姓名' }]
              }
            }, {
              type: EditType.InputStr,
              label: '用户昵称',
              key: 'userNick',
              config: {
                rules: [{ required: true, message: '请输入用户昵称' }]
              },
            }, {
              type: EditType.Image,
              label: '用户头像',
              key: 'userImages',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传用户头像' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传用户头像',
                accept: '.jpg, .png, .bmp, .jpeg',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('userImages') && props.form.getFieldValue('userImages').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '用户手机设备ID',
              key: 'userToken',
              config: {
                rules: [
                  { required: true, message: '请选择用户手机设备ID' }
                ]
              },
            }, {
              type: EditType.InputStr,
              label: '邮箱',
              key: 'userEmail',
              rules: [
                { pattern: /^\w+((-\w+)|(\.\w+))*@\w+((\.|-)\w+)*\.\w+$/, message: '邮箱格式不正确' },
                { required: true, message: '请输入邮箱' }
              ]
            }, {
              type: EditType.Select,
              label: '来源类型',
              key: 'fromType',
              options: [
                { value: 1, label: '安卓' },
                { value: 2, label: 'IOS' },
                { value: 3, label: 'PC' },
                { value: 4, label: '其他' }
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择来源类型' }
                ]
              },
            }, {
              type: EditType.Select,
              label: '账号类型',
              key: 'merAccType',
              options: [
                { value: 1, label: '对公' },
                { value: 2, label: '对私' },
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择账号类型' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '公司编码',
              key: 'merCode',
              config: {
                rules: [
                  { required: true, message: '请输入公司编码' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司名称',
              key: 'merName',
              config: {
                rules: [
                  { required: true, message: '请输入公司名称' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '企业邮箱',
              key: 'merEmail',
              config: {
                rules: [
                  { pattern: /^\w+((-\w+)|(\.\w+))*@\w+((\.|-)\w+)*\.\w+$/, message: '企业邮箱格式不正确' },
                  { required: true, message: '请输入企业邮箱' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司地址',
              key: 'merAddr',
              config: {
                rules: [
                  { required: true, message: '请输入公司地址' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '公司网址',
              key: 'merWebsite',
              config: {
                rules: [
                  { required: true, message: '请输入公司网址' }
                ]
              }
            }, {
              type: EditType.Textarea,
              label: '公司简介',
              key: 'merIntroduct',
              config: {
                rules: [
                  { required: true, message: '请输入公司简介' }
                ]
              }
            }, {
              type: EditType.InputNum,
              label: '营业执照号',
              key: 'merBusiLicNo',
              config: {
                rules: [
                  { required: true, message: '请输入营业执照号' }
                ]
              }
            }, {
              type: EditType.Image,
              label: '营业执照',
              key: 'merBusiLicUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传营业执照' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传营业执照',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merBusiLicUrl') && props.form.getFieldValue('merBusiLicUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '企业法人',
              key: 'merLegalPerson',
              config: {
                rules: [{ required: true, message: '请输入企业法人' }]
              }
            }, {
              type: EditType.InputStr,
              label: '法人身份证号码',
              key: 'merIdCard',
              config: {
                rules: [
                  { required: true, message: '请输入法人身份证号码' },
                  { pattern: /\d{18}|\d{15}/, message: '身份证号码格式错误' }
                ],
              }
            }, {
              type: EditType.Image,
              label: '法人身份证复印件',
              key: 'merIdCardCopyUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传法人身份证复印件' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '身份证复印件',
                accept: '.jpg',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merIdCardCopyUrl') && props.form.getFieldValue('merIdCardCopyUrl').length >= 2) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.Image,
              label: '协议上传',
              key: 'merAgreementUrl',
              config: {
                valuePropName: 'fileList',
                getValueFromEvent: (e) => {
                  if (Array.isArray(e)) {
                    return e;
                  }
                  return e && e.fileList;
                },
                rules: [
                  { required: true, message: '请上传协议上传' }
                ]
              },
              itemConfig: {
                action: window.baseUrl + uploadFileUrl,
                tip: '上传协议',
                accept: '.pdf',
                name: 'files'
              },
              isShowbtn: (props) => {
                if (props.form.getFieldValue('merAgreementUrl') && props.form.getFieldValue('merAgreementUrl').length) {
                  return false
                }
                return true
              }
            }, {
              type: EditType.InputStr,
              label: '公司银行开户名',
              key: 'bankAccountName',
              config: {
                rules: [
                  { required: true, message: '请输入公司银行开户名' }
                ]
              }
            }, {
              type: EditType.InputStr,
              label: '开户银行名称',
              key: 'bankBankName',
              config: {
                rules: [{ required: true, message: '请输入开户银行名称' }]
              }
            }, {
              type: EditType.InputNum,
              label: '开户账号',
              key: 'bankBankNumber',
              rules: [
                { required: true, message: '请输入开户账号' }
              ]
            }, {
              type: EditType.Select,
              label: '商户行业类型',
              key: 'bankType',
              config: {
                rules: [
                  { required: true, message: '请输入商户行业类型' }
                ]
              },
              itemConfig: {
                options: formatParentIdOptions({
                  options: this.props.industryTypeOptions,
                  hasDefaultOption: false,
                  valueKey: 'value'
                })
              }
            }, {
              type: EditType.Select,
              label: '审核状态',
              key: 'assStatus',
              options: [
                { value: 0, label: '未审核' },
                { value: 1, label: '审核通过' },
                { value: 2, label: '审核不通过' },
              ],
              isNum: true,
              config: {
                rules: [
                  { required: true, message: '请选择审核状态' }
                ]
              },
            }, {
              type: EditType.Select,
              label: '状态',
              key: 'status',
              options: [
                { value: 1, label: '正常' },
                { value: 2, label: '不正常' },
              ],
              config: {
                rules: [
                  { required: true, message: '请选择状态' }
                ]
              },
            },
          ]
        }
      }
    })()
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    const { edit, linkTo } = this.Action
    this.state = {
      title: addTitle,
      dataSource: [],
      modalVis: false,
      modal: {},
      editId: null,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '等级',
          id: 'grade',
          type: SearchType.Select,
          dataSource: formatParentIdOptions({ options: this.props.userLevelOptions, valueKey: 'value', hasDefaultOption: false })
        }, {
          type: SearchType.String,
          label: '手机号码',
          id: 'userMobile',
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '用户名',
        dataIndex: 'userName',
        key: 'userName'
      }, {
        title: '手机号码',
        dataIndex: 'userMobile',
        key: 'userMobile'
      }, {
        title: '等级',
        dataIndex: 'totalGrade',
        key: 'totalGrade',
        render: value => {
          const options = this.props.userLevelOptions && this.props.userLevelOptions.filter(item => item.value === value)
          return hasAttr(options, [0, 'name']) || ''
        },
      }, {
        title: '注册时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => (value && moment(value).format('YYYY/MM/DD')) || moment().format('YYYY/MM/DD')
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => value == 1 ? '正常' : '不正常'
      }, {
        title: '操作',
        dataIndex: 'actions',
        key: 'actions',
        width: 250,
        render: (text, record, index) => (
          <span>
            <Button type="primary" className="action-item" onClick={() => { edit(record, index) }}>修改</Button>
            <Button type="dashed" className="action-item" onClick={() => { linkTo(record, 'capital') }}> 资金账户</Button>
            <Button type="dashed" className="action-item" onClick={() => { linkTo(record, 'setting') }}> 个人中心系统设置</Button>
            <Button type="dashed" className="action-item" onClick={() => { linkTo(record, 'safeInfo') }}> 绑卡信息</Button>
            <Button type="dashed" className="action-item" onClick={() => { linkTo(record, 'upLowRelation') }}> 上下级关系</Button>
            <Button type="dashed" className="action-item" onClick={() => { linkTo(record, 'userIntegral') }}> 用户积分</Button>
          </span>
        )
      }
    ]
    // 编辑面板内容
    this.formItems = this.Util.getNewItemFormItem()
    //新建面板表单的初始内容
    this.newItem = formateEditData(newItem, this.formItems)
    for (let i in this.newItem) {
      this.newItem[i] = {
        value: this.newItem[i]
      }
    }
  }
  render() {
    const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
    const { add, search, clearSearch, save, cancel, changePage, editItems } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <Button type="primary" onClick={add} className="action-item">新增</Button>
          <DropdownBtn
            className="action-item"
            mainLabel="批量操作"
            keyName="status"
            items={[{ label: '批量启用', value: '1' },
            { label: '批量禁用', value: '0' }]}
            onClick={(obj) => { editItems(obj) }}
          />
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize: 20,
            current,
            total: totalModels,
            onChange: changePage
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: initGetParams
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
const mapStateToProps = (state, ownProps) => {
  return {
    userLevelOptions: hasAttr(state.index.dictList.filter((item, index) => item.value === 'UserLevel'), [0, 'items']) || []
  }
}
export default connect(mapStateToProps)(UserInfo)