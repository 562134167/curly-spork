import React, { Component } from 'react';
import { Table, Modal } from 'antd';
import moment from 'moment';
import { formatData, toMoney } from '../../../../Util/reactUtil'
import { arrayToObject } from '../../../../Util/index'
import { requestEnum } from '../../../../Util/Request'
import { getFetch } from '../../../../Config/request';

const pagingUrl = '/system/proxypay/getlist',
    getChannelListUrl = '/common/getchannellist',
    getProxyPayListUrl = '/system/enums/proxypaystatus' //获取代付状态列表

export default class ProxyPay extends Component {
    constructor(props) {
        super(props);

        this.onInit();
    }
    Request = {
        get: (params) => {
            getFetch(pagingUrl, params).then(res => {
                if (res && res.status === 0) {
                    this.setState({
                        dataSource: formatData(res.models)
                    })
                }
            })
        },
        getChannelList: () => {
            getFetch(getChannelListUrl).then(res => {
                if (res && res.status == 0) {
                    this.Request.getProxyPayList();
                    this.setState({
                        channelEnum: arrayToObject({ array: res.models, keyName: 'channelId', valueName: 'remarks' }),
                    })
                }
            })
        },
        getProxyPayList: () => {
            requestEnum({ getEnumUrl: getProxyPayListUrl, context: this, enumKey: 'proxyPayStatusEnum' })
        }
    }

    onInit() {
        this.state = {
            dataSource: [],
            proxyPayStatusEnum: {},
            channelEnum: {}
        }

        this.columns = [{
            title: '序号',
            dataIndex: 'index',
            key: 'index',
            fixed: 'left',
            width: 60,
            render: (text, record, index) => (index + 1)
        }, {
            title: '真实姓名',
            dataIndex: 'realName',
            key: 'realName'
        }, {
            title: '手机号',
            dataIndex: 'mobilePhone',
            key: 'mobilePhone'
        }, {
            title: '代付金额',
            dataIndex: 'amount',
            key: 'amount',
            render: value => toMoney(value)
        }, {
            title: '提现订单号',
            dataIndex: 'withdrawSn',
            key: 'withdrawSn'
        }, {
            title: '代付单号',
            dataIndex: 'proxyPaySn',
            key: 'proxyPaySn'
        },{
            title: '第三方订单号',
            dataIndex: 'bankSn',
            key: 'bankSn'
        }, {
            title: '文件名',
            dataIndex: 'batchSn',
            key: 'batchSn'
        }, {
            title: '订单时间',
            dataIndex: 'withdrawTime',
            key: 'withdrawTime',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '代付时间',
            dataIndex: 'proxyPayTime',
            key: 'proxyPayTime',
            render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
        }, {
            title: '代付状态',
            dataIndex: 'proxyPayStatus',
            key: 'proxyPayStatus',
            render: value => this.state.proxyPayStatusEnum[value] || value
        }, {
            title: '代付渠道',
            dataIndex: 'channelId',
            key: 'channelId',
            render: value => this.state.channelEnum[value] || value
        }, {
            title: '失败原因',
            dataIndex: 'failReason',
            key: 'failReason'
        }]
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.withdrawSn !== this.props.withdrawSn) {
            this.Request.get({ withdrawSn: nextProps.withdrawSn })
        }
    }

    componentDidMount() {
        this.Request.getChannelList();
        if (this.props.withdrawSn) {
            this.Request.get({ withdrawSn: this.props.withdrawSn })
        }
    }

    render() {
        const { dataSource } = this.state;
        const { modalVis, onClose } = this.props;
        return (
            <div>
                <Modal
                    title="查看代付记录"
                    visible={modalVis}
                    onOk={onClose}
                    onCancel={onClose}
                >
                    <Table
                        scroll={{ x: 1500 }}
                        columns={this.columns}
                        dataSource={dataSource}
                    />
                </Modal>
            </div>
        )
    }
}
