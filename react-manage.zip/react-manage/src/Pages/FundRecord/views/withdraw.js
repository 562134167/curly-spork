/*
 * @Author: miccy 
 * @Date: 2018-04-11 13:52:43 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-24 15:05:47
 * 银行卡提现
 */
import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import EditCols from '../../../Common/editCols'
import { Upload, Table, Button, message, Card, notification ,Icon } from 'antd'
import { formatData, toMoney } from '../../../Util/reactUtil'
import { arrayToObject, getStore ,hasAttr} from '../../../Util'
import { getFetch, fetch } from '../../../Config/request'
import { getSchemaCols, getShowCols } from '../../../Util/Action'
import ProxyPay from './component/proxyPay'

const initGetParams = {
  pageIndex: 1
}
const mobilePhones =[]


// 为了存储每一个页面的显示列历史，给每个页面唯一的模块名
const moduleName = 'fundRecord-withdraw'

const uploadFileUrl = '/system/withdraw/excelImport'  //导入手机号码
const pagingUrl = '/system/withdraw/paging',
  payUrl = '/system/withdraw/pay',//批量代付
  refuseUrl = '/system/withdraw/refuse',//批量拒绝
  errorUrl = '/system/withdraw/error',//批量异常
  getWithdrawStatusUrl = '/system/enums/withdrawstatus',//获取提现状态枚举列表
  getWithdrawPayStatusUrl = '/system/enums/withdrawpaystatus',//获取提现代付状态枚举列表
  checkProxyPayUrl = '/system/withdraw/addWithdrawByExecl',//导入提现订单
  uploadFileUrlorder = '/system/file/uploadexcel'

class Withdraw extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      return getFetch(pagingUrl,{ ...params, addType: 1 }).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels, totalPages } = res
          const dataSource = formatData(models)
          this.setState({
            dataSource,
            totalModels,
            totalPages,
            current: params.pageIndex,
            pageSize: params.pageSize,
            selectedRowKeys: []
          })
          // 判断下拉列表的数据源是否有数据，无则请求获取数据源
          const { withdrawPayStatusOptions, withdrawStatusOptions } = this.state
          !withdrawPayStatusOptions.length && this.Request.getWithdrawPayStatus();
          !withdrawStatusOptions.length && this.Request.getWithdrawStatus();
        }
        return res
      })
    },
    getWithdrawStatus: () => {
      getFetch(getWithdrawStatusUrl).then(res => {
        if (is.array(res)) {
          const { withdrawStatusOptions } = this.state
          res.forEach(item => {
            withdrawStatusOptions.push({
              label: item.name,
              value: item.value
            })
          })
          this.setState({
            withdrawStatusEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
            withdrawStatusOptions
          })
        }
      })
    },
    getWithdrawPayStatus: () => {
      getFetch(getWithdrawPayStatusUrl).then(res => {
        if (is.array(res)) {
          const { withdrawPayStatusOptions } = this.state
          res.forEach(item => {
            withdrawPayStatusOptions.push({
              label: item.name,
              value: item.value
            })
          })
          this.setState({
            withdrawPayStatusEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
            withdrawPayStatusOptions
          })
        }
      })
    },
    pay: (params) => {
      return fetch(payUrl, { ...params}).then(res => {
        if (res.status == 0) {
          this.Request.get(this.state.getDataParams)
        }
        return res
      })
    },
    error: (params) => {
      return fetch(errorUrl, params).then(res => {
        if (res.status == 0) {
          this.Request.get(this.state.getDataParams)
        }
        return res
      })
    },
    refuse: (params) => {
      return fetch(refuseUrl, params).then(res => {
        if (res.status == 0) {
          this.Request.get(this.state.getDataParams)
        }
        return res
      })
    },
    checkProxyPay: (params) => {
        return fetch(checkProxyPayUrl, params).then(res => {
            if (res.status == 0 && res.msg) {
                const content = {
                    __html: res.msg
                }
                notification.warn({
                    message: '操作部分失败',
                    description: <span dangerouslySetInnerHTML={content}></span>,
                    duration: null
                });
            }
            return res
        })
    }
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）

  Action = {
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = queryParams.createtime[0].format('x')
        queryParams.endTime = queryParams.createtime[1].format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }
	  if(this.state.mobilePhones){
	  	params.mobilePhone = this.state.mobilePhones;
	  }
	  
      this.setState({
        getDataParams: params,
        channelIds:params.channelIds
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
      })
    },
    onShowSizeChange: (current, pageSize) => {
      const { getDataParams } = this.state
      this.setState({
        getDataParams: { ...getDataParams, pageSize, pageIndex: 1 },
        pageSize
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        getDataParams: params,
        selectedRowKeys: []
      })

    },
    handleChange: (info) => {
	    if (info.file.status !== 'uploading') {
	      console.log(info.file, info.fileList);
	    }
	    if (info.file.status === 'done') {
	      	if(info.file.response.status==0){
	      		const params = {mobilePhone:info.file.response.model, pageIndex: 1, pageSize: 50 }
	      		this.setState({
	      			getDataParams: params,
		            mobilePhones: info.file.response.model
		        })
	      		console.log(this.state.mobilePhones);
	      		message.success(`${info.file.name} 上传成功`);
	      		
	      	}
	      	else{
	      		message.error(info.file.response.msg);
	      	}
	      
		     
	    } else if (info.file.status === 'error') {
	      message.error(`${info.file.name} 上传失败`);
	    }
	},
    save: (values) => {
      const { selectedRowKeys, type } = this.state
      this.Request[type]({
        ...values,
        ids: selectedRowKeys
      }).then(res => {
        if (res.status == 0) {
          this.setState({
            [type + 'ModalVis']: false,
            selectedRowKeys: []
          })
        }
      })
    },
    onCancelPayModal: () => {
      this.setState({
        payModalVis: false,
      })
    },
    onCancelErrorModal: () => {
      this.setState({
        errorModalVis: false,
      })
    },
    onCancelRefuseModal: () => {
      this.setState({
        refuseModalVis: false,
      })
    },
    // 点击批量操作按钮
    editItems: (type) => {
      const { selectedRowKeys } = this.state
      const { channelIds } = this.state
      if (!selectedRowKeys.length) {
        message.error('请至少选中一行要操作的数据')
        return;
      }
      
      if ( type == 'pay' && selectedRowKeys.length>1 &&(channelIds ==null||channelIds =='')) {
        message.error('多项代付请先筛选可支付渠道')
        return;
      }


      this.setState({
        [type + 'ModalVis']: true,
        type
      })

    },
    changeCols: (showKeys) => {
      const showCols = getShowCols({ context: this, showKeys });
      this.setState({ showCols, colsModalVis: false });
    },
    showColsModal: () => {
      this.setState({
        colsModalVis: true
      })
    },
    hideColsModal: () => {
      this.setState({
        colsModalVis: false
      })
    },
    rowSelectionChange: (selectedRowKeys, selectedRows) => {
      const newSelectedRowKeys = [];
      const disabledSerialNumbers = [];
      selectedRows.forEach(item => {
        if (item.withdrawStatus === 2 && (item.payStatus === 0 || item.payStatus === 2)) {
          newSelectedRowKeys.push(item.id);
        } else {
          disabledSerialNumbers.push(item.orderNo);
        }
      })
      if (disabledSerialNumbers.length) {
        notification.warn({
          message: '操作警告',
          description: `以下订单：
              ${disabledSerialNumbers.join(' , ')}
              不可进行操作！
              `,
          duration: null
        });
      }
      this.setState({
        selectedRowKeys: newSelectedRowKeys
      })
    },
    showProxyPay: (record) => {
      this.setState({
        withdrawSn: record.orderNo,
        proxyPayModalVis: true
      })
    },
    onCloseProxyPay: () => {
      this.setState({
        proxyPayModalVis: false
      })
    },
   		// 导入提现订单
        showCheckProxyPay: () => {
            this.setState({
                checkProxyPayModalVis: true
            })
        },
        cancelCheckProxyPay: () => {
            this.setState({
                checkProxyPayModalVis: false
            })
        },
        saveCheckProxyPay: (values) => {
            // actionSave({ context: this, values, handleChangedData: this.Util.handleChangedData })
            this.Request.checkProxyPay(this.Util.handleChangedData(values)).then(res => {
                if (res.status == 0) {
                    this.setState({
                        checkProxyPayModalVis: false,
                    })
                }
            })
        },
  }

  Util = {
    // 根据列表源数据算出当前页面的金额总额对象
    handleChangedData: (obj) => {
            if (is.object(obj)) {
                const filePath = hasAttr(obj, ['filePath', 0, 'response', 'model'])
                if (filePath) {
                    obj.filePath = filePath
                }
            }
            return obj
    },
    getTotalAmount: (dataSource) => {
      let totalAmount = 0, amount = 0, serviceCharge = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (item.amount) {
          amount += item.amount;
        }
        if (item.totalAmount) {
          totalAmount += item.totalAmount;
        }
        if (item.serviceCharge) {
          serviceCharge += item.serviceCharge;
        }
      })
      return { totalAmount, amount, serviceCharge };
    },

    // 根据列表源数据和选中的行数据key值数组算出选中行的金额总额对象
    getSelectedAmount: (dataSource, selectedRowKeys) => {
      const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
      if (!tempSelectedRowKeys.length) {
        return { totalAmount: 0, amount: 0, serviceCharge: 0 };
      }
      const selectedString = tempSelectedRowKeys.join(',')
      let totalAmount = 0, amount = 0, serviceCharge = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (selectedString.indexOf(item.id) > -1) {
          if (item.amount) {
            amount += item.amount;
          }
          if (item.totalAmount) {
            totalAmount += item.totalAmount;
          }
          if (item.serviceCharge) {
            serviceCharge += item.serviceCharge;
          }
        }
      })
      return { totalAmount, amount, serviceCharge };
    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    const { showProxyPay } = this.Action
    this.state = {
      dataSource: [],
      modal: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      totalPages: null,
      getDataParams: {},
      pageSize: 50,
      payModalVis: false,//支付密码输入面板
      refuseModalVis: false,
      errorModalVis: false,
      totalAmountObj: {},//当前页总金额
      selectedAmountObj: {},//已选择的项的总金额
      showCols: [],
      colsModalVis: false, //修改显示列面板
      withdrawStatusOptions: [],
      withdrawPayStatusOptions: [],
      withdrawStatusEnum: {},
      withdrawPayStatusEnum: {},
      proxyPayModalVis: false,
      channelIds: null,
      withdrawSn: null,
      mobilePhones:null,
      checkProxyPayModalVis: false,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone',
        }, {
          type: SearchType.Select,
          label: '用户订单状态',
          id: 'withdrawStatus',
          dataSource: this.state.withdrawStatusOptions
        }, {
          type: SearchType.Select,
          label: '代付状态',
          id: 'payStatus',
          dataSource: this.state.withdrawPayStatusOptions
        }, {
          type: SearchType.Select,
          label: '是否分批次',
          id: 'isBatch',
          dataSource: [{
            label: '是',
            value: 1
          }, {
            label: '否',
            value: 0
          }]
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime',
          config: {
            showTime: true,
            format: "YYYY-MM-DD HH:mm:ss",
          }
        }, {
          type: SearchType.String,
          label: '大额提现批次号',
          id: 'batchNo'
        }, {
          type: SearchType.String,
          label: '平台唯一订单号',
          id: 'orderNo'
        }, {
          type: SearchType.String,
          label: '第三方订单号',
          id: 'bankSn',
        }, {
          type: SearchType.Select,
          label: '代付渠道',
          id: 'substituteChannelId',
          dataSource: [{
            label: '通联快捷',
            value: 1
          }, {
            label: '乾易付',
            value: 9
          }]
        }, {
          type: SearchType.Select,
          label: '可支持代付渠道',
          id: 'channelIds',
          dataSource: [{
            label: '通联快捷',
            value: 1
          }, {
            label: '乾易付',
            value: 9
          }, {
            label: '维创',
            value: 12
          }]
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        fixed: 'left',
        width: 40,
        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
      },
      {
        title: '用户名',
        dataIndex: 'realName',
        key: 'realName',
        fixed: 'left',
        width: 60,
      }, {
        title: '手机号',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone',
        fixed: 'left',
        width: 100,
        // width: this.state.hiddenArray.indexOf('mobilePhone') > -1 ? 0 : 'auto'
      }, {
        title: '提现金额',
        dataIndex: 'totalAmount',
        key: 'totalAmount',
        fixed: 'left',
        width: 90,
        render: value => toMoney(value),
        sorter: (a, b) => a.totalAmount - b.totalAmount
      }, {
        title: '到账金额',
        dataIndex: 'amount',
        key: 'amount',
        width: 100,
        render: value => toMoney(value),
        sorter: (a, b) => a.amount - b.amount
      }, {
        title: '提现手续费',
        dataIndex: 'serviceCharge',
        key: 'serviceCharge',
        width: 100,
        render: value => toMoney(value),
        sorter: (a, b) => a.serviceCharge - b.serviceCharge
      }, {
        title: '银行卡名称',
        dataIndex: 'bankName',
        key: 'bankName'
      },
      {
        title: '银行卡账号',
        dataIndex: 'cardNo',
        key: 'cardNo',
        render: (text, record, index) => {
          return record.cardNo || record.alipayAccount || record.wechatAccount
        }
      },
      {
        title: '用户订单状态',
        dataIndex: 'withdrawStatus',
        key: 'withdrawStatus',
        render: (value, record) => this.state.withdrawStatusEnum[value] || value
      },
      {
        title: '代付状态',
        dataIndex: 'payStatus',
        key: 'payStatus',
        render: (value, record) => this.state.withdrawPayStatusEnum[value] || value
      }, {
        title: '申请时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
        sorter: (a, b) => a.createTime - b.createTime
      }, {
        title: '代付时间',
        dataIndex: 'payTime',
        key: 'payTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
        sorter: (a, b) => a.payTime - b.payTime
      }, {
        title: '代付到账时间',
        dataIndex: 'finishTime',
        key: 'finishTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
        sorter: (a, b) => a.finishTime - b.finishTime
      }, {
        title: '提现订单编号',
        dataIndex: 'orderNo',
        key: 'orderNo'
      }, {
        title: '大额提现批次号',
        dataIndex: 'batchNo',
        key: 'batchNo'
      }, {
        title: '是否分批次',
        dataIndex: 'isBatch',
        key: 'isBatch',
        render: value => value == 1 ? '是' : '否'
      }, {
        title: '代付失败理由',
        dataIndex: 'reason',
        key: 'reason',
        width: 150
      }, {
        title: '拒绝代付理由',
        dataIndex: 'handleResult',
        key: 'handleResult',
        width: 150
      }, {
        title: '管理员备注失败理由',
        dataIndex: 'handleRemark',
        key: 'handleRemark',
        width: 150
      }, {
        title: '代付渠道',
        dataIndex: 'substituteChannelIdName',
        key: 'substituteChannelIdName',
      },{
        title: '操作',
        dataIndex: 'action',
        key: 'action',
        fixed: 'right',
        render: (value, record) => {
          return (record.payStatus !== 0 ? (<span>
            <Button type="primary" onClick={() => showProxyPay(record)}>查看代付</Button>
          </span>) : null)

        }
      }
    ];
    this.schemaCols = getSchemaCols({ context: this });
    this.errorFormItems = [
      {
        type: EditType.InputStr,
        key: 'reason',
        label: '用户失败理由',
        config: {
          rules: [
            { required: true, message: '请填写用户失败理由' }
          ],
        },
      }, {
        type: EditType.InputStr,
        key: 'remark',
        label: '管理员备注失败理由',
        config: {
          rules: [
            { required: true, message: '请填写管理员备注失败理由' }
          ],
        },
      }, {
        type: EditType.InputStr,
        key: 'payPassword',
        label: '支付操作密码',
        itemConfig: {
          type: 'password'
        },
        config: {
          rules: [
            { required: true, message: '请填写支付操作密码' }
          ],
        },
      }
    ];
    this.refuseFormItems = [
      {
        type: EditType.InputStr,
        key: 'reason',
        label: '用户失败理由',
        config: {
          rules: [
            { required: true, message: '请填写用户失败理由' }
          ],
        },
      }, {
        type: EditType.InputStr,
        key: 'payPassword',
        label: '支付操作密码',
        itemConfig: {
          type: 'password'
        },
        config: {
          rules: [
            { required: true, message: '请填写支付操作密码' }
          ],
        },
      }
    ];
    this.payFormItems = [
      {
        type: EditType.InputStr,
        key: 'payPassword',
        label: '支付操作密码',
        itemConfig: {
          type: 'password'
        },
        config: {
          rules: [
            { required: true, message: '请填写支付操作密码' }
          ],
        },
      },
      {
        type: EditType.Select,
        key: 'channelId',
        label: '代付渠道',
        itemConfig: {
                    options: [
                        { value: 1, label: '通联快捷' },
                        { value: 9, label: '乾易付' },
                        { value: 12, label: '维创' },
                    ],
                    disabled: false
        },
        config: {
          rules: [
            { required: true, message: '请选择代付渠道' }
          ],
        },
      }
    ];
    // 编辑面板内容
        this.checkProxyPayFormItems = [
            {
                type: EditType.Image,
                label: 'excel文件',
                key: 'filePath',
                config: {
                    valuePropName: 'fileList',
                    getValueFromEvent: (e) => {
                        console.log(e);
                        if (Array.isArray(e)) {
                            return e;
                        }
                        return e && e.fileList;
                    },
                    rules: [
                        { required: true, message: '请上传excel文件' }
                    ]
                },
                itemConfig: {
                    action: window.baseUrl + uploadFileUrlorder,
                    tip: '上传excel文件',
                    accept: '.xls, .xlsx',
                    name: 'files',
                    listType: 'text',
                },
                isImageAutoHandle: false,
                isShowbtn: (props) => {
                    if (props.form.getFieldValue('filePath') && props.form.getFieldValue('filePath').length) {
                        return false
                    }
                    return true
                }
            }, {
                type: EditType.InputStr,
                label: '支付密码',
                key: 'payPassword',
                config: {
                    rules: [
                        { required: true, message: '请输入支付密码' }
                    ]
                },
                itemConfig: {
                    type: 'password'
                }
            }
        ]
  }
  render() {
    const { mobilePhones, dataSource, selectedRowKeys, current, totalModels, pageSize, payModalVis, errorModalVis, refuseModalVis, totalAmountObj, selectedAmountObj, colsModalVis, showCols, withdrawSn, proxyPayModalVis ,checkProxyPayModalVis} = this.state
    const { handleChange, changePage, search, clearSearch, onShowSizeChange, save, editItems, onCancelPayModal, onCancelErrorModal, onCancelRefuseModal, changeCols, showColsModal, hideColsModal, rowSelectionChange, onCloseProxyPay , showCheckProxyPay, saveCheckProxyPay, cancelCheckProxyPay,} = this.Action
    const phonelist = {
	  name: 'file',
	  accept: '.xls, .xlsx',
      listType: 'text',
      showUploadList:false,
	  action:window.baseUrl + uploadFileUrl,
	  headers: {
	    authorization: 'authorization-text',
	  },
	  onChange:handleChange,
	  
	}
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
	        <Upload {...phonelist}>
			  <Button className="action-item" type="primary" ghost>
			    <Icon type="upload" /> 导入手机号
			  </Button>
			</Upload>
		</Card>
        <Card>
          <Button className="action-item" type="primary" ghost onClick={() => editItems('pay')}>批量代付</Button>
          <Button className="action-item" type="primary" ghost onClick={() => editItems('refuse')}>批量拒绝</Button>
          <Button className="action-item" type="primary" ghost onClick={() => editItems('error')}>批量异常</Button>
          <Button className="action-item" type="primary" ghost onClick={showColsModal}>修改显示列</Button>

        </Card>
        
        <Card>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页总提现金额：{parseFloat((totalAmountObj.totalAmount || 0) / 100).toFixed(2) + '元'}，已选中的项的总提现金额：{parseFloat((selectedAmountObj.totalAmount || 0) / 100).toFixed(2) + '元'}</p>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页总到账金额：{parseFloat((totalAmountObj.amount || 0) / 100).toFixed(2) + '元'}，已选中的项的总到账金额：{parseFloat((selectedAmountObj.amount || 0) / 100).toFixed(2) + '元'}</p>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页总提现手续费：{parseFloat((totalAmountObj.serviceCharge || 0) / 100).toFixed(2) + '元'}，已选中的项的总提现手续费：{parseFloat((selectedAmountObj.serviceCharge || 0) / 100).toFixed(2) + '元'}</p>
        </Card>
        
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: rowSelectionChange
          }}
          scroll={{ x: 2530 }}
          columns={showCols}
          dataSource={dataSource}
          pagination={{
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            showSizeChanger: true,
            showTotal: (total, range) => `共 ${total} 条记录`,
            onShowSizeChange: onShowSizeChange,
            pageSizeOptions: ['15','50', '200', '500']
          }}
        />
        <EditPanel
          title="批量异常"
          modalVis={errorModalVis}
          formItems={this.errorFormItems}
          onSave={save}
          onCancel={onCancelErrorModal}
        />
        <EditPanel
          title="批量拒绝"
          modalVis={refuseModalVis}
          formItems={this.refuseFormItems}
          onSave={save}
          onCancel={onCancelRefuseModal}
        />
        <EditPanel
          title="批量代付"
          modalVis={payModalVis}
          formItems={this.payFormItems}
          onSave={save}
          onCancel={onCancelPayModal}
        />
        <EditCols
          moduleName={moduleName}
          changeCols={changeCols}
          cancel={hideColsModal}
          visible={colsModalVis}
          dataSource={this.schemaCols} />
        <EditPanel
            title='导入提现订单'
            modalVis={checkProxyPayModalVis}
            formItems={this.checkProxyPayFormItems}
            onSave={saveCheckProxyPay}
            onCancel={cancelCheckProxyPay}
        />
        <ProxyPay
          modalVis={proxyPayModalVis}
          onClose={onCloseProxyPay}
          withdrawSn={withdrawSn}
        />
      </div>
    )
  }
  componentDidMount() {
    // 将当前页面的历史显示列存在localStorage，如果有历史数据，则显示历史列，否则显示全部列
    let showCols = null;
    const showKeysString = getStore(moduleName);
    if (showKeysString) {
      showCols = getShowCols({ context: this, showKeys: JSON.parse(showKeysString) });
    }
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize },
      showCols: showCols || this.columns
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, selectedRowKeys, dataSource } = this.state
    const { get } = this.Request
    const { getSelectedAmount, getTotalAmount } = this.Util
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }

    // 选中的项发生变化时，计算已选中的项的总金额
    if (nextState.selectedRowKeys !== selectedRowKeys) {
      this.setState({
        selectedAmountObj: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
      })
    }
    // 当前页的数据发生变化时，计算当前页的总金额
    if (nextState.dataSource !== dataSource) {
      this.setState({
        totalAmountObj: getTotalAmount(nextState.dataSource)
      })
    }
  }
}

export default Withdraw
