import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
// import EditPanel from '../../../Common/editPanel'
// import * as EditType from '../../../Common/editType'
import { Table, message, Card } from 'antd'
import { formatData, flattenObj, handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { hasAttr } from '../../../Util'
import { getFetch } from '../../../Config/request'

const initGetParams = {
  // keyword: '',
  pageIndex: 1,
  // pageSize: 20
}
// 提现状态下拉框选项
const rechargeStatusOptions = [
  { label: '充值中', value: 1 },
  { label: '充值成功', value: 2 },
  { label: '充值失败', value: 3 },
]

const pagingUrl = '/system/recharge/paging'
// const getSourceUrl = ''

export default class Withdraw extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      /**@param {Object} params 
       * 数据格式
       * {
        @param {String} keyword,
        @param {Number} pageIndex,
        @param {Number} pageSize'
      }
       */
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['recharge']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex,
            pageSize: params.pageSize,
            selectedRowKeys: []
          })
        }
        return res
      })
    },
    // 获取渠道商名称
    // getSource: () => {
    //   return getFetch(getSourceUrl).then(res => {
    //     if (res.models && res.models.length) {
    //       this.setState({
    //         sourceOptions: res.models
    //       })
    //     }
    //     return res
    //   })
    // }
  }

  Util = {
    getTotalAmount: (dataSource) => {
      let totalAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (item.amount) {
          totalAmount += item.amount
        }
      })
      return totalAmount
    },
    getSelectedAmount: (dataSource, selectedRowKeys) => {
      const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
      if (!tempSelectedRowKeys.length) {
        return 0
      }
      const selectedString = tempSelectedRowKeys.join(',')
      let selectedAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (selectedString.indexOf(item.id) > -1 && item.amount) {
          selectedAmount += item.amount
        }
      })
      return selectedAmount
    }
  }

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
        message.error('请输入正确的手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }

      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
      })
    },
    onShowSizeChange: (current, pageSize) => {
      const { getDataParams } = this.state
      this.setState({
        getDataParams: { ...getDataParams, pageSize, pageIndex: 1 },
        pageSize
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })

    }
  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    this.state = {
      dataSource: [],
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
      type: '',//批量的类型
      sourceOptions: [],
      totalAmount: 0,
      selectedAmount: 0,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号码',
          id: 'mobilePhone',
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime'
        }
        // , {
        //   type: SearchType.Select,
        //   label: '充值状态',
        //   id: 'rechargeStatus',
        //   dataSource: rechargeStatusOptions,
        // }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        fixed: 'left',
        width: 60,
        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
      },
      // {
      //   title: '用户名',
      //   dataIndex: 'userName',
      //   key: 'userName',
      //   fixed: 'left',
      //   width: 110,
      // },
      {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName',
        fixed: 'left',
        width: 110,
      }, {
        title: '手机号',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone'
      }, {
        title: '金额',
        dataIndex: 'amount',
        key: 'amount',
        render: value => toMoney(value)
      }, {
        title: '手续费',
        dataIndex: 'serviceCharge',
        key: 'serviceCharge',
        render: value => toMoney(value)
      },/* {
        title: '使用的通道',
        dataIndex: 'channelId',
        key: 'channelId',
        render: id => {
          const options = this.state.sourceOptions
          const option = options.filter(item => item.id == id)
          return hasAttr(option, [0, 'name'])
        }
      },*/ {
        title: '流水号',
        dataIndex: 'serialNumber',
        key: 'serialNumber'
      }, {
        title: '充值状态',
        dataIndex: 'rechargeStatus',
        key: 'rechargeStatus',
        render: value => {
          const option = rechargeStatusOptions.filter(item => item.value == value)
          return hasAttr(option, [0, 'label'])
        },
        // sorter: (a, b) => a.rechargeStatus - b.rechargeStatus,
      }, {
        title: '支付成功时间',
        dataIndex: 'payTime',
        key: 'payTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }
    ];
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels, pageSize, totalAmount, selectedAmount } = this.state
    const { changePage, search, clearSearch, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页总打款金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的总打款金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            }
          }}
          scroll={{ x: 900 }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            showSizeChanger: true,
            showTotal: (total, range) => `共 ${total} 条记录`,
            onShowSizeChange: onShowSizeChange,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
    // this.Request.getSource()
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, selectedRowKeys, dataSource } = this.state
    const { get } = this.Request
    const { getSelectedAmount, getTotalAmount } = this.Util

    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }

    // 选中的项发生变化时，计算已选中的项的总金额
    if (nextState.selectedRowKeys !== selectedRowKeys) {
      this.setState({
        selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
      })
    }
    // 当前页的数据发生变化时，计算当前页的总金额
    if (nextState.dataSource !== dataSource) {
      this.setState({
        totalAmount: getTotalAmount(nextState.dataSource)
      })
    }
  }
}
