import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
// import EditPanel from '../../../Common/editPanel'
// import * as EditType from '../../../Common/editType'
import { Table, message, Card } from 'antd'
import { formatData, flattenObj, handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { hasAttr, arrayToObject } from '../../../Util'
import { getFetch } from '../../../Config/request'

const initGetParams = {
  pageIndex: 1,
}

const statusOptions = [
  { label: '成功', value: 1 },
  { label: '失败', value: 2 },
]
const pagingUrl = '/system/transfer/paging',
  getTransferStatusListUrl = '/system/enums/transferstatus'


export default class Transfer extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      /**@param {Object} params 
       * 数据格式
       * {
        @param {String} keyword,
        @param {Number} pageIndex,
        @param {Number} pageSize'
      }
       */
      return getFetch(pagingUrl, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['withdraw']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex,
            pageSize: params.pageSize,
            selectedRowKeys: []
          })
          !this.state.transferStatusOptions.length && this.Request.getTransferStatusList();
        }
        return res
      })
    },
    getTransferStatusList: () => {
      getFetch(getTransferStatusListUrl).then(res => {
        if (is.array(res)) {
          const { transferStatusOptions } = this.state
          res.forEach(item => {
            transferStatusOptions.push({
              label: item.name,
              value: item.value
            })
          })
          this.setState({
            transferStatusEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
            transferStatusOptions
          })
        }
      })
    }
  }

  Util = {
    getTotalAmount: (dataSource) => {
      let totalAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (item.amount) {
          totalAmount += item.amount
        }
      })
      return totalAmount
    },
    getSelectedAmount: (dataSource, selectedRowKeys) => {
      const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
      if (!tempSelectedRowKeys.length) {
        return 0
      }
      const selectedString = tempSelectedRowKeys.join(',')
      let selectedAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (selectedString.indexOf(item.id) > -1 && item.amount) {
          selectedAmount += item.amount
        }
      })
      return selectedAmount
    }
  }

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.toMobilePhone && (!mobileRegx.test(queryParams.toMobilePhone))) {
        message.error('请输入正确的转入手机号码')
        return;
      }
      if (queryParams.fromMobilePhone && (!mobileRegx.test(queryParams.fromMobilePhone))) {
        message.error('请输入正确的转出手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }

      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
      })
    },
    onShowSizeChange: (current, pageSize) => {
      const { getDataParams } = this.state
      this.setState({
        getDataParams: { ...getDataParams, pageSize, pageIndex: 1 },
        pageSize
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },


  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    // const { view, unfreeze } = this.Action
    this.state = {
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
      totalAmount: 0,
      selectedAmount: 0,
      transferStatusOptions: [],
      transferStatusEnum: {}
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '转入手机号码',
          id: 'toMobilePhone',
        }, {
          type: SearchType.String,
          label: '转出手机号码',
          id: 'fromMobilePhone'
        }, {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime'
        }, {
          type: SearchType.Select,
          label: '转账状态',
          id: 'transferStatus',
          dataSource: this.state.transferStatusOptions
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        fixed: 'left',
        width: 50,
        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index - 0 + 1)
      },
      {
        title: '转出姓名',
        dataIndex: 'fromRealName',
        key: 'fromRealName',
        fixed: 'left',
        width: 100,
      }, {
        title: '转出手机号',
        dataIndex: 'fromMobilePhone',
        key: 'fromMobilePhone'
      }, {
        title: '转入姓名',
        dataIndex: 'toRealName',
        key: 'toRealName',
      }, {
        title: '转入手机号',
        dataIndex: 'toMobilePhone',
        key: 'toMobilePhone'
      }, {
        title: '金额',
        dataIndex: 'amount',
        key: 'amount',
        render: value => toMoney(value)
      }, {
        title: '流水号',
        dataIndex: 'serialNumber',
        key: 'serialNumber',
      }, {
        title: '向对方喊话',
        dataIndex: 'desc',
        key: 'desc'
      }, {
        title: '转账状态',
        dataIndex: 'transferStatus',
        key: 'transferStatus',
        render: value => this.state.transferStatusEnum[value] || value
      }, {
        title: '状态',
        dataIndex: 'status',
        key: 'status',
        render: value => {
          const option = statusOptions.filter(item => item.value == value)
          return hasAttr(option, [0, 'label'])
        }
      }, {
        title: '转账时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }
    ];
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels, pageSize, totalAmount, selectedAmount } = this.state
    const { changePage, search, clearSearch, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页总打款金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的总打款金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          scroll={{ x: 900 }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            showSizeChanger: true,
            showTotal: (total, range) => `共 ${total} 条记录`,
            onShowSizeChange: onShowSizeChange,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, selectedRowKeys, dataSource } = this.state
    const { get } = this.Request
    const { getSelectedAmount, getTotalAmount } = this.Util

    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }

    // 选中的项发生变化时，计算已选中的项的总金额
    if (nextState.selectedRowKeys !== selectedRowKeys) {
      this.setState({
        selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
      })
    }
    // 当前页的数据发生变化时，计算当前页的总金额
    if (nextState.dataSource !== dataSource) {
      this.setState({
        totalAmount: getTotalAmount(nextState.dataSource)
      })
    }
  }
}
