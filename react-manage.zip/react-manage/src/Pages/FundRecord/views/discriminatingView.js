import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
// import EditPanel from '../../../Common/editPanel'
// import * as EditType from '../../../Common/editType'
import { Table, message, Card } from 'antd'
import { formatData, flattenObj, handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { hasAttr, arrayToObject } from '../../../Util'
import { getFetch } from '../../../Config/request'

const initGetParams = {
  pageIndex: 1,
}


const pagingIntegralExchange = '/system/userCardApply/paging'


export default class discriminatingView extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      /**@param {Object} params 
       * 数据格式
       * {
        @param {String} keyword,
        @param {Number} pageIndex,
        @param {Number} pageSize'
      }
       */
      return getFetch(pagingIntegralExchange, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['withdraw']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex,
            pageSize: params.pageSize,
            selectedRowKeys: []
          })
          !this.state.exchangeStatusOptions.length && this.Request.getTransferStatusList();
          !this.state.exchangecardOptions.length && this.Request.getTransfercardList();
        }
        return res
      })
    },
    getTransferStatusList: () => {
        	const statusOptions = [
        		{ label: '未鉴权', value: '0' },
					  { label: '鉴权通过', value: 1 },
					  { label: '鉴权不通过', value: 2 }
					]
          const { exchangeStatusOptions } = this.state
          statusOptions.forEach(item => {
            exchangeStatusOptions.push({
              label: item.label,
              value: item.value
            })
          })
          this.setState({
            exchangeStatusEnum: arrayToObject({ array: statusOptions, keyName: 'value', valueName: 'label' }),
            exchangeStatusOptions
             
            
          })
          console.log(this.state.exchangeStatusEnum);
         
    },
    getTransfercardList: () => {
        	const cardOptions = [
					  { label: '储蓄卡', value:'CashCard' },
					  { label: '信用卡', value: 'CreditCard' }
					]
          const { exchangecardOptions } = this.state
          cardOptions.forEach(item => {
            exchangecardOptions.push({
              label: item.label,
              value: item.value
            })
          })
          this.setState({
            exchangecardEnum: arrayToObject({ array: cardOptions, keyName: 'value', valueName: 'label' }),
            exchangecardOptions
            
          })
          console.log(this.state.exchangecardEnum);
    }
  }

  Util = {
    getTotalAmount: (dataSource) => {
      let totalAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (item.integralNum) {
          totalAmount += item.integralNum
        }
      })
      return totalAmount
    },
    getSelectedAmount: (dataSource, selectedRowKeys) => {
      const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
      if (!tempSelectedRowKeys.length) {
        return 0
      }
      const selectedString = tempSelectedRowKeys.join(',')
      let selectedAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (selectedString.indexOf(item.key) > -1 && item.integralNum) {
          selectedAmount += item.integralNum
        }
      })
      return selectedAmount
    }
  }

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
        message.error('请输入正确的转出手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
      })
    },
    onShowSizeChange: (current, pageSize) => {
      const { getDataParams } = this.state
      this.setState({
        getDataParams: { ...getDataParams, pageSize, pageIndex: 1 },
        pageSize
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },


  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    // const { view, unfreeze } = this.Action
    this.state = {
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
      totalAmount: 0,
      selectedAmount: 0,
      StatusOptions: [],
			exchangeStatusOptions:[],
      exchangeStatusEnum: {},
      cardOptions:[],
			exchangecardOptions:[],
			exchangecardEnum: {},
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '注册手机号',
          id: 'registerPhone'
        }, {
          type: SearchType.Select,
          label: '鉴权状态',
          id: 'status',
          dataSource: this.state.exchangeStatusOptions
        },{
          type: SearchType.Select,
          label: '卡类型',
          id: 'cardType',
          dataSource: this.state.exchangecardOptions
        },{
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        fixed: 'left',
        width: 50,
        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index - 0 + 1)
      },{
        title: '姓名',
        dataIndex: 'userName',
        key: 'userName',
        fixed: 'left',
        width: 80,
      }, {
        title: '注册手机号',
        dataIndex: 'registerPhone',
        key: 'registerPhone',
      }, {
        title: '卡类型',
        dataIndex: 'cardType',
        key: 'cardType',
        render: value => {
                    if (value == 'CashCard') {
                        return '储蓄卡'
                    } else if (value == 'CreditCard') {
                        return '信用卡'	
                    }
				}
      }, {
        title: '身份证号码',
        dataIndex: 'idCard',
        key: 'idCard'
      }, {
        title: '银行卡',
        dataIndex: 'cardNo',
        key: 'cardNo',
      }, {
        title: '预留手机号',
        dataIndex: 'reservePhone',
        key: 'reservePhone',
        
      }, {
        title: '信用卡有效期',
        dataIndex: 'expirationdate',
        key: 'expirationdate',
        render: value => value && moment(value).format('YYYY-MM')
      }
      , {
        title: '信用卡CVV码',
        dataIndex: 'cvv',
        key: 'cvv',
      }, {
        title: '提交时间',
        dataIndex: 'applyTime',
        key: 'applyTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '鉴权状态',
        dataIndex: 'status',
        key: 'status',
        render: value => {
                    if (value == 0) {
                        return '未鉴权'
                    } else if (value == 1) {
                        return '鉴权通过'
                    } else if (value == 2) {
                        return '鉴权不通过'
                    } 
				}
        
      }, {
        title: '鉴权失败原因',
        dataIndex: 'checkFailReason',
        key: 'checkFailReason',
      }
    ];
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels, pageSize, totalAmount, selectedAmount } = this.state
    const { changePage, search, clearSearch, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          scroll={{ x: 900 }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            showSizeChanger: true,
            showTotal: (total, range) => `共 ${total} 条记录`,
            onShowSizeChange: onShowSizeChange,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }
	componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
  }
}
