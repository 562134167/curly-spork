/*
 * @Author: miccy 
 * @Date: 2018-04-19 15:25:54 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-20 17:15:20
 * 达雍实名审核专用
 */
import React, { Component } from 'react'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import { Table, Button, message } from 'antd'
import { arrayToObject, getStore } from '../../../Util'
import { formatData, formateEditData, flattenObj, toMoney} from '../../../Util/reactUtil'
import { fetch, getFetch } from '../../../Config/request'
const title = '查看审核信息',
    initGetParams = {
        pageIndex: 1,
        pageSize: 50
    };
const pagingUrl = '/system/withdraw/paging',
getWithdrawStatusUrl = '/system/enums/withdrawstatus',//获取提现状态枚举列表
getWithdrawPayStatusUrl = '/system/enums/withdrawpaystatus'//获取提现代付状态枚举列表

class WithdrawSimple extends Component {
    constructor(props) {
       	super(props)
        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
			
            return getFetch(pagingUrl, params).then(res => {
                if (res && is.array(res.models)) {
                    const { models, totalModels, totalPages } = res
                    const dataSource = formatData(flattenObj(models, ['userSafeInfo', 'userAuditor']))
                    this.setState({
                        dataSource,
                        totalModels,
                        totalPages,
                        current: params.pageIndex
                    })
                }
                return res
            })
        },
        getWithdrawStatus: () => {
	      getFetch(getWithdrawStatusUrl).then(res => {
	        if (is.array(res)) {
	          const { withdrawStatusOptions } = this.state
	          res.forEach(item => {
	            withdrawStatusOptions.push({
	              label: item.name,
	              value: item.value
	            })
	          })
	          this.setState({
	            withdrawStatusEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
	            withdrawStatusOptions
	          })
	        }
	      })
	    },
	    getWithdrawPayStatus: () => {
	      getFetch(getWithdrawPayStatusUrl).then(res => {
	        if (is.array(res)) {
	          const { withdrawPayStatusOptions } = this.state
	          res.forEach(item => {
	            withdrawPayStatusOptions.push({
	              label: item.name,
	              value: item.value
	            })
	          })
	          this.setState({
	            withdrawPayStatusEnum: arrayToObject({ array: res, keyName: 'value', valueName: 'name' }),
	            withdrawPayStatusOptions
	          })
	        }
	      })
	    },
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        // 查
        search: (value) => {
            const mobileRegx = /^1\d{10}$/gi
            if (value.mobilePhone && (!mobileRegx.test(value.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }

            this.setState({
                getDataParams: { ...initGetParams, ...value }
            })
        },
        // 清空查找条件
        clearSearch: () => {
            this.setState({
                dataSource: []
            })
        },
        cancel: () => {
            this.setState({
                modalVis: false
            })
        },
        changePage: (page, pageSize) => {
            const { getDataParams } = this.state
            const params = { ...getDataParams, pageIndex: page }
            this.setState({
                selectedRowKeys: [],
                getDataParams: params
            })
        },
    }
    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        // const { selectedRowKeys } = this.state;
        const { edit } = this.Action
        this.state = {
            dataSource: [],
	        modal: {},
	        selectedRowKeys: [],
	        current: 1,
	        totalModels: null,
	        totalPages: null,
	        getDataParams: {},
	        pageSize: 50,
	        payModalVis: false,//支付密码输入面板
	        refuseModalVis: false,
	        errorModalVis: false,
	        totalAmountObj: {},//当前页总金额
	        selectedAmountObj: {},//已选择的项的总金额
	        showCols: [],
	        colsModalVis: false, //修改显示列面板
	        withdrawStatusOptions: [],
	        withdrawPayStatusOptions: [],
	        withdrawStatusEnum: {},
	        withdrawPayStatusEnum: {},
	        proxyPayModalVis: false,
	        withdrawSn: null,
	      	mobilePhones:null,
        }
        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone',
                }, {
		          type: SearchType.Select,
		          label: '用户订单状态',
		          id: 'withdrawStatus',
		          dataSource: this.state.withdrawStatusOptions
		        }, {
		          type: SearchType.Select,
		          label: '代付状态',
		          id: 'payStatus',
		          dataSource: this.state.withdrawPayStatusOptions
		        }
            ]
        }
        // 表头设置
        // 表头设置
	    this.columns = [
	      {
	        title: '序号',
	        dataIndex: 'index',
	        key: 'index',
	        fixed: 'left',
	        width: 40,
	        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
	      },
	      {
	        title: '用户名',
	        dataIndex: 'realName',
	        key: 'realName',
	        fixed: 'left',
	        width: 60,
	      }, {
	        title: '手机号',
	        dataIndex: 'mobilePhone',
	        key: 'mobilePhone',
	        width: 100,
	        // width: this.state.hiddenArray.indexOf('mobilePhone') > -1 ? 0 : 'auto'
	      }, {
	        title: '提现金额',
	        dataIndex: 'totalAmount',
	        key: 'totalAmount',
	        width: 100,
	        render: value => toMoney(value),
	        sorter: (a, b) => a.totalAmount - b.totalAmount
	      }, {
	        title: '到账金额',
	        dataIndex: 'amount',
	        key: 'amount',
	        width: 100,
	        render: value => toMoney(value),
	        sorter: (a, b) => a.amount - b.amount
	      }, {
	        title: '提现手续费',
	        dataIndex: 'serviceCharge',
	        key: 'serviceCharge',
	        width: 100,
	        render: value => toMoney(value),
	        sorter: (a, b) => a.serviceCharge - b.serviceCharge
	      }, {
	        title: '银行卡名称',
	        dataIndex: 'bankName',
	        key: 'bankName'
	      },
	      {
	        title: '银行卡账号',
	        dataIndex: 'cardNo',
	        key: 'cardNo',
	        render: (text, record, index) => {
	          return record.cardNo || record.alipayAccount || record.wechatAccount
	        }
	      },
	      {
	        title: '用户订单状态',
	        dataIndex: 'withdrawStatus',
	        key: 'withdrawStatus',
	        render: (value, record) => this.state.withdrawStatusEnum[value] || value
	      },
	      {
	        title: '代付状态',
	        dataIndex: 'payStatus',
	        key: 'payStatus',
	        render: (value, record) => this.state.withdrawPayStatusEnum[value] || value
	      }, {
	        title: '申请时间',
	        dataIndex: 'createTime',
	        key: 'createTime',
	        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
	        sorter: (a, b) => a.createTime - b.createTime
	      }, {
	        title: '代付时间',
	        dataIndex: 'payTime',
	        key: 'payTime',
	        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
	        sorter: (a, b) => a.payTime - b.payTime
	      }, {
	        title: '代付到账时间',
	        dataIndex: 'finishTime',
	        key: 'finishTime',
	        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss'),
	        sorter: (a, b) => a.finishTime - b.finishTime
	      }, {
	        title: '提现订单编号',
	        dataIndex: 'orderNo',
	        key: 'orderNo'
	      }, {
	        title: '大额提现批次号',
	        dataIndex: 'batchNo',
	        key: 'batchNo'
	      }, {
	        title: '是否分批次',
	        dataIndex: 'isBatch',
	        key: 'isBatch',
	        render: value => value == 1 ? '是' : '否'
	      }, {
	        title: '代付失败理由',
	        dataIndex: 'reason',
	        key: 'reason',
	        width: 150
	      }, {
	        title: '拒绝代付理由',
	        dataIndex: 'handleResult',
	        key: 'handleResult',
	        width: 150
	      }, {
	        title: '管理员备注失败理由',
	        dataIndex: 'handleRemark',
	        key: 'handleRemark',
	        width: 150
	      }
	    ];
	}
    render() {
        const { dataSource, title, modalVis, modal, selectedRowKeys, current, totalModels } = this.state
        const { search, clearSearch, cancel, changePage } = this.Action
        return (
            <div className="file-manage">
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Table
                    rowSelection={{
                        selectedRowKeys: selectedRowKeys,
                        onChange: (selectedRowKeys, selectedRows) => {
                            this.setState({
                                selectedRowKeys
                            })
                        },
                    }}
                    scroll={{ x: 2530 }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        current,
                        total: totalModels,
                        onChange: changePage,
                        pageSize: 50,
                        showTotal: (total, range) => `共 ${total} 条记录`
                    }}
                />
            </div>
        )
    }
	componentDidMount() {
    	this.Request.getWithdrawPayStatus();
        this.Request.getWithdrawStatus();
  	}
    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
    }
}

export default WithdrawSimple
