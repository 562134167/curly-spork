import React, { Component } from 'react'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import EditPanel from '../../../Common/editPanel'
import * as EditType from '../../../Common/editType'
import DropdownBtn from '../../../Common/dropdowmBtn'
import { Card, Table, Popconfirm, Button, message } from 'antd'
import { formatData, formateEditData, toMoney } from '../../../Util/reactUtil'
import { requestGet, requestAdd, requestUpdate, requestUpdateProperty, requestRemove, requestRemoveItems } from '../../../Util/Request'
import { actionAdd, actionChangePage, actionClearSearch, actionSearch, actionSave, initGetParams, actionOnShowSizeChange } from '../../../Util/Action'

const pagingUrl = '' //获取列表
class Income extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      requestGet({ params, pagingUrl, context: this })
    },
  }
  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {

    // 查
    search: (value) => {
      actionSearch({ value, context: this })
    },
    // 清空查找条件
    clearSearch: () => {
      actionClearSearch({ context: this })
    },
    changePage: (page, pageSize) => {
      actionChangePage({ page, pageSize, context: this })
    },
    onShowSizeChange: (current, pageSize) => {
      actionOnShowSizeChange({ pageSize, context: this })
    }
  }

  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    this.state = {
      dataSource: [],
      modalVis: false,
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          label: '手机号码',
          id: '',
          type: SearchType.String,
        }, {
          label: '时间段',
          id: '',
          type: SearchType.String,
        }
      ]
    }
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        fixed: 'left',
        width: 60,
        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
      },
      {
        title: '收款人姓名',
        dataIndex: 'realName',
        key: 'realName',
        fixed: 'left',
        width: 100,
      }, {
        title: '收款人手机号',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone'
      }, {
        title: '收款金额',
        dataIndex: 'amount',
        key: 'amount',
        render: value => toMoney(value)
      }, {
        title: '流水号',
        dataIndex: 'orderNo',
        key: 'orderNo'
      }, {
        title: '收款渠道',
        dataIndex: 'withdrawType',
        key: 'withdrawType',
        render: value => {
          const option = withdrawTypeOptions.filter(item => item.value == value)
          return hasAttr(option, [0, 'label'])
        }
      }, {
        title: '交易时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '交易状态',
        dataIndex: 'status',
        key: 'status',
        // render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '备注',
        dataIndex: 'tip',
        key: 'tip',
        // render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }
    ];
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels, pageSize } = this.state
    const { search, clearSearch, changePage, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            showSizeChanger: true,
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            onShowSizeChange,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
        <EditPanel
          title={title}
          modalVis={modalVis}
          formItems={this.formItems}
          modal={modal}
          onSave={save}
          onCancel={cancel}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams } = this.state
    const { get } = this.Request
    // console.log(nextState.selectedRowKeys)
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }
  }
}
export default ImageAdvert