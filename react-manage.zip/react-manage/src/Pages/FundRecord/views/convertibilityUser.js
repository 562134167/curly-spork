import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
// import EditPanel from '../../../Common/editPanel'
// import * as EditType from '../../../Common/editType'
import { Table, message, Card } from 'antd'
import { formatData, flattenObj, handleEndTime, handleStartTime, toMoney } from '../../../Util/reactUtil'
import { hasAttr, arrayToObject } from '../../../Util'
import { getFetch } from '../../../Config/request'

const initGetParams = {
  pageIndex: 1,
}


const pagingIntegralExchange = '/system/integral/pagingIntegralExchange',
  getTransferStatusListUrl = '/system/integral/pagingIntegralExchange'


export default class Transfer extends Component {
  constructor(props) {
    super(props)

    this.onInit()
  }
  // 服务器请求
  Request = {
    // 获取数据
    get: (params) => {
      /**@param {Object} params 
       * 数据格式
       * {
        @param {String} keyword,
        @param {Number} pageIndex,
        @param {Number} pageSize'
      }
       */
      return getFetch(pagingIntegralExchange, params).then(res => {
        if (res && is.array(res.models)) {
          const { models, totalModels } = res
          const dataSource = formatData(flattenObj(models, ['withdraw']))
          this.setState({
            dataSource,
            totalModels,
            current: params.pageIndex,
            pageSize: params.pageSize,
            selectedRowKeys: []
          })
          !this.state.exchangeStatusOptions.length && this.Request.getTransferStatusList();
        }
        return res
      })
    },
    getTransferStatusList: () => {
        	const statusOptions = [
					  { label: '兑换中', value: 1 },
					  { label: '交易成功', value: 2 },
					  { label: '交易失败', value: 3 }
					]
          const { exchangeStatusOptions } = this.state
          statusOptions.forEach(item => {
            exchangeStatusOptions.push({
              label: item.label,
              value: item.value
            })
          })
          this.setState({
            exchangeStatusEnum: arrayToObject({ array: statusOptions, keyName: 'value', valueName: 'label' }),
            exchangeStatusOptions
            
          })
    }
  }

  Util = {
    getTotalAmount: (dataSource) => {
      let totalAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (item.integralNum) {
          totalAmount += item.integralNum
        }
      })
      return totalAmount
    },
    getSelectedAmount: (dataSource, selectedRowKeys) => {
      const tempSelectedRowKeys = selectedRowKeys || this.state.selectedRowKeys
      if (!tempSelectedRowKeys.length) {
        return 0
      }
      const selectedString = tempSelectedRowKeys.join(',')
      let selectedAmount = 0;
      (dataSource || this.state.dataSource).forEach((item, index) => {
        if (selectedString.indexOf(item.key) > -1 && item.integralNum) {
          selectedAmount += item.integralNum
        }
      })
      return selectedAmount
    }
  }

  // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
  Action = {
    search: (value) => {
      const queryParams = Object.assign({}, value)
      const { getDataParams } = this.state
      const mobileRegx = /^1\d{10}$/gi
      if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
        queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
        queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
      } else {
        queryParams.startTime = undefined
        queryParams.endTime = undefined
      }
      if (queryParams.userMobile && (!mobileRegx.test(queryParams.userMobile))) {
        message.error('请输入正确的转出手机号码')
        return;
      }
      delete queryParams.createtime
      const params = { ...getDataParams, ...queryParams }
      this.setState({
        getDataParams: params
      })
    },
    // 清空查找条件
    clearSearch: () => {
      this.setState({
        getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
      })
    },
    onShowSizeChange: (current, pageSize) => {
      const { getDataParams } = this.state
      this.setState({
        getDataParams: { ...getDataParams, pageSize, pageIndex: 1 },
        pageSize
      })
    },
    changePage: (page, pageSize) => {
      const { getDataParams } = this.state
      const params = { ...getDataParams, pageIndex: page }
      this.setState({
        selectedRowKeys: [],
        getDataParams: params
      })
    },


  }
  // 组件初始化：生成配置项，获取初始化数据，设置state初始值
  onInit() {
    // const { selectedRowKeys } = this.state;
    // const { view, unfreeze } = this.Action
    this.state = {
      dataSource: [],
      modalVis: false,
      modal: {},
      selectedRowKeys: [],
      current: 1,
      totalModels: null,
      getDataParams: {},
      pageSize: 50,
      totalAmount: 0,
      selectedAmount: 0,
      transferStatusOptions: [],
      exchangeStatusOptions:[],
      transferStatusEnum: {},
      exchangeStatusEnum: {}
    }
    // 搜索面板元数据
    this.metadata = {
      conditions: [
        {
          type: SearchType.String,
          label: '手机号',
          id: 'userMobile'
        },  {
          type: SearchType.DateRange,
          label: '时间段',
          id: 'createtime'
        }, {
          type: SearchType.Select,
          label: '兑换状态',
          id: 'exchangeStatus',
          dataSource: this.state.exchangeStatusOptions
        },{
          type: SearchType.String,
          label: '订单号',
          id: 'orderNo'
        }
      ]
    }
    // 表头设置
    this.columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        fixed: 'left',
        width: 50,
        render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index - 0 + 1)
      },{
        title: '姓名',
        dataIndex: 'userRealName',
        key: 'userRealName',
        fixed: 'left',
        width: 100,
      }, {
        title: '手机号',
        dataIndex: 'userMobile',
        key: 'userMobile'
      }, {
        title: '转入类型',
        dataIndex: 'fromChannelIdDesc',
        key: 'fromChannelIdDesc',
      }, {
        title: '转出类型',
        dataIndex: 'toChannelIdDesc',
        key: 'toChannelIdDesc'
      }, {
        title: '金额',
        dataIndex: 'integralNum',
        key: 'integralNum',
        render: value => toMoney(value)
      }, {
        title: '转账状态',
        dataIndex: 'exchangeStatus',
        key: 'exchangeStatus',
        render: value => this.state.exchangeStatusEnum[value] || value
      }, {
        title: '创建时间',
        dataIndex: 'createTime',
        key: 'createTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }
      , {
        title: '审核通过/拒绝时间',
        dataIndex: 'updateTime',
        key: 'updateTime',
        render: value => value && moment(value).format('YYYY-MM-DD HH:mm:ss')
      }, {
        title: '订单号',
        dataIndex: 'orderNo',
        key: 'orderNo',
      }, {
        title: '拒绝原因',
        dataIndex: 'refuseReson',
        key: 'refuseReson',
      }
    ];
  }
  render() {
    const { dataSource, selectedRowKeys, current, totalModels, pageSize, totalAmount, selectedAmount } = this.state
    const { changePage, search, clearSearch, onShowSizeChange } = this.Action
    return (
      <div>
        <SearchPanel
          metadata={this.metadata}
          onSearch={search}
          onClearSearch={clearSearch}
        />
        <Card>
          <p style={{ fontSize: 20, fontWeight: 'bold', color: '#108ee9' }}>
            当前页金额：{parseFloat(totalAmount / 100).toFixed(2) + '元'}，已选中的项的金额：{parseFloat(selectedAmount / 100).toFixed(2) + '元'}</p>
        </Card>
        <Table
          rowSelection={{
            selectedRowKeys: selectedRowKeys,
            onChange: (selectedRowKeys, selectedRows) => {
              this.setState({
                selectedRowKeys
              })
            },
          }}
          scroll={{ x: 900 }}
          columns={this.columns}
          dataSource={dataSource}
          pagination={{
            pageSize,
            current,
            total: totalModels,
            onChange: changePage,
            showSizeChanger: true,
            showTotal: (total, range) => `共 ${total} 条记录`,
            onShowSizeChange: onShowSizeChange,
            pageSizeOptions: ['50', '100', '200']
          }}
        />
      </div>
    )
  }
  componentDidMount() {
    this.setState({
      getDataParams: { ...initGetParams, pageSize: this.state.pageSize }
    })
  }

  componentWillUpdate(nextProps, nextState) {
    const { getDataParams, selectedRowKeys, dataSource } = this.state
    const { get } = this.Request
    const { getSelectedAmount, getTotalAmount } = this.Util
    if (nextState.getDataParams !== getDataParams) {
      get(nextState.getDataParams)
    }

    // 选中的项发生变化时，计算已选中的项的总金额
    if (nextState.selectedRowKeys !== selectedRowKeys) {
      this.setState({
        selectedAmount: getSelectedAmount(nextState.dataSource, nextState.selectedRowKeys)
      })
    }
    // 当前页的数据发生变化时，计算当前页的总金额
    if (nextState.dataSource !== dataSource) {
      this.setState({
        totalAmount: getTotalAmount(nextState.dataSource)
      })
    }
  }
}
