import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'
// import './index.less'

const loadWithdraw = (cd) => {
  return import('./withdraw.js')
},
  loadAlipayWithdraw = (cd) => {
    return import('./alipayWithdraw.js')
  },
  loadTransfer = (cd) => {
    return import('./transfer.js')
  },
  loadPay = (cb) => {
    return import('./pay.js')
  },
  loadRecharge = (cd) => {
    return import('./recharge.js')
  },
  loadconvertibilityUser = (cd) => {
    return import('./convertibilityUser.js')
  }
  ,
  loadWithdrawSimple = (cd) => {
    return import('./withdrawSimple.js')
  }
  ,
  loaddiscriminatingView = (cd) => {
    return import('./discriminatingView.js')
  },
  loadshuangqianWithdraw = (cd) => {
  return import('./shuangqianwithdraw.js')
	},
	loadDyWithdraw = (cd) => {
  return import('./dywithdraw.js')
	}
  
const Withdraw = getComponent(loadWithdraw),
  AlipayWithdraw = getComponent(loadAlipayWithdraw),
  Transfer = getComponent(loadTransfer),
  Pay = getComponent(loadPay),
  Recharge = getComponent(loadRecharge),
  ConvertibilityUser = getComponent(loadconvertibilityUser),
  WithdrawSimple = getComponent(loadWithdrawSimple),
  DiscriminatingView = getComponent(loaddiscriminatingView),
  ShuangqianWithdraw = getComponent(loadshuangqianWithdraw),
  DyWithdraw = getComponent(loadDyWithdraw)
  
export default class FundRecord extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/fundRecord"
          exact render={() => <Redirect to="/fundRecord/withdraw" />}
        />
        <Route path='/fundRecord/withdraw' render={(props) => <Withdraw {...props} />} />
        <Route path='/fundRecord/alipayWithdraw' render={(props) => <AlipayWithdraw {...props} />} />
        <Route path='/fundRecord/transfer' render={(props) => <Transfer {...props} />} />
        <Route path='/fundRecord/recharge' render={(props) => <Recharge {...props} />} />
        <Route path='/fundRecord/pay' render={(props) => <Pay {...props} />} />
        <Route path='/fundRecord/convertibilityUser' render={(props) => <ConvertibilityUser {...props} />} />
        <Route path='/fundRecord/withdrawSimple' render={(props) => <WithdrawSimple {...props} />} />
        <Route path='/fundRecord/discriminatingView' render={(props) => <DiscriminatingView {...props} />} />
        <Route path='/fundRecord/shuangqianwithdraw' render={(props) => <ShuangqianWithdraw {...props} />} />
        <Route path='/fundRecord/dywithdraw' render={(props) => <DyWithdraw {...props} />} />
      </Switch>
    )
  }
}