/*
 * @Author: miccy 
 * @Date: 2018-02-28 15:51:47 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 11:10:32
 * 每日数据校验详情
 */
import React, { Component } from 'react'
import moment from 'moment'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import is from 'is_js'
import { Table, message, Card, Button } from 'antd'
import { bindFunc, flattenObj, formatData, toMoney } from '../../../Util/reactUtil'
import { requestGet } from '../../../Util/Request'
import { actionClearSearch, actionSearch, actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal } from '../../../Util/Action'

import XLSX from 'xlsx';

const pagingUrl = '/system/validateinfo/paging' //获取列表

const excelFormat = [
    {
        title: '用户ID',
        dataIndex: 'id',
        key: 'id'
    },
    {
        title: '真实姓名',
        dataIndex: 'realName',
        key: 'realName'
    }, {
        title: '手机号码',
        dataIndex: 'mobilePhone',
        key: 'mobilePhone'
    }, {
        title: '可用余额',
        dataIndex: 'totalResidual',
        key: 'totalResidual',
        render: value => toMoney(value, '')
    }, {
        title: '余额的计算结果',
        dataIndex: 'result',
        key: 'result',
        render: value => toMoney(value, '')
    }, {
        title: '余额的差值',
        dataIndex: 'differ',
        key: 'differ',
        render: value => toMoney(value, '')
    }, {
        title: '是否正确',
        dataIndex: 'isCorrect',
        key: 'isCorrect',
        render: value => value ? '正确' : '错误',
    }, {
        title: '错误原因',
        dataIndex: 'reason',
        key: 'reason',
    }
]
class ValidateDetail extends Component {
    constructor(props) {
        super(props)
        // 绑定作用域
        bindFunc([{
            key: 'Action',
            value: ['changePage', 'onShowSizeChange']
        }], this)
        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            const queryParams = { ...params }
            queryParams.recordId = this.locationState.recordId
            requestGet({
                params: queryParams, pagingUrl, context: this, successCallback: (res) => {
                    const { models, totalModels } = res
                    const dataSource = formatData(flattenObj(models, ['validateInfo']))
                    this.setState({
                        dataSource,
                        totalModels,
                        current: params.pageIndex,
                        pageSize: params.pageSize,
                        // selectedRowKeys: []
                    })
                }
            })
        }
    }

    Util = {
        handleExportData: () => {
            // const data = JSON.parse(JSON.stringify(this.state.dataSource));
            const data = [{}];
            for (let i in excelFormat) {
                const column = excelFormat[i];
                data[0][column.title] = column.title;
                for (let j in this.state.dataSource) {
                    if (!data[j - 0 + 1]) { data[j - 0 + 1] = {}; }
                    const item = this.state.dataSource[j][column.key];
                    if (column.render) {
                        data[j - 0 + 1][column.title] = column.render(item)
                    } else {
                        data[j - 0 + 1][column.title] = item;
                    }
                }
            }
            return data;
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this })
        },
        search: (value) => {
            const queryParams = Object.assign({}, value)
            const mobileRegx = /^1\d{10}$/gi
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码')
                return;
            }
            if (!is.undefined(queryParams.isCorrect)) {
                queryParams.isCorrect = parseInt(queryParams.isCorrect, 10)
            }
            actionSearch({ value: queryParams, context: this })
        },
        // 清空查找条件
        clearSearch: () => {
            actionClearSearch({ context: this })
        },
        downloadFile: () => { // 点击导出按钮
            const data = this.Util.handleExportData();
            this.Action.downloadExl(data, `数据校验-资金余额-${moment().format('YYYY-MM-DD')}`)
        },
        downloadExl: (json, downName, type) => {  // 导出到excel
            let keyMap = [] // 获取键
            for (let k in json[0]) {
                keyMap.push(k)
            }
            let tmpdata = [] // 用来保存转换好的json
            json.map((v, i) => keyMap.map((k, j) => Object.assign({}, {
                v: v[k],
                position: (j > 25 ? this.getCharCol(j) : String.fromCharCode(65 + j)) + (i + 1)
            }))).reduce((prev, next) => prev.concat(next)).forEach(function (v) {
                tmpdata[v.position] = {
                    v: v.v
                }
            })
            let outputPos = Object.keys(tmpdata)  // 设置区域,比如表格从A1到D10
            let tmpWB = {
                SheetNames: ['每日数据校验详情'], // 保存的表标题
                Sheets: {
                    '每日数据校验详情': Object.assign({},
                        tmpdata, // 内容
                        {
                            '!ref': outputPos[0] + ':' + outputPos[outputPos.length - 1] // 设置填充区域
                        })
                }
            }
            let tmpDown = new Blob([this.Action.s2ab(XLSX.write(tmpWB,
                { bookType: (type === undefined ? 'xlsx' : type), bookSST: false, type: 'binary' } // 这里的数据是用来定义导出的格式类型
            ))], {
                    type: ''
                })  // 创建二进制对象写入转换好的字节流
            var href = URL.createObjectURL(tmpDown)  // 创建对象超链接
            this.outFile.download = downName + '.xlsx'  // 下载名称
            this.outFile.href = href  // 绑定a标签
            this.outFile.click()  // 模拟点击实现下载
            setTimeout(function () {  // 延时释放
                URL.revokeObjectURL(tmpDown) // 用URL.revokeObjectURL()来释放这个object URL
            }, 100)
        },
        s2ab: (s) => { // 字符串转字符流
            var buf = new ArrayBuffer(s.length)
            var view = new Uint8Array(buf)
            for (var i = 0; i !== s.length; ++i) {
                view[i] = s.charCodeAt(i) & 0xFF
            }
            return buf
        },
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        this.locationState = this.props.location.state || {}

        this.state = {
            dataSource: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 20,
        }

        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone'
                }, {
                    type: SearchType.Boolean,
                    label: '是否正确',
                    id: 'isCorrect',
                    // config: {
                    formOption: {
                        initialValue: '0'
                    }
                    // }
                }
            ]
        }

        // 表头设置
        this.columns = [
            {
                title: '用户ID',
                dataIndex: 'id',
                key: 'id'
            },
            {
                title: '真实姓名',
                dataIndex: 'realName',
                key: 'realName'
            }, {
                title: '手机号码',
                dataIndex: 'mobilePhone',
                key: 'mobilePhone'
            }, {
                title: '可用余额',
                dataIndex: 'totalResidual',
                key: 'totalResidual',
                render: value => toMoney(value)
            }, {
                title: '余额的计算结果',
                dataIndex: 'result',
                key: 'result',
                render: value => toMoney(value)
            }, {
                title: '余额的差值',
                dataIndex: 'differ',
                key: 'differ',
                render: value => toMoney(value)
            }, {
                title: '是否正确',
                dataIndex: 'isCorrect',
                key: 'isCorrect',
                render: value => value ? <span style={{ color: '#00a854' }}>正确</span> : <span style={{ color: 'red' }}>错误</span>,
            }, {
                title: '错误原因',
                dataIndex: 'reason',
                key: 'reason',
                width: 600
            }
        ]


    }
    render() {
        const { dataSource, current, totalModels, pageSize } = this.state
        const { search, clearSearch, changePage, onShowSizeChange, downloadFile } = this.Action
        return (
            <div>
                <Card>
                    <Button onClick={downloadFile}>当前页导出为表格</Button>
                    <a style={{ width: 0, height: 0 }} ref={(inst) => { this.outFile = inst }}></a>
                </Card>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />

                <Table
                    ref={inst => { this.table = inst }}
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal,
                        pageSizeOptions: ['20', '50', '100', '200']
                    }}
                />

            </div>
        )
    }
    componentDidMount() {
        // if (is.undefined(this.locationState.recordId)) {
        //     this.props.history.replace('/validateFund/validateList')
        //     return;
        // }
        this.setState({
            getDataParams: { ...initGetParams, isCorrect: 0 }
        })
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
    }
}
export default ValidateDetail