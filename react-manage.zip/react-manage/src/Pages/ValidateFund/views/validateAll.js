/*
 * @Author: miccy 
 * @Date: 2018-02-06 13:46:13 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-03-23 10:59:26
 * 总的数据跑批校验
 */
import React, { Component } from 'react'
import { Button, Card, Table } from 'antd'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'

import { getFetch, fetch } from '../../../Config/request'
import { formatData, toMoney } from '../../../Util/reactUtil'

const execUrl = '/system/validate/capital', //执行跑批的url
    exportUrl = '/system/validate/export'

export default class ValidateAll extends Component {

    constructor(props) {
        super(props)
        this.onInit()
    }

    // 请求对象
    Request = {
        // 请求执行跑批
        exec: (params) => {
            return getFetch(execUrl, params, true, 0).then(res => {
                if (res.status == 0 && res.models && res.models.length) {
                    this.setState({
                        dataSource: formatData(res.models)
                    })
                    this.dataSource = formatData(res.models)
                }
            })
        },
        exportExcel: () => {
            return fetch(exportUrl, undefined, undefined, true, 0).then(res => {
                if (res.status == 0 && res.model) {
                    // window.open(res.model)
                    this.setState({
                        exportUrl: res.model
                    }, () => {
                        this.link.click()
                    })
                }
            })
        }
    }

    // 点击操作的函数对象
    Action = {
        getFail: () => {
            const dataSource = this.dataSource.filter(item => item.correct === false)
            this.setState({
                dataSource
            })
        },
        getSuccess: () => {
            const dataSource = this.dataSource.filter(item => item.correct === true)
            this.setState({
                dataSource
            })
        },
        clearFilter: () => {
            this.setState({
                dataSource: this.dataSource
            })
        },
        search: (values) => {
            this.Request.exec({ ...values, pageIndex: undefined })
        },
        clearSearch: () => {
            this.Request.exec()
        }
    }

    // 初始化组件
    onInit() {
        this.dataSource = []
        this.state = {
            dataSource: [],
            exportUrl: '',
        }
        // 搜索面板元数据
        this.metadata = {
            conditions: [{
                type: SearchType.String,
                label: '用户ID',
                id: 'id'
            }]
        }
        this.columns = [
            {
                title: '用户ID',
                dataIndex: 'id',
                key: 'id'
            },
            {
                title: '真实姓名',
                dataIndex: 'realName',
                key: 'realName'
            }, {
                title: '手机号码',
                dataIndex: 'mobilePhone',
                key: 'mobilePhone'
            }, {
                title: '可用余额',
                dataIndex: 'totalResidual',
                key: 'totalResidual',
                render: value => toMoney(value)
            }, {
                title: '余额的计算结果',
                dataIndex: 'result',
                key: 'result',
                render: value => toMoney(value)
            }, {
                title: '余额的差值',
                dataIndex: 'differ',
                key: 'differ',
                render: value => toMoney(value)
            }, {
                title: '是否正确',
                dataIndex: 'correct',
                key: 'correct',
                render: value => value ? <span style={{ color: '#00a854' }}>正确</span> : <span style={{ color: 'red' }}>错误</span>,
            },
        ]
    }

    render() {
        const { exec } = this.Request
        const { getFail, getSuccess, clearFilter, search, clearSearch } = this.Action
        const { exportExcel } = this.Request
        const { dataSource, exportUrl } = this.state

        return (
            <div>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <a style={{ width: 0, height: 0 }} href={exportUrl} ref={(inst) => { this.link = inst }}></a>
                <Card title="此功能用于账户可用余额校验">
                    <Button type="primary" className="action-item" onClick={() => exec()}>执行</Button>
                    <Button type="primary" className="action-item" onClick={getFail}>筛选校验错误的记录</Button>
                    <Button type="primary" className="action-item" onClick={getSuccess}>筛选校验成功的记录</Button>
                    <Button type="primary" className="action-item" onClick={clearFilter}>重置筛选</Button>
                    <Button type="primary" className="action-item" onClick={exportExcel}>导出数据</Button>
                </Card>
                <Table
                    columns={this.columns}
                    dataSource={dataSource}
                    // footer={() => `共${dataSource.length}条记录`}
                    pagination={{
                        pageSize: dataSource.length,
                        current: 1,
                        showTotal: (total, range) => `共 ${dataSource.length} 条记录`
                    }}
                />
            </div>
        )
    }
}
