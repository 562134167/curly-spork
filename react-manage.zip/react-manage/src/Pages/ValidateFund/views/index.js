import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
import { getComponent } from '../../../Common/bundle'

const loadValidateAll = (cb) => {
  return import('./validateAll.js')
}
const loadValidateList = (cb) => {
  return import('./validateList.js')
}
const loadValidateDetail = (cb) => {
  return import('./validateDetail.js')
}

const ValidateAll = getComponent(loadValidateAll)
const ValidateList = getComponent(loadValidateList)
const ValidateDetail = getComponent(loadValidateDetail)

export default class ValidateFund extends Component {
  render() {
    return (
      <Switch>
        <Route
          path="/validateFund"
          exact render={() => <Redirect to="/validateFund/validateAll" />}
        />
        <Route path="/validateFund/validateAll" render={(props) => <ValidateAll {...props} />} />
        <Route path="/validateFund/validateList" render={(props) => <ValidateList {...props} />} />
        <Route path="/validateFund/validateDetail" render={(props) => <ValidateDetail {...props} />} />

      </Switch>
    )
  }
}