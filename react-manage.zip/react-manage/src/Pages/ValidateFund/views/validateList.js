/*
 * @Author: miccy 
 * @Date: 2018-02-28 15:53:34 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-03-28 11:58:01
 * 每日数据校验列表
 */
import React, { Component } from 'react'
// import { connect } from 'react-redux'
import moment from 'moment'
import is from 'is_js'
import SearchPanel from '../../../Common/searchPanel'
import * as SearchType from '../../../Common/searchTypes'
import { Table, Button } from 'antd'
import { handleEndTime, handleStartTime } from '../../../Util/reactUtil'
import { requestGet } from '../../../Util/Request'
import { actionChangePage, initGetParams, actionOnShowSizeChange, actionShowTotal, actionSearch, actionClearSearch } from '../../../Util/Action'

const pagingUrl = '/system/validaterecord/paging' //获取列表

const userTypeEnum = {
    1: "普通钱包用户", 2: "摩根员工账户", 3: "钱包商户", 4: "收银台商户", 5: "平台系统账户"
}

class ValidateList extends Component {
    constructor(props) {
        super(props)

        this.onInit()
    }
    // 服务器请求
    Request = {
        // 获取数据
        get: (params) => {
            requestGet({ params, pagingUrl, context: this })
        }
    }
    // 点击按钮的操作（新建、删除、批量删除、修改、搜索、清空搜索、保存、取消模态框,点击页数按钮,点击批量操作按钮）
    Action = {
        // 点击查看详情
        view: (record, index) => {
            this.props.history.push('/validateFund/validateDetail', { recordId: record.id })
        },
        changePage: (page, pageSize) => {
            actionChangePage({ page, pageSize, context: this })
        },
        onShowSizeChange: (current, pageSize) => {
            actionOnShowSizeChange({ pageSize, context: this })
        },
        search: (value) => {
            const queryParams = Object.assign({}, value)
            if (!is.undefined(queryParams.createtime) && !is.undefined(queryParams.createtime[0])) {
                queryParams.startTime = handleStartTime(queryParams.createtime[0]).format('x')
                queryParams.endTime = handleEndTime(queryParams.createtime[1]).format('x')
            } else {
                queryParams.startTime = undefined
                queryParams.endTime = undefined
            }

            delete queryParams.createtime

            actionSearch({ value: queryParams, context: this })
        },
        clearSearch: () => {
            actionClearSearch({ context: this })
        }
    }

    // 组件初始化：生成配置项，获取初始化数据，设置state初始值
    onInit() {
        const { view } = this.Action
        this.state = {
            dataSource: [],
            current: 1,
            totalModels: null,
            getDataParams: {},
            pageSize: 20,
        }

        // 搜索面板元数据
        this.metadata = {
            conditions: [
                {
                    type: SearchType.DateRange,
                    label: '时间段',
                    id: 'createtime'
                }
            ]
        }

        // 表头设置
        this.columns = [
            {
                title: '序号',
                dataIndex: 'index',
                key: 'index',
                fixed: 'left',
                width: 60,
                render: (text, record, index) => (this.state.current - 1) * (this.state.pageSize || 50) + (index + 1)
            }, {
                title: '记录ID',
                dataIndex: 'id',
                key: 'id',
                fixed: 'left',
                width: 60,
            },
            {
                title: '跑批类型',
                dataIndex: 'userType',
                key: 'userType',
                render: (value) => userTypeEnum[value] || value
            },
            {
                title: '跑批日期',
                dataIndex: 'runDate',
                key: 'runDate',
                render: value => value && moment(value, 'x').format('YYYY-MM-DD HH:mm:ss')
            }, {
                title: '错误个数',
                dataIndex: 'errorCount',
                key: 'errorCount',
                render: value => value == 0 ? value : <span style={{ color: 'red' }}>{value}</span>
            }, {
                title: '操作',
                dataIndex: 'actions',
                key: 'actions',
                width: 80,
                render: (text, record, index) => (
                    <span>
                        <Button type="primary" className="action-item" onClick={() => { view(record, index) }}>查看详情</Button>
                    </span>
                )
            }
        ]


    }
    render() {
        const { dataSource, current, totalModels, pageSize } = this.state
        const { changePage, onShowSizeChange, search, clearSearch } = this.Action
        return (
            <div>
                <SearchPanel
                    metadata={this.metadata}
                    onSearch={search}
                    onClearSearch={clearSearch}
                />
                <Table
                    columns={this.columns}
                    dataSource={dataSource}
                    pagination={{
                        showSizeChanger: true,
                        pageSize,
                        current,
                        total: totalModels,
                        onChange: changePage,
                        onShowSizeChange,
                        showTotal: actionShowTotal
                    }}
                />

            </div>
        )
    }
    componentDidMount() {
        this.setState({
            getDataParams: initGetParams
        })
    }

    componentWillUpdate(nextProps, nextState) {
        const { getDataParams } = this.state
        const { get } = this.Request
        if (nextState.getDataParams !== getDataParams) {
            get(nextState.getDataParams)
        }
    }
}
export default ValidateList