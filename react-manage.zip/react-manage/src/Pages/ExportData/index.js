/*
 * @Author: miccy 
 * @Date: 2018-03-05 10:20:50 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-04-23 12:04:10
 * 通过筛选条件导出表格数据
 */
import React, { Component } from 'react';
import SearchPanel from '../../Common/searchPanel';
import * as SearchType from '../../Common/searchTypes';
import { message, Button, Card } from 'antd';
import { fetch, getFetch } from '../../Config/request';
import { getStore } from '../../Util';
// import { handleEndTime, handleStartTime } from '../../Util/reactUtil'
import is from 'is_js';

const exportWithdrawUrl = '/system/export/withdraw',
    exportIntegralRefundUrl = '/system/export/integralrefund',
    exportIntegralPurchaseUrl = '/system/export/buyintegral',
    exportFundDetailUrl = '/system/export/funddetail',
    exportCapitalUrl = '/system/export/capital',
    exportAppropriationUrl = '/system/export/appropriation',
    getCategoryListUrl = '/system/enums/goodscat',
    getChannelListUrl = '/common/getchannellist',
    getWithdrawStatusUrl = '/system/enums/withdrawstatus',//获取提现状态枚举列表
    getWithdrawPayStatusUrl = '/system/enums/withdrawpaystatus',//获取提现代付状态枚举列表
    getRefundStatusListUrl = '/system/enums/orderrefundstatus',//获取订单退款状态列表
    getOrderStatusListUrl = '/system/enums/orderstatus',//获取订单状态列表
    getTypeListUrl = '/system/appropriation/gettypelist'; //获取打款类型列表


const orderStatusOptions = [
    // { label: '待兑换', value: 0 },
    { label: '处理中', value: 1 },
    { label: '交易成功', value: 2 },
    { label: '审核拒绝', value: 3 },
    { label: '交易关闭', value: 4 }
],
    handleStatusOptions = [
        { label: '未处理', value: 0 },
        { label: '处理中', value: 1 },
        { label: '处理完成', value: 2 }
    ],
    payStatusOptions = [
        { label: '未处理', value: 0 },
        { label: '已提交', value: 1 },
        { label: '代付失败', value: 2 },
        { label: '代付成功', value: 3 }
    ]

class ExportData extends Component {
    constructor(props) {
        super(props);
        this.onInit();
    }

    // 服务器请求
    Request = {
        // 提现数据导出
        exportWithdraw: (params) => {
            fetch(exportWithdrawUrl, params, undefined, false, 0).then(res => {
                if (res.status == 0 && res.model) {
                    this.setState({
                        exportUrl: res.model
                    }, () => {
                        this.link.click();
                    });
                } else {
                    message.error('导出出错了~')
                }
            }, err => {
                message.error('请进行条件筛选后再点击导出！如已筛选请联系技术！')
            })
        },
        exportIntegralRefund: (params) => {
            fetch(exportIntegralRefundUrl, params, undefined, false, 0).then(res => {
                if (res.status == 0 && res.model) {
                    this.setState({
                        exportUrl: res.model
                    }, () => {
                        this.link.click();
                    });
                } else {
                    message.error('导出出错了~')
                }
            }, err => {
                message.error('请进行条件筛选后再点击导出！如已筛选请联系技术！')
            })
        },
        exportIntegralPurchase: (params) => {
            fetch(exportIntegralPurchaseUrl, params, undefined, false, 0).then(res => {
                if (res.status == 0 && res.model) {
                    this.setState({
                        exportUrl: res.model
                    }, () => {
                        this.link.click();
                    });
                } else {
                    message.error('导出出错了~')
                }
            }, err => {
                message.error('请进行条件筛选后再点击导出！如已筛选请联系技术！')
            })
        },
        exportFundDetail: (params) => {
            fetch(exportFundDetailUrl, params, undefined, false, 0).then(res => {
                if (res.status == 0 && res.model) {
                    this.setState({
                        exportUrl: res.model
                    }, () => {
                        this.link.click();
                    });
                } else {
                    message.error('导出出错了~')
                }
            }, err => {
                message.error('请进行条件筛选后再点击导出！如已筛选请联系技术！')
            })
        },
        exportCapital: () => {
            fetch(exportCapitalUrl, undefined, undefined, false, 0).then(res => {
                if (res.status == 0 && res.model) {
                    this.setState({
                        exportUrl: res.model
                    }, () => {
                        this.link.click();
                    });
                } else {
                    message.error('导出出错了~')
                }
            }, err => {
                message.error('请进行条件筛选后再点击导出！如已筛选请联系技术！')
            })
        },
        exportAppropriation: (params) => {
            fetch(exportAppropriationUrl, params, undefined, false, 0).then(res => {
                if (res.status == 0 && res.model) {
                    this.setState({
                        exportUrl: res.model
                    }, () => {
                        this.link.click();
                    });
                } else {
                    message.error('导出出错了~')
                }
            }, err => {
                message.error('请进行条件筛选后再点击导出！如已筛选请联系技术！')
            })
        },
        getCategoryList: () => {
            getFetch(getCategoryListUrl).then(res => {
                if (is.array(res)) {
                    const { categroyListOptions } = this.state
                    res.forEach(item => {
                        categroyListOptions.push({
                            label: item.name,
                            value: item.value
                        })
                    })
                    this.setState({
                        categroyListOptions
                    })
                }
            })
        },
        getChannelList: () => {
            getFetch(getChannelListUrl).then(res => {
                if (res && res.status == 0) {
                    const { channelListOptions } = this.state
                    res.models.forEach(item => {
                        channelListOptions.push({
                            label: item.remarks,
                            value: item.channelId
                        })
                    })
                    this.setState({
                        channelListOptions
                    })
                }
            })
        },
        getWithdrawStatus: () => {
            getFetch(getWithdrawStatusUrl).then(res => {
                if (is.array(res)) {
                    const { withdrawStatusOptions } = this.state
                    res.forEach(item => {
                        withdrawStatusOptions.push({
                            label: item.name,
                            value: item.value
                        })
                    })
                    this.setState({
                        withdrawStatusOptions
                    })
                }
            })
        },
        getWithdrawPayStatus: () => {
            getFetch(getWithdrawPayStatusUrl).then(res => {
                if (is.array(res)) {
                    const { withdrawPayStatusOptions } = this.state
                    res.forEach(item => {
                        withdrawPayStatusOptions.push({
                            label: item.name,
                            value: item.value
                        })
                    })
                    this.setState({
                        withdrawPayStatusOptions
                    })
                }
            })
        },
        getRefundStatusList: () => {
            getFetch(getRefundStatusListUrl).then(res => {
                if (is.array(res)) {
                    const { refundStatusOptions } = this.state
                    res.forEach(item => {
                        refundStatusOptions.push({
                            label: item.name,
                            value: item.value
                        })
                    })
                    this.setState({
                        refundStatusOptions
                    })
                }
            })
        },
        getOrderStatusList: () => {
            getFetch(getOrderStatusListUrl).then(res => {
                if (is.array(res)) {
                    const { orderStatusOptions } = this.state
                    res.forEach(item => {
                        orderStatusOptions.push({
                            label: item.name,
                            value: item.value
                        })
                    })
                    this.setState({
                        orderStatusOptions
                    })
                }
            })
        },
        getTypeList: () => {
            getFetch(getTypeListUrl).then(res => {
                if (res.status == 0) {
                    const { typeOptions } = this.state
                    res.models.forEach(item => {
                        typeOptions.push({
                            label: item.name,
                            value: item.id,
                            status: item.status
                        })
                    })
                    this.setState({
                        typeOptions
                    })
                }
            })
        },
    }

    Util = {
        handleSearch: (values) => {
            const queryParams = Object.assign({}, values),
                mobileRegx = /^1\d{10}$/gi;
            if (queryParams.mobilePhone && (!mobileRegx.test(queryParams.mobilePhone))) {
                message.error('请输入正确的手机号码');
                return;
            }
            if (!is.undefined(queryParams.createTime) && !is.undefined(queryParams.createTime[0])) {
                queryParams.startTime = queryParams.createTime[0].format('x');
                queryParams.endTime = queryParams.createTime[1].format('x');
            } else {
                queryParams.startTime = undefined;
                queryParams.endTime = undefined;
            }
            delete queryParams.createTime;
            delete queryParams.pageIndex;
            return queryParams;
        }
    }

    // 点击按钮操作
    Action = {
        exportWithdraw: (values) => {
            const queryParams = this.Util.handleSearch(values);
            if (queryParams) {
                this.Request.exportWithdraw(queryParams);
            }
        },
        exportIntegralRefund: (values) => {
            const queryParams = this.Util.handleSearch(values);
            if (queryParams) {
                this.Request.exportIntegralRefund(queryParams);
            }
        },
        exportIntegralPurchase: (values) => {
            const queryParams = this.Util.handleSearch(values);
            if (queryParams) {
                this.Request.exportIntegralPurchase(queryParams);
            }
        },
        exportFundDetail: (values) => {
            const queryParams = this.Util.handleSearch(values);
            if (queryParams) {
                this.Request.exportFundDetail(queryParams);
            }
        },
        exportAppropriation: (values) => {
            const queryParams = this.Util.handleSearch(values);
            if (queryParams) {
                this.Request.exportAppropriation(queryParams);
            }
        },
    }

    // 初始化数据
    onInit() {

        this.state = {
            exportUrl: "", //导出表格的下载链接
            categroyListOptions: [],
            channelListOptions: [],
            withdrawStatusOptions: [],
            withdrawPayStatusOptions: [],
            orderStatusOptions: [],
            refundStatusOptions: [],
            typeOptions: []
        }

        // 提现导出筛选条件
        this.exportWithdrawMetadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone',
                }, {
                    type: SearchType.Select,
                    label: '用户订单状态',
                    id: 'withdrawStatus',
                    dataSource: this.state.withdrawStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '代付状态',
                    id: 'payStatus',
                    dataSource: this.state.withdrawPayStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '是否分批次',
                    id: 'isBatch',
                    dataSource: [{
                        label: '是',
                        value: 1
                    }, {
                        label: '否',
                        value: 0
                    }]
                }, {
                    type: SearchType.DateRange,
                    label: '时间段',
                    id: 'createTime',
                    config: {
                        showTime: true,
                        format: "YYYY-MM-DD HH:mm:ss",
                    }
                }, {
                    type: SearchType.String,
                    label: '大额提现批次号',
                    id: 'batchNo'
                }, {
                    type: SearchType.String,
                    label: '平台唯一订单号',
                    id: 'orderNo'
                }, {
                    type: SearchType.Select,
                    label: '提现渠道',
                    id: 'channelId',
                    dataSource: this.state.channelListOptions
                }
            ]
        }

        // 积分兑换导出筛选条件
        this.exportIntegralRefundMetadata = {
            conditions: [
                {
                    type: SearchType.String,
                    label: '手机号码',
                    id: 'mobilePhone',
                }, {
                    type: SearchType.Select,
                    label: '用户订单状态',
                    id: 'orderStatus',
                    dataSource: orderStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '渠道代付状态',
                    id: 'payStatus',
                    dataSource: payStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '管理操作状态',
                    id: 'handleStatus',
                    dataSource: handleStatusOptions
                }, {
                    type: SearchType.Select,
                    label: '是否分批次',
                    id: 'isBatch',
                    dataSource: [{
                        label: '是',
                        value: 1
                    }, {
                        label: '否',
                        value: 0
                    }]
                }, {
                    type: SearchType.DateRange,
                    label: '提现申请时间',
                    id: 'createTime',
                    config: {
                        showTime: true,
                        format: "YYYY-MM-DD HH:mm:ss",
                    },
                }, {
                    type: SearchType.String,
                    label: '大额提现批次号',
                    id: 'batchNo'
                }, {
                    type: SearchType.String,
                    label: '订单号',
                    id: 'serialNumber'
                }
            ]
        }

        // 积分申购导出筛选条件
        this.exportIntegralPurchaseMetadata = {
            conditions: [{
                type: SearchType.String,
                label: '手机号码',
                id: 'mobilePhone'
            },
            {
                type: SearchType.String,
                label: '订单号',
                id: 'orderNo'
            },
            {
                type: SearchType.DateRange,
                label: '时间段',
                id: 'createTime'
            }, {
                type: SearchType.Select,
                label: '产品类型',
                id: 'catId',
                dataSource: this.state.categroyListOptions
            }, {
                type: SearchType.Select,
                label: '申购渠道',
                id: 'channelId',
                dataSource: this.state.channelListOptions
            }, {
                type: SearchType.Select,
                label: '订单状态',
                id: 'orderStatus',
                dataSource: this.state.orderStatusOptions
            }, {
                type: SearchType.Select,
                label: '订单退款状态',
                id: 'refundStatus',
                dataSource: this.state.refundStatusOptions
            }
            ]
        }

        // 资金明细导出筛选条件
        this.exportFundDetailMetadata = {
            conditions: [
                {
                    type: SearchType.DateRange,
                    label: '时间段',
                    id: 'createTime',
                    config: {
                        showTime: true,
                        format: "YYYY-MM-DD HH:mm:ss",
                    }
                }
            ]
        }

        this.exportAppropriationMetadata = {
            conditions: [{
                type: SearchType.String,
                label: '手机号码',
                id: 'mobilePhone'
            }, {
                type: SearchType.DateRange,
                label: '时间段',
                id: 'createTime',
                config: {
                    showTime: true,
                    format: "YYYY-MM-DD HH:mm:ss",
                }
            }, {
                type: SearchType.Select,
                label: '打款操作类型',
                id: 'type',
                dataSource: this.state.typeOptions
            }]
        }

    }

    render() {
        const { exportWithdraw, exportIntegralRefund, exportIntegralPurchase, exportFundDetail, exportAppropriation } = this.Action,
            { exportUrl } = this.state;

        return (
            <div>
                <div style={{ margin: 10 }}>
                    <SearchPanel
                        isExport={true}
                        title="导出提现订单"
                        metadata={this.exportWithdrawMetadata}
                        onSearch={exportWithdraw}
                    />
                </div>
                <div style={{ margin: 10 }}>
                    <SearchPanel
                        isExport={true}
                        title="导出积分兑换列表"
                        metadata={this.exportIntegralRefundMetadata}
                        onSearch={exportIntegralRefund}
                    />
                </div>
                <div style={{ margin: 10 }}>
                    <SearchPanel
                        isExport={true}
                        title="导出积分申购列表"
                        metadata={this.exportIntegralPurchaseMetadata}
                        onSearch={exportIntegralPurchase}
                    />
                </div>

                <div style={{ margin: 10 }}>
                    <SearchPanel
                        isExport={true}
                        title="导出资金明细列表"
                        metadata={this.exportFundDetailMetadata}
                        onSearch={exportFundDetail}
                    />
                </div>

                <div style={{ margin: 10 }}>
                    <Card title='导出资金账户列表'>
                        <Button type='primary' onClick={this.Request.exportCapital} size="large" style={{ marginLeft: 10 }}>导出</Button>
                    </Card>
                </div>

                <div style={{ margin: 10 }}>
                    <SearchPanel
                        isExport={true}
                        title="导出打款记录列表"
                        metadata={this.exportAppropriationMetadata}
                        onSearch={exportAppropriation}
                    />
                </div>

                <a style={{ width: 0, height: 0 }} href={exportUrl} ref={(inst) => { this.link = inst }}></a>
            </div>
        )
    }
    componentDidMount() {
        this.Request.getCategoryList();
        this.Request.getChannelList();
        this.Request.getWithdrawPayStatus();
        this.Request.getWithdrawStatus();
        this.Request.getRefundStatusList();
        this.Request.getOrderStatusList();
        this.Request.getTypeList();
    }

}
export default ExportData;
