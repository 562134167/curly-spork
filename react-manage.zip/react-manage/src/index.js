import React from 'react'
import ReactDOM from 'react-dom'

import { Provider } from 'react-redux'

import createHistory from 'history/createBrowserHistory'

import { ConnectedRouter } from 'react-router-redux'

import store from './store'  //引入store配置


// import registerServiceWorker, { unregister } from './registerServiceWorker';
import { unregister } from './registerServiceWorker';

import './Styles/index.less';
import './Styles/antd_style.less'

import Routes from './Config/routes';

// import { polyfill } from 'es6-promise'
// import 'isomorphic-fetch';
import moment from 'moment';

// 推荐在入口文件全局设置 locale
import 'moment/locale/zh-cn';
moment.locale('zh-cn');
// polyfill();
// Create a history of your choosing (we're using a browser history in this case)
const history = createHistory()


// 给增强后的store传入reducer
// const store = finalCreateStore(reducers)
// Now you can dispatch navigation actions from anywhere!
// store.dispatch(push('/foo'))

ReactDOM.render(
  <Provider store={store}>
    { /* ConnectedRouter will use the store from Provider automatically */}
    <ConnectedRouter history={history}>
      <Routes />
    </ConnectedRouter>
  </Provider>,
  document.getElementById('root')
)
// registerServiceWorker();
unregister();