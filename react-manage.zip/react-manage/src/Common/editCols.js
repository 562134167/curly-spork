import React, { Component } from 'react';
import { Modal, Transfer } from 'antd';
import { getStore, setStore } from '../Util'

export default class EditCols extends Component {
    constructor(props) {
        super(props);
        const moduleName = props.moduleName || '',
            dataSource = props.dataSource;
        this.state = {
            targetKeys: getStore(moduleName) ? JSON.parse(getStore(moduleName)) : dataSource.map(item => item.key),
        }
    }

    Action = {
        handleChange: (nextTargetKeys, direction, moveKeys) => {
            this.setState({ targetKeys: nextTargetKeys });
        },
        // handleSelectChange = (sourceSelectedKeys, targetSelectedKeys) => {
        //     this.setState({ selectedKeys: [...sourceSelectedKeys, ...targetSelectedKeys] });
        // },
        onOk: () => {
            if (this.props.moduleName) {
                setStore(this.props.moduleName, JSON.stringify(this.state.targetKeys))
            }
            this.props.changeCols(this.state.targetKeys);
        },
        onCancel: () => {
            this.props.cancel();
        }
    }

    render() {
        const { visible, dataSource } = this.props,
            { targetKeys } = this.state,
            { handleChange, onCancel, onOk } = this.Action;
        return (
            <Modal
                visible={visible}
                title="修改显示列"
                onOk={onOk}
                onCancel={onCancel}
            >
                <Transfer
                    listStyle={{
                        width: '40%',
                        height: 350,
                    }}
                    dataSource={dataSource}
                    titles={['隐藏列', '显示列']}
                    targetKeys={targetKeys}
                    // selectedKeys={selectedKeys}
                    onChange={handleChange}
                    // onSelectChange={handleSelectChange}
                    render={item => item.title}
                />
            </Modal>
        )
    }
}