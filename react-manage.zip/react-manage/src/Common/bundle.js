import React, { Component } from 'react'
import Loading from './loading'

export class Bundle extends Component {
  state = {
    // short for "module" but that's a keyword in js, so "mod"
    mod: null
  }

  componentDidMount() {
    this && this.load(this.props)
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.load !== this.props.load) {
      this && this.load(nextProps)
    }
  }

  load(props) {
    if (this) {
      this.setState({
        mod: null
      })
      props.load().then((mod) => {
        this && this.setState({
          mod: mod.default ? mod.default : mod
        });

      });
    }
  }

  render() {
    return this.state.mod ? this.props.children(this.state.mod) : <Loading />
  }
}

export const getComponent = (loadComponent) => {
  return (props) => (
    <Bundle load={
      loadComponent
    }>
      {(Component) => Component.view ? <Component.view {...props} /> : <Component {...props} />}
    </Bundle >
  )
}
