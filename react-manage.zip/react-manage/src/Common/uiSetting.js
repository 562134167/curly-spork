//标准UI设置

export const TableSetting={
        bordered: true,                     //显示边框线
        loading: false,                     //显示加载中效果
        pagination: true,                   //显示分页
        size: 'middle',                     //行大小 default,middle,small
        expandedRowRender:undefined,        //是否显示行扩展   undefined 为不显示
        title:undefined,                    //是否显示表格标题   undefined 为不显示
        showHeader:true,                    //是否显示列标题
        footer:undefined,                   //是否显示底部行
        //rowSelection: {},                 //是否启用选择列 undefined 为不显示
        scroll: undefined,                  //是否冻结列头
}

export const EditFormItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    };