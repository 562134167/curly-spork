import React, { Component } from 'react';
import { Upload, Modal, Icon } from 'antd';
import { hasAttr } from '../Util'

export default class MyUpload extends Component {
    state = {
        // previewVisible: false,
        previewImage: ''
    }
    handleCancel = () => {
        this.setState({
            previewImage: ''
        })
    }
    render() {
        const { previewImage } = this.state
        const { item, formProps } = this.props
        const { itemConfig, ...otherProps } = item
        return (
            <div>
                <Upload
                    {...formProps}
                    {...otherProps}
                    listType="picture-card"
                    {...item.itemConfig}
                    onPreview={
                        (file) => {
                            this.setState({ previewImage: file.response || file.thumbUrl })
                        }
                    }
                    onRemove={() => {
                        if (item.itemConfig && item.itemConfig.disabled) {
                            return false
                        }
                        return true
                    }}
                    withCredentials={true}
                >
                    {item.isShowbtn(formProps) ? (<div>
                        <Icon type="plus" />
                        <div className="ant-upload-text">{hasAttr(item, ['itemConfig', 'tip']) ? item.itemConfig.tip : '上传图片'}</div>
                    </div>) : null}
                </Upload>
                <Modal visible={Boolean(previewImage)} footer={null} onCancel={this.handleCancel}>
                    <img alt="example" style={{ width: '100%' }} src={previewImage} />
                </Modal>
            </div>
        )
    }
}