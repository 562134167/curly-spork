import React, { Component } from 'react';
import is from 'is_js'
import * as SearchTypes from './searchTypes';
import { Select, Form, Input, InputNumber, DatePicker, Card, Button, Icon } from 'antd';
const FormItem = Form.Item;
const Option = Select.Option;
const { RangePicker } = DatePicker;
const InputGroup = Input.Group;


/**
 * 获取查询面板全部条件栏目
 * @param {*} conditions
 */

/**
 * 组件prop.metadata 说明
 * @prop {Object} metadata
 * metadata参数模板
 * @param {Array} orders
 * @param {Array} conditions
 * {
      orders: [
        { value: 'num', label: '排序号' },
        @param {String} value 选中当前项时对应的值（当选中当前项时，表明用户希望以num为排序的标准）
        @param {String} label 显示在页面的标签名
      ],
      conditions: [
        {
          label: '部门', id: 'name', type: SearchType.Boolean
          @param {String} label 生成表单项的标签文本
          @param {String} id 获取表单项的值的key
          @param {String} type 动态生成表单项的类别（例如input，select等等），具体可生成类别可在'./searchTypes.js'中查看
        }
      ]
    }
 * 
 * 
 */
const getSearchFormItems = (conditions, getFieldDecorator) => {
    return conditions.map((o, i) => {
        return (
            <FormItem key={i} label={o.label} style={{ paddingBottom: 10 }} >
                {getFormItem(o, getFieldDecorator)}
            </FormItem>
        )
    })
    
}

const getOpSelect = (o, getFieldDecorator) => {
    return getFieldDecorator(o.id + '_PRE', { initialValue: 'Eq', })(
        <Select style={{ width: 60 }}>
            <Option value="Eq">=</Option>
            <Option value="Gr">&gt;</Option>
            <Option value="GrEq">&gt;=</Option>
            <Option value="Le">&lt;</Option>
            <Option value="LeEq">&lt;=</Option>
            <Option value="NotEq">&lt;&gt;</Option>
        </Select>
    )
}
const getLikeSelect = (o, getFieldDecorator) => {
    return getFieldDecorator(o.id + '_PRE', {
        initialValue: 'Eq',
    })(
        <Select style={{ width: 60 }}>
            <Option value="Eq">=</Option>
            <Option value="Lk">*[]*</Option>
            <Option value="LeLk">[]*</Option>
            <Option value="RiLk">*[]</Option>
        </Select>
    );
}

const getFormItem = (o, getFieldDecorator) => {
    switch (o.type) {
        case SearchTypes.String:
            return getFieldDecorator(o.id)(<Input {...o.config} />)
        case SearchTypes.StringEx:
            return getFieldDecorator(o.id)(<Input {...o.config} addonBefore={getLikeSelect(o, getFieldDecorator)} />)
        case SearchTypes.Date:
            return getFieldDecorator(o.id)(<DatePicker {...o.config} />)
        case SearchTypes.DateEx:
            return (<InputGroup compact>
                {getOpSelect(o, getFieldDecorator)}
                {getFieldDecorator(o.id)(<DatePicker  {...o.config} />)}
            </InputGroup>)
        case SearchTypes.DateRange:
            return getFieldDecorator(o.id, o.formOption)(<RangePicker {...o.config} />)
        case SearchTypes.Numberic:
            return getFieldDecorator(o.id)(<InputNumber {...o.config} />)
        case SearchTypes.NumbericEx:
            return (
                <InputGroup compact>
                    {getOpSelect(o, getFieldDecorator)}
                    {getFieldDecorator(o.id)(<InputNumber  {...o.config} size="large" style={{ marginTop: 0 }} />)}
                </InputGroup>)
        case SearchTypes.Boolean:
            return getFieldDecorator(o.id, o.formOption)(
                <Select  {...o.config} style={{ width: 120 }} allowClear>
                    <Option value='1'>{o.trueTitle ? o.trueTitle : '是'}</Option>
                    <Option value='0'>{o.falseTitle ? o.falseTitle : '否'}</Option>
                </Select>
            )
        case SearchTypes.Select:
            return getFieldDecorator(o.id)(
                <Select {...o.config} style={{ width: 120 }} allowClear>
                    {o.dataSource.map((o, i) => { return (<Option key={i} value={o.value.toString()}>{o.label}</Option>) })}
                </Select>
            )
        default:
            throw new Error('未知的搜索面板类型');
    }
}

class SearchPanel extends Component {
    render() {
        const { metadata, onSearch, onClearSearch, modalDeriva, onDerivationItems, title, isExport } = this.props;
        const { getFieldDecorator } = this.props.form;
        return (
            <Card title={title || "搜索"} extra={
                <Button onClick={
                    () => {
                        if (!this.props.form.isFieldsTouched()) {
                            return;
                        }
                        this.props.form.resetFields();
                        onClearSearch && onClearSearch()
                    }}
                >清空条件</Button>}
            >
                <Form layout='inline' onSubmit={(e) => {
                    e.preventDefault();
                    if (!isExport && !this.props.form.isFieldsTouched()) {
                        return;
                    }
                    const values = this.props.form.getFieldsValue();
                    // let isAllEmpty = true
                    for (let i in values) {
                        if (is.empty(values[i])) {
                            values[i] = undefined
                        }
                    }
                    onSearch({ ...values, pageIndex: 1 });
                }}>
                    {getSearchFormItems(metadata.conditions, getFieldDecorator)}
                    {
                        metadata.orders && metadata.orders.length > 0 ? (
                            <div className="ant-row ant-form-item" style={{ paddingBottom: 10, }}>
                                <FormItem label="排序" style={{ marginRight: 0 }}>

                                    {getFieldDecorator('ORDER')(
                                        <Select style={{ width: 100 }} placeholder='默认'>
                                            {metadata.orders.map((o, i) => (<Option key={i} value={o.value}>{o.label}</Option>))}
                                        </Select>
                                    )}
                                </FormItem>
                                <FormItem style={{ marginRight: 0 }}>
                                    {getFieldDecorator('ORDER_DIRECTION', { initialValue: 'ASC' })(
                                        <Select style={{ width: 60 }}>
                                            <Option value="ASC">升序</Option>
                                            <Option value="DESC">降序</Option>
                                        </Select>
                                    )}
                                </FormItem>
                            </div>
                        ) : null
                    }
                    <Button type='primary' htmlType="submit" style={{ marginTop: 1, height: 32, marginBottom: 10 }}><Icon type="search" />{title || '搜索'}</Button>
                    {modalDeriva ? (<Button type='primary' onClick={() => onDerivationItems(this.props.form.getFieldsValue())} size="large" style={{ marginLeft: 10 }}>导出</Button>) : null}
                </Form>
            </Card>
        )
    }
}

export default Form.create()(SearchPanel);