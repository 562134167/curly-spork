import React, { PureComponent } from 'react';
import is from 'is_js'
import { Form, Input, InputNumber, Select, DatePicker, Checkbox, Radio, Switch, TimePicker, Upload, Icon, Button } from 'antd';
import * as EditType from './editType';
import { EditFormItemLayout } from './uiSetting';
import { toString } from '../Util/reactUtil'
import { hasAttr } from '../Util/index'
const { RangePicker, MonthPicker } = DatePicker;
const CheckboxGroup = Checkbox.Group;
const RadioGroup = Radio.Group;
const FormItem = Form.Item;
class EditForm extends PureComponent {
    render() {
        const { getFieldDecorator } = this.props.form;
        return (
            <Form>
                {
                    this.props.formItems.map((item, i) => (
                        getFormItem(this.props, item, getFieldDecorator, i)
                    ))
                }
            </Form>
        )
    }
}

class InputPwd extends PureComponent {
    state = {
        type: 'password'
    }
    toggleType = () => {
        this.setState({
            type: this.state.type === 'password' ? 'text' : 'password'
        })
    }
    render() {
        const { itemConfig, ...otherProps } = this.props;
        const { type } = this.state;
        return (
            <Input {...otherProps} {...itemConfig} type={type}
                suffix={<Icon type={type === 'password' ? 'eye-o' : 'eye'} onClick={this.toggleType} />}
            />
        )
    }

}
/**
 *根据传入的配置，生成编辑面板
 *如果传入render，则默认由用户自己实现FormItem的实现
 *否则必须传入生成FormItem的类型，传入的类型必须在EditType里有声明的，否则报错
 *item类型：Object
*/
const getFormItem = (props, item, getFieldDecorator, index) => {
    // 为了显示纯展示性的文字
    if (!(item.key) && item.render) {
        return item.render(props, index)
    } else if (item.render) {
        const RenderComponent = item.render
        return (
            <FormItem {...EditFormItemLayout} {...item.itemLayout} label={item.label} key={index}>
                {getFieldDecorator(item.key, item.config)(<RenderComponent {...props} item={item} />)}
            </FormItem>
        )
    }
    return (
        <FormItem {...EditFormItemLayout} label={item.label} key={index}>
            {getFieldDecorator(item.key, item.config)(renderItem(props, item))}
        </FormItem>
    )

}

const renderItem = (props, item) => {
    switch (item.type) {
        case EditType.InputStr:
            if (item.itemConfig && item.itemConfig.type === 'password') {
                return (
                    // <Input {...item.itemConfig}>
                    //     <Icon type={item.itemConfig.type === 'password' ? 'eye-o' : 'eye'} onClick={} />
                    // </Input>
                    <InputPwd {...item} />
                )
            }
            return (
                <Input {...item.itemConfig} />
            )
        case EditType.InputNum:
            return (
                <InputNumber {...item.itemConfig} />
            )
        case EditType.Textarea:
            return (
                <Input type="textarea" {...item.itemConfig} />
            )
        case EditType.Select:
            // ant design2.X 不支持Number类型的值
            for (let i in item.options) {
                let option = item.options[i]
                if (!is.string(option.value)) {
                    option.value = toString(option.value)
                }
            }
            let options = hasAttr(item, ['itemConfig', 'options'])
            if (options) {
                for (let i in options) {
                    let option = options[i]
                    if (!is.string(option.value)) {
                        option.value = toString(option.value)
                    }
                }
            }

            return (
                <Select {...item.itemConfig}>
                    {item.options && item.options.map((o, i) => (<Select.Option key={i} value={o.value}>{o.label}</Select.Option>))}
                    {item.itemConfig && item.itemConfig.options && item.itemConfig.options.map((o, i) => (<Select.Option key={i} value={o.value}>{o.label}</Select.Option>))}
                </Select>
            )
        case EditType.DatePicker:
            return (
                <DatePicker format="YYYY-MM-DD HH:mm:ss" {...item.itemConfig} />
            )
        case EditType.RangePicker:
            return (
                <RangePicker
                    {...item.itemConfig}
                />
            )
        case EditType.MonthPicker:
            return (
                <MonthPicker {...item.itemConfig} />
            )
        case EditType.TimePicker:
            return (
                <TimePicker {...item.itemConfig} />
            )
        case EditType.Checkbox:
            return (
                <Checkbox {...item.itemConfig}>{item.itemConfig && item.itemConfig.label}</Checkbox>
            )
        case EditType.CheckboxGroup:
            return (
                <CheckboxGroup {...item.itemConfig} />
            )
        case EditType.Radio:
            return (
                <Radio  {...item.itemConfig} />
            )
        case EditType.RadioGroup:
            return (
                <RadioGroup {...item.itemConfig}>
                    {
                        is.array(item.options) && item.options.map((o, index) => (
                            <Radio value={o.value} key={index}> {o.label}</Radio>
                        ))
                    }
                </RadioGroup>
            )
        case EditType.Switch:
            return (
                <Switch {...item.itemConfig} />
            )
        case EditType.Image:
            if (item.itemConfig && item.itemConfig.listType == 'text') {
                return (<Upload
                    listType="text"
                    {...item.itemConfig}
                    onPreview={
                        (file) => {
                            if (is.string(file.response || file.thumbUrl)) {
                                window.open(file.response || file.thumbUrl)
                            }
                        }
                    }
                    onRemove={() => {
                        if (item.itemConfig && item.itemConfig.disabled) {
                            return false
                        }
                        return true
                    }}
                    withCredentials={true}
                >
                    {item.isShowbtn(props) ? (
                        <Button>
                            <Icon type="upload" /> {hasAttr(item, ['itemConfig', 'tip']) ? item.itemConfig.tip : '上传图片'}
                        </Button>) : null}
                </Upload>)
            }
            return (

                <Upload
                    listType="picture-card"
                    {...item.itemConfig}
                    onPreview={
                        (file) => {
                            if (is.function(props.onPreview)) {
                                props.onPreview(file)
                            } else {
                                window.open(file.response || file.thumbUrl)
                            }
                        }
                    }
                    onRemove={() => {
                        if (item.itemConfig && item.itemConfig.disabled) {
                            return false
                        }
                        return true
                    }}
                    withCredentials={true}
                >
                    {item.isShowbtn(props) ? (<div>
                        <Icon type="plus" />
                        <div className="ant-upload-text">{hasAttr(item, ['itemConfig', 'tip']) ? item.itemConfig.tip : '上传图片'}</div>
                    </div>) : null}
                </Upload>
            )
        default:
            throw new Error('未知的编辑表单项类型');
    }
}

export default Form.create({
    mapPropsToFields(props) { return { ...props.modal } },
    onValuesChange(props, fields) {
        if (props.onValuesChange) {
            props.onValuesChange(fields)
        }
    }

})(EditForm);