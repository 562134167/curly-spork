import React, { PureComponent } from 'react';
// import is from 'is_js'
import { Modal } from 'antd';
// import * as EditType from './editType';
// import { EditFormItemLayout } from './uiSetting';
import { formatFormData } from '../Util/reactUtil'
// import { hasAttr } from '../Util/index'
import EditForm from './editForm'

// const { RangePicker, MonthPicker } = DatePicker;
// const CheckboxGroup = Checkbox.Group;
// const RadioGroup = Radio.Group;
// const FormItem = Form.Item;


export const EditFormWrapper = EditForm
/**
 * 组件传入props说明
 * @prop {Boolean} modalVis 模态框是否可见
 * @prop {String | ReactNode} title 模态框的窗口标题
 * @prop {Object} modal 模态框表单数据对象，用以填充表单域
 * @prop {Function} onSave 保存模态框表单修改/新建执行的函数
 * @prop {Function} onCancel 取消模态框表单修改/新建执行的函数
 * @prop {Array} formItems 动态生成模态框表单的配置，根据配置生成当前页面的表单
 * @prop {String} className 指定当前模态框的类名，用于添加样式
 * @prop {Object} modalConfig 其他模态框设置，可根据ant design提供的modal API进行进一步设置
 * 
 * formItems 数组传入说明
 *  [
 *     @param {Object} formItems[0]  
      {
        @param {Function} render 生成表单项的render函数，自定义实现表单项。如果有此函数，则忽略type、label、itemConfig
        
        render: () => {
            return (
                <div></div>
            )
        }
        @param {String} type 生成表单项的类型，可选类型可参照'./editType.js',如果没有符合的选项，可自己实现表单项的render
        type: EditType.InputStr,
        @param {String} label 生成表单项的标签文本
        label: '全称',
        @param {String} key 当前表单项取值所对应的key，表单也可从传入的modal[key]中获取到当前项的值
        key: 'fullname',
        @param {Object} config 对ant design表单项的配置，设置规则参照ant design中Form.Item的API
        config: {
          rules: [
            { required: true, message: '请输入全称', type: 'string' },
          ]
        }
        @param {Object} itemConfig 对输入域的配置，可参照ant design中数据输入组件的API（eg：如果当前type为EditType.InputStr,则可参照ant design中input组件的API）
        itemConfig: { disabled: true, format: 'YYYY-MM-DD HH:mm:ss' }
        
      } 
    ]     
 */
const imgStyle = {
    marginTop: 30,
    width: '100%'
}
class EditPanel extends PureComponent {
    state = {
        previewImage: ''
    }
    handleCancel = () => {
        this.setState({
            previewImage: ''
        })
    }
    onPreview = (file) => {
        this.setState({ previewImage: file.response || file.thumbUrl })
    }
    render() {
        const { modalVis, title, modal, onSave, onCancel, formItems, className, modalConfig, footer } = this.props;
        return (modalVis ? (<Modal
            className={className}
            title={title}
            visible={modalVis}
            maskClosable={false}
            onOk={() => {
                this.editForm.props.form.validateFieldsAndScroll((err, values) => { if (!err) { onSave(formatFormData(values, formItems)); } })
            }}
            footer={footer ? footer(this) : undefined}
            onCancel={onCancel}
            {...modalConfig}>
            <EditFormWrapper wrappedComponentRef={(inst) => this.editForm = inst} modal={modal} formItems={formItems} onPreview={this.onPreview} />
            <Modal visible={Boolean(this.state.previewImage)} footer={null} onCancel={this.handleCancel}>
                <img style={imgStyle} alt="图片" src={this.state.previewImage} />
            </Modal>
        </Modal>) : null)

    }
    // componentWillReceiveProps(nextProps) {
    /* for (let key in nextProps) {
        console.log(key, nextProps[key] == this.props[key])
    } */
    // }
}

export default EditPanel;
