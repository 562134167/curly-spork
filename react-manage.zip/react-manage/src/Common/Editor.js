/*
 * @Author: miccy 
 * @Date: 2017-12-15 13:46:48 
 * @Last Modified by: miccy
 * @Last Modified time: 2018-03-08 15:52:51
 * tinymce 编辑器
 */

import React, { Component } from 'react';
// import window.tinymce from 'tinymce';
// import 'tinymce/themes/modern';
// import 'tinymce/plugins/wordcount';
// import 'tinymce/plugins/table';
import { fetchImg } from '../Config/request'
import { hasAttr } from '../Util/index'

const uploadFileUrl = '/system/file/upload'

class TinyEditorComponent extends Component {
  constructor() {
    super();
    this.state = { editor: null };
  }
  Request = {
    uploadImg: (params) => {
      return fetchImg(uploadFileUrl, params).then(res => {
        return res
      })
    }
  }
  Action = {
    uploadImg: (blobInfo, success, failure) => {
      const formData = new FormData()
      formData.append('files', blobInfo.blob(), blobInfo.filename())
      this.Request.uploadImg(formData).then(res => {
        success(res)
      })
    },
    uploadImgs: () => {

    }
  }
  componentDidMount() {
    // console.log(this.props.item.label)
    window.tinymce.init({
      // width: 750,
      height: 500,
      selector: `#tinyeditor`,
      skin_url: `${process.env.PUBLIC_URL}/skins/lightgray`,
      toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media | forecolor backcolor | fontselect fontsizeselect restoredraft",
      // font_formats: 'Arial=arial,helvetica,sans-serif;Courier New=courier new,courier,monospace;AkrutiKndPadmini=Akpdmi-n',
      plugins: [
        "advlist autolink lists link image charmap preview anchor",
        "searchreplace visualblocks media code fullscreen wordcount imagetools textcolor autosave",
        // "insertdatetime media table contextmenu paste imagetools"
      ],
      // theme: 'advanced',
      // theme_advanced_toolbar_location : "top",
      file_picker_types: 'image media',
      theme_advanced_resizing: true,
      images_upload_handler: this.Action.uploadImg,
      file_browser_callback_types: 'file image media',
      images_upload_credentials: true,
      language: 'zh_CN',
      language_url: '/js/tinymce/langs/zh_CN.js',
      branding: false,
      fixed_toolbar_container: '#mytoolbar',
      // inline: true,
      // audio_template_callback: (data) => {
      //   return '<audio controls>' + '\n<source src="' + data.source1 + '"' + (data.source1mime ? ' type="' + data.source1mime + '"' : '') + ' />\n' + '</audio>';
      // },
      video_template_callback: function (data) {
        return '<video width="' + data.width + '" height="' + data.height + '"' + (data.poster ? ' poster="' + data.poster + '"' : '') + ' controls="controls">\n' + '<source src="' + data.source1 + '"' + (data.source1mime ? ' type="' + data.source1mime + '"' : '') + ' />\n' + (data.source2 ? '<source src="' + data.source2 + '"' + (data.source2mime ? ' type="' + data.source2mime + '"' : '') + ' />\n' : '') + '</video>';
      },
      file_picker_callback: (cb, value, meta) => {
        // console.log(meta)
        if (meta.filetype == 'image') {
          this.upload.setAttribute('accept', 'image/*')
        } else if (meta.filetype == 'media') {
          this.upload.setAttribute('accept', 'video/*')
        } else {
          this.upload.setAttribute('accept', 'audio/*')
        }
        this.upload.onchange = (e) => {
          console.log(e.target)
          if (!e.target.files || !e.target.files[0]) {
            return;
          }
          const formData = new FormData()
          formData.append('files', e.target.files[0])
          this.Request.uploadImg(formData).then(res => {
            cb(res, { title: e.target.files[0].name });
          })
        }
        this.upload.click()
      },
      setup: editor => {
        this.setState({ editor });
        editor.on('change', () => {
          if (!window.tinymce.activeEditor) {
            return;
          }
          if (hasAttr(this.props, 'item.itemConfig') && this.props.item.itemConfig.disabled) {
            window.tinymce.activeEditor.getBody().setAttribute('contenteditable', false);
            return;
          }
          const content = editor.getContent();
          this.props.onChange(content);
        });
      },
      init_instance_callback: (editor) => {
        editor.focus()
        // console.log("Editor: " + editor.id + " is now initialized.");
        if (hasAttr(this.props, 'item.itemConfig') && this.props.item.itemConfig.disabled) {
          window.tinymce.activeEditor.getBody().setAttribute('contenteditable', false);
          return;
        }
        // window.tinymce.activeEditor.getBody().setAttribute('contenteditable', false);
      }
    });
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.value === this.props.value) {
      return;
    }
    if ('value' in nextProps) {
      try {
        // this.state.editor.setContent(nextProps.value || '')
        // this.state.editor.selection.select(this.state.editor.getBody(), true);//this.state.editor is the editor instance
        // this.state.editor.selection.collapse(false);
        window.tinymce.activeEditor.setContent(nextProps.value || '')
        window.tinymce.activeEditor.selection.select(window.tinymce.activeEditor.getBody(), true)
        window.tinymce.activeEditor.selection.collapse(false);
      } catch (e) {
      }
    }
  }

  componentWillUnmount() {
    // console.log(this)
    this.setState({
      editor: null
    })
    window.tinymce.remove(this.state.editor);
  }

  render() {
    return (
      <div>
        {/* <div id="mytoolbar"></div> */}
        {/* <div style={{ position: 'fixed', top: 0 }} id="mytoolbar"></div> */}
        <textarea
          id="tinyeditor"
          value={this.props.value}
          onChange={e => console.log(e)}
        />
        <input type="file" accept="video/*" style={{ display: 'none' }} ref={(el) => { this.upload = el }} />
      </div>
    );
  }
}

export default TinyEditorComponent;