import React from 'react';
import { Spin } from 'antd';
const styles = {
  container: {
    position: 'fixed', 
    left: 0, 
    right: 0, 
    bottom: 0, 
    top: 0, 
    height: '100%', 
    display: 'flex', 
    justifyContent: 'center', 
    alignItems: 'center', 
    // background: 'rgba(255,255,255,.8)',
    zIndex: 99999,
  }
}
export default ({tip="内容加载中..."}) => (
  <div style={styles.container}>
    <Spin tip={tip} size="large">
      {/*<Alert
      message="Alert message title"
      description="Further details about the context of this alert."
      type="info"
    />*/}
    </Spin>
  </div>
)