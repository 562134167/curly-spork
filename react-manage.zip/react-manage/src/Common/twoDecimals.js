import React, { PureComponent } from 'react'
import { Input } from 'antd'
import is from 'is_js'
import { changeTwoDecimal } from '../Util/index'
export default class TwoDecimals extends PureComponent {
  constructor(props) {
    super(props)
    const value = this.props.value
    this.state = {
      value: changeTwoDecimal(value || '')
    }
  }
  Action = {
    onInputChange: (e) => {
      const value = e.target.value
      if (value && !/^\d+\.?\d{0,2}$/.test(value)) {
        return;
      }
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    onInputBlur: (e) => {
      const value = changeTwoDecimal(e.target.value)
      if (!('value' in this.props)) {
        this.setState({
          value
        })
      }
      this.Action.triggerChange(value)
    },
    triggerChange: (changedValue) => {
      const onChange = this.props.onChange
      if (onChange) {
        onChange(changedValue)
      }
    }
  }
  componentWillReceiveProps(nextProps) {
    if ('value' in nextProps) {
      const value = nextProps.value
      if (!is.undefined(value)) {
        this.setState({ value })
      }
    }
  }

  render() {
    const { onInputChange, onInputBlur } = this.Action
    const { value } = this.state
    return (
      <div>
        <Input
          type="number"
          value={value}
          placeholder={parseFloat(0).toFixed(2)}
          onChange={onInputChange}
          onBlur={onInputBlur}
          {...this.props.item.itemConfig}
        />
      </div>
    )
  }
}