import React from 'react'
import { Dropdown, Button, Icon, Menu } from 'antd'
import is from 'is_js'

export default (props) => {
  const { mainLabel, keyName, items, onClick } = props
  if (!is.array(items)) {
    throw new Error(`组件dropdownBtn传入的prop.item应为Array类型`)
  }
  if (is.undefined(keyName)) {
    throw new Error(`组件dropdownBtn的prop.keyName必须传入`)
  }
  const menu = (
    <Menu onClick={({ key }) => { onClick({ name: keyName, value: key }) }}>
      {items.map((item, index) => (
        <Menu.Item key={item.value}>{item.label}</Menu.Item>
      ))}
    </Menu>
  );
  return (<Dropdown
    overlay={menu}
    trigger={["click"]}
  >
    <Button ghost className={props.className} trigger={['trigger']} type={props.type || 'primary'}>
      {mainLabel}<Icon type="down" />
    </Button>
  </Dropdown>)
}
