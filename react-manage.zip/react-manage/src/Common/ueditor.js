
import React, { Component } from 'react';

/* import '../static/ueditor/ueditor.config.js';
import UE from '../static/ueditor/ueditor.all.min.js';
import '../static/ueditor/lang/zh-cn/zh-cn.js' */
const { UE } = window;
export default class Ueditor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      editor: null,
    }
  }
  resetContent() {
    this.state.editor.setContent('')
  }
  // 初始化编辑器
  initEditor() {
    const { id, config, initValue, form, label } = this.props;
    const ueEditor = UE.getEditor(id, config);
    const self = this;
    ueEditor.ready((status) => {
      if (!status) {
        UE.delEditor(id);
        self.initEditor()
      }
      ueEditor.setContent(initValue);
      // ueEditor.focus(true);
      // ueEditor.fireEvent('autoheightchanged', true);
      ueEditor.addListener('contentChange', () => {
        // const wordCount = ueEditor.getContentLength(true);
        const content = ueEditor.getContent();
        // const plainTxt = ueEditor.getPlainTxt();
        // const htmlCont = ueEditor.getAllHtml();
        if (form) {
          if (!label) {
            throw new Error('请传入label值');
          }
          form.setFieldsValue({
            [label]: content
          })
        }
      })
    })
  }
  onChange() {
    const ueEditor = UE.getEditor(this.props.id);
    return ueEditor.getContent();
  }
  render() {
    return (
      <div id={this.props.id}></div>
    )
  }
  componentDidMount() {
    this.initEditor();
  }
  componentWillUnmount() {
    UE.delEditor(this.props.id);
    console.log(UE)
  }
}
Ueditor.defaultProps = {
  config: {},
  id: new Date().getTime() + 'id',
  initValue: ''
}