import React, { Component } from 'react';
import { Button, message } from 'antd';
const styles = {
  input: {
    display: 'none'
  }
}

export default class Upload extends Component {
  constructor(props) {
    super(props);
    this.onChange = this.onChange.bind(this);
    this.onClick = this.onClick.bind(this);
  }

  onChange(e) {
    const { options } = this.props;
    const file = e.target.value;
    if (!file) {
      return;
    } else {
      let fd = new FormData();
      let type = file.split('.').pop();//获取图片类型
      let fileType = options.fileType || [];
      if (fileType.indexOf(type.toLocaleLowerCase()) == -1) {
        message.error("暂不支持该类型的文件，请重新选择!");
        return;
      }
      //文件上传前处理事件
      if (options.beforeSend instanceof Function) {
        if (options.beforeSend(e) === false) {
          return false;
        }
      }
      //多文件上传
      if (options.multiple) {
        for (let i = 0, file; file = e.target.files[i++];) {
          fd.append('file' + i, file);
        }
      } else {
        fd.append('uploadFile', e.target.files[0]);
      }
    }

  }
  onClick() {
    this.refs.upload.click();
  }
  render() {
    const { btnTxt } = this.props;
    return (
      <div style={styles.container}>
        <Button type="primary" icon="plus" onClick={this.onClick}>{btnTxt}</Button>
        <input type="file" ref="upload" onChange={this.upload} style={styles.input} />

      </div >
    )
  }

}
Upload.defaultProps = {
  btnTxt: '上传图片',
  options: {}
}
