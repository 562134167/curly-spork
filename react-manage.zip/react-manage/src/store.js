import { createStore, combineReducers, applyMiddleware } from 'redux';
import { routerReducer, routerMiddleware } from 'react-router-redux';
import createHistory from 'history/createBrowserHistory';
// import { createLogger } from 'redux-logger' // 利用redux-logger打印日志
import thunk from 'redux-thunk';
import { reducer as indexReducer, action as indexAction } from './Pages'
import { reducer as loginReducer, action as loginAction } from './Pages/Login'
import axios from 'axios'
import { message } from 'antd'
import { removeStore } from './Util'
import is from 'is_js'
const history = createHistory()
// Build the middleware for intercepting and dispatching navigation actions
const routermiddleware = routerMiddleware(history)
// 调用日志打印方法
// const loggerMiddleware = createLogger();

const middleware = [thunk, routermiddleware];
// console.log(middleware)
const store = createStore(
  combineReducers({
    index: indexReducer,
    router: routerReducer,
    login: loginReducer
  }),
  applyMiddleware(...middleware)
);


// axios请求
axios.defaults.withCredentials = true
axios.defaults.timeout = 20000
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
axios.defaults.headers.post['Access-Control-Allow-Origin'] = '*'
// axios.defaults.headers.post['Access-Control-Allow-Credentials'] = true
// axios.defaults.headers.post['withCredentials'] = true
axios.defaults.baseURL = window.baseUrl;

// 显示加载数据loading效果
axios.interceptors.request.use((config) => {
  // 加载效果
  store.dispatch(indexAction.showLoading())
  return config
}, (error) => {
  //关闭加载效果
  store.dispatch(indexAction.hideLoading())
  message.error('请求出错')
  return Promise.reject(error)
});
// 返回状态判断
axios.interceptors.response.use((res) => {
  //返回成功关闭加载效果
  store.dispatch(indexAction.hideLoading())
  //返回值
  if (!is.empty(res)) {
    if (res.status != 200) {
      message.error(res.msg || '出错了！')
    }
  }
  return res;
}, (error) => {
  //返回失败关闭加载效果
  if (error.response) {
    if (error.response.status == 401) {
      message.error('登录过期，请重新登录')
      removeStore('user')
      store.dispatch(loginAction.loginFail())
    }
  }
  // else if (error.request.status == 401 || !error.request.status) {
  //   if (error.request.status == 401) {
  //     message.error('登录过期，请重新登录')
  //   }
  //   removeStore('user')
  //   store.dispatch(loginAction.loginFail())
  // } 
  else {
    message.error('网络错误！')
  }
  store.dispatch(indexAction.hideLoading())
  return Promise.reject(error);
});

export default store