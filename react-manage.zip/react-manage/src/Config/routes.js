import React, { Component } from 'react'
import { Route, Redirect, Switch } from 'react-router'
// import CSSTransitionGroup from 'react-addons-css-transition-group'
import { getComponent } from '../Common/bundle'
// import { getStore } from '../Util'
const loadApp = (cb) => {
  return import('../Pages/App/index')
}
const loadHome = (cb) => {
  return import('../Pages/Home/index')
}
const loadLogin = (cb) => {
  return import('../Pages/Login/index')
}
const loadNotFound = (cb) => {
  return import('../Pages/NotFound/index')
}
const loadSystemManage = (cb) => {
  return import('../Pages/SystemManage/index')
}
// const loadPayment = (cb) => {
//   return import('../Pages/Payment/index')
// }
// const loadRoute = (cb) => {
//   return import('../Pages/RouteManage/index')
// }
// const loadMoneyManage = (cd) => {
//   return import('../Pages/MoneyManage/index')
// }
// const loadOrderManage = (cb) => {
//   return import('../Pages/OrderManage/index')
// }
// const loadBusinessManage = (cd) => {
//   return import('../Pages/BusinessManage/index')
// }
const loadAccountCenter = (cb) => {
  return import('../Pages/AccountCenter/index')
}
const loadFundRecord = (cb) => {
  return import('../Pages/FundRecord/index')
}
const loadMessage = (cb) => {
  return import('../Pages/Message/index')
}
const loadOfficialAccount = (cb) => {
  return import('../Pages/OfficialAccount/index')
}
// const loadImageMsg = (cb) => {
//   return import('../Pages/ImageMsg/index')
// }
const loadBusinessCircle = (cb) => {
  return import('../Pages/BusinessCircle/index')
}
const loadAdvert = (cb) => {
  return import('../Pages/Advert/index')
}
// const loadMeal = (cb) => {
//   return import('../Pages/Meal/index')
// }
const loadActivity = (cb) => {
  return import('../Pages/Activity/index')
}
const loadFinance = (cb) => {
  return import('../Pages/Finance/index')
}
// const loadFinance = (cb) => {
//   return import('../Pages/Finance/index')
// }
const loadRecharge = (cb) => {
  return import('../Pages/Recharge/index')
}
const loadSubsidiary = (cb) => {
  return import('../Pages/Subsidiary/index')
}
const loadValidateFund = (cb) => {
  return import('../Pages/ValidateFund/index')
}
const loadRedpacket = (cb) => {
  return import('../Pages/Redpacket/index')
}
//const loadTraintickets = (cb) => {
//return import('../Pages/Traintickets/index')
//}
const loadExportData = (cb) => {
  return import('../Pages/ExportData/index')
}
const loadIntegral = (cb) => {
  return import('../Pages/Integral/index')
}
const loadLifePay = (cb) => {
  return import('../Pages/LifePay/index')
}
const loadMall = (cb) => {
  return import('../Pages/Mall/index')
}
const loadApplication = (cb) => {
  return import('../Pages/Application/index')
}
const loadthirdparty = (cb) => {
  return import('../Pages/thirdparty/index')
}
const App = getComponent(loadApp)
const Login = getComponent(loadLogin)
const NotFound = getComponent(loadNotFound)

const routes = [
  {
    path: '/home',
    component: getComponent(loadHome)
  }, {
    path: '/system',
    component: getComponent(loadSystemManage)
  },
  // {
  //   path: '/payment',
  //   component: getComponent(loadPayment)
  // }, {
  //   path: '/route',
  //   component: getComponent(loadRoute)
  // },
  // {
  //   path: '/moneyManage',
  //   component: getComponent(loadMoneyManage)
  // }, 
  // {
  //   path: '/orderManage',
  //   component: getComponent(loadOrderManage)
  // },
  // {
  //   path: '/businessManage',
  //   component: getComponent(loadBusinessManage)
  // }, 
  {
    path: '/accountCenter',
    component: getComponent(loadAccountCenter)
  }, {
    path: '/fundRecord',
    component: getComponent(loadFundRecord)
  }, {
    path: '/message',
    component: getComponent(loadMessage)
  }, {
    path: '/officialAccount',
    component: getComponent(loadOfficialAccount)
  }, {
    path: '/advert',
    component: getComponent(loadAdvert)
  }, {
    path: '/businessCircle',
    component: getComponent(loadBusinessCircle)
  },
  // {
  //   path: '/meal',
  //   component: getComponent(loadMeal)
  // }, 
  {
    path: '/activity',
    component: getComponent(loadActivity)
  },
  {
    path: '/finance',
    component: getComponent(loadFinance)
  },
  {
    path: '/recharge',
    component: getComponent(loadRecharge)
  }, {
    path: '/subsidiary',
    component: getComponent(loadSubsidiary)
  }
  , {
    path: '/validateFund',
    component: getComponent(loadValidateFund)
  }, {
    path: '/redpacket',
    component: getComponent(loadRedpacket)
  }, {
    path: '/exportData',
    component: getComponent(loadExportData)
  }
//, {
//  path: '/Traintickets',
//  component: getComponent(loadTraintickets)
//}
  , {
    path: '/integral',
    component: getComponent(loadIntegral)
  }, {
    path: '/lifePay',
    component: getComponent(loadLifePay)
  }, {
    path: '/mall',
    component: getComponent(loadMall)
  }, {
    path: '/application',
    component: getComponent(loadApplication)
  }, {
    path: '/thirdparty',
    component: getComponent(loadthirdparty)
  }
  ]
// 循环路由
const RouteWithSubRoutes = ({ location, ...route }) => {
  return (
    <Route location={location} path={route.path} render={props => {

      // if (!getStore('user') && location.pathname !== '/login') {
      //   props.history.push('/login')
      // }
      return (
        <route.component  {...props} />
      )
    }} />

  )
}    
class Routes extends Component {
  render() {
    return (
      <Route render={(props) => {
        const location = props.location
        return (
          <App {...props}>
            <Switch>
              <Route
                path="/"
                location={location}
                key={location.key}
                exact render={() => <Redirect to="/login" />}
              />
              <Route path="/login" exact render={(props) => <Login {...props} />} />
              {routes.map((route, i) => (
                <RouteWithSubRoutes
                  location={location}
                  key={i}
                  {...route} />
              ))
              }
              <Route render={(props) => <NotFound {...props} />} />
            </Switch>
          </App >
        )
      }
      } />
    )
  }
}
export default Routes;