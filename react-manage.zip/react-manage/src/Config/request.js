import React from 'react'
import axios from 'axios'
import is from 'is_js'
import qs from 'qs'
import { message } from 'antd'
export const fetchImg = (url, params) => {
  return new Promise((resolve, reject, foramt) => {
    // console.log(params)
    axios({
      method: 'post',
      url,
      data: params,
      timeout: 200000,
      headers: { 'Content-Type': 'multipart/form-data' }
    }).then(response => {
      var temp = {};
      if (is.object(response) && response.data) {
        temp = response.data;
      }
      // if (temp.status == 0) {
      //   message.success('上传图片成功！')
      // } else {
      //   message.error('上传图片失败！')
      // }
      resolve(temp);
    }, err => {
      reject(err);
    })
      .catch((error) => {
        reject(error)
      })
  })
}
export const fetch = (url, params, foramt, timeout, isShowError = true) => {
  return new Promise((resolve, reject) => {
    axios({
      method: 'post',
      url,
      data: qs.stringify(params, { arrayFormat: (foramt && foramt.arrayFormat) || 'repeat', allowDots: true }),
      timeout: timeout !== undefined ? timeout : 20000,
    }).then(response => {

        var temp = {};

        if (is.object(response) && response.data) {
          temp = response.data;
        }


        if (temp.status == 0) {
          message.success('操作成功!')
        } else if (isShowError) {
          const content = {
            __html: temp.msg || '操作失败！'
          }
          message.error(<span dangerouslySetInnerHTML={content}></span>)
        }
        resolve(temp);
      }, err => {
        //console.log(err)
        reject(err);
      })
      .catch((error) => {
        reject(error)
      })
  })
}

export const getFetch = (url, params, isShowError = true, timeout) => {
  return new Promise((resolve, reject) => {
    axios({
      method: 'get',
      url: params ? url + qs.stringify(params, { addQueryPrefix: true }) : url,
      timeout: timeout !== undefined ? timeout : 20000,
    })
      .then(response => {
        var temp;
        // console.log(response)
        if (is.object(response) && response.data) {
          temp = response.data;
        }
        if (temp && temp.status == 1 && temp.msg && isShowError) {
          const content = {
            __html: temp.msg
          }
          message.error(<span dangerouslySetInnerHTML={content}></span>)
        }
        resolve(temp);
      }, err => {
        //console.log(err)
        reject(err);
      })
      .catch((error) => {
        reject(error)
      })

  })
}




export const baseUrl = window.baseUrl

