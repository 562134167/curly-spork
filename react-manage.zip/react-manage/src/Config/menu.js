const items = [];
/**
 * 用于左边菜单与路径匹配
 * @param {*} items
 * @param {*} path
 */
const getFullPath = (items, path) => {
  for (let i in items) {
    const subItem = items[i];
    if (subItem.items && subItem.items.length) {
      let arr = getFullPath(subItem.items, path)
      if (arr) {
        arr.push(subItem.url)
        return arr;
      }
    } else if (subItem.url === path) {
      return []
    }
  }
  return null;
}
/**
 * 用于面包屑进行路径显示
 * @param {*} items
 * @param {*} path
 */
const getFullItems = (items, path) => {
  for (let i in items) {
    const subItem = items[i];
    if (subItem.items && subItem.items.length) {
      let arr = getFullItems(subItem.items, path);
      if (arr) {
        arr.push(subItem);
        return arr;
      }
    } else {
      if (subItem.url === path) {
        return [subItem];
      }
    }
  }
  return null;
}
const hasItems = (items, path) => {
  for (let i in items) {
    const subItem = items[i];
    if (subItem.items && subItem.items.length) {
      if (getFullItems(subItem.items, path)) {
        return true;
      }
    } else {
      if (subItem.url === path) {
        return true;
      }
    }
  }
  return false;
}
const MenuData = {
  items,
  getOpenKeys(path, menuData = this.items) {
    return getFullPath(menuData, path);
  },
  getFullItems(path, menuData = this.items) {
    return getFullItems(menuData, path);
  },
  hasItems(path, menuData = this.items) {
    return hasItems(menuData, path);
  },
  setItems(items) {
    this.items = items;
  }
}

export default MenuData;