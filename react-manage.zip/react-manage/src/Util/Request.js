import { getFetch, fetch } from '../Config/request'
import is from 'is_js'
import { formatData } from './reactUtil'
import { arrayToObject } from './index'

/**
 * 获取页面列表数据
 * @param {Object} params 请求的参数    
 * @param {Function} successCallback 请求成功执行的函数 
 * @param {Function} failCallback 请求失败执行的函数
 * @param {String} pagingUrl 请求的url（*）
 * @param {Object} context 当前请求的上下文(如果没有传入successCallback,则必须传入context)
 * @param {Object} format 请求参数的格式
 */
export const requestGet = ({
  params,
  successCallback,
  failCallback,
  pagingUrl,
  context,
  foramt
}) => {
  return getFetch(pagingUrl, params, foramt).then(res => {
    // 如果获取的
    if (res && is.array(res.models)) {
      if (is.function(successCallback)) {
        successCallback(res)
      } else {
        const { models, totalModels } = res
        const dataSource = formatData(models)
        context.setState({
          dataSource,
          totalModels,
          current: params.pageIndex,
          pageSize: params.pageSize,
          selectedRowKeys: []
        })
      }
    } /*else if (is.function(failCallback)) {
      failCallback(res)
    }*/
    console.log(res.models);
    return res
  }, (error) => {
    if (is.function(failCallback)) {
      failCallback(error)
    }
  })
}
/**
 * 请求添加列表项
 * @param {Object} params 请求的参数 
 * @param {Function} successCallback 请求成功执行的函数 
 * @param {Function} failCallback 请求失败执行的函数
 * @param {String} addUrl 请求的url（*）
 * @param {Object} context 当前请求的上下文(如果没有传入successCallback,则必须传入context)
 * @param {Object} format 请求参数的格式
 */
export const requestAdd = ({
  params,
  successCallback,
  failCallback,
  addUrl,
  context,
  format
}) => {
  return fetch(addUrl, params, format).then(res => {
    if (res.status == 0) {
      if (is.function(successCallback)) {
        successCallback(res)
      } else {
        context.setState({
          modalVis: false
        })

        context.Request.get(context.state.getDataParams)
      }
    } else if (is.function(failCallback)) {
      failCallback(res)
    }     
    return res
  }, (error) => {
    if (is.function(failCallback)) {
      failCallback(error)
    }
  })
}
/**
 * 请求修改列表项
 * @param {Object} params 请求的参数 
 * @param {Function} successCallback 请求成功执行的函数 
 * @param {Function} failCallback 请求失败执行的函数
 * @param {String} updateUrl 请求的url（*）
 * @param {Object} context 当前请求的上下文(如果没有传入successCallback,则必须传入context)
 * @param {Object} format 请求参数的格式
 */
export const requestUpdate = ({
  params,
  successCallback,
  failCallback,
  updateUrl,
  context,
  format
}) => {
  return fetch(updateUrl, params, format).then(res => {
    if (res.status == 0) {
      if (is.function(successCallback)) {
        successCallback(res)
      } else {
        context.setState({
          modalVis: false
        })
        context.Request.get(context.state.getDataParams)
      }
    } else if (is.function(failCallback)) {
      failCallback(res)
    }
    return res
  }, (error) => {
    if (is.function(failCallback)) {
      failCallback(error)
    }
  })
}
/**
 * 批量更新属性
 * @param {Object} params 请求的参数 
 * @param {Function} successCallback 请求成功执行的函数 
 * @param {Function} failCallback 请求失败执行的函数
 * @param {String} updatePropertyUrl 请求的url（*）
 * @param {Object} context 当前请求的上下文(如果没有传入successCallback,则必须传入context)
 * @param {Object} format 请求参数的格式
 */
export const requestUpdateProperty = ({
  params,
  successCallback,
  failCallback,
  updatePropertyUrl,
  context,
  format
}) => {
  return fetch(updatePropertyUrl, params, format).then(res => {
    if (res.status == 0) {
      if (is.function(successCallback)) {
        successCallback(res)
      } else {
        context.Request.get(context.state.getDataParams)
      }
    } else if (is.function(failCallback)) {
      failCallback()
    }
    return res
  }, error => {
    if (is.function(failCallback)) {
      failCallback(error)
    }
  })
}
/**
 * 删除列表项
 * @param {Object} params 请求的参数 
 * @param {Function} successCallback 请求成功执行的函数 
 * @param {Function} failCallback 请求失败执行的函数
 * @param {String} removeUrl 请求的url（*）
 * @param {Object} context 当前请求的上下文(如果没有传入successCallback,则必须传入context)
 * @param {Object} format 请求参数的格式
 */
export const requestRemove = ({
  params,
  successCallback,
  failCallback,
  removeUrl,
  context,
  format
}) => {    
  return fetch(removeUrl, params).then(res => {
    if (res.status == 0) {
      if (is.function(successCallback)) {
        successCallback()    
      } else {
        const { selectedRowKeys } = context.state;
        for (let i in selectedRowKeys) {
          if (selectedRowKeys[i] === params.id) {
            selectedRowKeys.splice(i, 1);
            break;
          }
        }
        context.setState({
          selectedRowKeys
        })
        context.Request.get(context.state.getDataParams)
      }
    } else if (is.function(failCallback)) {
      failCallback()
    }
    return res
  }, error => {
    if (is.function(failCallback)) {
      failCallback()
    }
  })
}
/**
 * 批量删除列表项
 * @param {Object} params 请求的参数 
 * @param {Function} successCallback 请求成功执行的函数 
 * @param {Function} failCallback 请求失败执行的函数
 * @param {String} removeItemsUrl 请求的url（*）
 * @param {Object} context 当前请求的上下文(如果没有传入successCallback,则必须传入context)
 * @param {Object} format 请求参数的格式
 */
export const requestRemoveItems = ({
  params,
  successCallback,
  failCallback,
  removeItemsUrl,
  context,
  format
}) => {
  return fetch(removeItemsUrl, params).then(res => {
    if (res.status == 0) {
      if (is.function(successCallback)) {
        successCallback()
      } else {
        context.setState({
          selectedRowKeys: []
        })
        context.Request.get(context.state.getDataParams)
      }
    } else if (is.function(failCallback)) {
      failCallback()
    }
    return res
  }, error => {
    if (is.function(failCallback)) {
      failCallback()
    }
  })
}

export const requestEnum = ({ successCallback, failCallback, getEnumUrl, context, optionKey, enumKey, labelKey = 'name', valueKey = 'value' }) => {
  return getFetch(getEnumUrl).then(res => {
    if (is.array(res)) {
      if (is.function(successCallback)) {
        successCallback()
      } else {
        let options = null, enumObj = null;
        if (optionKey) {
          options = context.state[optionKey];
          res.forEach(item => {
            options.push({
              label: item[labelKey],
              value: item[valueKey]
            })
          })
        }
        if (enumKey) {
          enumObj = arrayToObject({ array: res, keyName: valueKey, valueName: labelKey })
        }
        optionKey && context.setState({
          [optionKey]: options
        })
        enumKey && context.setState({
          [enumKey]: enumObj
        })
      }
    } else {
      if (is.function(failCallback)) {
        failCallback()
      }
    }
    return res
  }, error => {
    if (is.function(failCallback)) {
      failCallback()
    }
  })
}
