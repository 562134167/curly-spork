import { formateEditData } from './reactUtil'
import { message } from 'antd'
import is from 'is_js'
export const initGetParams = {
  // keyword: '',
  pageIndex: 1,
  pageSize: 20
}                     

export const initNullParams = {
  
}

// 点击新增按钮
export const actionAdd = ({ context, addTitle }) => {
  context.setState({
    modalVis: true,
    modal: context.newItem,
    editId: null,
    title: addTitle,
  })
}
// 点击列表项的编辑按钮
export const actionEdit = ({ record, handleEditData, context, editTitle }) => {
  let modal = {}
  let obj
  if (is.function(handleEditData)) {
    obj = formateEditData(record, context.formItems, handleEditData)
  } else {
    obj = formateEditData(record, context.formItems)
  }
  for (let i in obj) {
    modal[i] = {
      value: obj[i]
    }
  }
  context.setState({
    editId: obj.id,
    modalVis: true,
    modal: modal,
    title: editTitle
  })
}
// 点击搜索面板的搜索按钮
export const actionSearch = ({ value, context }) => {
  const queryParams = Object.assign({}, value)
  const { getDataParams } = context.state
  const params = { ...getDataParams, ...queryParams }
  context.setState({
    getDataParams: params
  })
}
// 点击搜索面板的清空搜索按钮
export const actionClearSearch = ({
  context,
  initGetParams = {
    // keyword: '',
    pageIndex: 1,
    pageSize: 20
  }
}) => {
  const pageSize = context.state.pageSize
  if (pageSize) {
    context.setState({
      getDataParams: { ...initGetParams, pageSize }
    })
  } else {
    context.setState({
      getDataParams: initGetParams
    })
  }

}
// 点击模态框的保存按钮
export const actionSave = ({ context, values, handleChangedData }) => {
  const { dataSource, editId } = context.state
  const { add, edit } = context.Request
  // 把保存的数值发送到服务器
  // 编辑状态下的保存
  if (editId || editId === 0) {
    for (let i in dataSource) {
      if (dataSource[i].id === editId) {
        if (is.function(handleChangedData)) {
          const temp = handleChangedData({ ...dataSource[i], ...values })
          edit(temp)
        } else {
          const temp = { ...dataSource[i], ...values }
          edit(temp)
        }
        break;
      }
    }
  } else {
    // 新增状态下的保存
    if (is.function(handleChangedData)) {
      const temp = handleChangedData(values);
      add(temp)
    } else {
      console.log(values);
      add(values)
    }
  }
}


// 点击模态框的取消按钮
export const actionCancel = ({ context }) => {
  context.setState({
    modalVis: false
  })
}
// 点击列表页的页数按钮
export const actionChangePage = ({ page, pageSize, context }) => {
  const { getDataParams } = context.state
  const params = { ...getDataParams, pageIndex: page }
  context.setState({
    getDataParams: params,
  })
}
export const actionOnShowSizeChange = ({ pageSize, context }) => {
  const { getDataParams } = context.state
  const params = { ...getDataParams, pageSize, pageIndex: 1 }
  console.log(params)
  context.setState({
    getDataParams: params,
    pageSize
  })
}
// 点击批量更新属性的按钮
export const actionEditItems = ({ context, name, value }) => {
  const { selectedRowKeys } = context.state
  if (!selectedRowKeys.length) {
    message.error('请至少选中一行要操作的数据')
    return;
  }
  context.Request.editItems({
    name,
    value,
    ids: selectedRowKeys
  })
}
// 点击列表项的删除按钮
export const actionRemove = ({ context, id }) => {
  context.Request.delete({ id })
}
// 点击批量删除按钮
export const actionRemoveItems = ({ context }) => {
  const { selectedRowKeys } = context.state;
  context.Request.deleteItems({ ids: selectedRowKeys })
}
export const actionShowTotal = (total, range) => `共 ${total} 条记录`

export const getSchemaCols = ({ context }) => {
  const schemaCols = [];
  if (context.columns) {
    context.columns.forEach(item => {
      schemaCols.push({
        key: item.key,
        title: item.title
      })
    });
  }
  return schemaCols;
}

export const getShowCols = ({ context, showKeys }) => {
  let showCols = [];
  if (context.columns) {
    showCols = context.columns.filter(item => {
      if (showKeys.indexOf(item.key) > -1) {
        return true;
      }
    });
  }
  return showCols;
}