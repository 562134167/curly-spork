import is from 'is_js'
import moment from 'moment'
import { hasAttr } from './index'
import * as EditType from '../Common/editType'

// 将后端传的分金额转换成元
export const toMoney = (val, unit = '元') => {
  return parseFloat(isNaN(val) ? 0 : (val / 100)).toFixed(2) + unit;
}

// 将url字符串转换成符合antd的图片数组
export const getFileList = (url) => {
  // 将获得的url转换成Upload要求的数据格式
  let tempUrl = url.replace('[', '')
  tempUrl = tempUrl.replace(']', '')
  const tempArr = tempUrl.split(',')
  const fileList = []
  for (let i in tempArr) {
    fileList.push({
      uid: new Date().getTime() + i,
      status: 'done',
      url: tempArr[i],
      response: tempArr[i]
    })
  }
  return fileList
}
// 将上传的图片数组转换成以逗号连接的字符串
export const getUrl = (fileList) => {
  const tempArr = []
  for (let i in fileList) {
    tempArr.push(fileList[i].response)
  }
  return tempArr.join(',')
}

// 将传入的options，根据传入的配置，生成符合Select规则的Option
export const formatParentIdOptions = ({ options, id, hasDefaultOption = true, valueKey = 'id', labelKey = 'name' }) => {
  const newOptions = []
  for (let i in options) {
    if (id && options[i].id === id) {
      continue;
    }
    const newOption = {
      value: options[i][valueKey],
      label: options[i][labelKey]
    }
    newOptions.push(newOption)
  }
  if (hasDefaultOption) {
    newOptions.unshift({
      value: 0,
      label: '无'
    })
  }
  return newOptions
}
/**
 * 根据传入的对象和key值将对象扁平化
 * @param {Object} objArr 
 * @param {Array} keyArr 
 * @returns {Array} 返回一个对象（扁平化）数组
 */
export const flattenObj = (objArr, keyArr) => {
  let newArr = []
  for (let j = 0, arrLength = objArr.length; j < arrLength; j++) {
    let newObj = { ...objArr[j] };
    for (let i = 0, length = keyArr.length; i < length; i++) {
      const item = objArr[j][keyArr[i]]
      if (is.object(item)) {
        newObj = { ...newObj, ...item }
        delete newObj[keyArr[i]]
      }
    }
    newArr.push(newObj)
  }
  return newArr
}
// react组件函数绑定作用域，
/**
 * 
 * @param {Array} bindArr 
 * @param {Object} context 
 * eg: ['onInit',{key: 'Request',value: ['search']}]
 * equal: this.onInit = this.onInit.bind(this)
 * this.Request.search = this.Request/search.bind(this)
 */
export const bindFunc = function f(bindArr, context) {
  if (is.undefined(bindArr)) {
    throw new Error(`参数bindArr不能为空`)
  }
  if (is.undefined(context)) {
    throw new Error(`参数context不能为空`)
  }
  for (let i in bindArr) {
    const bindItem = bindArr[i]
    if (is.object(bindItem)) {
      f(bindItem.value, context[bindItem.key])
    } else if (is.string(bindItem)) {
      if (is.undefined(context[bindItem])) {
        throw new Error(`函数名${bindItem}在context中未定义`)
      }
      context[bindItem] = context[bindItem].bind(context)
    } else {
      throw new Error(`传入参数${bindItem}错误，参数类型应为Object或String`)
    }
  }
}
/**
 * 对请求获得的表格数据进行处理，符合ant design Table数据要求
 */
export const formatData = (data, uniqueKey = 'id') => {
  if (!is.array(data)) {
    throw new Error(`函数formatData传入的参数必须为Array，您传入的参数为${is(data)}`)
  }
  const arr = Object.assign([], data)
  for (let i in arr) {
    const id = hasAttr(arr[i], uniqueKey);
    if (id) {
      arr[i].key = id
    } else {
      arr[i].key = new Date().getTime() + i
    }
  }
  return arr
}
// 获取表单输入域的配置
export const getFormItem = (key, formItems) => {
  for (let i in formItems) {
    if (formItems[i].key === key) {
      return formItems[i]
    }
  }
}
// 对表单保存的结果进行处理
export const formatFormData = (values, formItems, fn) => {
  const obj = Object.assign({}, values)
  for (let key in obj) {
    const formItem = getFormItem(key, formItems)
    if (is.undefined(formItem)) {
      continue;
    }
    if (FormDataStragety[formItem.type]) {
      FormDataStragety[formItem.type](obj, key, formItem)
    }
  }
  // 用户自定义处理obj
  if (is.function(fn)) {
    fn(obj)
  }

  return obj
}

// 对传入表单的初始数据进行处理
export const formateEditData = (record, formItems, fn) => {
  const obj = Object.assign({}, record)
  for (let key in obj) {
    const formItem = getFormItem(key, formItems)
    // 如果下拉框的值不是String，则强制转换成String（ant design中Select只接受String）
    if (is.undefined(formItem)) {
      continue;
    }
    if (EditDataStragety[formItem.type]) {
      EditDataStragety[formItem.type](obj, key, formItem)
    }
  }
  // 用户自定义处理obj
  if (is.function(fn)) {
    fn(obj)
  }
  // console.log(obj)
  return obj
}


// 将传入的value强转换为字符串的value
export const toString = (value) => {
  if (!is.undefined(value)) {
    return Object.prototype.toLocaleString.call(value)
  }
  return value
}
// 将传入的value强转换为数字类型的value
export const toNumber = (value) => {
  if (!isNaN(value)) {
    return Number(value)
  }
  return value || 0
}
export const handleStartTime = (startTime) => {
  if (moment.isMoment(startTime)) {
    startTime.set('hour', 0)
    startTime.set('minute', 0)
    startTime.set('second', 0)
  }
  return startTime
}
export const handleEndTime = (endTime) => {
  if (moment.isMoment(endTime)) {
    endTime.set('hour', 23)
    endTime.set('minute', 59)
    endTime.set('second', 59)
  }
  return endTime
}
// 将表单数据按照不同type进行处理
const FormDataStragety = {
  [EditType.Select]: (obj, key, formItem) => {
    if (!is.undefined(obj[key]) && is.string(obj[key])) {
      if (formItem.isNum || formItem.isSelectNum) {
        obj[key] = toNumber(obj[key])
      }
    }
  },
  [EditType.Switch]: (obj, key, formItem) => {
    if (formItem.isNum || formItem.isSwitchNum) {
      obj[key] = toNumber(obj[key] || 0)
    }
  },
  [EditType.DatePicker]: (obj, key, formItem) => {
    if (obj[key] && is.function(obj[key].format)) {
      obj[key] = obj[key] && is.function(obj[key].format) && obj[key].format('x')
    }
  },
  [EditType.TimePicker]: (obj, key, formItem) => {
    if (obj[key] && is.function(obj[key].format)) {
      obj[key] = obj[key] && is.function(obj[key].format) && obj[key].format('x')
    }
  },
  [EditType.RangePicker]: (obj, key, formItem) => {
    const temp = Object.assign([], obj[key])
    // let startTime = hasAttr(temp, [0, 'format']) && is.function(temp[0].format) && temp[0] 
    // let endTime = hasAttr(temp, [1, 'format']) && is.function(temp[0].format) && temp[1]
    // if(startTime && endTime) {

    // }
    obj[key] = [
      (hasAttr(temp, [0, 'format']) && is.function(temp[0].format) && temp[0].format('YYYY-MM-DD')) || undefined,
      (hasAttr(temp, [1, 'format']) && is.function(temp[0].format) && temp[1].format('YYYY-MM-DD')) || undefined,
    ]
    obj[key] = obj[key].join(',')
  },
  [EditType.InputNum]: (obj, key, formItem) => {
    if (formItem.isNum === true || formItem.isInputNum === true) {
      if (obj[key] && formItem.numKey) {
        for (let i in formItem.numKey) {
          const numKey = formItem.numKey[i];
          obj[key][numKey] = Math.round(obj[key][numKey] && obj[key][numKey] * 100) || 0
        }
      } else {
        obj[key] = Math.round(obj[key] && obj[key] * 100) || 0
      }
    }
  },
  [EditType.Image]: (obj, key, formItem) => {
    if (is.array(obj[key]) && formItem.isImageAutoHandle !== false) {
      obj[key] = getUrl(obj[key])
    }
  }
  // to be continue...
}

// 将传入表单的数据按照type进行处理
const EditDataStragety = {
  [EditType.Select]: (obj, key, formItem) => {
    if (!is.undefined(obj[key]) && !is.string(obj[key])) {
      obj[key] = toString(obj[key])
    }
  },
  [EditType.Switch]: (obj, key, formItem) => {
    obj[key] = Boolean(obj[key])
  },
  [EditType.DatePicker]: (obj, key, formItem) => {
    obj[key] = obj[key] && moment(obj[key], 'x')
  },
  [EditType.TimePicker]: (obj, key, formItem) => {
    obj[key] = obj[key] && moment(obj[key], 'x')
  },
  [EditType.RangePicker]: (obj, key, formItem) => {
    const temp = obj[key].split(',')
    obj[key] = [
      (hasAttr(temp, 0) && moment(temp[0], 'YYYY-MM-DD')) || undefined,
      (hasAttr(temp, 1) && moment(temp[1], 'YYYY-MM-DD')) || undefined,
    ]
  },
  [EditType.InputNum]: (obj, key, formItem) => {
    if (formItem.isInputNum === true) {
      if (formItem.numKey) {
        for (let i in formItem.numKey) {
          const numKey = formItem.numKey[i];
          obj[key][numKey] = (obj[key][numKey] && obj[key][numKey] / 100) || 0
        }
      } else {
        obj[key] = (obj[key] && obj[key] / 100) || 0
      }
    }
  },
  [EditType.Image]: (obj, key, formItem) => {
    if (formItem.isImageAutoHandle !== false) {
      obj[key] = (obj[key] && obj[key].trim() && getFileList(obj[key].trim())) || []
    }
  }
  // to be continue...
}


// 去除传入数据中的双引号
export const delArrMark = (strarr) => {
	  let newArr = null;
	  var str = strarr.toString().replace(/"([^"]*)"/g, "$1");
	  newArr = str;
	  return newArr
}
