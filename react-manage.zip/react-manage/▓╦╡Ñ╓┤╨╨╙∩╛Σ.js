// 红包列表
this.Action.evalCode({ status: 1, num: 1, pid: 0, code: '21', url: '/redPacket', uri: '/system/redPacket', name: '红包列表', icon: 'red-envelop', isMenu: 1 })
// 子公司
this.Action.evalCode({ status: 1, num: 1, pid: 0, code: '19', url: '/subsidiary', uri: '', name: '子公司管理', icon: 'usergroup-add', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 264, code: '1904', url: '/subsidiary/pay', uri: '/system/subsidiary', name: '给子公司打款', isMenu: 1 })
// 数据校验
this.Action.evalCode({ status: 1, num: 1, code: '20', icon: 'pie-chart', url: '/validateFund', uri: '/system/validate', name: '数据校验', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 269, code: '2001', url: '/validateFund/validateAll', uri: '/system/validate', name: '总数据校验', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 269, code: '2002', url: '/validateFund/validateList', uri: '/system/validaterecord', name: '每日数据校验列表', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 269, code: '2003', url: '/validateFund/validateDetail', uri: '/system/validateinfo', name: '每日数据校验详情', isMenu: 1 })
// 导出数据
this.Action.evalCode({ status: 1, num: 4, pid: 0, code: '22', url: '/exportData', uri: '/system/export', name: '导出数据', icon: 'download', isMenu: 1 })
// 单条消息编辑
this.Action.evalCode({ status: 1, num: 4, pid: 216, code: '1005', url: '/message/singleMsgList', uri: '/system/message,/system/file,/system/officialaccounts,/system/merchant', name: '单条消息编辑', isMenu: 1 })
// 区块链积分
this.Action.evalCode({ status: 1, num: 5, code: '23', icon: 'bank', url: '/integral', uri: '', name: '区块链积分', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 287, code: '2301', url: '/integral/integralAudit', uri: '/system/integral', name: '积分联盟申请表', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 287, code: '2302', url: '/integral/purchase', uri: '/system/integral', name: '积分申购', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 287, code: '2303', url: '/integral/refund', uri: '/system/integral', name: '积分兑换', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 287, code: '2304', url: '/integral/cashierPurchase', uri: '/system/gateway', name: '收银台充值', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 287, code: '2305', url: '/integral/cashierExchange', uri: '/system/gateway', name: '收银台提现', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 287, code: '2306', url: '/integral/gameCard', uri: '/system/gamecard', name: '游戏卡列表', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 287, code: '2307', url: '/integral/transfer', uri: '/system/gateway', name: '积分转赠', isMenu: 1 })

// 生活缴费
this.Action.evalCode({ status: 1, num: 6, code: '24', icon: 'wallet', url: '/lifePay', uri: '/system/life', name: '生活缴费', isMenu: 1 })

// 单店商城
this.Action.evalCode({ status: 1, num: 7, code: '25', icon: 'shop', url: '/mall', uri: '', name: '单店商城', isMenu: 1 })
this.Action.evalCode({ pid: 287, status: 1, num: 1, code: '2501', url: '/mall/goods', uri: '/system/shop,/system/file', name: '商品管理', isMenu: 1 })
this.Action.evalCode({ pid: 287, status: 1, num: 1, code: '2502', url: '/mall/order', uri: '/system/shop', name: '订单管理', isMenu: 1 })
this.Action.evalCode({ pid: 287, status: 1, num: 1, code: '2503', url: '/mall/orderDetail', uri: '/system/shop,/system/order', name: '订单详情', isMenu: 1 })
this.Action.evalCode({ pid: 287, status: 1, num: 1, code: '2504', url: '/mall/returnManage', uri: '/system/shop,/system/enums', name: '退货管理', isMenu: 1 })
// 财务管理操作类型
this.Action.evalCode({ pid: 246, status: 1, num: 1, code: '1705', url: '/finance/actionType', uri: '', name: '打款操作类型', isMenu: 1 })
// 审核管理
this.Action.evalCode({ status: 1, num: 8, code: '26', icon: 'edit', url: '/application', uri: '', name: '审核管理', isMenu: 1 })
this.Action.evalCode({ pid: 293, status: 1, num: 1, code: '2601', url: '/application/realname', uri: '/system/userauditor,/system/file', name: '实名审核', isMenu: 1 })
this.Action.evalCode({ pid: 293, status: 1, num: 1, code: '2605', url: '/application/dyRealname', uri: '/system/userauditor,/system/file', name: '达雍实名审核', isMenu: 1 })
this.Action.evalCode({ pid: 293, status: 1, num: 1, code: '2602', url: '/application/integral', uri: '/system/integral', name: '积分联盟审核', isMenu: 1 })
this.Action.evalCode({ pid: 293, status: 1, num: 1, code: '2603', url: '/application/refund', uri: '/system/refund', name: '运营退款审核', isMenu: 1 })
this.Action.evalCode({ pid: 293, status: 1, num: 1, code: '2604', url: '/application/financeRefund', uri: '/system/refund', name: '财务退款审核', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 293, code: '2606', url: '/application/convertibilityUser', uri: '', name: '用户积分兑换审核', isMenu: 1 })

// 资金流水
this.Action.evalCode({ status: 1, num: 1, pid: 212, code: '0905', url: '/fundRecord/pay', uri: '/system/proxypay,/system/enums', name: '代付管理', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 212, code: '0906', url: '/fundRecord/convertibilityUser', uri: '/system/integral', name: '用户积分兑换', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 212, code: '0907', url: '/fundRecord/withdrawSimple', uri: '/system/withdraw,/system/enums', name: '查看提现记录', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 212, code: '0908', url: '/fundRecord/discriminatingView', uri: '/system/userCardApply', name: '银行卡鉴权查看', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 212, code: '0908', url: '/fundRecord/shuangqianwithdraw', uri: '/system/userCardApply', name: '双乾提现记录', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 212, code: '0909', url: '/fundRecord/dywithdraw', uri: '/system/withdraw,/system/enums,/system/file,/system/gateway', name: '手工提现', isMenu: 1 })

//账户中心
this.Action.evalCode({ status: 1, num: 1, pid: 201, code: '0709', url: '/accountCenter/worldList', uri: '/system/appealmessage', name: '留言回复', isMenu: 1 })

//火车票
this.Action.evalCode({ status: 1, num: 1, pid: 0, code: '090', url: '/Traintickets', uri: '/common/getEnumeByClassName,/common/getchannellist,/train/order', name: '火车票', icon: 'car', isMenu: 1 })

//第三方功能
this.Action.evalCode({ status: 1, num: 1, code: '3001', url: '/ThirdParty', icon:'appstore-o', name: '第三方功能', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 308, code: '3002', url: '/ThirdParty/refuelingCard', uri: '/system/oil' ,  name: '加油卡', isMenu: 1 })
this.Action.evalCode({ status: 1, num: 1, pid: 308, code: '3003', url: '/ThirdParty/Traintickets', uri: '/common/getEnumeByClassName,/common/getchannellist,/train/order', name: '火车票', isMenu: 1 })



